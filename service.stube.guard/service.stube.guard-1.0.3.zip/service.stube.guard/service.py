import xbmc
import xbmcgui
import json

EXPECTED_PACKAGE = "stube.box.legacy"
EXPECTED_KODI_MAJOR = 21
COUNTDOWN_SECONDS = 5

TITLE = "Falsche App"
MESSAGE_MAIN = "Hallo, nur mit der originalen NOVA App :) tschüssss"
TAXI_YELLOW = "FFC58A00"

def enforce_global_update_lock():
    try:
        request = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": "general.addonupdates",
                "value": 2
            },
            "id": 1
        }
        xbmc.executeJSONRPC(json.dumps(request))
    except Exception:
        pass

def show_nova_update_start_notice():
    try:
        xbmcgui.Window(10000).setProperty("FireXUpdater.EarlyNotice", "1")
        xbmcgui.Dialog().notification(
            "Nova Updates",
            "[COLOR %s][B]Nova Updates werden geprüft.[/B][/COLOR]" % TAXI_YELLOW,
            xbmcgui.NOTIFICATION_INFO,
            7000,
            False
        )
    except Exception:
        pass

def get_android_process_name():
    try:
        with open("/proc/self/cmdline", "rb") as f:
            raw = f.read(256)
        proc = raw.split(b"\x00", 1)[0].decode("utf-8", "ignore").strip()
        return proc
    except Exception:
        return ""

def get_kodi_major_version():
    s = xbmc.getInfoLabel("System.BuildVersion") or ""
    try:
        major_str = s.split(".", 1)[0].strip()
        return int(major_str) if major_str.isdigit() else None
    except Exception:
        return None

def quit_with_countdown(reason):
    xbmcgui.Dialog().ok(TITLE, MESSAGE_MAIN)

    for remaining in range(COUNTDOWN_SECONDS, 0, -1):
        xbmcgui.Dialog().notification(
            TITLE,
            f"Kodi wird in {remaining} Sekunden beendet.",
            xbmcgui.NOTIFICATION_WARNING,
            900
        )
        xbmc.sleep(1000)

    xbmc.executebuiltin("Quit")

def run_checks():
    enforce_global_update_lock()
    show_nova_update_start_notice()

    proc = get_android_process_name()
    if proc != EXPECTED_PACKAGE:
        quit_with_countdown(f"Falscher Paketname ({proc or 'unbekannt'})")
        return

    major = get_kodi_major_version()
    if major != EXPECTED_KODI_MAJOR:
        quit_with_countdown(f"Falsche Kodi-Version ({major if major is not None else 'unbekannt'})")
        return

run_checks()
