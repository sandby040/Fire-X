"""Local Kodi resolution of an ALREADY signed live stream; no network calls.

Kodi 21.0's DirectoryFactory creates a fresh playlist item for .m3u8 and loses
the supplied MIME/ContentLookup flag. Its MIME Stat blocks the GUI thread.
The local plugin path has no .m3u8 extension. Kodi resolves its dynamic path
AFTER that factory check, retaining the ORIGINAL provider ListItem/properties.
"""
import re
import time
from urllib.parse import urlsplit

from livetv1_auto_core import ACTIVE, PREFIX, PROVIDERS, read
from livetv1_trace import Trace, url_info

CANCEL_OWNER = 'LiveTV1.Auto.CancelOwner'


def native_mime(item):
    base = item.getPath().partition('|')[0]
    if (urlsplit(base).path.lower().endswith('.m3u8') or '/hls/' in base.lower()
            or item.getProperty('inputstream.ffmpegdirect.manifest_type') == 'hls'):
        return 'application/vnd.apple.mpegurl'
    if urlsplit(base).path.lower().endswith('.ts'):
        return 'video/mp2t'
    return ''


def plugin_path(ticket):
    if not re.fullmatch(r'[0-9a-f]{32}', ticket):
        raise ValueError('invalid handoff ticket')
    return 'plugin://plugin.video.iptvmaster/?action=livetv1_native_handoff&ticket=' + ticket


def authorized(window, ticket, clock=time.monotonic):
    if not re.fullmatch(r'[0-9a-f]{32}', ticket or ''):
        return None
    prop = PREFIX + ticket
    request = read(window, prop)
    value = read(window, prop + '.result')
    owner = request.get('owner')
    if (not owner or request.get('ticket') != ticket
            or request.get('provider') not in PROVIDERS.values()
            or request.get('kind') != 'resolve'
            or window.getProperty(ACTIVE) != owner
            or window.getProperty(CANCEL_OWNER) == owner
            or window.getProperty(prop + '.play') != ticket
            or window.getProperty(prop + '.cancel') == ticket
            or float(request.get('deadline', 0)) <= clock()
            or value.get('ticket') != ticket
            or value.get('state') not in ('resolved', 'playing')
            or value.get('mime') not in ('application/vnd.apple.mpegurl', 'video/mp2t')
            or urlsplit(value.get('path', '').partition('|')[0]).scheme not in ('http', 'https')):
        return None
    return value


def resolve(ticket, handle):
    import xbmc
    import xbmcgui
    import xbmcplugin
    window = xbmcgui.Window(10000)
    request = read(window, PREFIX + ticket)
    trace = Trace(request.get('owner', ''), ticket, request.get('provider', ''))
    trace.emit('handoff_plugin_enter')
    value = authorized(window, ticket)
    if value:
        item = xbmcgui.ListItem(path=value['path'])
        item.setMimeType(value['mime'])
        item.setContentLookup(False)
        # GetPluginResult merges into the ORIGINAL native provider item.
        # Its inputstream/codec/HTTP properties are not reconstructed here.
        if authorized(window, ticket) == value:
            xbmc.log('[Live TV 1] AUTO local native handoff resolved: no HTTP HEAD, no new authentication', xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, item)
            trace.emit('handoff_plugin_resolved', mime=value['mime'], **url_info(value['path']))
            return
    xbmc.log('[Live TV 1] AUTO local native handoff denied: cancelled, expired or superseded', xbmc.LOGINFO)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    trace.emit('handoff_plugin_denied')
