"""Dismiss ONLY Kodi's standard playback-error OK for our active attempt.

Never close all dialogs or send a generic OK key: installation, yes/no, input
and other addons' prompts must stay interactive.
"""
import re
import importlib.util
import os

_policy = None


def _shared_policy():
    global _policy
    if _policy is None:
        import xbmcaddon
        import xbmcvfs
        folder = xbmcvfs.translatePath(xbmcaddon.Addon('service.stoponback').getAddonInfo('path'))
        spec = importlib.util.spec_from_file_location('nova_shared_playback_dialogs',
                                                    os.path.join(folder, 'nova_playback_dialogs.py'))
        policy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(policy)
        _policy = policy
    return _policy


def normalized(value):
    return ' '.join(re.sub(r'\[/?(?:COLOR[^\]]*|B|I|U)\]', '', str(value or ''),
                           flags=re.I).split()).casefold()


def dismiss_playback_error(xbmc, xbmcgui, owns_attempt):
    try:
        if not owns_attempt():
            return False
        return _shared_policy().dismiss(xbmc, xbmcgui, owns_attempt)
    except Exception:
        return False
