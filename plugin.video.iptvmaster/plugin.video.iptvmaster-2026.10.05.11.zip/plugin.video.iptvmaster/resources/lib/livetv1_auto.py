"""One cancellable foreground operation; sequential native-source fallback."""
import sys
import time
import uuid
import threading

from livetv1_auto_core import (ACTIVE, PREFIX, PROVIDERS, RESOLVE_SECONDS,
                              TOTAL_SECONDS, MIN_SOURCE_GAP_SECONDS,
                              Rotation, read, write, playable_sources, rotated,
                              numbered_sources,
                              migrate_group_cursor, local_json, same_path,
                              expand_vod_group, is_vod_group)
from livetv1_error_dialog import dismiss_playback_error
from livetv1_transport_stop import TRANSPORT, STARTED, CANCELLED, request_cancel, released
from livetv1_cancel import PlayerSnapshot, progress_window
from livetv1_handoff import CANCEL_OWNER
from livetv1_trace import Trace


def run(key, owner):
    import os
    import xbmc
    import xbmcgui
    import xbmcvfs
    from livetv1_sources import load
    window = xbmcgui.Window(10000)
    if window.getProperty(ACTIVE) != owner:
        window.clearProperty('LiveTV1.Auto.Row.' + owner)
        return
    retiring_ticket = request_cancel(window)
    addon_path = xbmcvfs.translatePath('special://home/addons/plugin.video.iptvmaster')
    row = load(addon_path).channels.get(key)
    runtime_row = read(window, 'LiveTV1.Auto.Row.' + owner)
    window.clearProperty('LiveTV1.Auto.Row.' + owner)
    if not row and runtime_row.get('key') == key:
        row = runtime_row.get('row')
    if not row:
        return
    monitor = xbmc.Monitor()
    cancel_event = threading.Event()
    overall_deadline = time.monotonic() + TOTAL_SECONDS
    pending = ''
    reason = ''
    success = False
    stop_ack = threading.Event()
    stop_thread = None
    trace = Trace(owner)
    trace.context.update(channel=row['name'], country=row.get('country', ''))

    class Observer(xbmc.Player):
        expected = ''
        available = False
        failed = False
        cancelled = False
        armed = False
        stopping = False
        stop_failed = False
        stopped_at = None
        armed_at = 0.0
        av_seen = ''

        def current(self):
            return player_snapshot.value[0]

        def owned(self):
            path, sampled_at = player_snapshot.value
            return (window.getProperty(ACTIVE) == owner and sampled_at >= self.armed_at
                    and same_path(path, self.expected))

        def event_owned(self):
            current = self.current()
            return self.armed and window.getProperty(ACTIVE) == owner and (
                not current or same_path(current, self.expected))

        def onAVStarted(self):
            trace.emit('callback_av_started', armed=self.armed)
            if self.armed and window.getProperty(ACTIVE) == owner:
                self.av_seen = self.expected

        def onPlayBackError(self):
            trace.emit('callback_playback_error', armed=self.armed)
            if self.event_owned():
                self.failed = True

        def onPlayBackEnded(self):
            trace.emit('callback_playback_ended', armed=self.armed)
            if self.event_owned():
                self.failed = True

        def onPlayBackStopped(self):
            trace.emit('callback_playback_stopped', armed=self.armed, stopping=self.stopping)
            if not self.stopping and not self.failed and self.event_owned():
                # Native error+stopped messages may precede the rendered OK or
                # worker failure by a frame. Keep a brief classification grace.
                self.stopped_at = time.monotonic()

    observer = Observer()
    def sample_playing_path():
        is_playing = getattr(observer, 'isPlaying', None)
        if callable(is_playing) and not is_playing():
            return ''
        return observer.getPlayingFile()

    player_snapshot = PlayerSnapshot(sample_playing_path)

    def invalidate_pending():
        if pending:
            window.clearProperty(pending + '.play')
            payload = read(window, pending)
            if payload.get('owner') == owner:
                payload['deadline'] = 0
                write(window, pending, payload)
                window.setProperty(pending + '.cancel', pending[len(PREFIX):])

    def cancel_now():
        if cancel_event.is_set():
            return
        cancel_event.set()
        trace.emit('cancel_accepted')
        invalidate_pending()
        # An old dialog must NEVER stop a newer channel/addon.
        if window.getProperty(ACTIVE) == owner:
            observer.stopping = True
            request_cancel(window)
            if observer.armed or (pending and window.getProperty(pending + '.handoff')):
                request_stop()
            window.clearProperty(ACTIVE)
        xbmc.log('[Live TV 1] AUTO cancellation accepted: worker permission withdrawn; no next source',
                 xbmc.LOGINFO)

    progress = progress_window(xbmcgui, addon_path, cancel_now, owner=owner, window=window)

    def fast_cancelled():
        return (cancel_event.is_set() or window.getProperty(ACTIVE) != owner
                or window.getProperty(CANCEL_OWNER) == owner
                or monitor.abortRequested() or progress.iscanceled() or observer.cancelled)

    def cancelled():
        # Input first. Never put player/GUI queries in front of this check.
        if fast_cancelled():
            cancel_now()
            return True
        # Kodi's error OK can block its own stopped/error callback delivery.
        # Dismiss it before interpreting a stopped callback as a user action.
        if observer.armed and window.getProperty(ACTIVE) == owner:
            trace.mark('error_dialog_check')
            dismissed = dismiss_playback_error(xbmc, xbmcgui, lambda:
                observer.event_owned() and not observer.available)
            trace.mark('controller_poll')
            result = read(window, pending + '.result') if pending else {}
            if dismissed or result.get('state') == 'failed':
                observer.failed = True
                observer.cancelled = False
                observer.stopped_at = None
            elif observer.stopped_at is not None and time.monotonic() - observer.stopped_at >= 0.15:
                observer.cancelled = True
        if observer.cancelled:
            cancel_now()
        return fast_cancelled()

    def wait(interval=0.05):
        monitor.waitForAbort(interval)
        return not cancelled()

    def cleanup(prop):
        for suffix in ('', '.result', '.play', '.done', '.cancel', '.handoff', '.released'):
            window.clearProperty(prop + suffix)

    def worker(source, deadline, kind='resolve'):
        nonlocal pending
        ticket = uuid.uuid4().hex
        trace.ticket = ticket[:12]
        trace.emit('worker_launch', provider=source['provider'], kind=kind,
                   remaining_ms=int((deadline-time.monotonic())*1000))
        pending = PREFIX + ticket
        provider = PROVIDERS[source['provider']]
        write(window, pending, {
            'owner': owner, 'ticket': ticket, 'provider': provider,
            'url': source['url'], 'label': row['name'], 'country': row['country'],
            'kind': kind, 'deadline': min(deadline, overall_deadline),
            'diagnostic_number': trace.context.get('number', 0),
            'diagnostic_total': trace.context.get('total', 0),
        })
        xbmc.executebuiltin('RunScript(special://home/addons/%s/codex_livetv1_worker.py,%s)' %
                            (provider, ticket))
        return ticket

    def wait_result(ticket, deadline):
        while not cancelled():
            value = read(window, pending + '.result')
            if value.get('ticket') == ticket and value.get('state') in ('catalog', 'resolved', 'failed'):
                return value
            if time.monotonic() >= min(deadline, overall_deadline):
                return {'state': 'failed', 'reason': 'timeout'}
            wait()
        return {'state': 'failed', 'reason': 'cancelled'}

    def release_worker(ticket):
        # Invalidate request BEFORE advancing. A late native result cannot play.
        window.clearProperty(pending + '.play')
        payload = read(window, pending)
        payload['deadline'] = 0
        write(window, pending, payload)
        until = time.monotonic() + 4
        while window.getProperty(pending + '.done') != ticket:
            if time.monotonic() >= until or cancelled():
                return False
            wait()
        cleanup(pending)
        return True

    def request_stop():
        """Main-thread barrier in a helper, never block the controller/UI."""
        nonlocal stop_thread
        if stop_thread and stop_thread.is_alive():
            return
        stop_ack.clear()
        trace.emit('stop_queued')
        barrier_owner = uuid.uuid4().hex
        window.setProperty('LiveTV1.Auto.PlayerBarrier', barrier_owner)
        stopping_prop = pending
        stopping_ticket = request_cancel(window)
        def stop_and_ack():
            try:
                # Let the owning provider close FFmpeg's local HTTP sockets
                # BEFORE a synchronous Kodi Stop can take the GUI/player lock.
                if stopping_ticket:
                    until = time.monotonic() + 0.75
                    while (window.getProperty(CANCELLED + stopping_ticket) != stopping_ticket
                           and not released(window, stopping_ticket)
                           and time.monotonic() < until):
                        time.sleep(0.01)
                    trace.emit('stop_transport_cancel_ack',
                               success=(window.getProperty(CANCELLED + stopping_ticket) == stopping_ticket
                                        or released(window, stopping_ticket)))
                try:
                    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                except Exception:
                    pass
                # wait=True acknowledges completion, not just a queued command.
                trace.emit('stop_native_begin')
                xbmc.executebuiltin('PlayerControl(Stop)', True)
                trace.emit('stop_native_return')
                # A native handoff can have passed its last permission check
                # just before cancellation. Drain that worker while holding
                # the barrier, then acknowledge a final stop of its queued play.
                if cancel_event.is_set() and stopping_prop:
                    until = time.monotonic() + 4
                    warned = False
                    while (read(window, stopping_prop)
                           and not window.getProperty(stopping_prop + '.done')):
                        if time.monotonic() >= until and not warned:
                            xbmc.log('[Live TV 1] AUTO cancel drain pending; stop barrier retained', xbmc.LOGWARNING)
                            warned = True
                        if monitor.abortRequested():
                            return
                        time.sleep(0.025)
                    xbmc.executebuiltin('PlayerControl(Stop)', True)
                    cleanup(stopping_prop)
                stop_ack.set()
                trace.emit('stop_acknowledged')
                if window.getProperty('LiveTV1.Auto.PlayerBarrier') == barrier_owner:
                    window.clearProperty('LiveTV1.Auto.PlayerBarrier')
                    pending_player = read(window, 'LiveTV1.Auto.PendingPlayer')
                    if (not stopping_prop or pending_player.get('ticket') == stopping_prop[len(PREFIX):]):
                        window.clearProperty('LiveTV1.Auto.PendingPlayer')
            except Exception:
                xbmc.log('[Live TV 1] AUTO stop barrier failed', xbmc.LOGWARNING)
        stop_thread = threading.Thread(target=stop_and_ack, daemon=True)
        stop_thread.start()

    def stop_owned():
        trace.mark('stopping_owned_player')
        # Never stop another addon/channel selected after this operation.
        if pending and read(window, TRANSPORT).get('ticket') == pending[len(PREFIX):]:
            request_cancel(window)
        if window.getProperty(ACTIVE) != owner:
            return False
        if not observer.armed:
            return True
        observer.stopping = True
        if pending:
            window.setProperty(pending + '.cancel', pending[len(PREFIX):])
        request_stop()
        until = time.monotonic() + 6
        while True:
            current = observer.current()
            handed_off = pending and window.getProperty(pending + '.handoff')
            released = not handed_off or window.getProperty(pending + '.released') == handed_off
            if stop_ack.is_set() and not same_path(current, observer.expected) and released:
                break
            if time.monotonic() >= until or cancelled():
                observer.stopping = False
                observer.stop_failed = True
                trace.emit('stop_release_timeout', stop_ack=stop_ack.is_set())
                return False
            wait()
        observer.stopping = False
        observer.armed = False
        trace.mark('player_released')
        return True

    def stop_previous_player():
        nonlocal retiring_ticket
        retiring_ticket = request_cancel(window) or retiring_ticket
        # Always queue a stop: a cached empty path does not prove the player
        # is idle, and a synchronous getPlayingFile here can block cancellation.
        observer.stopping = True
        started = time.monotonic()
        request_stop()
        # Close the transport first; only inspect Kodi's player AFTER its stop
        # acknowledgement. getPlayingFile itself can block on the player lock.
        until = started + 10
        while True:
            # Catch a handoff published concurrently with the accepted click.
            retiring_ticket = request_cancel(window) or retiring_ticket
            is_stopped = False
            try:
                is_stopped = not observer.current()
            except Exception:
                is_stopped = True
            if stop_ack.is_set() and released(window, retiring_ticket) and is_stopped:
                break
            if released(window, retiring_ticket) and is_stopped and not window.getProperty('LiveTV1.Auto.PlayerBarrier'):
                break
            if time.monotonic() >= until or cancelled():
                observer.stopping = False
                observer.stop_failed = True
                return False
            wait()
        observer.stopping = False
        xbmc.log('[Live TV 1] AUTO pre-stop complete: name=%s elapsed_ms=%d' %
                 (row['name'], int((time.monotonic() - started) * 1000)), xbmc.LOGINFO)
        return True

    livetv1_icon = xbmcvfs.translatePath(
        'special://home/addons/plugin.video.iptvmaster/resources/media/nova.png'
    )
    if not os.path.exists(livetv1_icon):
        livetv1_icon = xbmcvfs.translatePath(
            'special://home/addons/plugin.video.iptvmaster/resources/media/livetv1.png'
        )
    if not os.path.exists(livetv1_icon):
        livetv1_icon = xbmcvfs.translatePath(
            'special://home/addons/plugin.video.mediabox.livetv/resources/icons/live_tv_1_user.png'
        )

    def notify(message, duration=2200):
        try:
            xbmcgui.Dialog().notification('Live TV 1', message, livetv1_icon, duration)
        except Exception:
            pass

    try:
        trace.start()
        trace.emit('operation_begin')
        player_snapshot.start()
        progress.create('Quelle wird geprüft')
        # A previous stop command can still be queued although getPlayingFile
        # is empty. Do not authorize a new start before that barrier completes.
        barrier_until = time.monotonic() + 6
        while window.getProperty('LiveTV1.Auto.PlayerBarrier'):
            if time.monotonic() >= barrier_until or cancelled():
                reason = 'Player wird noch beendet – bitte kurz warten'
                observer.stop_failed = True
                return
            wait()
        # Release immediately before resolving any new source.
        trace.mark('stopping_previous_player')
        if not stop_previous_player():
            reason = 'Player ist noch beschäftigt – bitte kurz warten'
            xbmc.log('[Live TV 1] AUTO pre-stop blocked: name=%s' % row['name'], xbmc.LOGWARNING)
            return
        enabled = {p for p, addon in PROVIDERS.items()
                   if xbmc.getCondVisibility('System.HasAddon(%s)' % addon)}
        # VODKOOL and Kodibox TV keep their own signing/resolve/play mechanics.
        # Ask the provider to load/build its OWN local unsigned group cache.
        # This also works after cache clearing and in foreign countries. The
        # catalog worker forbids network requests: no scan or authentication.
        vod_items = []
        if 'VODKOOL' in enabled:
            for group_source in row.get('sources', []):
                if not is_vod_group(group_source):
                    continue
                ticket = worker(group_source, time.monotonic() + 8, kind='catalog')
                catalog = wait_result(ticket, time.monotonic() + 8)
                if cancelled():
                    return
                expanded = expand_vod_group(row, group_source, catalog.get('group', {}))
                xbmc.log('[Live TV 1] AUTO local catalog: country=%s name=%s state=%s streams=%d reason=%s' %
                         (row.get('country'), row['name'], catalog.get('state'), len(expanded),
                          catalog.get('reason', '')), xbmc.LOGINFO)
                if not release_worker(ticket):
                    reason = 'Lokaler Quellenprozess noch aktiv – Start sicher beendet'
                    return
                pending = ''
                vod_items.extend(expanded)
        # A missing VOD cache must not block independently mapped KodiBox
        # streams. Never silently count an opaque group as one stream, either.
        playable_row = dict(row, sources=[s for s in row.get('sources', []) if not is_vod_group(s)])
        sources = numbered_sources(playable_sources(vod_items, playable_row, enabled))
        trace.emit('source_list_ready', total=len(sources))
        if not sources:
            reason = 'Keine lokalen Quellen verfügbar – bitte Senderliste aktualisieren'
            return
        rotation = Rotation(xbmcvfs.translatePath(
            'special://userdata/addon_data/plugin.video.iptvmaster/livetv1_auto_rotation.json'))
        last_attempt = migrate_group_cursor(sources, rotation.last(key), local_json(
            xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.vodkool/codex_live_rotation.json')))
        # Identity controls rotation; source numbers belong to the fixed full list.
        queue = rotated(sources, last_attempt)
        total_attempts = len(sources)
        source_index = 0
        while source_index < len(queue):
            source = queue[source_index]
            source_index += 1
            number = source['number']
            trace.context.update(provider=source['provider'], number=number, total=total_attempts)
            if cancelled():
                return
            if time.monotonic() >= overall_deadline:
                reason = 'Startsuche beendet – keine Quelle gestartet'
                break
            label = (source.get('label') or source['provider']).strip()
            status = 'Quelle %d von %d' % (number, total_attempts)
            percent = min(99, int((source_index - 1) * 100 / max(total_attempts, 1)))
            progress.update(percent, '%d / %d' % (number, total_attempts))
            trace.emit('source_attempt_begin')
            notify(status)
            rotation.remember(key, source)
            rotation.remember_position(key, source, total_attempts, 'attempted')
            observer.expected = ''
            observer.av_seen = ''
            observer.armed = observer.available = observer.failed = False
            observer.stopped_at = None
            xbmc.log('[Live TV 1] AUTO attempt: country=%s name=%s provider=%s label=%s source=%d/%d id=%s' %
                     (row.get('country', ''), row['name'], source['provider'], label,
                      number, total_attempts, source['id']), xbmc.LOGINFO)
            attempt_started = time.monotonic()
            attempt_deadline = min(attempt_started + RESOLVE_SECONDS, overall_deadline)
            ticket = worker(source, attempt_deadline)
            trace.mark('waiting_native_resolve')
            value = wait_result(ticket, attempt_deadline)
            trace.emit('resolve_result', state=value.get('state', ''), reason=value.get('reason', ''),
                       remaining_ms=int((attempt_deadline-time.monotonic())*1000))
            xbmc.log('[Live TV 1] AUTO resolve result: provider=%s state=%s reason=%s elapsed_ms=%d' %
                     (source['provider'], value.get('state', ''), value.get('reason', ''),
                      int((time.monotonic() - attempt_started) * 1000)), xbmc.LOGINFO)
            if value.get('state') == 'resolved' and value.get('path'):
                observer.expected = value['path']
                observer.armed_at = time.monotonic()
                observer.armed = True
                window.setProperty(pending + '.play', ticket)
                trace.mark('waiting_av_start')
                trace.emit('play_authorized')
                # One 15-second total budget includes resolve and Kodi AV start.
                until = min(attempt_deadline, overall_deadline)
                while not cancelled() and not observer.available and not observer.failed:
                    if time.monotonic() >= until:
                        break
                    current = observer.current()
                    if observer.av_seen == observer.expected and observer.owned():
                        observer.available = True
                        break
                    if (player_snapshot.value[1] >= observer.armed_at
                            and current and not same_path(current, observer.expected)):
                        observer.cancelled = True
                        break
                    wait()
                if observer.available and not cancelled():
                    success = True
                    # Persist beyond controller cleanup for the provider's
                    # transport. Only this observer verified ticket AND path.
                    window.setProperty(STARTED + ticket, ticket)
                    trace.emit('av_confirmed', elapsed_ms=int((time.monotonic()-attempt_started)*1000))
                    rotation.remember_position(key, source, total_attempts, 'started')
                    notify('Quelle %d von %d gestartet' %
                           (number, total_attempts), duration=3000)
                    xbmc.log('[Live TV 1] AUTO AV started: name=%s provider=%s source=%d/%d' %
                             (row['name'], source['provider'], number, total_attempts), xbmc.LOGINFO)
                    return
                if cancelled():
                    return
                failure = 'player-error' if observer.failed else 'no-av-start-15s'
                trace.emit('av_failed', reason=failure,
                           elapsed_ms=int((time.monotonic()-attempt_started)*1000),
                           av_seen=bool(observer.av_seen),
                           snapshot_age_ms=int((time.monotonic()-player_snapshot.value[1])*1000)
                           if player_snapshot.value[1] else -1)
                xbmc.log('[Live TV 1] AUTO player result: provider=%s reason=%s elapsed_ms=%d' %
                         (source['provider'], failure,
                          int((time.monotonic() - attempt_started) * 1000)), xbmc.LOGWARNING)
                # Withdraw permission first, then stop without blocking Kodi's UI.
                window.clearProperty(pending + '.play')
                if not stop_owned():
                    reason = 'Player ließ sich nicht freigeben – nächster Start abgebrochen'
                    break
            else:
                if cancelled():
                    return
                failure = value.get('reason', 'unavailable')
            rotation.remember_position(key, source, total_attempts, 'failed')
            trace.emit('source_attempt_failed', reason=failure, stop_ack=stop_ack.is_set(),
                       elapsed_ms=int((time.monotonic()-attempt_started)*1000))
            xbmc.log('[Live TV 1] AUTO next source: provider=%s label=%s reason=%s elapsed_ms=%d' %
                     (source['provider'], label, failure,
                      int((time.monotonic() - attempt_started) * 1000)), xbmc.LOGWARNING)
            if not release_worker(ticket):
                reason = 'Quellenprozess ist noch aktiv – Suche sicher beendet'
                break
            if source_index >= len(queue):
                reason = 'Keine Quelle konnte gestartet werden'
                break
            # Enforce at least two seconds between source starts, including fast failures.
            next_attempt_at = time.monotonic() + MIN_SOURCE_GAP_SECONDS
            while time.monotonic() < next_attempt_at:
                if not wait(min(0.1, next_attempt_at - time.monotonic())):
                    return
        if not reason:
            reason = 'Keine Quelle konnte gestartet werden'
    except Exception as exc:
        xbmc.log('[Live TV 1] AUTO stopped: exception=' + type(exc).__name__, xbmc.LOGWARNING)
        reason = 'Senderstart fehlgeschlagen'
    finally:
        trace.mark('controller_cleanup')
        trace.emit('cleanup_begin', success=success, reason=reason)
        was_cancelled = fast_cancelled()
        # Let the user leave immediately; cleanup/Stop must not keep the dialog
        # open. Never perform a blocking player query on this thread.
        if was_cancelled:
            cancel_now()
        if not success:
            invalidate_pending()
        progress.close()
        if not success and not was_cancelled and not observer.stop_failed:
            stop_owned()
        # The cancel stop helper drains an in-flight native handoff before
        # cleaning its properties; clearing them here would hide that race.
        if pending and not (was_cancelled and stop_thread and stop_thread.is_alive()):
            cleanup(pending)
        player_snapshot.close()
        if window.getProperty(ACTIVE) == owner:
            window.clearProperty(ACTIVE)
            if reason and not was_cancelled:
                # Keep technical reasons in the log, not in a long UI toast.
                xbmc.log('[Live TV 1] AUTO user retry: reason=' + reason, xbmc.LOGWARNING)
                notify('Bitte nochmal versuchen', duration=3500)
        trace.emit('operation_finished', success=success, reason=reason)
        trace.close()


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
