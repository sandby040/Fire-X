"""Passive, bounded diagnostics. No player queries, network, stop or retry."""
import hashlib
import json
import os
import re
import threading
import time
import uuid
from urllib.parse import urlsplit

MAX_BYTES = 1024 * 1024
# Retained for future diagnostics. Change only this switch to reactivate,
# then restart Nova. Explicit PC-test paths may still opt in locally.
WATCHDOG_ENABLED = False
CONTEXT_PROPERTY = 'LiveTV1.Diagnostics.PlayerContext'
FIELDS = set(('provider channel country kind number total state reason error stage '
              'elapsed_ms remaining_ms status bytes auth_requests transport mime '
              'scheme host url_id extension options inputstream manifest open_mode '
              'stream_mode armed owned stopping av_seen snapshot_age_ms stop_ack '
              'phase phase_ms source_ticket notification correlation success method content_type header_count protocols '
              'open_timeout_ms read_timeout_ms inflight').split())
_bound = None


def safe(value):
    if isinstance(value, (bool, int, float)) or value is None:
        return value
    text = str(value)
    if (re.search(r'(?:https?|plugin)://|(?:token|signature|authorization|cookie)\s*[=:]', text, re.I)
            or re.search(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}', text, re.I)):
        return '<redacted>'
    return text.replace('\r', ' ').replace('\n', ' ')[:180]


def url_info(url):
    """Hash even the path: some providers embed credentials there."""
    try:
        base, _, options = str(url).partition('|')
        parsed = urlsplit(base)
        extension = os.path.splitext(parsed.path)[1].lower()
        return dict(scheme=parsed.scheme, host=parsed.hostname or '',
                    url_id=hashlib.sha256(str(url).encode()).hexdigest()[:16],
                    extension=extension if re.fullmatch(r'\.[a-z0-9]{1,8}', extension) else '',
                    options=','.join(p.partition('=')[0] for p in options.split('&')
                                     if re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,40}', p.partition('=')[0])))
    except Exception:
        return {}


def item_info(item):
    try:
        return dict(inputstream=item.getProperty('inputstream'),
                    manifest=item.getProperty('inputstream.ffmpegdirect.manifest_type'),
                    open_mode=item.getProperty('inputstream.ffmpegdirect.open_mode'),
                    stream_mode=item.getProperty('inputstream.ffmpegdirect.stream_mode'),
                    protocols=item.getProperty('inputstream.ffmpegdirect.protocol_whitelist'),
                    **url_info(item.getPath()))
    except Exception:
        return {}


def append(path, record):
    """Non-waiting cross-process lock on Android; all logging failures are safe."""
    try:
        payload = (json.dumps(record, ensure_ascii=True, separators=(',', ':'))+'\n').encode()
        if len(payload) > 4096:
            return False
        os.makedirs(os.path.dirname(path), exist_ok=True)
        lock = os.open(path+'.lock', os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            try:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except ImportError:
                pass  # PC test runtime; Android has fcntl.
            except OSError:
                return False
            if os.path.exists(path) and os.path.getsize(path)+len(payload) > MAX_BYTES:
                if os.path.exists(path+'.1'):
                    os.replace(path+'.1', path+'.2')
                os.replace(path, path+'.1')
            fd = os.open(path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
            try:
                os.write(fd, payload)
            finally:
                os.close(fd)
        finally:
            os.close(lock)
        return True
    except Exception:
        return False


class Trace:
    def __init__(self, owner='', ticket='', provider='', path=None):
        self.op = hashlib.sha256((owner or uuid.uuid4().hex).encode()).hexdigest()[:12]
        self.ticket = ticket[:12]
        self.context = dict(provider=provider) if provider else {}
        self.started = time.monotonic()
        self.phase = ('initializing', self.started)
        self.finished = threading.Event()
        self.path = path

    @property
    def enabled(self):
        return (os.environ.get('NOVA_TRACE_DISABLE') != '1'
                and (WATCHDOG_ENABLED or self.path is not None))

    def mark(self, phase):
        self.phase = (phase, time.monotonic())

    def emit(self, event, **fields):
        try:
            if not self.enabled:
                return
            data = dict(self.context)
            data.update(fields)
            record = dict(ts=round(time.time(), 3), mono_ms=int(time.monotonic()*1000),
                          pid=os.getpid(), thread=threading.current_thread().name,
                          op=self.op, ticket=self.ticket, event=safe(event),
                          **{k:safe(v) for k,v in data.items() if k in FIELDS})
            path = self.path
            if path is None:
                import xbmcvfs
                path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.iptvmaster/diagnostics/live1_watchdog.jsonl')
            append(path, record)
            try:
                import xbmc
                xbmc.log('[LiveTV1-WATCH] '+json.dumps(record, separators=(',', ':')), xbmc.LOGINFO)
            except Exception:
                pass
        except Exception:
            pass

    def start(self, interval=5):
        def watch():
            while not self.finished.wait(interval):
                if not self.enabled:
                    return
                phase, since = self.phase
                self.emit('watchdog_wait', phase=phase,
                          phase_ms=int((time.monotonic()-since)*1000))
        try:
            if self.enabled:
                threading.Thread(target=watch, name='live1-passive-watch', daemon=True).start()
        except Exception:
            pass

    def close(self):
        self.finished.set()


def bind(trace):
    global _bound
    _bound = trace


def provider_event(provider, event, **fields):
    """Also usable by direct provider starts when Live TV 1 is installed."""
    global _bound
    if not WATCHDOG_ENABLED:
        return
    try:
        if _bound is None or (event.endswith('resolve_begin') and 'kind' not in _bound.context):
            _bound = Trace(provider=provider)
        _bound.emit(event, provider=provider, **fields)
    except Exception:
        pass


def player_notification(method, raw_data):
    if not WATCHDOG_ENABLED:
        return
    # Never query Player/getPlayingFile here: those locks can cause the hang.
    if method not in ('Player.OnPlay', 'Player.OnAVStart', 'Player.OnStop', 'Player.OnError'):
        return
    try:
        import xbmcgui
        window = xbmcgui.Window(10000)
        ctx = json.loads(window.getProperty(CONTEXT_PROPERTY) or '{}')
        if not ctx or time.time()-ctx.get('ts', 0) > 7200:
            return
        data = json.loads(raw_data or '{}')
        trace = Trace()
        trace.op = ctx['op']; trace.ticket = ctx.get('ticket', '')
        trace.context = {k:v for k,v in ctx.items() if k in FIELDS}
        trace.emit('kodi_notification', notification=method,
                   correlation='context-only', reason='ended' if data.get('end') else '')
    except Exception:
        pass
