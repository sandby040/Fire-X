"""Live TV 1 only: remote-input cancellation and non-blocking player samples."""
import threading
import time

from livetv1_auto_core import ACTIVE

DIALOG_OWNER = 'LiveTV1.Auto.CancelDialogOwner'
DIALOG_PROGRESS = 'LiveTV1.Auto.CancelDialogProgress'
DIALOG_SOURCE = 'LiveTV1.Auto.CancelDialogSource'


class PlayerSnapshot:
    """Never take Kodi's player lock on the input/controller thread.

    Kodi can hold that lock during a remote URL Stat/FFmpeg open. The single
    sampler may wait for it; cancellation and the 15-second timer must not.
    """
    def __init__(self, get_path):
        self.get_path = get_path
        self.value = ('', 0.0)
        self.finished = threading.Event()
        self.thread = threading.Thread(target=self._sample, daemon=True)

    def start(self):
        self.thread.start()

    def _sample(self):
        while not self.finished.is_set():
            try:
                path = self.get_path()
            except RuntimeError:
                path = ''  # Kodi's documented "not playing" exception.
            except Exception:
                if self.finished.wait(0.05):
                    return
                continue
            self.value = (path, time.monotonic())
            self.finished.wait(0.05)

    def close(self):
        # Do not join: a blocked native call is exactly what we are avoiding.
        self.finished.set()


def progress_window(xbmcgui, addon_path, cancel, owner='', window=None):
    """Capture remote actions only while this source-start dialog is open.

    No global keymap or dialog-OK auto-confirmation. Pointer motion is not a
    button press; navigation, OK, Back, Stop, etc. all cancel this operation.
    """
    class Progress(xbmcgui.WindowXMLDialog):
        dismissed = False
        cancelled = False

        def create(self, *args):
            self.setProperty('OperationOwner', owner)
            self.setProperty('SourceNumber', '')
            # Kodi's native busy dialog can become modal above this window.
            # Publish ONLY this dialog's owner/progress for its scoped button.
            if window is not None and window.getProperty(ACTIVE) == owner:
                window.setProperty(DIALOG_PROGRESS, '0')
                window.setProperty(DIALOG_SOURCE, '')
                window.setProperty(DIALOG_OWNER, owner)
            self.show()

        def onInit(self):
            self.setFocusId(100)

        def update(self, percent, source_number='', *args):
            if not self.dismissed:
                self.setProperty('SourceProgress', str(int(percent)))
                self.setProperty('SourceNumber', source_number)
                if window is not None and window.getProperty(DIALOG_OWNER) == owner:
                    window.setProperty(DIALOG_PROGRESS, str(int(percent)))
                    window.setProperty(DIALOG_SOURCE, source_number)

        def iscanceled(self):
            return self.cancelled

        def abort(self):
            if self.dismissed:
                return
            self.cancelled = True
            # Withdraw worker permissions and request stop BEFORE closing UI.
            cancel()
            self.close()

        def onAction(self, action):
            if action.getId() not in (0, 107):  # NONE / MOUSE_MOVE
                self.abort()

        def onClick(self, control_id):
            if control_id == 100:
                self.abort()

        def close(self):
            if not self.dismissed:
                self.dismissed = True
                # Never remove the state of a newer operation's dialog.
                if window is not None and window.getProperty(DIALOG_OWNER) == owner:
                    window.clearProperty(DIALOG_OWNER)
                    window.clearProperty(DIALOG_PROGRESS)
                    window.clearProperty(DIALOG_SOURCE)
                super().close()

    return Progress('LiveTV1Cancel.xml', addon_path, 'Default', '1080i')
