"""Migrate only Live TV 1's existing busy-overlay label, never a whole skin."""
import os
import tempfile
import xml.etree.ElementTree as ET

OLD_LABEL = '$INFO[Window(Home).Property(LiveTV1.Auto.CancelDialogProgress),,%]'
NEW_LABEL = '$INFO[Window(Home).Property(LiveTV1.Auto.CancelDialogSource)]'


def upgrade_counter(path):
    if not os.path.isfile(path):
        return False
    with open(path, 'rb') as handle:
        raw = handle.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        return False
    root = ET.fromstring(raw)
    overlay = root.find('.//control[@id="9100"]')
    if overlay is None:
        return False
    # Unknown skins/labels stay untouched. Already migrated is a no-op.
    labels = [node.text for node in overlay.iter('label')]
    old, new = OLD_LABEL.encode('utf-8'), NEW_LABEL.encode('utf-8')
    if labels.count(OLD_LABEL) != 1 or raw.count(old) != 1:
        return False
    changed = raw.replace(old, new, 1)
    ET.fromstring(changed)
    fd, temporary = tempfile.mkstemp(prefix='.livetv1-counter-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(changed)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return True
