import sys
import os


ADDON_PATH = os.path.dirname(os.path.abspath(__file__))
LIB_PATH   = os.path.join(ADDON_PATH, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from urllib.parse import parse_qsl

if __name__ == '__main__':
    # Resolve the already-signed native URL without loading catalogs/settings.
    params = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
    if params.get('action') == 'livetv1_native_handoff':
        from livetv1_handoff import resolve
        resolve(params.get('ticket', ''), int(sys.argv[1]))
    else:
        from main import Router
        Router(sys.argv).dispatch()
