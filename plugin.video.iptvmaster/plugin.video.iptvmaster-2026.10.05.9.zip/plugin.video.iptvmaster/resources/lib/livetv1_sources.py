"""Local source menu only. Each playable entry calls its native provider.

Do not resolve HTTP URLs or obtain a token in IPTV Master. Existing favourites
and render-cache URLs are upgraded in the directory, without deleting caches.
"""
import json
import hashlib
import os
from urllib.parse import parse_qsl, urlencode, urlsplit

ADDON = 'plugin.video.iptvmaster'
ACTION = 'livetv1_sources'
PROVIDERS = {'VODKOOL': 'plugin.video.vodkool', 'Kodibox TV': 'plugin.video.kodiboxtv'}


def source_url(key):
    return 'plugin://%s/?%s' % (ADDON, urlencode({'action': ACTION, 'key': key}))


def menu_key(url):
    parsed = urlsplit(url)
    if parsed.scheme == 'plugin' and parsed.netloc == ADDON:
        args = dict(parse_qsl(parsed.query))
        if args.get('action') == ACTION:
            return args.get('key', '')
    return ''


class SourceMap:
    def __init__(self, path):
        with open(path, encoding='utf-8-sig') as file:
            obj = json.load(file)
        if obj.get('schema') != 1 or not isinstance(obj.get('channels'), dict):
            raise ValueError('Invalid Live TV 1 source map')
        self.channels = obj['channels']
        self.originals = {source['url']: key for key, row in self.channels.items()
                          for source in row.get('sources', []) if source.get('provider') == 'VODKOOL'}

    def directory_url(self, url):
        """Return menu URL for only managed channels, including old favourites."""
        parsed = urlsplit(url)
        if parsed.scheme == 'plugin' and parsed.netloc == ADDON:
            args = dict(parse_qsl(parsed.query))
            if args.get('action') == ACTION:
                return url
            if args.get('action') == 'play_live':
                url = args.get('url', '')
        key = menu_key(url) or self.originals.get(url, '')
        if not key:
            parsed = urlsplit(url)
            args = dict(parse_qsl(parsed.query))
            action = args.get('action')
            if parsed.netloc == 'plugin.video.vodkool' and action in (
                    'codex_de_play_group', 'codex_country_play_group'):
                country = 'Germany' if action == 'codex_de_play_group' else args.get('country', '')
                if country and args.get('group'):
                    key = hashlib.sha256((country + '\n' + url).encode()).hexdigest()[:20]
                    self.channels[key] = {'name': args.get('label') or args['group'],
                        'country': country, 'logo': '', 'sources': [
                            {'provider': 'VODKOOL', 'url': url, 'label': 'VODKOOL'}]}
                    self.originals[url] = key
        return source_url(key) if key else ''


def load(addon_path):
    return SourceMap(os.path.join(addon_path, 'resources', 'data', 'livetv1_sources.json'))


def _icon():
    import xbmcvfs
    p = xbmcvfs.translatePath('special://home/addons/plugin.video.iptvmaster/resources/media/nova.png')
    if not os.path.exists(p):
        p = xbmcvfs.translatePath('special://home/addons/plugin.video.iptvmaster/resources/media/livetv1.png')
    return p


def launch(key, mapping):
    """Existing playlist/favourite URLs now launch one sequential operation."""
    import time
    import uuid
    import xbmc
    import xbmcgui
    from livetv1_auto_core import ACTIVE, read, write
    from livetv1_transport_stop import request_cancel
    if not mapping or key not in mapping.channels:
        xbmcgui.Dialog().notification('Live TV 1', 'Senderzuordnung fehlt', _icon(), 3500)
        return
    window = xbmcgui.Window(10000)
    last = read(window, 'LiveTV1.Auto.Click')
    if (window.getProperty(ACTIVE) and last.get('key') == key
            and 0 <= time.monotonic() - last.get('at', 0) < 2.5):
        return
    write(window, 'LiveTV1.Auto.Click', {'key': key, 'at': time.monotonic()})
    owner = uuid.uuid4().hex
    write(window, 'LiveTV1.Auto.Row.' + owner, dict(key=key, row=mapping.channels[key]))
    window.setProperty(ACTIVE, owner)
    request_cancel(window)
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.iptvmaster/'
                        'resources/lib/livetv1_auto.py,%s,%s)' % (key, owner))


def show(handle, key, mapping):
    import xbmc
    import xbmcgui
    import xbmcplugin
    row = mapping.channels.get(key)
    if not row:
        xbmcgui.Dialog().notification('Live TV 1', 'Senderzuordnung fehlt', _icon(), 3500)
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.setPluginCategory(handle, row['name'] + ' - Quellen')
    added = 0
    for source in row['sources']:
        provider = source.get('provider')
        addon_id = PROVIDERS.get(provider)
        target = urlsplit(source.get('url', ''))
        if not addon_id or target.scheme != 'plugin' or target.netloc != addon_id:
            continue
        if not xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
            continue
        label = source.get('label') or provider
        item = xbmcgui.ListItem(label)
        item.setArt({'thumb': row.get('logo', ''), 'icon': row.get('logo', '')})
        item.setInfo('video', {'title': row['name'] + ' - ' + label,
                              'plot': 'Wiedergabe durch ' + provider, 'mediatype': 'video'})
        folder = bool(source.get('folder'))
        item.setProperty('IsPlayable', 'false' if folder else 'true')
        xbmcplugin.addDirectoryItem(handle, source['url'], item, isFolder=folder)
        added += 1
    xbmc.log('[Live TV 1] Source menu: country=%s name=%s sources=%d'
             % (row['country'], row['name'], added), xbmc.LOGINFO)
    if not added:
        xbmcgui.Dialog().notification('Live TV 1', 'Quell-Add-ons nicht aktiviert', _icon(), 3500)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
