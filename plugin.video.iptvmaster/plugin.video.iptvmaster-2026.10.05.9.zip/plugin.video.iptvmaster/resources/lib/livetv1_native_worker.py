"""Runs in the selected provider's isolated Kodi script interpreter.

Native code creates the ListItem and signs/resolves the stream. We retain that
same item, never copy a token to another provider, never store final URLs on
disk. Controller must explicitly authorize playback of the current ticket.
"""
import os
import runpy
import sys
import time
import urllib.request
from urllib.parse import parse_qsl, urlsplit
import xml.etree.ElementTree as ET
import json
import zlib

from livetv1_auto_core import (ACTIVE, PREFIX, AttemptAborted, read, write,
                              player_options)
from livetv1_stream_gate import StreamGate
from livetv1_transport_stop import TransportLease
from livetv1_error_dialog import dismiss_playback_error


def dependency_paths(addon_id, seen=None):
    import xbmcaddon
    import xbmcvfs
    seen = set() if seen is None else seen
    if addon_id in seen:
        return
    seen.add(addon_id)
    addon = xbmcaddon.Addon(addon_id)
    path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    tree = ET.parse(os.path.join(path, 'addon.xml'))
    for extension in tree.findall('extension'):
        if extension.get('point') == 'xbmc.python.module':
            library = os.path.join(path, extension.get('library', ''))
            if library not in sys.path:
                sys.path.insert(0, library)
    for child in tree.findall('./requires/import'):
        dep = child.get('addon', '')
        if dep.startswith('script.module.'):
            try:
                dependency_paths(dep, seen)
            except (RuntimeError, OSError):
                if child.get('optional') != 'true':
                    raise


class Budget:
    def __init__(self, window, request, clock=time.monotonic):
        self.window, self.request, self.clock = window, request, clock
        self.auth_count = 0
        self.failed = False

    def check(self):
        if self.window.getProperty(ACTIVE) != self.request['owner']:
            raise AttemptAborted('cancelled')
        if not read(self.window, PREFIX + self.request['ticket']):
            raise AttemptAborted('cancelled')
        left = self.request['deadline'] - self.clock()
        if left <= 0 or self.failed:
            raise AttemptAborted('timeout' if not self.failed else 'unavailable')
        return max(0.1, min(3, left))

    def start(self, url):
        if self.request.get('kind') == 'catalog':
            raise AttemptAborted('catalog-network-forbidden')
        timeout = self.check()
        if '/ping' in urlsplit(url).path:
            self.auth_count += 1
            if self.auth_count > 1:
                raise AttemptAborted('auth-failed')
        return timeout

    def failure(self, url):
        self.failed = True
        raise AttemptAborted('auth-failed' if '/ping' in urlsplit(url).path else 'unavailable')


class Response:
    def __init__(self, response, budget, url):
        self.response, self.budget, self.url = response, budget, url

    def read(self, size=-1):
        chunks, length = [], 0
        try:
            while size < 0 or length < size:
                self.budget.check()
                part = self.response.read(65536 if size < 0 else min(65536, size - length))
                if not part:
                    break
                chunks.append(part)
                length += len(part)
                if length > 8 * 1024 * 1024:
                    raise AttemptAborted('oversized-response')
            self.budget.check()
            return b''.join(chunks)
        except Exception:
            self.budget.failure(self.url)
        finally:
            self.response.close()

    def __getattr__(self, name):
        return getattr(self.response, name)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.response.close()


def install_transport(budget):
    import requests
    original_request = requests.sessions.Session.request
    original_urlopen = urllib.request.urlopen

    def request(session, method, url, *args, **kwargs):
        timeout = budget.start(url)
        kwargs['timeout'] = (timeout, timeout)
        try:
            response = original_request(session, method, url, *args, **kwargs)
            if response.status_code >= 400:
                response.close()
                budget.failure(url)
            budget.check()
            return response
        except Exception:
            budget.failure(url)

    def urlopen(url, data=None, timeout=None, **kwargs):
        address = url.full_url if isinstance(url, urllib.request.Request) else url
        limit = budget.start(address)
        try:
            response = original_urlopen(url, data=data, timeout=limit, **kwargs)
            return Response(response, budget, address)
        except Exception as exc:
            if hasattr(exc, 'close'):
                exc.close()
            budget.failure(address)

    requests.sessions.Session.request = request
    urllib.request.urlopen = urlopen
    def restore():
        requests.sessions.Session.request = original_request
        urllib.request.urlopen = original_urlopen
    return restore


def local_catalog(utils, public_rows):
    """Only unsigned identifiers; do not run a whole catalog scan during play.

    A cached identifier may be old, but every playback still resolves it anew
    with the provider's valid signature. No TTL is extended or file modified.
    """
    for name, native in ((os.path.join(utils.addonprofile, 'catalog', 'livetv1_catalog.zlib'), False),
                         (os.path.join(utils.cachepath, 'vav_channels'), True)):
        try:
            with open(name, 'rb') as f:
                packed = f.read(8 * 1024 * 1024 + 1)
            if len(packed) > 8 * 1024 * 1024:
                continue
            decoder = zlib.decompressobj()
            raw = decoder.decompress(packed, 8 * 1024 * 1024 + 1)
            if len(raw) > 8 * 1024 * 1024 or not decoder.eof:
                continue
            data = json.loads(raw)
            if native:
                data = data.get('value', {})
            rows = public_rows(data.get('channels'))
            if rows:
                return rows
        except (OSError, ValueError, TypeError, zlib.error):
            continue
    return []


def run(ticket, provider):
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
    window = xbmcgui.Window(10000)
    prop = PREFIX + ticket
    request = read(window, prop)
    if request.get('ticket') != ticket or request.get('provider') != provider:
        return
    budget = Budget(window, request)
    result_prop = prop + '.result'
    items = []
    vod_group_count = [0]
    gate = None
    lease = None
    player = None
    restore_transport = None

    def result(state, **kwargs):
        if read(window, prop).get('ticket') == ticket:
            write(window, result_prop, dict(ticket=ticket, state=state, **kwargs))

    class QuietProgress:
        def create(self, *a, **k): pass
        def update(self, *a, **k): pass
        def close(self): pass
        def iscanceled(self): return window.getProperty(ACTIVE) != request['owner']

    class QuietDialog:
        def notification(self, *a, **k): pass
        def ok(self, *a, **k): return False
        def yesno(self, *a, **k): return False

    def resolved(handle, succeeded, item):
        budget.check()
        if succeeded and item and item.getPath():
            items.append(item)

    try:
        budget.check()
        dependency_paths(provider)
        native_addon = xbmcaddon.Addon
        path = xbmcvfs.translatePath(native_addon(provider).getAddonInfo('path'))
        # A path-based RunScript can inherit its caller's addon context.
        # Explicitly bind no-argument Addon() calls to the native provider.
        xbmcaddon.Addon = lambda id=None: native_addon(id or provider)
        xbmcgui.DialogProgress = QuietProgress
        xbmcgui.Dialog = QuietDialog
        xbmcplugin.setResolvedUrl = resolved
        xbmcplugin.endOfDirectory = lambda *a, **k: None
        source = request['url']
        parsed = urlsplit(source)
        if parsed.scheme != 'plugin' or parsed.netloc != provider:
            raise AttemptAborted('invalid-provider')
        params = dict(parse_qsl(parsed.query))
        sys.argv = ['plugin://' + provider + '/', '-1', '?' + parsed.query]
        sys.path.insert(0, path)
        restore_transport = install_transport(budget)
        if provider == 'plugin.video.vodkool':
            # Use VODKOOL's native one-at-a-time group rotation directly.
            # This avoids a preliminary group scan and does not inspect stream
            # availability before the actual native player resolution.
            wrapper = runpy.run_path(os.path.join(path, 'default_run.py'), run_name='codex_native')
            wrapper['codex_startup_guard'].begin = lambda *a, **k: ''
            action = params.get('action')
            if request.get('kind') == 'catalog':
                if action == 'codex_de_play_group' and request['country'] == 'Germany':
                    data = wrapper['_load_group_data']()
                elif action == 'codex_country_play_group' and params.get('country') == request['country']:
                    data = wrapper['_load_country_data'](request['country'])
                else:
                    raise AttemptAborted('invalid-group')
                group = (data.get('groups') or {}).get(params.get('group'), {})
                result('catalog', group=group)
                return
            if action == 'play_kool_live':
                wrapper['default'].play_kool_live(params.get('url', ''), params.get('label', request['label']))
            elif action == 'codex_de_play_group':
                data = wrapper['_load_group_data']()
                group_key = params.get('group', '')
                vod_group_count[0] = len(((data.get('groups') or {}).get(group_key) or {}).get('items') or [])
                # runpy returns a copied namespace; replacing a wrapper entry
                # does not replace the globals used by its original functions.
                wrapper['_play_group_stream'](data, group_key, 'de::' + group_key,
                                               params.get('label') or request['label'])
            elif action == 'codex_country_play_group':
                country, group_key = params.get('country', ''), params.get('group', '')
                data = wrapper['_load_country_data'](country)
                vod_group_count[0] = len(((data.get('groups') or {}).get(group_key) or {}).get('items') or [])
                wrapper['_play_group_stream'](data, group_key,
                                               'country::%s::%s' % (country, group_key),
                                               params.get('label') or request['label'])
            else:
                raise AttemptAborted('invalid-source')
        elif provider == 'plugin.video.kodiboxtv':
            sys.path.insert(0, os.path.join(path, 'resources'))
            from vavoo import codex_livetv1, codex_catalog_cache, utils
            if not params.get('codex_raw') or params.get('group') != request['country']:
                raise AttemptAborted('invalid-source')
            rows = local_catalog(utils, codex_catalog_cache.public_rows)
            original_catalog = codex_catalog_cache.catalog_rows
            codex_catalog_cache.catalog_rows = lambda *a: (rows, 'identifier-cache')
            try:
                codex_livetv1.play(params)
            finally:
                codex_catalog_cache.catalog_rows = original_catalog
        else:
            raise AttemptAborted('invalid-provider')
        budget.check()
        if not items:
            raise AttemptAborted('unavailable')
        # The signing/resolve budget must not remain installed for the lifetime
        # of a playing stream or interfere with provider background keepalive.
        if restore_transport:
            restore_transport()
            restore_transport = None
        item = player_options(items[0])
        stream_url = item.getPath()
        result('resolved', path=stream_url, group_count=vod_group_count[0])

        # A late response can NEVER start playback without a current ticket.
        wait_until = time.monotonic() + 3
        monitor = xbmc.Monitor()
        while time.monotonic() < wait_until:
            budget.check()
            if window.getProperty(prop + '.play') == ticket:
                if window.getProperty(ACTIVE) != request['owner']:
                    raise AttemptAborted('cancelled')
                xbmc.log('[Live TV 1] AUTO native handoff: provider=%s transport=direct' %
                         provider, xbmc.LOGINFO)
                window.setProperty(prop + '.handoff', ticket)
                write(window, 'LiveTV1.Auto.PendingPlayer', {'ticket': ticket, 'path': stream_url})
                player = xbmc.Player()
                player.play(stream_url, item)
                result('playing', path=stream_url)
                window.setProperty(prop + '.done', ticket)
                window.setProperty(prop + '.released', ticket)
                return
            if monitor.waitForAbort(0.025):
                raise AttemptAborted('cancelled')
        raise AttemptAborted('not-authorized')
    except AttemptAborted as exc:
        result('failed', reason=exc.reason, group_count=vod_group_count[0])
    except Exception as exc:
        xbmc.log('[Live TV 1] AUTO native failure: provider=%s exception=%s' %
                 (provider, type(exc).__name__), xbmc.LOGWARNING)
        result('failed', reason='unavailable', group_count=vod_group_count[0])
    finally:
        if restore_transport:
            restore_transport()
        if read(window, prop).get('ticket') == ticket:
            window.setProperty(prop + '.released', ticket)
            window.setProperty(prop + '.done', ticket)
