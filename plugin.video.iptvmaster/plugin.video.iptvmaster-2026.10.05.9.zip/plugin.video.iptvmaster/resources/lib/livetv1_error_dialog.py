"""Dismiss ONLY Kodi's standard playback-error OK for our active attempt.

Never close all dialogs or send a generic OK key: installation, yes/no, input
and other addons' prompts must stay interactive.
"""
import re


def normalized(value):
    return ' '.join(re.sub(r'\[/?(?:COLOR[^\]]*|B|I|U)\]', '', str(value or ''),
                           flags=re.I).split()).casefold()


def dismiss_playback_error(xbmc, xbmcgui, owns_attempt):
    try:
        if not owns_attempt():
            return False
        wanted_heading = normalized(xbmc.getLocalizedString(16026))
        wanted_text = normalized(xbmc.getLocalizedString(16027))
        for win_id in (10101, 10100, 12002, 12000):
            if not xbmc.getCondVisibility('Window.IsActive(%d)' % win_id):
                continue
            dialog = xbmcgui.Window(win_id)
            heading = ''
            for title_id in (1, 2, 0):
                try:
                    control = dialog.getControl(title_id)
                    heading = normalized(getattr(control, 'getLabel', lambda: '')())
                    if heading:
                        break
                except (RuntimeError, AttributeError):
                    pass
            texts = []
            for control_id in (9, 2, 3, 4):
                try:
                    control = dialog.getControl(control_id)
                    getter = getattr(control, 'getText', None) or getattr(control, 'getLabel', None)
                    if getter:
                        texts.append(str(getter() or ''))
                except (RuntimeError, AttributeError):
                    pass
            combined_text = normalized(' '.join(texts))
            is_error_body = (
                (wanted_text and wanted_text in combined_text)
                or (wanted_heading and wanted_heading in heading)
                or ('wiedergabe' in heading and 'nicht' in heading)
                or ('playback' in heading and 'fail' in heading)
                or ('allgemeiner fehler' in combined_text)
                or ('nicht erreichbar' in combined_text)
                or ('unreachable' in combined_text)
            )
            if not is_error_body or not owns_attempt():
                continue
            xbmc.executebuiltin('Dialog.Close(%d,true)' % win_id)
            xbmc.executebuiltin('Dialog.Close(okdialog,true)')
            xbmc.executebuiltin('Dialog.Close(dialogok,true)')
            xbmc.executebuiltin('Dialog.Close(yesnodialog,true)')
            xbmc.executebuiltin('Dialog.Close(dialogconfirm,true)')
            xbmc.executebuiltin('Action(Select)')
            xbmc.log('[Live TV 1] AUTO standard playback error dismissed: window=%d' % win_id, xbmc.LOGINFO)
            return True
        return False
    except Exception:
        return False
