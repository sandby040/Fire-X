"""A live transport lease survives controller cleanup; no credentials or URLs on disk."""
import threading

from livetv1_auto_core import read, write

TRANSPORT = 'LiveTV1.Auto.Transport'
CANCEL = 'LiveTV1.Auto.TransportCancel.'


def request_cancel(window):
    lease = read(window, TRANSPORT)
    ticket = lease.get('ticket', '')
    if ticket and lease.get('state') in ('active', 'blocked'):
        window.setProperty(CANCEL + ticket, ticket)
        return ticket
    return ''


def released(window, ticket):
    if not ticket:
        return True
    lease = read(window, TRANSPORT)
    return lease.get('ticket') == ticket and lease.get('state') == 'released'


class TransportLease:
    def __init__(self, window, ticket, gate=None, log=lambda message: None):
        self.window, self.ticket, self.gate, self.log = window, ticket, gate, log
        self.finished = threading.Event()
        write(window, TRANSPORT, {'ticket': ticket, 'state': 'active'})
        self.thread = threading.Thread(target=self.watch, daemon=True)
        self.thread.start()

    def watch(self):
        while not self.finished.is_set():
            if self.window.getProperty(CANCEL + self.ticket) == self.ticket:
                if self.gate and hasattr(self.gate, 'cancel'):
                    try:
                        self.gate.cancel()
                    except Exception:
                        pass
                self.log('transport stop signalled')
                return
            self.finished.wait(0.025)

    def finish(self, io_released=True):
        self.finished.set()
        self.thread.join(timeout=0.2)
        self.publish('released' if io_released else 'blocked')
        self.window.clearProperty(CANCEL + self.ticket)

    def publish(self, state):
        if read(self.window, TRANSPORT).get('ticket') == self.ticket:
            write(self.window, TRANSPORT, {'ticket': self.ticket, 'state': state})
