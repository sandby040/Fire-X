"""State/rotation for sequential native providers. No credentials on disk."""
import hashlib
import json
import os
import tempfile
from urllib.parse import parse_qsl, urlencode, urlsplit

ACTIVE = 'LiveTV1.Auto.Active'
RESOLVE_SECONDS = 15
AV_SECONDS = 15
MIN_SOURCE_GAP_SECONDS = 2
# One selected German channel may contain a VOD group plus many mapped KodiBox
# entries. Keep the run cancellable and bounded even if a provider reports an
# unexpectedly large group.
TOTAL_SECONDS = 1200
PREFIX = 'LiveTV1.Auto.Request.'
PROVIDERS = {'VODKOOL': 'plugin.video.vodkool', 'Kodibox TV': 'plugin.video.kodiboxtv'}


class AttemptAborted(BaseException):
    """Do not let legacy except Exception/retry loops repeat a failed request."""
    def __init__(self, reason):
        self.reason = reason


def read(window, key):
    try:
        obj = json.loads(window.getProperty(key))
        return obj if isinstance(obj, dict) else {}
    except (ValueError, TypeError):
        return {}


def write(window, key, obj):
    window.setProperty(key, json.dumps(obj, ensure_ascii=True))


def source_id(source):
    args = dict(parse_qsl(urlsplit(source['url']).query))
    if source['provider'] == 'VODKOOL':
        if args.get('action') == 'play_kool_live':
            native_id = args.get('url', '')
        else:
            native_id = json.dumps([args.get('action'), args.get('country'), args.get('group')])
    else:
        native_id = json.dumps([args.get('group'), args.get('codex_raw'), args.get('codex_slot', '0')])
    return hashlib.sha256((source['provider'] + '\n' + native_id).encode()).hexdigest()[:24]


def playable_sources(vod_items, row, enabled):
    """Order direct native attempts; never expose provider source folders."""
    queues = {p: [] for p in PROVIDERS}
    seen = set()
    items = [dict(item, provider='VODKOOL') for item in vod_items]
    replaced_groups = {item.get('group_id') for item in vod_items if item.get('group_id')}
    items += [s for s in row['sources'] if s.get('provider') == 'VODKOOL'
              and source_id(s) not in replaced_groups]
    items += [s for s in row['sources'] if s.get('provider') == 'Kodibox TV']
    for item in items:
        provider = item.get('provider')
        parsed = urlsplit(item.get('url', ''))
        if provider not in enabled or item.get('folder') or parsed.netloc != PROVIDERS.get(provider) or parsed.scheme != 'plugin':
            continue
        args = dict(parse_qsl(parsed.query))
        if provider == 'VODKOOL':
            action = args.get('action')
            direct_play = action == 'play_kool_live' and args.get('url')
            group_play = action in ('codex_de_play_group', 'codex_country_play_group') and args.get('group')
            if not (direct_play or group_play):
                continue
        if provider == 'Kodibox TV' and (not args.get('codex_raw') or args.get('group') != row['country']):
            continue
        entry = {'provider': provider, 'url': item['url'], 'label': item.get('label') or row['name']}
        for field in ('group_id', 'native_index', 'storage_key'):
            if field in item:
                entry[field] = item[field]
        entry['id'] = source_id(entry)
        if entry['id'] not in seen:
            seen.add(entry['id'])
            queues[provider].append(entry)
    result = []
    for i in range(max((len(q) for q in queues.values()), default=0)):
        for provider in PROVIDERS:
            if i < len(queues[provider]):
                result.append(queues[provider][i])
    return result


def local_json(path):
    """Read local unsigned catalog/rotation data, without any provider request."""
    try:
        with open(path, encoding='utf-8-sig') as file:
            raw = file.read(8 * 1024 * 1024 + 1)
        if len(raw) > 8 * 1024 * 1024:
            return {}
        value = json.loads(raw)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def expand_vod_group(row, source, group):
    """Validate unsigned native entries for exactly one country/channel group."""
    args = dict(parse_qsl(urlsplit(source.get('url', '')).query))
    action = args.get('action')
    if not is_vod_group(source) or not isinstance(group, dict):
        return []
    if action == 'codex_de_play_group':
        if row.get('country') != 'Germany':
            return []
        storage_key = 'de::' + args.get('group', '')
    else:
        if args.get('country') != row.get('country'):
            return []
        storage_key = 'country::%s::%s' % (args['country'], args.get('group', ''))
    result = []
    for index, item in enumerate(group.get('items') or []):
        if not isinstance(item, dict):
            continue
        parsed = urlsplit(item.get('url', ''))
        native_args = dict(parse_qsl(parsed.query))
        if (parsed.scheme != 'plugin' or parsed.netloc != PROVIDERS['VODKOOL']
                or native_args.get('action') != 'play_kool_live'
                or not native_args.get('url')):
            continue
        result.append({'url': item['url'], 'label': item.get('label') or row['name'],
                       'group_id': source_id(source), 'native_index': index,
                       'storage_key': storage_key})
    return result


def cached_vod_sources(row, path):
    """Expand exactly this channel's native cached group into streams.

    Entries remain plugin:// calls to VODKOOL's native resolver. No signed play
    URL is copied, refreshed, or probed. Missing catalogs keep the group route.
    """
    data = local_json(path)
    if row.get('country') != 'Germany':
        countries = data.get('countries') or {}
        data = next((value for value in countries.values()
                     if isinstance(value, dict) and value.get('country') == row.get('country')), {})
    groups = data.get('groups') or {}
    if not isinstance(groups, dict):
        return []
    result = []
    for source in row.get('sources', []):
        if not is_vod_group(source):
            continue
        args = dict(parse_qsl(urlsplit(source.get('url', '')).query))
        group = groups.get(args.get('group'), {})
        result.extend(expand_vod_group(row, source, group))
    return result


def numbered_sources(sources):
    """Stable source positions BEFORE rotating the queue for a new click."""
    return [dict(source, number=index + 1) for index, source in enumerate(sources)]


def migrate_group_cursor(sources, last, native_rotation):
    """Upgrade the old single-group cursor to its last actual native stream."""
    if any(source['id'] == last for source in sources):
        return last
    for source in sources:
        if (source.get('group_id') == last
                and source.get('native_index') == native_rotation.get(source.get('storage_key'))):
            return source['id']
    return last


def rotated(sources, last):
    ids = [s['id'] for s in sources]
    start = (ids.index(last) + 1) % len(ids) if last in ids else 0
    return sources[start:] + sources[:start]


def is_vod_group(source):
    if not source or source.get('provider') != 'VODKOOL':
        return False
    args = dict(parse_qsl(urlsplit(source.get('url', '')).query))
    return args.get('action') in ('codex_de_play_group', 'codex_country_play_group')


class Rotation:
    def __init__(self, path):
        self.path = path
        try:
            with open(path, encoding='utf-8') as f:
                self.rows = json.load(f)
            if not isinstance(self.rows, dict):
                self.rows = {}
        except (OSError, ValueError):
            self.rows = {}

    def last(self, key):
        return self.rows.get(key, '')

    def group_progress(self, key):
        value = self.rows.get(key + ':group', {})
        return value if isinstance(value, dict) else {}

    def remember_group_progress(self, key, attempts, total):
        self.rows[key + ':group'] = {
            'attempts': max(0, int(attempts)),
            'total': max(0, int(total)),
        }
        self._save()

    def _save(self):
        self.rows = dict(list(self.rows.items())[-3000:])
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        fd, name = tempfile.mkstemp(prefix='.rotation-', dir=os.path.dirname(self.path))
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(self.rows, f)
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def remember(self, key, source):
        # Only opaque hashes; no token, final URL, title or provider setting.
        self.rows[key] = source['id']
        self._save()

    def remember_position(self, key, source, total, state):
        # Source identity remains authoritative when the list changes.
        self.rows[key + ':position'] = {'source_id': source['id'],
                                      'number': source['number'], 'total': total,
                                      'state': state}
        if state == 'started':
            self.rows[key + ':success'] = source['id']
        self._save()

def same_path(current, expected):
    return bool(current and expected and current.partition('|')[0] == expected.partition('|')[0])


def player_options(item):
    """No Kodi HEAD/Stat guessing; bound only this item's connection timeout."""
    path = item.getPath()
    base, _, options = path.partition('|')
    parts = [p for p in options.split('&') if p and p.split('=', 1)[0].lower() != 'connection-timeout']
    parts.append('connection-timeout=6')
    item.setPath(base + '|' + '&'.join(parts))
    item.setContentLookup(False)
    if 'm3u8' in base.lower() or '/hls/' in base.lower():
        item.setMimeType('application/vnd.apple.mpegurl')
    elif urlsplit(base).path.lower().endswith('.ts'):
        item.setMimeType('video/mp2t')
    get_prop = getattr(item, 'getProperty', None)
    inputstream = get_prop('inputstream') if callable(get_prop) else getattr(item, 'props', {}).get('inputstream', '')
    if inputstream == 'inputstream.ffmpegdirect':
        item.setProperty('inputstream.ffmpegdirect.stream_mode', '')
        item.setProperty('inputstream.ffmpegdirect.playback_as_live', 'true')
        item.setProperty('inputstream.ffmpegdirect.stream_opts', '')
    return item
