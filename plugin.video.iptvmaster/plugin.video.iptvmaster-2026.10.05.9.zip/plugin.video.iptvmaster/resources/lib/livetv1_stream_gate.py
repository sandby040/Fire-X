"""Per-play loopback transport, not a stream scan or a token resolver.

Kodi HEAD/Stat is answered locally. The player's first GET is the only upstream
GET; HLS manifests, segments and keys stay on this cancellable transport. URLs
and headers exist only in this provider interpreter's RAM. No global settings.
"""
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import re
import socket
import threading
import time
from http.cookiejar import CookieJar
from urllib.parse import parse_qsl, urljoin, urlsplit
from urllib.request import build_opener, ProxyHandler, HTTPCookieProcessor, Request


class StreamGate:
    def __init__(self, path, deadline, clock=time.monotonic):
        self.clock, self.deadline = clock, deadline
        self.started = False
        self.cancelled = threading.Event()
        self.lock = threading.RLock()
        self.routes = OrderedDict()
        self.clients = set()
        self.upstreams = set()
        self.inflight = 0
        self.failure = ''
        self.counter = 0
        self.opener = build_opener(ProxyHandler({}), HTTPCookieProcessor(CookieJar()))
        address, _, options = path.partition('|')
        allowed = {'user-agent', 'referer', 'origin', 'cookie', 'authorization',
                   'accept', 'accept-language', 'x-requested-with', 'host'}
        self.headers = {}
        for key, value in parse_qsl(options, keep_blank_values=True):
            if key.lower() in allowed or key.startswith('!'):
                key = key.lstrip('!')
                if '\r' not in key + value and '\n' not in key + value:
                    self.headers[key] = value
        self.headers.setdefault('User-Agent', 'libmpv')
        self.headers['Accept-Encoding'] = 'identity'
        gate = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.0'
            def log_message(self, *args): pass  # Never log signed URLs/headers.
            def do_HEAD(self): gate.serve(self, head=True)
            def do_GET(self): gate.serve(self, head=False)

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': 0.05}, daemon=True)
        self.url = self.register(address)
        self.thread.start()

    def register(self, address):
        if urlsplit(address).scheme not in ('http', 'https'):
            raise ValueError('unsupported-stream-scheme')
        with self.lock:
            # Reuse routes for live playlist reloads, but bound RAM usage.
            for key, existing in list(self.routes.items()):
                if existing == address:
                    self.routes.move_to_end(key)
                    return self.base + key
            self.counter += 1
            suffix = '.m3u8' if '.m3u8' in urlsplit(address).path.lower() else '.bin'
            key = '/media/%d%s' % (self.counter, suffix)
            self.routes[key] = address
            while len(self.routes) > 4096:
                self.routes.popitem(last=False)
            return self.base + key

    @property
    def base(self):
        return 'http://127.0.0.1:%d' % self.server.server_address[1]

    def timeout(self):
        if self.cancelled.is_set():
            raise TimeoutError('cancelled')
        remaining = 10 if self.started else self.deadline - self.clock()
        if remaining <= 0:
            raise TimeoutError('startup-deadline')
        # Bounds DNS/socket connect/read when opening; no automatic HTTP retries.
        return max(0.05, min(3 if not self.started else 10, remaining))

    def mark_started(self):
        self.started = True
        with self.lock:
            for connection in list(self.clients):
                try:
                    connection.settimeout(10)
                except OSError:
                    pass

    def rewrite(self, raw, base):
        text = raw.decode('utf-8-sig')
        if not text.lstrip().startswith('#EXTM3U'):
            raise ValueError('invalid-hls')
        def uri(match):
            return 'URI="%s"' % self.register(urljoin(base, match.group(1)))
        lines = []
        for line in text.splitlines():
            if line.strip() and not line.lstrip().startswith('#'):
                line = self.register(urljoin(base, line.strip()))
            elif 'URI="' in line:
                line = re.sub(r'URI="([^"]+)"', uri, line)
            lines.append(line)
        return ('\n'.join(lines) + '\n').encode('utf-8')

    def serve(self, handler, head=False):
        response = None
        upstream = None
        sent = False
        with self.lock:
            target = self.routes.get(urlsplit(handler.path).path)
            self.clients.add(handler.connection)
            self.inflight += 1
        try:
            handler.connection.settimeout(10 if self.started else 3)
            if not target or self.cancelled.is_set():
                handler.close_connection = True
                handler.send_error(410)
                return
            if head:
                # A metadata check must not consume a signed stream or contact
                # an unavailable provider. No false availability judgement.
                handler.send_response(200)
                handler.send_header('Content-Type', 'application/vnd.apple.mpegurl'
                                    if '.m3u8' in handler.path else 'application/octet-stream')
                handler.send_header('Cache-Control', 'no-store')
                handler.end_headers()
                return
            headers = dict(self.headers)
            if handler.headers.get('Range'):
                headers['Range'] = handler.headers['Range']
            response = self.opener.open(Request(target, headers=headers), timeout=self.timeout())
            # HTTPResponse's underlying socket can be shut down without calling
            # close() on its buffered reader from another thread (read-lock).
            upstream = getattr(getattr(getattr(response, 'fp', None), 'raw', None), '_sock', None)
            if upstream is not None:
                with self.lock:
                    self.upstreams.add(upstream)
                    if self.cancelled.is_set():
                        self.shutdown(upstream)
            content = response.headers.get('Content-Type', '')
            manifest = ('.m3u8' in urlsplit(response.geturl()).path.lower()
                        or 'mpegurl' in content.lower())
            if manifest:
                data = bytearray()
                while True:
                    self.timeout()
                    chunk = response.read1(65536)
                    if not chunk:
                        break
                    data.extend(chunk)
                    if len(data) > 2 * 1024 * 1024:
                        raise ValueError('oversized-hls')
                body = self.rewrite(bytes(data), response.geturl())
                handler.send_response(200)
                handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                handler.send_header('Content-Length', str(len(body)))
                handler.send_header('Cache-Control', 'no-store')
                handler.end_headers()
                sent = True
                handler.wfile.write(body)
            else:
                handler.send_response(response.status)
                for name in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                    if response.headers.get(name):
                        handler.send_header(name, response.headers[name])
                handler.end_headers()
                sent = True
                while True:
                    self.timeout()
                    chunk = response.read1(65536)
                    if not chunk:
                        break
                    handler.wfile.write(chunk)
        except (OSError, ValueError) as exc:
            if not self.started and not self.cancelled.is_set():
                self.failure = type(exc).__name__
            if not sent:
                try:
                    handler.send_error(504)
                except OSError:
                    pass
        finally:
            if response:
                response.close()
            with self.lock:
                self.upstreams.discard(upstream)
                self.clients.discard(handler.connection)
                self.inflight -= 1

    @staticmethod
    def shutdown(connection):
        try:
            connection.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        # urllib's makefile can retain the descriptor after socket.close().
        # Close the same socket object (invalidating its fd, not an integer fd
        # that could be reused) to interrupt a pending read on Windows too.
        try:
            getattr(connection, '_real_close', connection.close)()
        except OSError:
            pass

    def cancel(self):
        self.cancelled.set()
        with self.lock:
            for connection in list(self.clients) + list(self.upstreams):
                self.shutdown(connection)

    def close(self):
        self.cancel()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)
