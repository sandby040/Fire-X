import re
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from utils import setting, setting_bool, setting_int, info, debug, warn, error

def _stop_existing_playback():
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return
        info('stopping existing playback before opening new stream')
        player.stop()
        for _ in range(20):
            xbmc.sleep(100)
            if not player.isPlaying():
                break
    except Exception as exc:
        warn(f'could not stop existing playback cleanly: {exc}')

def detect_stream_type(url: str) -> str:
    u = url.lower().split('?')[0].split('|')[0]
    if u.endswith('.m3u8')             : return 'hls'
    if u.endswith('.mpd')              : return 'dash'
    if u.startswith('rtmp')            : return 'rtmp'
    if u.startswith('rtsp')            : return 'rtsp'
    if u.endswith(('.ts', '.mp4', '.mkv', '.avi', '.flv', '.wmv')): return 'direct'
    if '/m3u8' in u or 'playlist.m3u' in u: return 'hls'
    if '/timeshift/' in u or '/live/' in u : return 'hls'
    return 'http'

def _isa_available() -> bool:
    try:
        import xbmcaddon
        xbmcaddon.Addon('inputstream.adaptive')
        return True
    except RuntimeError:
        return False

def _build_header_string(url: str, extra_headers: dict = None) -> str:

    base_url  = url
    existing  = {}

    if '|' in url:
        base_url, hdr_part = url.split('|', 1)
        for pair in hdr_part.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                existing[k.strip()] = urllib.parse.unquote(v.strip())

    ua = setting('user_agent',
                 'Mozilla/5.0 (Linux; Android 11; TV) '
                 'AppleWebKit/537.36 (KHTML, like Gecko) '
                 'Chrome/112.0.0.0 Mobile Safari/537.36')

    merged = {'User-Agent': ua}
    merged.update(existing)
    if extra_headers:
        merged.update(extra_headers)

    hdr_str = '&'.join(
        f'{k}={urllib.parse.quote(str(v), safe="")}' for k, v in merged.items()
    )
    return base_url, hdr_str


def build_playable_item(url: str,
                        title: str = '',
                        logo:  str = '',
                        headers: dict = None,
                        drm_info: dict = None,
                        live: bool = False) -> xbmcgui.ListItem:
    """
    Return a fully configured ListItem ready for setResolvedUrl.
    Automatically picks InputStream Adaptive for HLS/DASH when available.
    """
    if not url:
        error('build_playable_item: empty URL')
        return xbmcgui.ListItem(title)

    if url.lower().startswith('plugin://'):
        debug(f'plugin playback: {url[:120]}')
        li = xbmcgui.ListItem(title)
        li.setArt({'icon': logo, 'thumb': logo})
        li.setInfo('video', {'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setPath(url)
        return li

    stype      = detect_stream_type(url)
    is_hls     = (stype == 'hls')
    is_dash    = (stype == 'dash')
    is_rtmp    = (stype == 'rtmp')
    use_isa    = False
    player_pref= setting_int('player_default', 0)

    debug(f'play: type={stype}  url={url[:80]}')

    base_url, hdr_str = _build_header_string(url, headers)

    li = xbmcgui.ListItem(title)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'title': title, 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')

    if live and not is_rtmp:
        use_isa = False
    elif (is_hls or is_dash) and player_pref in (0, 1) and _isa_available():
        use_isa = True

    if use_isa:
        debug(f'ISA playback: {base_url[:80]}')
        li.setProperty('inputstream', 'inputstream.adaptive')
        manifest = 'hls' if is_hls else 'mpd'
        li.setProperty('inputstream.adaptive.manifest_type', manifest)
        li.setProperty('inputstream.adaptive.stream_headers', hdr_str)
        li.setProperty('inputstream.adaptive.manifest_headers', hdr_str)
        if drm_info:
            _apply_drm(li, drm_info, hdr_str)
        li.setPath(base_url)
        return li

    if is_rtmp:
        li.setPath(url)
        return li

    if live:
        debug(f'live ffmpegdirect playback: {base_url[:80]}')
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstreamaddon', 'inputstream.ffmpegdirect')
        if is_hls:
            li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('inputstream.ffmpegdirect.stream_mode', '')
        li.setProperty('inputstream.ffmpegdirect.playback_as_live', 'true')
        li.setProperty('inputstream.ffmpegdirect.protocol_whitelist', 'http,https,tcp,tls,crypto')
        li.setProperty('inputstream.ffmpegdirect.stream_opts', ':'.join([
            'http_persistent=1',
            'multiple_requests=1',
            'reconnect=1',
            'reconnect_streamed=1',
            'reconnect_delay_max=2',
            'timeout=10000000',
        ]))
        li.setProperty('inputstream.ffmpegdirect.user_agent', 'libmpv')
        li.setPath(f'{base_url}|{hdr_str}' if hdr_str else base_url)
        return li

    final = f'{base_url}|{hdr_str}' if hdr_str else base_url
    debug(f'direct playback: {final[:120]}')
    li.setPath(final)
    return li

def _apply_drm(li, drm_info: dict, hdr_str: str = ''):
    drm_type  = drm_info.get('type', 'com.widevine.alpha')
    lic_url   = drm_info.get('licence_url', '')
    challenge = drm_info.get('challenge', 'R{SSM}')
    response  = drm_info.get('response', '')
    li.setProperty('inputstream.adaptive.license_type', drm_type)
    li.setProperty('inputstream.adaptive.license_key',
                   f'{lic_url}|{hdr_str}|{challenge}|{response}')


def play_stream(handle: int, url: str,
                title: str = '', logo: str = '',
                headers: dict = None, drm_info: dict = None,
                live: bool = False):

    if not url:
        error('play_stream: no URL provided')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    info(f'play_stream: {url[:100]}')
    _stop_existing_playback()
    li = build_playable_item(url, title=title, logo=logo,
                             headers=headers, drm_info=drm_info,
                             live=live)
    xbmcplugin.setResolvedUrl(handle, True, li)

def play_catchup(handle: int, url: str,
                 start_ts: int = 0, stop_ts: int = 0,
                 title: str = '', logo: str = '',
                 headers: dict = None):

    if not url:
        error('play_catchup: no URL provided')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    info(f'play_catchup: {url[:100]}')
    li = build_playable_item(url, title=title, logo=logo, headers=headers)
    xbmcplugin.setResolvedUrl(handle, True, li)

def channel_list_item(channel, current_prog=None, progress: float = 0.0):
    title = channel.name
    li = xbmcgui.ListItem(title)
    logo = channel.logo or ''
    if not logo.lower().startswith(('http://', 'https://', 'special://', 'plugin://')):
        logo = current_prog.icon if current_prog else ''
    li.setArt({'icon': logo, 'thumb': logo})
    info_d = {'title': channel.name, 'mediatype': 'video'}
    if current_prog:
        programme_title = (current_prog.title or '').strip()
        programme_desc = (current_prog.desc or '').strip()
        try:
            programme_time = (
                f'{time.strftime("%H:%M", time.localtime(current_prog.start))} - '
                f'{time.strftime("%H:%M", time.localtime(current_prog.stop))}'
            ) if current_prog.start and current_prog.stop else ''
        except Exception:
            programme_time = ''
        plot_parts = []
        if programme_time:
            plot_parts.append(f'[B]{programme_time}[/B]')
        if programme_title:
            plot_parts.append(f'[B]{programme_title}[/B]')
        if programme_desc and programme_desc != programme_title:
            plot_parts.append(programme_desc)
        programme_plot = '\n'.join(part for part in plot_parts if part)
        info_d.update({
            'plot'    : f'[COLOR FFF7B731]{programme_plot}[/COLOR]',
            'genre'   : current_prog.category,
            'duration': max(0, current_prog.stop - current_prog.start),
        })
    li.setInfo('video', info_d)
    li.setProperty('IsPlayable', 'true')
    if progress > 0:
        li.setProperty('ProgressPercentage', str(int(progress * 100)))
    return li

def vod_list_item(vod: dict):
    from utils import safe_int, safe_float, safe_year
    title = vod.get('name', '')
    year  = safe_year(vod.get('year'))
    li    = xbmcgui.ListItem(f'{title} ({year})' if year else title)
    li.setArt({
        'icon'  : vod.get('stream_icon', ''),
        'thumb' : vod.get('stream_icon', ''),
        'poster': vod.get('stream_icon', ''),
    })
    cast = vod.get('cast', '')
    li.setInfo('video', {
        'title'    : title,
        'plot'     : vod.get('plot', ''),
        'year'     : year,
        'rating'   : safe_float(vod.get('rating')),
        'genre'    : vod.get('genre', ''),
        'director' : vod.get('director', ''),
        'cast'     : cast.split(',') if isinstance(cast, str) and cast else [],
        'duration' : safe_int(vod.get('duration_secs')),
        'mediatype': 'movie',
    })
    li.setProperty('IsPlayable', 'true')
    return li

def series_list_item(series: dict):
    from utils import safe_float
    title = series.get('name', '')
    li    = xbmcgui.ListItem(title)
    cover = series.get('cover', '')
    fan   = (series.get('backdrop_path', ['']) or [''])[0] \
            if isinstance(series.get('backdrop_path'), list) \
            else series.get('backdrop_path', '')
    li.setArt({'icon': cover, 'thumb': cover, 'poster': cover, 'fanart': fan})
    li.setInfo('video', {
        'title'    : title,
        'plot'     : series.get('plot', ''),
        'rating'   : safe_float(series.get('rating')),
        'genre'    : series.get('genre', ''),
        'mediatype': 'tvshow',
    })
    li.setProperty('IsPlayable', 'false')
    return li

def episode_list_item(ep: dict, show_name: str = ''):
    from utils import safe_int
    ep_num = ep.get('episode_num', '')
    title  = ep.get('title', f'Episode {ep_num}')
    full   = f'{show_name} - {title}' if show_name else title
    li     = xbmcgui.ListItem(full)
    img    = (ep.get('info') or {}).get('movie_image', '')
    li.setArt({'icon': img, 'thumb': img})
    li.setInfo('video', {
        'title'    : title,
        'season'   : safe_int(ep.get('season')),
        'episode'  : safe_int(ep.get('episode_num')),
        'plot'     : (ep.get('info') or {}).get('plot', ''),
        'duration' : safe_int((ep.get('info') or {}).get('duration_secs')),
        'mediatype': 'episode',
    })
    li.setProperty('IsPlayable', 'true')
    return li
