import time, sys, os, json, threading, gzip, io, re
import xml.etree.ElementTree as ET
import xbmc, xbmcaddon, xbmcvfs

ADDON    = xbmcaddon.Addon()
LIB_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from utils import setting, setting_bool, setting_int, load_favourites, info, debug, error, apply_lang_sort


class IPTVMasterService(xbmc.Monitor):

    def __init__(self):
        super().__init__()
        self._last_epg = time.time()
        info('IPTV Master service started')
        self._start_reminders()
        self._start_livetv1_list_warmup()
        self._start_favourites_warmup()
        self._start_livetv1_render_warmup()
        self._start_macsimum_epg_warmup()

    def _start_reminders(self):
        try:
            from reminders import ReminderMonitor
            self._reminder_monitor = ReminderMonitor()
        except Exception as e:
            error(f'reminder monitor: {e}')

    def _start_favourites_warmup(self):
        try:
            t = threading.Thread(
                target=self._warmup_favourites_epg_cache_bg,
                name='iptvmaster_favourites_warmup',
                daemon=True,
            )
            t.start()
        except Exception as e:
            error(f'favourites warmup start: {e}')

    def _start_livetv1_list_warmup(self):
        try:
            t = threading.Thread(
                target=self._warmup_livetv1_list_cache_bg,
                name='iptvmaster_livetv1_list_warmup',
                daemon=True,
            )
            t.start()
        except Exception as e:
            error(f'Live TV 1 list warmup start: {e}')

    def _start_livetv1_render_warmup(self):
        try:
            t = threading.Thread(
                target=self._warmup_livetv1_render_cache_bg,
                name='iptvmaster_livetv1_render_warmup',
                daemon=True,
            )
            t.start()
        except Exception as e:
            error(f'Live TV 1 render warmup start: {e}')

    def _start_macsimum_epg_warmup(self):
        try:
            t = threading.Thread(
                target=self._warmup_macsimum_epg_subset_bg,
                name='iptvmaster_macsimum_epg_warmup',
                daemon=True,
            )
            t.start()
        except Exception as e:
            error(f'macsimum EPG warmup start: {e}')

    def _cache_dir(self):
        path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.iptvmaster/cache/')
        xbmcvfs.mkdirs(path)
        return path

    def _favourites_epg_cache_path(self):
        return os.path.join(self._cache_dir(), 'favourites_epg_subset.json')

    def _livetv1_current_epg_cache_path(self):
        return os.path.join(self._cache_dir(), 'livetv1_current_epg.json')

    def _livetv1_render_cache_path(self):
        return os.path.join(self._cache_dir(), 'livetv1_render_cache.json')

    def _favourites_file_signature(self):
        fav_path = setting('favourites_file')
        if not fav_path:
            fav_path = os.path.join(
                xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.iptvmaster/'),
                'favourites.json'
            )
        try:
            return {
                'path': fav_path,
                'mtime': int(os.path.getmtime(fav_path)),
                'size': int(os.path.getsize(fav_path)),
            }
        except Exception:
            return {'path': fav_path, 'mtime': 0, 'size': 0}

    def _shared_epg_signature(self):
        try:
            epg_path = xbmcvfs.translatePath(
                'special://userdata/addon_data/pvr.iptvsimple/xmltv.xml.cache-1'
            )
            return {
                'path': epg_path,
                'mtime': int(os.path.getmtime(epg_path)),
                'size': int(os.path.getsize(epg_path)),
            }
        except Exception:
            return {'path': '', 'mtime': 0, 'size': 0}

    def _favourites_epg_signature(self, favs, portal):
        tvg_ids = sorted({str(f.get('tvg_id') or '').strip() for f in favs if f.get('tvg_id')})
        return {
            'version': 1,
            'portal_id': portal.get('id', '') if portal else '',
            'favourites': self._favourites_file_signature(),
            'shared_epg': self._shared_epg_signature(),
            'tvg_ids': tvg_ids,
        }

    def _load_favourites_epg_cache(self, favs, portal):
        path = self._favourites_epg_cache_path()
        if not os.path.exists(path):
            return None
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                obj = json.load(fh)
            if obj.get('signature') != self._favourites_epg_signature(favs, portal):
                return None
            data = obj.get('data')
            if isinstance(data, dict):
                return data
        except Exception as e:
            debug(f'favourites warmup cache read: {e}')
        return None

    @staticmethod
    def _filter_favourites_epg(favs, epg_data):
        if not isinstance(epg_data, dict):
            return {}
        wanted = {str(f.get('tvg_id') or '').strip() for f in favs if f.get('tvg_id')}
        return {tid: epg_data.get(tid, []) for tid in wanted if epg_data.get(tid)}

    def _save_favourites_epg_cache(self, favs, portal, epg_data):
        if not isinstance(epg_data, dict):
            return
        obj = {
            'ts': int(time.time()),
            'signature': self._favourites_epg_signature(favs, portal),
            'data': epg_data,
        }
        with open(self._favourites_epg_cache_path(), 'w', encoding='utf-8') as fh:
            json.dump(obj, fh, ensure_ascii=False, separators=(',', ':'))

    def _save_livetv1_current_epg_cache(self, epg_data):
        if not isinstance(epg_data, dict):
            return
        now = int(time.time())
        horizon = now + 8 * 3600
        compact = {}
        for key, entries in epg_data.items():
            if not isinstance(entries, list):
                continue
            keep = []
            for ev in entries:
                if not isinstance(ev, dict):
                    continue
                try:
                    start = int(ev.get('start_timestamp') or 0)
                    stop = int(ev.get('stop_timestamp') or 0)
                except Exception:
                    continue
                if stop >= now and start <= horizon:
                    keep.append(ev)
                if len(keep) >= 4:
                    break
            if keep:
                compact[key] = keep
        with open(self._livetv1_current_epg_cache_path(), 'w', encoding='utf-8') as fh:
            json.dump({'ts': int(time.time()), 'data': compact}, fh, ensure_ascii=False, separators=(',', ':'))
        info(f'Live TV 1 warmup: prepared compact EPG for {len(compact)} channels')

    def _load_livetv1_current_epg_cache(self):
        path = self._livetv1_current_epg_cache_path()
        if not os.path.exists(path):
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                obj = json.load(fh)
            data = obj.get('data')
            return data if isinstance(data, dict) else {}
        except Exception as e:
            debug(f'Live TV 1 render warmup: EPG cache read failed: {e}')
            return {}

    def _livetv1_portal(self):
        try:
            import portals as P
            portal = P.get_by_id('livetv1-vodkool-bridge')
            if portal:
                return portal
            for p in P.get_active():
                if p.get('id') == 'livetv1-vodkool-bridge':
                    return p
        except Exception as e:
            debug(f'Live TV 1 warmup: portal lookup failed: {e}')
        return None

    def _livetv1_render_signature(self, portal):
        playlist = (portal or {}).get('m3u_url', '')
        try:
            if playlist.startswith('special://'):
                playlist = xbmcvfs.translatePath(playlist)
        except Exception:
            pass
        playlist_sig = self._file_sig(playlist)
        epg_sig = self._file_sig(self._livetv1_current_epg_cache_path())
        playlist_sig.pop('path', None)
        epg_sig.pop('path', None)
        return {
            'version': 1,
            'portal_id': (portal or {}).get('id', ''),
            'playlist': playlist_sig,
            'epg': epg_sig,
            'sort_channels': setting_int('sort_channels'),
        }

    @staticmethod
    def _programme_to_info(channel, current_prog):
        info_d = {'title': channel.name, 'mediatype': 'video'}
        art_logo = channel.logo or ''
        progress = 0
        if current_prog:
            if not art_logo.lower().startswith(('http://', 'https://', 'special://', 'plugin://')):
                art_logo = current_prog.icon or art_logo
            programme_title = (current_prog.title or '').strip()
            programme_desc = (current_prog.desc or '').strip()
            try:
                programme_time = (
                    f'{time.strftime("%H:%M", time.localtime(current_prog.start))} - '
                    f'{time.strftime("%H:%M", time.localtime(current_prog.stop))}'
                ) if current_prog.start and current_prog.stop else ''
            except Exception:
                programme_time = ''
            plot_parts = []
            if programme_time:
                plot_parts.append(f'[B]{programme_time}[/B]')
            if programme_title:
                plot_parts.append(f'[B]{programme_title}[/B]')
            if programme_desc and programme_desc != programme_title:
                plot_parts.append(programme_desc)
            programme_plot = '\n'.join(part for part in plot_parts if part)
            info_d.update({
                'plot': f'[COLOR FFF7B731]{programme_plot}[/COLOR]',
                'genre': current_prog.category,
                'duration': max(0, current_prog.stop - current_prog.start),
            })
            try:
                progress = int(current_prog.progress() * 100)
            except Exception:
                progress = 0
        return info_d, art_logo, progress

    def _warmup_livetv1_render_cache_bg(self):
        for attempt in range(1, 5):
            if self.abortRequested():
                return
            xbmc.sleep(7000 if attempt == 1 else 3500)
            try:
                if self._warmup_livetv1_render_cache_once():
                    return
            except Exception as e:
                error(f'Live TV 1 render warmup attempt {attempt}: {e}')

    def _warmup_livetv1_render_cache_once(self):
        portal = self._livetv1_portal()
        if not portal:
            return False
        url = (portal.get('m3u_url') or '').strip()
        if not url:
            return False
        try:
            from iptv import load_m3u
            from epg import EPGManager
            channels = load_m3u(url, portal_id=portal.get('id', ''), force_refresh=False)
            channels = [c for c in channels if (c.group == 'Standart' or not c.group)]
            s = setting_int('sort_channels')
            if s == 1:
                channels.sort(key=lambda c: c.name.lower())
            elif s == 2:
                channels.sort(key=lambda c: c.name.lower(), reverse=True)
            channels = apply_lang_sort(channels)

            epg_data = self._load_livetv1_current_epg_cache()
            epg_mgr = EPGManager(epg_data) if epg_data else None
            rows = []
            now = time.time()
            for ch in channels:
                current = epg_mgr.get_current(ch.tvg_id, now=now) if epg_mgr else None
                info_d, logo, progress = self._programme_to_info(ch, current)
                rows.append({
                    'channel': ch.to_dict(),
                    'label': ch.name,
                    'play_url': ch.url,
                    'art': {'icon': logo, 'thumb': logo},
                    'info': info_d,
                    'progress': progress,
                })
            if not rows:
                return False
            payload = {
                'ts': time.time(),
                'signature': self._livetv1_render_signature(portal),
                'rows': rows,
            }
            with open(self._livetv1_render_cache_path(), 'w', encoding='utf-8') as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
            info(f'Live TV 1 warmup: prepared render cache for {len(rows)} channels')
            return True
        except Exception as e:
            error(f'Live TV 1 render warmup: {e}')
            return False

    def _warmup_favourites_epg_cache_bg(self):
        # Kodi/PVR brauchen beim Start manchmal ein paar Sekunden, bis die
        # IPTV-Simple-EPG-Datei sichtbar ist. Deshalb mehrere kurze Versuche.
        for attempt in range(1, 5):
            if self.abortRequested():
                return
            xbmc.sleep(4000 if attempt == 1 else 2500)
            try:
                if self._warmup_favourites_epg_cache_once():
                    return
            except Exception as e:
                error(f'favourites warmup attempt {attempt}: {e}')

    def _warmup_livetv1_list_cache_bg(self):
        # Live TV 1 ist eine lokale M3U-Brücke. Beim Start einmal parsen,
        # damit der IPTV-Master-Cache schon steht, bevor der Nutzer reingeht.
        for attempt in range(1, 4):
            if self.abortRequested():
                return
            xbmc.sleep(2500 if attempt == 1 else 2000)
            try:
                if self._warmup_livetv1_list_cache_once():
                    return
            except Exception as e:
                error(f'Live TV 1 list warmup attempt {attempt}: {e}')

    def _warmup_livetv1_list_cache_once(self):
        try:
            import portals as P
            from iptv import load_m3u
            portal = P.get_by_id('livetv1-vodkool-bridge')
            if not portal:
                for p in P.get_active():
                    if p.get('id') == 'livetv1-vodkool-bridge':
                        portal = p
                        break
            if not portal:
                debug('Live TV 1 warmup: bridge portal missing')
                return False
            url = (portal.get('m3u_url') or '').strip()
            if not url:
                debug('Live TV 1 warmup: bridge playlist missing')
                return False
            channels = load_m3u(url, portal_id=portal.get('id', ''), force_refresh=False)
            info(f'Live TV 1 warmup: prepared channel cache for {len(channels)} channels')
            return True
        except Exception as e:
            error(f'Live TV 1 warmup: {e}')
            return False

    def _warmup_favourites_epg_cache_once(self):
        favs = load_favourites()
        if not favs:
            debug('Favourites warmup: no favourites')
            return True

        import portals as P
        fav_portal = None
        for p in P.get_active():
            if p.get('type') == 'm3u' and p.get('epg_url'):
                fav_portal = p
                break
        if not fav_portal:
            debug('Favourites warmup: no active M3U portal with EPG')
            return False

        cached = self._load_favourites_epg_cache(favs, fav_portal)
        if isinstance(cached, dict):
            self._save_livetv1_current_epg_cache(cached)
            info(f'Favourites warmup: cache already ready ({len(cached)} channels)')
            return True

        from epg import load_cache, ensure_epg_loaded_for_portal
        epg_data = load_cache(fav_portal.get('id', ''))
        if not epg_data:
            epg_data = ensure_epg_loaded_for_portal(fav_portal, force=False) or {}
        subset = self._filter_favourites_epg(favs, epg_data)
        self._save_favourites_epg_cache(favs, fav_portal, subset)
        self._save_livetv1_current_epg_cache(subset)
        self._warmup_livetv1_render_cache_once()
        info(f'Favourites warmup: prepared {len(subset)} EPG channels for {len(favs)} favourites')
        return bool(subset) or not any(f.get('tvg_id') for f in favs)

    @staticmethod
    def _epg_norm(value):
        text = str(value or '').upper().replace('&', ' UND ')
        text = re.sub(r'\b(FHD|FULLHD|HD|RAW|HEVC|UHD|QHD|4K|2K|SD|HDR)\b', ' ', text)
        text = re.sub(r'[^A-Z0-9ÄÖÜẞ]+', ' ', text)
        return re.sub(r'\s+', ' ', text).strip()

    @staticmethod
    def _epg_norm_compact(value):
        return IPTVMasterService._epg_norm(value).replace(' ', '')

    @staticmethod
    def _xmltv_ts_to_epoch(value):
        raw = str(value or '').strip()
        if len(raw) < 14:
            return 0
        try:
            return time.mktime(time.strptime(raw[:14], '%Y%m%d%H%M%S'))
        except Exception:
            return 0

    def _macsimum_epg_paths(self):
        pvr_epg = xbmcvfs.translatePath('special://userdata/addon_data/pvr.iptvsimple/xmltv.xml.cache-1')
        playlist = xbmcvfs.translatePath(
            'special://userdata/addon_data/plugin.video.playlistloader.macsimum/playlists/stalker_macsimum_live_tv.m3u'
        )
        target_dir = xbmcvfs.translatePath(
            'special://userdata/addon_data/plugin.video.playlistloader.macsimum/epg/'
        )
        xbmcvfs.mkdirs(target_dir)
        target = os.path.join(target_dir, 'macsimum_epg_subset.xml')
        meta = os.path.join(target_dir, 'macsimum_epg_subset.meta.json')
        return pvr_epg, playlist, target, meta

    def _file_sig(self, path):
        try:
            return {'path': path, 'mtime': int(os.path.getmtime(path)), 'size': int(os.path.getsize(path))}
        except Exception:
            return {'path': path, 'mtime': 0, 'size': 0}

    def _read_macsimum_de_targets(self, playlist):
        targets = set()
        target_compact = set()
        target_ids = set()
        attr_re = re.compile(r'(tvg-id|tvg-name)="([^"]*)"')
        try:
            with open(playlist, 'r', encoding='utf-8', errors='ignore') as fh:
                for line in fh:
                    if not line.startswith('#EXTINF'):
                        continue
                    attrs = dict(attr_re.findall(line))
                    label = line.rsplit(',', 1)[-1].strip() if ',' in line else ''
                    for value in (label, attrs.get('tvg-name', ''), attrs.get('tvg-id', '')):
                        key = self._epg_norm(value)
                        if key:
                            targets.add(key)
                            target_compact.add(key.replace(' ', ''))
                    tid = str(attrs.get('tvg-id') or '').strip()
                    if tid:
                        target_ids.add(tid)
        except Exception as e:
            error(f'Macsimum EPG: could not read playlist targets: {e}')
        return targets, target_compact, target_ids

    def _open_xmltv_bytes(self, path):
        with open(path, 'rb') as fh:
            raw = fh.read()
        if raw[:2] == b'\x1f\x8b':
            raw = gzip.decompress(raw)
        return io.BytesIO(raw)

    def _warmup_macsimum_epg_subset_bg(self):
        # Erst nach IPTV Simple/PVR warten: diese Datei ist die Online-Quelle,
        # aus der die kompakte Live-TV-3-EPG gebaut wird.
        for attempt in range(1, 6):
            if self.abortRequested():
                return
            xbmc.sleep(7000 if attempt == 1 else 4000)
            try:
                if self._warmup_macsimum_epg_subset_once():
                    return
            except Exception as e:
                error(f'Macsimum EPG warmup attempt {attempt}: {e}')

    def _warmup_macsimum_epg_subset_once(self):
        pvr_epg, playlist, target, meta = self._macsimum_epg_paths()
        if not os.path.exists(pvr_epg) or not os.path.exists(playlist):
            debug('Macsimum EPG: source EPG or playlist missing')
            return False

        signature = {
            'version': 3,
            'source': self._file_sig(pvr_epg),
            'playlist': self._file_sig(playlist),
            'window_hours': 12,
            'max_programmes_per_channel': 4,
        }
        try:
            if os.path.exists(target) and os.path.exists(meta):
                with open(meta, 'r', encoding='utf-8') as fh:
                    old = json.load(fh)
                # Auch bei gleicher Quelle nach 6 Stunden neu schneiden, damit
                # "jetzt läuft" nicht mit einem uralten Zeitfenster arbeitet.
                if old.get('signature') == signature and time.time() - float(old.get('ts', 0)) < 6 * 3600:
                    info('Macsimum EPG: compact subset already current')
                    return True
        except Exception:
            pass

        targets, target_compact, target_ids = self._read_macsimum_de_targets(playlist)
        if not targets and not target_ids:
            debug('Macsimum EPG: no playlist targets')
            return False

        matched_ids = set()
        channel_xml = {}
        programmes_xml = []
        programme_counts = {}
        now = time.time()
        start_floor = now - 3 * 3600
        stop_ceiling = now + 12 * 3600

        stream = self._open_xmltv_bytes(pvr_epg)
        for event, elem in ET.iterparse(stream, events=('end',)):
            if elem.tag == 'channel':
                cid = elem.attrib.get('id', '')
                display = elem.findtext('display-name') or cid
                key = self._epg_norm(display)
                key_compact = key.replace(' ', '')
                if cid in target_ids or key in targets or key_compact in target_compact:
                    matched_ids.add(cid)
                    channel_xml[cid] = ET.tostring(elem, encoding='unicode')
                elem.clear()
            elif elem.tag == 'programme':
                cid = elem.attrib.get('channel', '')
                if cid in matched_ids:
                    start_ts = self._xmltv_ts_to_epoch(elem.attrib.get('start', ''))
                    stop_ts = self._xmltv_ts_to_epoch(elem.attrib.get('stop', ''))
                    if (
                        stop_ts >= start_floor
                        and start_ts <= stop_ceiling
                        and programme_counts.get(cid, 0) < 4
                    ):
                        programmes_xml.append(ET.tostring(elem, encoding='unicode'))
                        programme_counts[cid] = programme_counts.get(cid, 0) + 1
                elem.clear()

        if not channel_xml or not programmes_xml:
            debug(f'Macsimum EPG: no usable subset channels={len(channel_xml)} programmes={len(programmes_xml)}')
            return False

        tmp = target + '.tmp'
        with open(tmp, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write("<?xml version='1.0' encoding='utf-8'?>\n<tv>\n")
            for cid in sorted(channel_xml):
                fh.write(channel_xml[cid])
                fh.write('\n')
            for row in programmes_xml:
                fh.write(row)
                fh.write('\n')
            fh.write('</tv>\n')
        os.replace(tmp, target)
        with open(meta, 'w', encoding='utf-8') as fh:
            json.dump({
                'ts': time.time(),
                'signature': signature,
                'channels': len(channel_xml),
                'programmes': len(programmes_xml),
                'source': 'pvr.iptvsimple/xmltv.xml.cache-1',
            }, fh, ensure_ascii=False, indent=2)

        # Alte "now"-Caches und Render-Caches verwerfen; die neue EPG-Signatur
        # soll beim nächsten Öffnen frisch und schnell greifen.
        for rel in ('codex_epg_now_cache', 'codex_render_cache'):
            cache_dir = xbmcvfs.translatePath(f'special://userdata/addon_data/plugin.video.playlistloader.macsimum/{rel}/')
            try:
                if os.path.isdir(cache_dir):
                    for name in os.listdir(cache_dir):
                        path = os.path.join(cache_dir, name)
                        if os.path.isfile(path) and name.endswith('.json'):
                            os.unlink(path)
            except Exception:
                pass
        info(f'Macsimum EPG: compact subset updated channels={len(channel_xml)} programmes={len(programmes_xml)} bytes={os.path.getsize(target)}')
        return True

    def _maybe_refresh_epg(self):
        if not setting_bool('epg_auto_refresh', True):
            return
        interval = setting_int('epg_refresh_hours', 12) * 3600
        if time.time() - self._last_epg < interval:
            return
        self._last_epg = time.time()
        info('Service: auto-refreshing EPG for all active portals')
        try:
            import portals as P
            from epg import ensure_epg_loaded_for_portal
            for p in P.get_active():
                ensure_epg_loaded_for_portal(p, force=False)
            self._warmup_favourites_epg_cache_once()
            self._warmup_livetv1_render_cache_once()
            self._warmup_macsimum_epg_subset_once()
        except Exception as e:
            error(f'Service EPG refresh: {e}')

    def run(self):
        last_livetv1_render = 0
        while not self.abortRequested():
            self._maybe_refresh_epg()
            if time.time() - last_livetv1_render > 15 * 60:
                last_livetv1_render = time.time()
                try:
                    self._warmup_livetv1_render_cache_once()
                except Exception as e:
                    error(f'Live TV 1 periodic render warmup: {e}')
            self.waitForAbort(300)
        info('IPTV Master service stopped')


if __name__ == '__main__':
    IPTVMasterService().run()
