﻿"""Stalker VOD plugin entry point"""
from __future__ import absolute_import, division, unicode_literals

ADDON_ID = 'plugin.video.stalker.macsimum.talker3'
OLD_ADDON_ID = 'plugin.video.stalker.macsimum'
EXPECTED_PACKAGE = 'stubebox.legacy.org'
CURRENT_PACKAGE = 'stube.box.legacy'
CODEX_TITLE_VIEW_MODE = 131572
CODEX_MEDIA_PAGE_SIZE = 60
CODEX_TMDB_API_KEY = '86dd18b04874d9c94afadde7993d94e3'
_CODEX_TMDB_CACHE = {}
TALKER3_FAVORITES_FILE = 'talker3_favorites.json'

def _codex_redact_mac(value):
    try:
        import re
        match = re.search(r'(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b', str(value or ''))
        mac_value = match.group(0).upper() if match else ''
        return '****' + mac_value[-5:] if mac_value else '<none>'
    except Exception:
        return '<none>'


def _codex_extract_macs_from_text(text, limit=8):
    try:
        import re
        if isinstance(text, bytes):
            text = text.decode('utf-8', 'ignore')
        found = []
        for mac in re.findall(r'(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b', str(text or '')):
            mac = mac.upper()
            if mac not in found:
                found.append(mac)
            if len(found) >= int(limit):
                break
        return found
    except Exception:
        return []


def _codex_talker3_profile_mac_snapshot():
    try:
        import os
        import xbmcaddon
        import xbmcvfs
        profile = xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')
        data_dir = xbmcvfs.translatePath(profile)
        if not data_dir or not os.path.isdir(data_dir):
            return []
        hits = []
        for name in os.listdir(data_dir):
            lname = name.lower()
            if not lname.endswith(('.json', '.txt', '.dat', '.cache')):
                continue
            if not any(marker in lname for marker in ('mac', 'session', 'token', 'handshake', 'auth', 'profile')):
                continue
            path = os.path.join(data_dir, name)
            if not os.path.isfile(path):
                continue
            try:
                with open(path, 'rb') as fh:
                    chunk = fh.read(4096)
                for mac in _codex_extract_macs_from_text(chunk, limit=4):
                    hits.append('%s=%s' % (name, _codex_redact_mac(mac)))
            except Exception:
                continue
        return hits[:12]
    except Exception:
        return []


def _codex_log_mac_analytics(portal, event, reason=''):
    try:
        import xbmc
        snapshot = _codex_talker3_profile_mac_snapshot()
        xbmc.log(
            '[CODEX-MAC-ANALYTICS][%s] %s reason=%s profile_macs=%s' % (
                portal,
                event,
                reason or '-',
                ', '.join(snapshot) if snapshot else '<none>',
            ),
            xbmc.LOGWARNING,
        )
    except Exception:
        pass


def _install_talker3_runtime_patch():
    try:
        import builtins
        import json
        import os
        import sys
        import time
        import xbmc
        import xbmcaddon
        import xbmcgui
    except Exception:
        return

    state = {'package_warning_at': 0.0}

    class _PortalList(list):
        def get(self, key, default=None):
            if key in ('js', 'data', 'results', 'items', 'channels'):
                return self
            if key in ('total_items', 'total', 'count'):
                return len(self)
            if key in ('max_page_items', 'page_items'):
                return len(self)
            return default

    def _portal_compat(value):
        if isinstance(value, list) and not isinstance(value, _PortalList):
            return _PortalList(_portal_compat(item) for item in value)
        if isinstance(value, dict):
            for key, item in list(value.items()):
                value[key] = _portal_compat(item)
        return value

    try:
        _orig_json_loads = json.loads
        _orig_json_load = json.load

        def _safe_json_loads(*args, **kwargs):
            return _portal_compat(_orig_json_loads(*args, **kwargs))

        def _safe_json_load(*args, **kwargs):
            return _portal_compat(_orig_json_load(*args, **kwargs))

        json.loads = _safe_json_loads
        json.load = _safe_json_load
    except Exception:
        pass

    def _blocked_exit(*args, **kwargs):
        try:
            xbmc.log('[Talker3 Macsimum] blocked forced addon exit', xbmc.LOGWARNING)
        except Exception:
            pass
        return None

    try:
        builtins.exit = _blocked_exit
        builtins.quit = _blocked_exit
        sys.exit = _blocked_exit
        os._exit = _blocked_exit
    except Exception:
        pass

    try:
        _orig_builtin = xbmc.executebuiltin

        def _safe_builtin(command, *args, **kwargs):
            cmd = str(command or '').lower()
            blocked = (
                'quit' in cmd or
                'shutdown' in cmd or
                'restartapp' in cmd or
                'system.exit' in cmd
            )
            if blocked:
                try:
                    xbmc.log('[Talker3 Macsimum] blocked builtin: %s' % command, xbmc.LOGWARNING)
                except Exception:
                    pass
                return None
            return _orig_builtin(command, *args, **kwargs)

        xbmc.executebuiltin = _safe_builtin
    except Exception:
        pass

    try:
        _orig_sleep = xbmc.sleep

        def _safe_sleep(milliseconds):
            try:
                delay = int(milliseconds)
            except Exception:
                delay = 0
            if delay >= 9000 and time.monotonic() - state.get('package_warning_at', 0.0) < 2.0:
                try:
                    xbmc.log('[Talker3 Macsimum] skipped package guard delay: %sms' % delay, xbmc.LOGWARNING)
                except Exception:
                    pass
                return None
            return _orig_sleep(milliseconds)

        xbmc.sleep = _safe_sleep
    except Exception:
        pass

    try:
        _orig_info_label = xbmc.getInfoLabel

        def _safe_info_label(label):
            value = _orig_info_label(label)
            if isinstance(value, str) and CURRENT_PACKAGE in value:
                return value.replace(CURRENT_PACKAGE, EXPECTED_PACKAGE)
            return value

        xbmc.getInfoLabel = _safe_info_label
    except Exception:
        pass

    try:
        _orig_translate = getattr(xbmc, 'translatePath', None)
        if _orig_translate:
            def _safe_translate(path):
                value = _orig_translate(path)
                path_text = str(path or '').lower()
                if (
                    isinstance(value, str) and
                    CURRENT_PACKAGE in value and
                    (
                        path_text.startswith('special://xbmc') or
                        path_text.startswith('special://xbmcbin') or
                        path_text.startswith('special://envhome')
                    )
                ):
                    return value.replace(CURRENT_PACKAGE, EXPECTED_PACKAGE)
                return value

            xbmc.translatePath = _safe_translate
    except Exception:
        pass

    try:
        import xbmcvfs
        _orig_vfs_translate = getattr(xbmcvfs, 'translatePath', None)
        if _orig_vfs_translate:
            def _safe_vfs_translate(path):
                value = _orig_vfs_translate(path)
                path_text = str(path or '').lower()
                if (
                    isinstance(value, str) and
                    CURRENT_PACKAGE in value and
                    (
                        path_text.startswith('special://xbmc') or
                        path_text.startswith('special://xbmcbin') or
                        path_text.startswith('special://envhome')
                    )
                ):
                    return value.replace(CURRENT_PACKAGE, EXPECTED_PACKAGE)
                return value

            xbmcvfs.translatePath = _safe_vfs_translate
    except Exception:
        pass

    try:
        import socket
        import urllib.parse
        import urllib.request
        import ssl
        import ipaddress
        import json as _dns_json
        import time
        import os
        import sys
        import xbmcplugin

        _dns_state = {
            'cache': {},
            'endpoints': (
                'https://cloudflare-dns.com/dns-query',
                'https://dns.google/resolve',
            ),
        }

        def _dns_provider_name(endpoint):
            endpoint = str(endpoint or '').lower()
            if 'cloudflare' in endpoint:
                return 'Cloudflare DoH'
            if 'google' in endpoint:
                return 'Google DoH'
            return endpoint or 'unknown DoH'

        def _dns_normalize_host(host):
            if host is None:
                return ''
            if isinstance(host, bytes):
                try:
                    host = host.decode('utf-8')
                except Exception:
                    host = host.decode('latin-1', 'ignore')
            host = str(host).strip()
            if host.startswith('[') and host.endswith(']'):
                host = host[1:-1]
            return host.lower()

        def _dns_is_ip(host):
            try:
                ipaddress.ip_address(host)
                return True
            except Exception:
                return False

        def _dns_resolve_host(host):
            host = _dns_normalize_host(host)
            if not host or host == 'localhost' or _dns_is_ip(host):
                return host
            cached = _dns_state['cache'].get(host)
            now = time.time()
            if cached and cached[1] > now:
                try:
                    xbmc.log('[Talker3 Codex DNS] Resolved %s to %s via %s (cache)' % (host, cached[0], cached[2]), xbmc.LOGINFO)
                except Exception:
                    pass
                return cached[0]
            for endpoint in _dns_state['endpoints']:
                try:
                    url = '%s?%s' % (endpoint, urllib.parse.urlencode({'name': host, 'type': 'A'}))
                    req = urllib.request.Request(url)
                    req.add_header('Accept', 'application/dns-json')
                    ctx = ssl.create_default_context()
                    response = urllib.request.urlopen(req, timeout=5, context=ctx)
                    payload = _dns_json.loads(response.read().decode('utf-8', 'replace'))
                    for answer in payload.get('Answer') or []:
                        if answer.get('type') != 1:
                            continue
                        ip = answer.get('data')
                        if not ip or not _dns_is_ip(ip):
                            continue
                        ttl = int(answer.get('TTL') or 600)
                        ttl = max(60, min(ttl, 3600))
                        provider = _dns_provider_name(endpoint)
                        _dns_state['cache'][host] = (ip, now + ttl, provider)
                        try:
                            xbmc.log('[Talker3 Codex DNS] %s %s -> %s' % (provider, host, ip), xbmc.LOGINFO)
                        except Exception:
                            pass
                        return ip
                except Exception as dns_exc:
                    try:
                        xbmc.log('[Talker3 Codex DNS] %s failed for %s: %s' % (_dns_provider_name(endpoint), host, dns_exc), xbmc.LOGDEBUG)
                    except Exception:
                        pass
            return None

        class _CodexDnsAnswer(object):
            def __init__(self, ip):
                self._ip = ip

            def to_text(self):
                return self._ip

            def __str__(self):
                return self._ip

        class _CodexDnsAnswerList(list):
            def __init__(self, ip):
                super(_CodexDnsAnswerList, self).__init__([_CodexDnsAnswer(ip)])

        def _dns_patch_dnspython():
            try:
                addon_lib = os.path.join(os.path.dirname(__file__), 'lib')
                if addon_lib not in sys.path:
                    sys.path.insert(0, addon_lib)
                import dns.resolver as _dns_resolver
            except Exception as import_exc:
                try:
                    xbmc.log('[Talker3 Codex DNS] dnspython import skipped: %s' % import_exc, xbmc.LOGDEBUG)
                except Exception:
                    pass
                return

            _orig_module_resolve = getattr(_dns_resolver, 'resolve', None)
            _orig_module_query = getattr(_dns_resolver, 'query', None)
            _orig_resolver_resolve = getattr(getattr(_dns_resolver, 'Resolver', object), 'resolve', None)

            def _codex_module_resolve(qname, rdtype='A', *args, **kwargs):
                if str(rdtype or 'A').upper() in ('A', '1'):
                    ip = _dns_resolve_host(qname)
                    if ip:
                        return _CodexDnsAnswerList(ip)
                if _orig_module_resolve:
                    return _orig_module_resolve(qname, rdtype, *args, **kwargs)
                raise Exception('DNS resolve failed for %s' % qname)

            def _codex_module_query(qname, rdtype='A', *args, **kwargs):
                return _codex_module_resolve(qname, rdtype, *args, **kwargs)

            def _codex_resolver_resolve(self, qname, rdtype='A', *args, **kwargs):
                if str(rdtype or 'A').upper() in ('A', '1'):
                    ip = _dns_resolve_host(qname)
                    if ip:
                        return _CodexDnsAnswerList(ip)
                if _orig_resolver_resolve:
                    return _orig_resolver_resolve(self, qname, rdtype, *args, **kwargs)
                raise Exception('DNS resolve failed for %s' % qname)

            try:
                _dns_resolver.resolve = _codex_module_resolve
                _dns_resolver.query = _codex_module_query
                if hasattr(_dns_resolver, 'Resolver'):
                    _dns_resolver.Resolver.resolve = _codex_resolver_resolve
                xbmc.log('[Talker3 Codex DNS] dnspython resolver patched to Cloudflare/Google DoH', xbmc.LOGINFO)
            except Exception as patch_exc:
                try:
                    xbmc.log('[Talker3 Codex DNS] dnspython patch failed: %s' % patch_exc, xbmc.LOGWARNING)
                except Exception:
                    pass

        _dns_patch_dnspython()

        def _dns_split_kodi_options(url):
            if '|' not in url:
                return url, ''
            return url.split('|', 1)

        def _dns_append_option(option_string, key, value):
            if not option_string:
                return '%s=%s' % (key, urllib.parse.quote(str(value), safe=''))
            if ('%s=' % key.lower()) in option_string.lower():
                return option_string
            return '%s&%s=%s' % (option_string, key, urllib.parse.quote(str(value), safe=''))

        def _dns_prepare_stream_url(url):
            if not isinstance(url, str) or not url:
                return url
            base_url, option_string = _dns_split_kodi_options(url)
            parsed = urllib.parse.urlsplit(base_url)
            host = _dns_normalize_host(parsed.hostname)
            if parsed.scheme.lower() != 'http':
                return url
            if not host or host == 'localhost' or _dns_is_ip(host):
                return url
            ip = _dns_resolve_host(host)
            if not ip:
                return url
            credentials = ''
            if parsed.username:
                credentials = parsed.username
                if parsed.password is not None:
                    credentials += ':' + parsed.password
                credentials += '@'
            netloc = credentials + ip
            if parsed.port:
                netloc += ':%s' % parsed.port
            rewritten = urllib.parse.urlunsplit((parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment))
            host_header = host
            if parsed.port:
                host_header += ':%s' % parsed.port
            option_string = _dns_append_option(option_string, 'Host', host_header)
            result = '%s|%s' % (rewritten, option_string)
            try:
                xbmc.log('[Talker3 Codex DNS] prepared Kodi stream URL host=%s ip=%s' % (host, ip), xbmc.LOGINFO)
            except Exception:
                pass
            return result

        _orig_set_resolved_url = xbmcplugin.setResolvedUrl

        def _dns_safe_set_resolved_url(handle, succeeded, listitem, *args, **kwargs):
            try:
                if succeeded and listitem is not None:
                    path = ''
                    try:
                        path = listitem.getPath()
                    except Exception:
                        path = ''
                    new_path = _dns_prepare_stream_url(path)
                    if new_path and new_path != path:
                        try:
                            listitem.setPath(new_path)
                        except Exception:
                            pass
            except Exception as patch_exc:
                try:
                    xbmc.log('[Talker3 Codex DNS] setResolvedUrl patch skipped: %s' % patch_exc, xbmc.LOGDEBUG)
                except Exception:
                    pass
            return _orig_set_resolved_url(handle, succeeded, listitem, *args, **kwargs)

        xbmcplugin.setResolvedUrl = _dns_safe_set_resolved_url
        xbmc.log('[Talker3 Codex DNS] request-safe DNS prepared for direct HTTP streams', xbmc.LOGINFO)
    except Exception as exc:
        try:
            xbmc.log('[Talker3 Codex DNS] setup failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass

    try:
        _orig_dialog = xbmcgui.Dialog

        def _is_package_warning(*parts):
            text = ' '.join(str(part or '') for part in parts).lower()
            return (
                ('wrong' in text and 'application' in text) or
                ('studio box' in text and 'apk' in text) or
                ('original' in text and 'studio' in text) or
                ('shutting down kodi' in text) or
                ('stubebox.legacy.org' in text and CURRENT_PACKAGE in text)
            )

        class _SafeDialog(object):
            def __init__(self, *args, **kwargs):
                self._dialog = _orig_dialog(*args, **kwargs)

            def __getattr__(self, name):
                return getattr(self._dialog, name)

            def ok(self, heading, message='', *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state['package_warning_at'] = time.monotonic()
                    try:
                        xbmc.log('[Talker3 Macsimum] suppressed package warning dialog', xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return True
                return self._dialog.ok(heading, message, *args, **kwargs)

            def yesno(self, heading, message='', *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state['package_warning_at'] = time.monotonic()
                    try:
                        xbmc.log('[Talker3 Macsimum] suppressed package yesno dialog', xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return False
                return self._dialog.yesno(heading, message, *args, **kwargs)

            def notification(self, heading, message='', *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state['package_warning_at'] = time.monotonic()
                    try:
                        xbmc.log('[Talker3 Macsimum] suppressed package notification', xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return None
                return self._dialog.notification(heading, message, *args, **kwargs)

        xbmcgui.Dialog = _SafeDialog
    except Exception:
        pass

    try:
        _orig_addon = xbmcaddon.Addon

        def _talker3_addon(addon_id=None):
            if addon_id == OLD_ADDON_ID:
                addon_id = ADDON_ID
            return _orig_addon(addon_id) if addon_id else _orig_addon()

        xbmcaddon.Addon = _talker3_addon
    except Exception:
        pass


def _codex_data_dir():
    try:
        import os
        import xbmc
        base = xbmc.translatePath('special://profile/addon_data/%s' % ADDON_ID)
        os.makedirs(base, exist_ok=True)
        return base
    except Exception:
        try:
            import os
            base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'userdata', 'addon_data', ADDON_ID))
            os.makedirs(base, exist_ok=True)
            return base
        except Exception:
            return ''


def _codex_norm(value):
    try:
        import re
        value = str(value or '').lower().replace('Ã¢â€ Âº', ' ').replace('â†º', ' ')
        value = re.sub(r'[^a-z0-9Ã¤Ã¶Ã¼ÃŸ]+', ' ', value)
        return re.sub(r'\s+', ' ', value).strip()
    except Exception:
        return str(value or '').lower().strip()


def _codex_base(value):
    try:
        import re
        value = _codex_norm(value)
        value = re.sub(r'\b(fhd|full hd|hd|hevc|raw|uhd|4k|2k|sd|de|germany|deutschland)\b', ' ', value)
        return re.sub(r'\s+', ' ', value).strip()
    except Exception:
        return _codex_norm(value)


def _codex_quality(value):
    n = _codex_norm(value)
    return {q for q in ('fhd', 'hd', 'hevc', 'raw', 'uhd', '4k', '2k', 'sd') if q in n.split()}


def _codex_aliases(label):
    keys = set()
    for value in (label, _codex_norm(label), _codex_base(label)):
        value = _codex_norm(value)
        if value:
            keys.add(value)
    for key in list(keys):
        variants = (
            key.replace('pro 7', 'prosieben'),
            key.replace('pro sieben', 'prosieben'),
            key.replace('prosieben', 'pro sieben'),
            key.replace('prosieben', 'pro 7'),
            key.replace('sat 1', 'sat1'),
            key.replace('sat1', 'sat 1'),
            key.replace('sat eins', 'sat 1'),
            key.replace('kabel eins', 'kabel 1'),
            key.replace('kabel 1', 'kabel eins'),
            key.replace('rtl zwei', 'rtl2'),
            key.replace('rtl2', 'rtl zwei'),
            key.replace(' ', '').replace('.', ''),
        )
        for item in variants:
            if item:
                keys.add(item)
    return sorted(k for k in keys if k)


def _codex_norm(value):
    try:
        import re
        value = str(value or '').lower()
        value = value.replace('ÃƒÂ¢Ã¢â‚¬Â Ã‚Âº', ' ').replace('Ã¢â€ Âº', ' ').replace('ÃƒÅ¸', 'ss')
        value = value.replace('ÃŸ', 'ss').replace('Â²', '').replace('Â³', '')
        value = re.sub(r'[^a-z0-9ÃƒÂ¤ÃƒÂ¶ÃƒÂ¼ÃƒÅ¸]+', ' ', value)
        return re.sub(r'\s+', ' ', value).strip()
    except Exception:
        return str(value or '').lower().strip()


def _codex_base(value):
    try:
        import re
        value = _codex_norm(value)
        value = value.replace('fussball tv tv', 'fussball tv')
        value = value.replace('kabel eins', 'kabel 1')
        value = value.replace('sat eins', 'sat 1')
        value = value.replace('rtl zwei', 'rtl2')
        value = value.replace('pro sieben', 'prosieben')
        value = value.replace('pro 7', 'prosieben')
        value = re.sub(r'\b(magenta tv|magenta|telekom|bck|backup|web|neu|bks|720p|1080p|2160p)\b', ' ', value)
        value = re.sub(r'\b(fhd|full hd|hd|hevc|raw|uhd|4k|2k|sd|de|germany|deutschland)\b', ' ', value)
        return re.sub(r'\s+', ' ', value).strip()
    except Exception:
        return _codex_norm(value)


def _codex_quality(value):
    n = _codex_norm(value)
    return {q for q in ('fhd', 'hd', 'hevc', 'raw', 'uhd', '4k', '2k', 'sd') if q in n.split()}


def _codex_aliases(label):
    keys = set()
    for value in (label, _codex_norm(label), _codex_base(label)):
        value = _codex_norm(value)
        if value:
            keys.add(value)
    for key in list(keys):
        variants = (
            key.replace('pro 7', 'prosieben'),
            key.replace('pro sieben', 'prosieben'),
            key.replace('prosieben', 'pro sieben'),
            key.replace('prosieben', 'pro 7'),
            key.replace('sat 1', 'sat1'),
            key.replace('sat1', 'sat 1'),
            key.replace('sat eins', 'sat 1'),
            key.replace('kabel eins', 'kabel 1'),
            key.replace('kabel 1', 'kabel eins'),
            key.replace('rtl zwei', 'rtl2'),
            key.replace('rtl2', 'rtl zwei'),
            key.replace('fussball tv', 'fussball'),
            key.replace('fussball', 'fussball tv'),
            key.replace('fussball tv tv', 'fussball tv'),
            key.replace('magenta tv ', ''),
            key.replace('magenta ', ''),
            key.replace('telekom ', ''),
            key.replace(' ', '').replace('.', ''),
        )
        for item in variants:
            item = _codex_norm(item)
            if item:
                keys.add(item)
                keys.add(item.replace(' ', '').replace('.', ''))
    return sorted(k for k in keys if k)


def _codex_store_channel(label, cmd, icon=''):
    try:
        import json
        import os
        import time
        import xbmc
    except Exception:
        return False
    try:
        label = str(label or '').strip()
        cmd = str(cmd or '').strip()
        icon = str(icon or '').strip()
        if not label or not cmd:
            return False
        base = _codex_data_dir()
        if not base:
            return False
        now = int(time.time())
        keys = _codex_aliases(label)
        entry = {'name': label, 'cmd': cmd, 'icon': icon, 'keys': keys, 'captured_at': now}

        cache_path = os.path.join(base, 'codex_talker3_channels_cache.json')
        cache_read_failed = False
        try:
            with open(cache_path, 'r', encoding='utf-8') as fh:
                cache = json.load(fh)
        except Exception:
            cache = {}
            cache_read_failed = True
        if not isinstance(cache, dict):
            cache = {}
            cache_read_failed = True
        if cache_read_failed:
            try:
                if os.path.exists(cache_path) and os.path.getsize(cache_path) > 30000:
                    xbmc.log('[Talker3 Codex] bridge cache single write skipped: existing cache unreadable/large', xbmc.LOGWARNING)
                    return False
            except Exception:
                pass
        channels = cache.get('channels') if isinstance(cache.get('channels'), list) else []
        replaced = False
        for idx, old in enumerate(channels):
            try:
                if old.get('cmd') == cmd or _codex_norm(old.get('name')) == _codex_norm(label):
                    channels[idx] = entry
                    replaced = True
                    break
            except Exception:
                pass
        if not replaced:
            channels.append(entry)
        cache['channels'] = channels
        cache['updated_at'] = now
        tmp_cache_path = cache_path + '.tmp'
        with open(tmp_cache_path, 'w', encoding='utf-8') as fh:
            json.dump(cache, fh, ensure_ascii=False, indent=2)
        try:
            os.replace(tmp_cache_path, cache_path)
        except Exception:
            with open(cache_path, 'w', encoding='utf-8') as fh:
                json.dump(cache, fh, ensure_ascii=False, indent=2)

        recent_path = os.path.join(base, 'codex_talker3_recent_plays.json')
        try:
            with open(recent_path, 'r', encoding='utf-8') as fh:
                recent = json.load(fh)
        except Exception:
            recent = {}
        if not isinstance(recent, dict):
            recent = {}
        plays = recent.get('plays') if isinstance(recent.get('plays'), dict) else {}
        recent_entry = {'cmd': cmd, 'icon': icon, 'captured_at': now, 'keys': keys}
        for key in keys:
            plays[key] = recent_entry
        recent['plays'] = plays
        recent['updated_at'] = now
        tmp_recent_path = recent_path + '.tmp'
        with open(tmp_recent_path, 'w', encoding='utf-8') as fh:
            json.dump(recent, fh, ensure_ascii=False, indent=2)
        try:
            os.replace(tmp_recent_path, recent_path)
        except Exception:
            with open(recent_path, 'w', encoding='utf-8') as fh:
                json.dump(recent, fh, ensure_ascii=False, indent=2)
        try:
            xbmc.log('[Talker3 Codex] stored channel %s -> %s' % (label, cmd), xbmc.LOGWARNING)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _codex_store_channels_batch(entries):
    try:
        import json
        import os
        import time
        import xbmc
    except Exception:
        return 0
    try:
        base = _codex_data_dir()
        if not base:
            return 0
        now = int(time.time())
        clean = []
        seen = set()
        for item in entries or []:
            try:
                label = str(item.get('name') or item.get('label') or '').strip()
                cmd = str(item.get('cmd') or '').strip()
                icon = str(item.get('icon') or item.get('logo') or '').strip()
                if not label or not cmd or cmd in seen:
                    continue
                seen.add(cmd)
                clean.append({'name': label, 'cmd': cmd, 'icon': icon, 'keys': _codex_aliases(label), 'captured_at': now})
            except Exception:
                pass
        if not clean:
            return 0

        cache_path = os.path.join(base, 'codex_talker3_channels_cache.json')
        try:
            with open(cache_path, 'r', encoding='utf-8') as fh:
                cache = json.load(fh)
        except Exception:
            cache = {}
        if not isinstance(cache, dict):
            cache = {}
        channels = cache.get('channels') if isinstance(cache.get('channels'), list) else []
        index = {}
        for idx, old in enumerate(channels):
            try:
                if old.get('cmd'):
                    index[('cmd', old.get('cmd'))] = idx
                if old.get('name'):
                    index[('name', _codex_norm(old.get('name')))] = idx
            except Exception:
                pass
        written = 0
        for entry in clean:
            idx = index.get(('cmd', entry['cmd']))
            if idx is None:
                idx = index.get(('name', _codex_norm(entry['name'])))
            if idx is None:
                channels.append(entry)
                idx = len(channels) - 1
            else:
                channels[idx] = entry
            index[('cmd', entry['cmd'])] = idx
            index[('name', _codex_norm(entry['name']))] = idx
            written += 1
        cache['channels'] = channels[-6000:]
        cache['updated_at'] = now
        tmp_cache_path = cache_path + '.tmp'
        with open(tmp_cache_path, 'w', encoding='utf-8') as fh:
            json.dump(cache, fh, ensure_ascii=False, indent=2)
        try:
            os.replace(tmp_cache_path, cache_path)
        except Exception:
            with open(cache_path, 'w', encoding='utf-8') as fh:
                json.dump(cache, fh, ensure_ascii=False, indent=2)

        recent_path = os.path.join(base, 'codex_talker3_recent_plays.json')
        try:
            with open(recent_path, 'r', encoding='utf-8') as fh:
                recent = json.load(fh)
        except Exception:
            recent = {}
        if not isinstance(recent, dict):
            recent = {}
        plays = recent.get('plays') if isinstance(recent.get('plays'), dict) else {}
        for entry in clean:
            recent_entry = {'cmd': entry['cmd'], 'icon': entry.get('icon', ''), 'captured_at': now, 'keys': entry.get('keys') or [], 'name': entry.get('name') or ''}
            for key in recent_entry['keys']:
                plays[key] = recent_entry
        recent['plays'] = plays
        recent['updated_at'] = now
        tmp_recent_path = recent_path + '.tmp'
        with open(tmp_recent_path, 'w', encoding='utf-8') as fh:
            json.dump(recent, fh, ensure_ascii=False, indent=2)
        try:
            os.replace(tmp_recent_path, recent_path)
        except Exception:
            with open(recent_path, 'w', encoding='utf-8') as fh:
                json.dump(recent, fh, ensure_ascii=False, indent=2)
        try:
            xbmc.log('[Talker3 Codex] bridge cache batch stored %s channels' % written, xbmc.LOGWARNING)
        except Exception:
            pass
        return written
    except Exception:
        return 0


def _codex_count_cached_channels():
    try:
        import json
        import os
        base = _codex_data_dir()
        if not base:
            return 0
        path = os.path.join(base, 'codex_talker3_channels_cache.json')
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        channels = data.get('channels') if isinstance(data, dict) else []
        if not isinstance(channels, list):
            return 0
        names = set()
        for channel in channels:
            if isinstance(channel, dict):
                name = str(channel.get('name') or channel.get('label') or channel.get('title') or '').strip()
                if name:
                    names.add(name)
        return len(names)
    except Exception:
        return 0


def _codex_write_last_scan_seen_report(seen_entries, stored_entries=None, playlist_target_count=0):
    try:
        import json
        import os
        import time
        base = _codex_data_dir()
        if not base:
            return ''
        seen_entries = seen_entries if isinstance(seen_entries, list) else []
        stored_entries = stored_entries if isinstance(stored_entries, list) else []
        now = int(time.time())
        report = {
            'created_at': now,
            'seen_total_rows': len(seen_entries),
            'seen_unique_names': len(set(str((entry or {}).get('name') or '').strip() for entry in seen_entries if isinstance(entry, dict) and str((entry or {}).get('name') or '').strip())),
            'stored_total_rows': len(stored_entries),
            'playlist_target_count': playlist_target_count,
            'seen': seen_entries,
        }
        json_path = os.path.join(base, 'codex_talker3_last_scan_seen.json')
        with open(json_path, 'w', encoding='utf-8') as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2)

        txt_path = os.path.join(base, 'codex_talker3_last_scan_seen_names.txt')
        lines = [
            'Talker3 DE Scan - alle roh gesehenen Kanalnamen',
            'Roh gesehen: %s' % len(seen_entries),
            'Eindeutige Namen: %s' % report['seen_unique_names'],
            'IPTV-Simple-Ziele: %s' % playlist_target_count,
            '',
        ]
        for idx, entry in enumerate(seen_entries, 1):
            try:
                name = str((entry or {}).get('name') or '').strip()
                category = str((entry or {}).get('category') or '').strip()
                page = str((entry or {}).get('page') or '').strip()
                lines.append('%04d. %s%s%s' % (
                    idx,
                    name,
                    '  [%s]' % category if category else '',
                    '  p%s' % page if page else '',
                ))
            except Exception:
                pass
        with open(txt_path, 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(lines) + '\n')
        return txt_path
    except Exception:
        return ''


def _codex_playlist_targets():
    try:
        import os
        import re
        import xbmc
        paths = []
        try:
            paths.append(xbmc.translatePath('special://profile/addon_data/pvr.iptvsimple/providers/playlist.m3u'))
        except Exception:
            pass
        try:
            import xbmcvfs
            paths.append(xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple/providers/playlist.m3u'))
        except Exception:
            pass
        try:
            base = _codex_data_dir()
            if base:
                paths.append(os.path.abspath(os.path.join(base, '..', 'pvr.iptvsimple', 'providers', 'playlist.m3u')))
        except Exception:
            pass
        try:
            paths.append('/storage/emulated/0/Android/data/stube.box.legacy/files/.kodi/userdata/addon_data/pvr.iptvsimple/providers/playlist.m3u')
        except Exception:
            pass

        path = ''
        seen_paths = set()
        for candidate in paths:
            candidate = str(candidate or '').strip()
            if not candidate or candidate in seen_paths:
                continue
            seen_paths.add(candidate)
            try:
                if os.path.exists(candidate):
                    path = candidate
                    break
            except Exception:
                pass
        if not path:
            try:
                xbmc.log('[Talker3 Codex] IPTV Simple playlist not found. Tried: %s' % ' | '.join(seen_paths), xbmc.LOGWARNING)
            except Exception:
                pass
            return []
        labels = []
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            for line in fh:
                try:
                    if not str(line).startswith('#EXTINF') or ',' not in str(line):
                        continue
                    label = str(line).rsplit(',', 1)[1].strip()
                    label = re.sub(r'\s+', ' ', label.replace('Ã‚Â²', '').replace('Ã‚Â³', '')).strip()
                    if label:
                        labels.append(label)
                except Exception:
                    pass
        seen = set()
        result = []
        for label in labels:
            key = _codex_norm(label)
            if key and key not in seen:
                seen.add(key)
                result.append(label)
        try:
            xbmc.log('[Talker3 Codex] IPTV Simple playlist targets loaded: %s from %s' % (len(result), path), xbmc.LOGWARNING)
        except Exception:
            pass
        return result
    except Exception:
        try:
            import traceback
            import xbmc
            xbmc.log('[Talker3 Codex] IPTV Simple playlist load failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
        except Exception:
            pass
        return []


def _codex_build_target_index(labels):
    target_aliases = set()
    target_bases = set()
    try:
        for label in labels or []:
            for key in _codex_aliases(label):
                if key:
                    target_aliases.add(key)
            base = _codex_base(label)
            if base:
                target_bases.add(base)
    except Exception:
        pass
    return target_aliases, target_bases


def _codex_matches_bridge_target(title, target_aliases, target_bases):
    try:
        aliases = set(_codex_aliases(title))
        if aliases.intersection(target_aliases):
            return True
        base = _codex_base(title)
        if base and base in target_bases:
            return True
        compact = _codex_norm(title).replace(' ', '').replace('.', '')
        if compact and compact in target_aliases:
            return True
    except Exception:
        pass
    return False


def _codex_category_key(value):
    try:
        import re
        return re.sub(r'\s+', ' ', str(value or '').strip().upper())
    except Exception:
        return str(value or '').strip().upper()


_CODEX_DE_CATEGORY_NAMES = {
    'DE | GERMANY RAW',
    'DE | GERMANY FHD & HD',
    'DE | NEWS',
    'DE | DOKU',
    'DE | KINDER',
    'DE | SKY CINEMA',
    'DE | THE COLLECTION',
    'DE | AMAZONTV',
    'DE | MUSIK',
    'DE | SKY BUNDESLIGA',
    'DE | DAZN & EVENTS',
    'DE | DAZN NFL',
    'DE | SKY SPORTS',
    'DE | WOW TV SPORT',
    'DE | SPORT & EUROSPORT360',
    'DE | EUROSPORT EVENT',
    'DE | RTL+ EVENTS',
    'DE | AMAZON PRIME LIVE',
    'DE | MAGENTA SPORT',
    'DE | REGIONAL SPORT',
    'DE | DYN SPORT EVENTS',
    'DE | SPORTDEUTSCHLAND TV',
    'DE | SPORTTOTAL',
    'DE | FORMEL 1 LIVE',
    'DE | FRENCH OPEN',
    'DE | PPV & EVENTS LIVE',
    'DE | SHOPTV & VERSCH.',
    'DE | CATCHUP',
    'DE | REGIONAL',
}


def _codex_is_talker3_de_category(genre):
    try:
        title = (genre or {}).get('title') if isinstance(genre, dict) else genre
        key = _codex_category_key(title)
        if '24/7' in key or '24 7' in key:
            return False
        if key in _CODEX_DE_CATEGORY_NAMES:
            return True
        norm = _codex_norm(title)
        if not norm.startswith('de '):
            return False
        blocked = ('adult', 'xxx', 'porn', 'vod', 'movie', 'series', 'italy', 'turkey', 'france', 'spain', 'poland', 'russia')
        if any(token in norm for token in blocked):
            return False
        wanted = (
            'germany', 'deutsch', 'news', 'doku', 'kinder', 'musik', 'cinema',
            'sky', 'bundesliga', 'dazn', 'sport', 'wow', 'euro', 'rtl',
            'amazon', 'magenta', 'fussball', 'football', 'event', 'formel',
            'regional', 'catchup', 'ppv', 'shop'
        )
        return any(token in norm for token in wanted)
    except Exception:
        return False


def _codex_de_category_priority(genre):
    try:
        title = _codex_category_key((genre or {}).get('title') if isinstance(genre, dict) else genre)
        order = [
            'DE | GERMANY FHD & HD',
            'DE | GERMANY RAW',
            'DE | SKY CINEMA',
            'DE | DOKU',
            'DE | NEWS',
            'DE | KINDER',
            'DE | MUSIK',
            'DE | THE COLLECTION',
            'DE | MAGENTA SPORT',
            'DE | DAZN & EVENTS',
            'DE | AMAZONTV',
            'DE | AMAZON PRIME LIVE',
            'DE | SKY SPORTS',
            'DE | SKY BUNDESLIGA',
            'DE | SPORT & EUROSPORT360',
            'DE | DAZN NFL',
            'DE | WOW TV SPORT',
            'DE | SPORTDEUTSCHLAND TV',
            'DE | EUROSPORT EVENT',
            'DE | RTL+ EVENTS',
            'DE | REGIONAL SPORT',
            'DE | DYN SPORT EVENTS',
            'DE | SPORTTOTAL',
            'DE | FORMEL 1 LIVE',
            'DE | FRENCH OPEN',
            'DE | PPV & EVENTS LIVE',
            'DE | SHOPTV & VERSCH.',
            'DE | CATCHUP',
            'DE | REGIONAL',
        ]
        norm = _codex_norm(title)
        if title in order:
            return (order.index(title), title)
        if 'germany' in norm or 'deutsch' in norm or 'raw' in norm:
            return (0, title)
        if 'cinema' in norm:
            return (2, title)
        if 'magenta' in norm or 'fussball' in norm or 'football' in norm:
            return (9, title)
        if 'dazn' in norm:
            return (10, title)
        if 'bundesliga' in norm:
            return (14, title)
        if 'sport' in norm or 'event' in norm:
            return (20, title)
        return (99, title)
    except Exception:
        return (99, '')


def _codex_extract_channel_page(videos):
    data = []
    total_items = 0
    page_items = 1
    try:
        if isinstance(videos, list):
            data = videos
        elif isinstance(videos, dict):
            data = (
                videos.get('data')
                or videos.get('channels')
                or videos.get('items')
                or videos.get('results')
                or videos.get('js')
                or []
            )
            if isinstance(data, dict):
                data = (
                    data.get('data')
                    or data.get('channels')
                    or data.get('items')
                    or data.get('results')
                    or []
                )
        try:
            total_items = int((videos or {}).get('total_items') or (videos or {}).get('total') or (videos or {}).get('count') or len(data or []))
        except Exception:
            total_items = len(data or [])
        try:
            page_items = int((videos or {}).get('max_page_items') or (videos or {}).get('page_items') or len(data or []) or 1)
        except Exception:
            page_items = len(data or []) or 1
    except Exception:
        data = []
        total_items = 0
        page_items = 1
    if not isinstance(data, list):
        try:
            data = list(data or [])
        except Exception:
            data = []
    return data, total_items, page_items


def _codex_positive_int(value, default=1):
    try:
        value = int(str(value or '').strip())
        return value if value > 0 else default
    except Exception:
        return default


def _codex_page_art(next_page=True):
    try:
        return _codex_resource_path('resources', 'next_page.png' if next_page else 'previous_page.png')
    except Exception:
        return ''


def _codex_add_page_item(handle, label, action, category_id, category_title, page, next_page=True, media_type=''):
    try:
        import xbmcgui
        import xbmcplugin
        from urllib.parse import urlencode
        icon = _codex_page_art(next_page)
        params = {
            'action': action,
            'category_id': category_id or '',
            'category_title': category_title or '',
            'page': str(page),
            'update_listing': 'False',
        }
        if media_type:
            params['type'] = media_type
        url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(params))
        try:
            _codex_sync_title_view_for_current_path(extra_paths=[url])
        except Exception:
            pass
        li = xbmcgui.ListItem(label=label)
        if icon:
            try:
                li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
            except Exception:
                pass
        try:
            li.setInfo(type='Video', infoLabels={'title': label})
            li.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, url, li, True)
    except Exception:
        pass


def _codex_scan_category_jsonrpc(category_title, category_id, target_aliases, target_bases, max_dirs=30, max_seconds=8.0):
    entries = []
    try:
        import json
        import time
        import xbmc
        from urllib.parse import parse_qs, unquote_plus, urlencode, urlsplit
    except Exception:
        return entries
    try:
        started = time.time()
        root = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
            'action': 'tv_listing',
            'category': str(category_title or ''),
            'category_id': str(category_id or ''),
            'page': '1',
            'update_listing': 'False',
        }))
        queue = [(root, 0)]
        visited = set()
        while queue and len(visited) < max_dirs and time.time() - started < max_seconds:
            directory, depth = queue.pop(0)
            if not directory or directory in visited or depth > 3:
                continue
            visited.add(directory)
            request = {
                'jsonrpc': '2.0',
                'id': 'talker3-codex-category-scan',
                'method': 'Files.GetDirectory',
                'params': {
                    'directory': directory,
                    'media': 'video',
                    'properties': ['title', 'thumbnail']
                }
            }
            try:
                response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            except Exception:
                response = {}
            files = response.get('result', {}).get('files', []) if isinstance(response, dict) else []
            for item in files or []:
                try:
                    path = item.get('file') or ''
                    filetype = item.get('filetype') or ''
                    label = item.get('label') or item.get('title') or ''
                    icon = item.get('thumbnail') or ''
                    if ADDON_ID in path and 'action=tv_play' in path:
                        query = parse_qs(urlsplit(path).query, keep_blank_values=True)
                        cmd = unquote_plus((query.get('cmd') or [''])[0]).strip()
                        found_label = label or unquote_plus((query.get('name') or query.get('label') or [''])[0]).strip()
                        found_icon = icon or unquote_plus((query.get('icon') or [''])[0]).strip()
                        if cmd and found_label and _codex_matches_bridge_target(found_label, target_aliases, target_bases):
                            entries.append({'name': found_label, 'cmd': cmd, 'icon': found_icon})
                    elif filetype == 'directory' and path.startswith('plugin://%s/' % ADDON_ID):
                        queue.append((path, depth + 1))
                except Exception:
                    pass
        try:
            xbmc.log('[Talker3 Codex] JSONRPC fallback category %s dirs=%s matches=%s' % (category_title, len(visited), len(entries)), xbmc.LOGWARNING)
        except Exception:
            pass
    except Exception:
        pass
    return entries


def _codex_handle_de_channels(argv, native_addon=None):
    try:
        import json
        import os
        import sys
        import time
        import xbmc
        import xbmcgui
        import xbmcplugin
        from urllib.parse import parse_qs
    except Exception:
        return False

    try:
        query = argv[2] if len(argv) > 2 else ''
        if query.startswith('?'):
            query = query[1:]
        params = parse_qs(query, keep_blank_values=True)
        if (params.get('action') or [''])[0] != 'codex_de_channels':
            return False
        quiet_start = str((params.get('quiet_start') or [''])[0]).strip().lower() in ('1', 'true', 'yes', 'on')
        scan_profile = str((params.get('scan_profile') or ['bridge'])[0]).strip().lower()

        lock_path = ''
        status_path = ''
        lock_created = False
        def _write_scan_status(ok, reason='', **extra):
            try:
                data = {
                    'ok': bool(ok),
                    'reason': str(reason or ''),
                    'updated_at': time.time(),
                }
                data.update(extra)
                if status_path:
                    with open(status_path, 'w', encoding='utf-8') as fh:
                        json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
            except Exception:
                pass
        try:
            base_dir = _codex_data_dir()
            lock_path = os.path.join(base_dir, 'codex_talker3_de_scan.lock') if base_dir else ''
            status_path = os.path.join(base_dir, 'codex_talker3_de_scan_status.json') if base_dir else ''
            if lock_path and os.path.exists(lock_path):
                try:
                    age = time.time() - os.path.getmtime(lock_path)
                except Exception:
                    age = 0
                if age < 240:
                    if not quiet_start:
                        try:
                            xbmcgui.Dialog().notification('Senderliste', 'Aktualisierung lÃ¤uft bereits', time=2500)
                        except Exception:
                            pass
                    _write_scan_status(False, 'already_running', age=age)
                    xbmc.log('[Talker3 Codex] DE quick scan skipped: already running age=%.1fs' % age, xbmc.LOGWARNING)
                    return True
                try:
                    os.remove(lock_path)
                except Exception:
                    pass
            if lock_path:
                with open(lock_path, 'w', encoding='utf-8') as fh:
                    fh.write(str(int(time.time())))
                lock_created = True
        except Exception:
            lock_created = False

        if native_addon is None:
            original_argv2 = None
            try:
                # Wichtig fuer Live TV 2:
                # Beim normalen Import kann der alte native Startpfad schon vor
                # unserem Scanner eine Initial-Auth ausloesen. Das hat im Log zu
                # "Kein Token erhalten" + mehreren schnellen Folgeversuchen
                # gefuehrt. Wie beim stabilen Bridge-Playback importieren wir
                # Talker3 hier in einem neutralen Codex-Kontext.
                if len(sys.argv) > 2:
                    original_argv2 = sys.argv[2]
                    sys.argv[2] = '?action=codex_talker3_bridge_play'
                import lib.addon as native_addon
            finally:
                try:
                    if original_argv2 is not None and len(sys.argv) > 2:
                        sys.argv[2] = original_argv2
                except Exception:
                    pass

        handle = int(argv[1]) if len(argv) > 1 else -1
        if not quiet_start:
            try:
                xbmcgui.Dialog().notification('Senderliste', 'Aktualisierung gestartet', time=2500)
            except Exception:
                pass
        targets = _codex_playlist_targets()
        target_aliases, target_bases = _codex_build_target_index(targets)
        if not targets:
            xbmc.log('[Talker3 Codex] DE quick scan stopped: no IPTV Simple bridge targets', xbmc.LOGWARNING)
            _write_scan_status(False, 'no_playlist_targets', targets=0)
            if not quiet_start:
                try:
                    xbmcgui.Dialog().notification('Talker3', 'Keine BrÃ¼ckenliste gefunden', time=2500)
                except Exception:
                    pass
            if handle >= 0:
                xbmcplugin.endOfDirectory(handle, succeeded=False, updateListing=False, cacheToDisc=False)
            try:
                if lock_created and lock_path and os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            return True

        def _safe_reload_native(reason=''):
            try:
                import importlib
                original_argv2 = None
                try:
                    if len(sys.argv) > 2:
                        original_argv2 = sys.argv[2]
                        sys.argv[2] = '?action=codex_talker3_bridge_play'
                    reloaded = importlib.reload(native_addon)
                    try:
                        xbmc.log('[Talker3 Codex] DE quick scan native reload: %s' % (reason or '-'), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return reloaded
                finally:
                    try:
                        if original_argv2 is not None and len(sys.argv) > 2:
                            sys.argv[2] = original_argv2
                    except Exception:
                        pass
            except Exception as reload_exc:
                try:
                    xbmc.log('[Talker3 Codex] DE quick scan native reload skipped: %s' % reload_exc, xbmc.LOGWARNING)
                except Exception:
                    pass
            return native_addon

        genres = []
        try:
            xbmc.log('[Talker3 Codex] DE quick scan auth warmup: start steady', xbmc.LOGWARNING)
        except Exception:
            pass
        # Maximal drei ruhige Genre-/Auth-Anläufe, bewusst mit Abstand. Der
        # letzte Anlauf darf eine Rotation erlauben, falls die alte MAC wirklich
        # tot ist; vorher wird nichts aggressiv gewechselt.
        genre_attempt_plan = (
            ('warmup-current', False, 0.0),
            ('warmup-reload', False, 1.35),
            ('warmup-rotate-on-empty', True, 2.0),
        )
        for attempt_name, rotate_empty, pause_before in genre_attempt_plan:
            if genres:
                break
            try:
                if pause_before:
                    time.sleep(pause_before)
                if attempt_name == 'warmup-reload':
                    native_addon = _safe_reload_native(attempt_name)
                payload = native_addon.retry_call_with_mac_rotation(
                    native_addon.get_tv_genres,
                    base_delay=0.0,
                    attempts=1,
                    rotate_on_empty=rotate_empty,
                    log_prefix='CODEX-DE-QUICK-AUTH-%s' % attempt_name.upper(),
                ) if hasattr(native_addon, 'retry_call_with_mac_rotation') else native_addon.get_tv_genres()
                genres = _codex_extract_category_list(payload)
                xbmc.log('[Talker3 Codex] DE quick scan auth %s: categories=%s rotate_on_empty=%s' % (attempt_name, len(genres or []), rotate_empty), xbmc.LOGWARNING)
            except Exception as warmup_exc:
                try:
                    xbmc.log('[Talker3 Codex] DE quick scan auth %s failed: %s' % (attempt_name, warmup_exc), xbmc.LOGWARNING)
                except Exception:
                    pass
        de_genres = [genre for genre in genres if _codex_is_talker3_de_category(genre)]
        if not de_genres:
            try:
                xbmc.log('[Talker3 Codex] DE quick scan categories empty after steady warmup; stop without auth storm', xbmc.LOGWARNING)
            except Exception:
                pass
        if not de_genres:
            try:
                xbmc.log('[Talker3 Codex] DE quick scan stopped: no live categories from portal', xbmc.LOGWARNING)
            except Exception:
                pass
            _write_scan_status(False, 'no_live_categories', scanned=0, matched=0, stored=0, cache_total=_codex_count_cached_channels(), targets=len(targets), elapsed=time.time() - started if 'started' in locals() else 0, report_path='')
            if handle >= 0:
                xbmcplugin.endOfDirectory(handle, succeeded=False, updateListing=False, cacheToDisc=False)
            try:
                if lock_created and lock_path and os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            return True
        de_genres.sort(key=_codex_de_category_priority)
        xbmc.log('[Talker3 Codex] DE quick scan targets=%s categories=%s' % (len(targets), len(de_genres)), xbmc.LOGWARNING)
        if not de_genres:
            _write_scan_status(False, 'no_de_categories', targets=len(targets), categories=0)
        try:
            xbmc.log('[Talker3 Codex] DE quick scan categories: %s' % ' | '.join(str((genre or {}).get('title') or '') for genre in de_genres), xbmc.LOGWARNING)
        except Exception:
            pass

        started = time.time()
        scanned = 0
        stored = 0
        matched = 0
        seen_cmds = set()
        batch_entries = []
        scan_seen_entries = []
        max_seconds = 420.0 if scan_profile in ('bridge', 'bruecke', 'brÃƒÂ¼cke', 'combined', 'kombiniert', 'full', 'all') else 90.0
        max_pages = 8
        max_total = 12000
        consecutive_empty_categories = 0

        genre_by_title = {}
        for genre in de_genres:
            try:
                title_key = _codex_category_key((genre or {}).get('title') if isinstance(genre, dict) else genre)
                if title_key and title_key not in genre_by_title:
                    genre_by_title[title_key] = genre
            except Exception:
                pass

        phase_defs = [
            ('GERMANY', [
                'DE | GERMANY FHD & HD',
                'DE | GERMANY RAW',
            ]),
            ('MEDIEN', [
                'DE | SKY CINEMA',
                'DE | DOKU',
                'DE | NEWS',
                'DE | KINDER',
                'DE | MUSIK',
                'DE | AMAZONTV',
            ]),
            ('SPORT', [
                'DE | MAGENTA SPORT',
                'DE | DAZN & EVENTS',
                'DE | SPORTDEUTSCHLAND TV',
                'DE | DAZN NFL',
                'DE | SKY BUNDESLIGA',
                'DE | SKY SPORTS',
                'DE | WOW TV SPORT',
                'DE | SPORT & EUROSPORT360',
            ]),
            ('EVENTS', [
                'DE | EUROSPORT EVENT',
                'DE | RTL+ EVENTS',
                'DE | AMAZON PRIME LIVE',
                'DE | REGIONAL SPORT',
                'DE | DYN SPORT EVENTS',
                'DE | SPORTTOTAL',
                'DE | FORMEL 1 LIVE',
                'DE | FRENCH OPEN',
                'DE | PPV & EVENTS LIVE',
                'DE | SHOPTV & VERSCH.',
                'DE | CATCHUP',
                'DE | REGIONAL',
            ]),
        ]
        if scan_profile in ('bridge', 'bruecke', 'brÃ¼cke', 'combined', 'kombiniert'):
            phase_defs = []
        elif scan_profile in ('germany', 'media', 'medien'):
            phase_defs = [item for item in phase_defs if item[0] in ('GERMANY', 'MEDIEN')]
        elif scan_profile in ('sport', 'sports'):
            phase_defs = [item for item in phase_defs if item[0] in ('SPORT',)]
        elif scan_profile in ('events', 'rest'):
            phase_defs = [item for item in phase_defs if item[0] in ('EVENTS',)]
        xbmc.log('[Talker3 Codex] DE quick scan profile: %s' % scan_profile, xbmc.LOGWARNING)
        used_phase_titles = set()
        scan_phases = []
        for phase_name, titles in phase_defs:
            phase_genres = []
            for title in titles:
                if title in genre_by_title:
                    phase_genres.append(genre_by_title[title])
                    used_phase_titles.add(title)
            if phase_genres:
                scan_phases.append((phase_name, phase_genres))
        rest_genres = []
        for genre in de_genres:
            try:
                title_key = _codex_category_key((genre or {}).get('title') if isinstance(genre, dict) else genre)
                if title_key not in used_phase_titles:
                    rest_genres.append(genre)
            except Exception:
                pass
        if rest_genres and scan_profile in ('full', 'all'):
            scan_phases.append(('REST', rest_genres))
        if scan_profile in ('bridge', 'bruecke', 'brÃƒÂ¼cke', 'combined', 'kombiniert'):
            scan_phases = [('BRIDGE', de_genres)]

        total_categories = sum(len(items) for _, items in scan_phases) or len(de_genres) or 1
        categories_done = 0

        def _update_running_status(current_category='', phase_name=''):
            try:
                progress = int(min(98, max(1, round((float(categories_done) / float(total_categories)) * 98.0))))
            except Exception:
                progress = 1
            _write_scan_status(
                True,
                'running',
                running=True,
                progress=progress,
                scanned=scanned,
                matched=matched,
                stored=len(batch_entries),
                targets=len(targets),
                categories_done=categories_done,
                categories_total=total_categories,
                current_category=current_category or '',
                phase=phase_name or '',
            )

        def _fetch_category_page(category_id, category_title, page, important=True):
            category_key = _codex_category_key(category_title)
            is_magenta = category_key == 'DE | MAGENTA SPORT'
            is_sky_sports = category_key == 'DE | SKY SPORTS'
            attempts = 4 if is_magenta and page == 1 else (3 if is_sky_sports and page == 1 else (2 if important and page == 1 else 1))
            if (is_magenta or is_sky_sports) and page == 1:
                try:
                    if is_magenta:
                        xbmc.log('[Talker3 Codex] DE quick scan Magenta Schonpause vor Abruf', xbmc.LOGWARNING)
                        time.sleep(0.85)
                    else:
                        xbmc.log('[Talker3 Codex] DE quick scan Sky Sports Schonpause vor Abruf', xbmc.LOGWARNING)
                        time.sleep(0.65)
                except Exception:
                    pass
            last_videos = None
            last_data = []
            last_total_items = 0
            last_page_items = 1
            for attempt in range(1, attempts + 1):
                try:
                    videos = native_addon.retry_call_with_mac_rotation(
                        lambda cid=category_id, pg=page: native_addon.get_tv_channels(cid, str(pg)),
                        base_delay=0.0,
                        attempts=1,
                        rotate_on_empty=False,
                        log_prefix='CODEX-DE-QUICK %s p%s same-mac %s/%s' % (category_title, page, attempt, attempts),
                    )
                    data, total_items, page_items = _codex_extract_channel_page(videos)
                    last_videos, last_data, last_total_items, last_page_items = videos, data, total_items, page_items
                    if data or page != 1:
                        if attempt > 1:
                            try:
                                xbmc.log('[Talker3 Codex] DE quick scan empty category recovered after retry: %s page=%s attempt=%s rows=%s' % (category_title, page, attempt, len(data or [])), xbmc.LOGWARNING)
                            except Exception:
                                pass
                        return videos, data, total_items, page_items
                except Exception:
                    pass
                if page == 1 and attempt < attempts:
                    try:
                        if is_magenta:
                            time.sleep(1.45 + (0.25 * attempt))
                        elif is_sky_sports:
                            time.sleep(1.35 + (0.22 * attempt))
                        else:
                            time.sleep(2.0)
                    except Exception:
                        pass

            if important and page == 1:
                try:
                    time.sleep(2.0)
                except Exception:
                    pass
                try:
                    alt_videos = native_addon.retry_call_with_mac_rotation(
                        lambda cid=category_id: native_addon.get_tv_channels(cid, '0'),
                        base_delay=0.0,
                        attempts=1,
                        rotate_on_empty=False,
                        log_prefix='CODEX-DE-QUICK %s p0 same-mac' % category_title,
                    )
                    alt_data, alt_total_items, alt_page_items = _codex_extract_channel_page(alt_videos)
                    if alt_data:
                        return alt_videos, alt_data, alt_total_items, alt_page_items
                except Exception:
                    pass

            return last_videos, last_data, last_total_items, last_page_items

        _update_running_status('', 'START')
        xbmc.log('[Talker3 Codex] DE quick scan phases: %s' % ' | '.join('%s=%s' % (name, len(items)) for name, items in scan_phases), xbmc.LOGWARNING)

        stop_all_scan = False
        for phase_index, (phase_name, phase_genres) in enumerate(scan_phases):
            if stop_all_scan or time.time() - started > max_seconds or scanned >= max_total:
                break
            try:
                if phase_index > 0:
                    # Zwischen den Bloecken die Talker3-Modulsession neu laden.
                    # Ein Block liefert Daten, danach werden andere Bloecke oft leer.
                    # Reload ist sauberer als Sessiondateien zu loeschen.
                    try:
                        import importlib
                        native_addon = importlib.reload(native_addon)
                        xbmc.log('[Talker3 Codex] DE quick scan phase reload: %s' % phase_name, xbmc.LOGWARNING)
                    except Exception as reload_error:
                        try:
                            xbmc.log('[Talker3 Codex] DE quick scan phase reload failed: %s %s' % (phase_name, reload_error), xbmc.LOGWARNING)
                        except Exception:
                            pass
                    native_addon.retry_call_with_mac_rotation(
                        native_addon.get_tv_genres,
                        base_delay=0.25,
                        attempts=1,
                        rotate_on_empty=False,
                        log_prefix='CODEX-DE-QUICK-PHASE-%s-GENRES' % phase_name,
                    )
                    time.sleep(0.12)
            except Exception:
                pass
            phase_seen = 0
            xbmc.log('[Talker3 Codex] DE quick scan phase start: %s categories=%s' % (phase_name, len(phase_genres)), xbmc.LOGWARNING)
            for genre in phase_genres:
                if time.time() - started > max_seconds or scanned >= max_total:
                    stop_all_scan = True
                    break
                try:
                    category_id = str((genre or {}).get('id') or (genre or {}).get('gid') or (genre or {}).get('category_id') or '').strip()
                    category_title = str((genre or {}).get('title') or '').strip()
                    if not category_id:
                        categories_done += 1
                        _update_running_status(category_title, phase_name)
                        continue
                    _update_running_status(category_title, phase_name)
                    category_seen = 0
                    category_matched = 0
                    category_stored = 0
                    page = 1
                    important_category = phase_name in ('BRIDGE', 'GERMANY', 'MEDIEN', 'SPORT')
                    while page <= max_pages and scanned < max_total:
                        if time.time() - started > max_seconds:
                            stop_all_scan = True
                            break
                        videos, data, total_items, page_items = _fetch_category_page(category_id, category_title, page, important_category)
                        if not data:
                            try:
                                if page == 1:
                                    xbmc.log('[Talker3 Codex] DE quick scan empty category: %s id=%s response=%s genre=%s' % (category_title, category_id, type(videos).__name__, repr(genre)[:500]), xbmc.LOGWARNING)
                            except Exception:
                                pass
                            break
                        for video in data:
                            try:
                                title = str(video.get('name') or '').strip()
                                cmd = str(video.get('cmd') or '').strip()
                                icon = str(video.get('logo') or '').strip()
                                scanned += 1
                                category_seen += 1
                                phase_seen += 1
                                if title:
                                    scan_seen_entries.append({
                                        'name': title,
                                        'category': category_title,
                                        'page': page,
                                        'has_cmd': bool(cmd),
                                    })
                                if not title or not cmd or cmd in seen_cmds:
                                    continue
                                seen_cmds.add(cmd)
                                batch_entries.append({'name': title, 'cmd': cmd, 'icon': icon})
                                category_stored += 1
                                if _codex_matches_bridge_target(title, target_aliases, target_bases):
                                    matched += 1
                                    category_matched += 1
                            except Exception:
                                pass
                        if total_items <= page * page_items:
                            break
                        page += 1
                    categories_done += 1
                    _update_running_status(category_title, phase_name)
                    try:
                        xbmc.log('[Talker3 Codex] DE category result: %s seen=%s matched_playlist=%s stored=%s' % (category_title, category_seen, category_matched, category_stored), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    if category_seen > 0:
                        consecutive_empty_categories = 0
                    else:
                        consecutive_empty_categories += 1
                    if scanned <= 0 and consecutive_empty_categories >= 3:
                        try:
                            xbmc.log('[Talker3 Codex] DE quick scan abort: first categories empty, session/token not ready', xbmc.LOGWARNING)
                        except Exception:
                            pass
                        stop_all_scan = True
                        break
                    try:
                        if scan_profile in ('bridge', 'bruecke', 'brÃƒÂ¼cke', 'combined', 'kombiniert', 'full', 'all'):
                            time.sleep(1.25 if category_seen > 0 else 2.0)
                        elif category_seen >= 100:
                            time.sleep(0.55)
                        elif category_seen > 0:
                            time.sleep(0.22)
                        else:
                            time.sleep(0.12)
                    except Exception:
                        pass
                except Exception:
                    categories_done += 1
                    _update_running_status('', phase_name)
                    pass
            xbmc.log('[Talker3 Codex] DE quick scan phase done: %s seen=%s total_scanned=%s matched=%s' % (phase_name, phase_seen, scanned, matched), xbmc.LOGWARNING)

        try:
            names_for_stats = [str((entry or {}).get('name') or '') for entry in batch_entries if isinstance(entry, dict)]
            def _count_stat(*tokens):
                return sum(1 for name in names_for_stats if any(token in name.lower() for token in tokens))
            xbmc.log(
                '[Talker3 Codex] DE quick scan key stats: fussball=%s magenta=%s rtl=%s comedy_central=%s dmax=%s kabel1=%s pro7=%s dazn=%s' % (
                    _count_stat('fussball', 'fuÃŸball'),
                    _count_stat('magenta', 'telekom'),
                    _count_stat('rtl'),
                    _count_stat('comedy central'),
                    _count_stat('dmax'),
                    _count_stat('kabel 1', 'kabeleins'),
                    _count_stat('pro7', 'prosieben'),
                    _count_stat('dazn'),
                ),
                xbmc.LOGWARNING
            )
        except Exception:
            pass
        stored = _codex_store_channels_batch(batch_entries)
        cache_total = _codex_count_cached_channels()
        report_path = _codex_write_last_scan_seen_report(scan_seen_entries, batch_entries, len(targets))
        if report_path:
            xbmc.log('[Talker3 Codex] DE quick scan seen-name report: %s rows=%s' % (report_path, len(scan_seen_entries)), xbmc.LOGWARNING)
        elapsed = time.time() - started
        xbmc.log('[Talker3 Codex] DE quick scan done: scanned=%s matched=%s stored=%s cache_total=%s playlist_targets=%s elapsed=%.1fs' % (scanned, matched, stored, cache_total, len(targets), elapsed), xbmc.LOGWARNING)
        if scanned <= 0:
            _write_scan_status(False, 'no_channels_scanned', scanned=scanned, matched=matched, stored=stored, cache_total=cache_total, targets=len(targets), elapsed=elapsed, report_path=report_path or '')
            if not quiet_start:
                try:
                    xbmcgui.Dialog().notification('Senderliste', 'Nicht aktualisiert', time=3000)
                except Exception:
                    pass
            if handle >= 0:
                xbmcplugin.endOfDirectory(handle, succeeded=False, updateListing=False, cacheToDisc=False)
            try:
                if lock_created and lock_path and os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            return True
        _write_scan_status(True, 'done', scanned=scanned, matched=matched, stored=stored, cache_total=cache_total, targets=len(targets), elapsed=elapsed, report_path=report_path or '')
        if not quiet_start:
            try:
                xbmcgui.Dialog().notification('AKTUALISIERT', '%s von %s' % (matched, len(targets)), time=3000)
            except Exception:
                pass
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        try:
            if lock_created and lock_path and os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        return True
    except Exception:
        try:
            import traceback
            import xbmc
            xbmc.log('[Talker3 Codex] DE quick scan failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
        except Exception:
            pass
        try:
            if '_write_scan_status' in locals():
                _write_scan_status(False, 'exception')
        except Exception:
            pass
        try:
            if 'lock_created' in locals() and lock_created and 'lock_path' in locals() and lock_path and os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        return False


def _codex_install_directory_cache():
    try:
        import json
        import os
        import time
        import xbmc
        import xbmcgui
        import xbmcplugin
        from urllib.parse import parse_qs, unquote_plus, urlencode, urlsplit
    except Exception:
        return

    try:
        if getattr(xbmcplugin.addDirectoryItem, '_codex_talker3_wrapped', False):
            return
    except Exception:
        pass

    def _item_label(listitem):
        for attr in ('getLabel', 'getLabel2'):
            try:
                value = getattr(listitem, attr)()
                if value:
                    return str(value)
            except Exception:
                pass
        return ''

    def _item_icon(listitem):
        for art_key in ('thumb', 'icon', 'poster'):
            try:
                value = listitem.getArt(art_key)
                if value:
                    return str(value)
            except Exception:
                pass
        return ''

    def _capture(url, listitem=None):
        try:
            url_text = str(url or '')
            if ADDON_ID not in url_text or 'action=tv_play' not in url_text:
                return
            query = parse_qs(urlsplit(url_text).query, keep_blank_values=True)
            if (query.get('source') or [''])[0] == 'codex_pvr':
                return
            cmd = unquote_plus((query.get('cmd') or [''])[0]).strip()
            if not cmd:
                return
            label = _item_label(listitem) or unquote_plus((query.get('label') or query.get('name') or [''])[0]).strip()
            if not label:
                return
            icon = unquote_plus((query.get('icon') or [''])[0]).strip() or _item_icon(listitem)
            _codex_store_channel(label, cmd, icon)
        except Exception:
            pass

    state = {'de_folder_added': False}

    def _maybe_add_de_folder(handle, url, listitem=None):
        try:
            if state.get('de_folder_added'):
                return
            url_text = str(url or '')
            if ADDON_ID not in url_text or 'action=tv_listing' not in url_text:
                return
            state['de_folder_added'] = True
            de_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({'action': 'codex_de_channels', 'scan_profile': 'bridge'}))
            de_item = xbmcgui.ListItem(label='DE SENDER')
            icon = _item_icon(listitem)
            if icon:
                de_item.setArt({'icon': icon, 'thumb': icon})
            try:
                de_item.getVideoInfoTag().setPlot('Aktualisiert die IPTV-Simple-BrÃ¼cke manuell')
            except Exception:
                pass
            original_add(handle, de_url, de_item, True)
            xbmc.log('[Talker3 Codex] inserted DE SENDER quick scan folder', xbmc.LOGWARNING)
        except Exception:
            pass

    try:
        original_add = xbmcplugin.addDirectoryItem

        def addDirectoryItem(handle, url, listitem=None, isFolder=False, totalItems=0):
            _maybe_add_de_folder(handle, url, listitem)
            _capture(url, listitem)
            return original_add(handle, url, listitem, isFolder, totalItems)

        addDirectoryItem._codex_talker3_wrapped = True
        xbmcplugin.addDirectoryItem = addDirectoryItem
    except Exception:
        pass

    try:
        original_add_many = getattr(xbmcplugin, 'addDirectoryItems', None)
        if original_add_many:
            def addDirectoryItems(handle, items, totalItems=0):
                try:
                    for item in items or []:
                        try:
                            _capture(item[0], item[1] if len(item) > 1 else None)
                        except Exception:
                            pass
                except Exception:
                    pass
                return original_add_many(handle, items, totalItems)

            xbmcplugin.addDirectoryItems = addDirectoryItems
    except Exception:
        pass


def _codex_name_looks_like(target, candidate):
    try:
        target_aliases = set(_codex_aliases(target))
        candidate_aliases = set(_codex_aliases(candidate))
        if target_aliases.intersection(candidate_aliases):
            return True
        target_base = _codex_base(target)
        candidate_base = _codex_base(candidate)
        target_compact = _codex_norm(target).replace(' ', '').replace('.', '')
        candidate_compact = _codex_norm(candidate).replace(' ', '').replace('.', '')
        if target_base and candidate_base and (target_base == candidate_base or candidate_base.startswith(target_base + ' ')):
            return True
        if target_compact and candidate_compact and candidate_compact.startswith(target_compact):
            return True
    except Exception:
        pass
    return False


def _codex_refresh_name_cache(target_label, max_dirs=420):
    try:
        import json
        import xbmc
        from urllib.parse import parse_qs, unquote_plus, urlsplit
    except Exception:
        return False

    try:
        target_label = str(target_label or '').strip()
        if not target_label:
            return False
        root = 'plugin://%s/' % ADDON_ID
        queue = [(root, 0)]
        visited = set()
        scanned = 0
        max_depth = 8
        target_words = set(_codex_base(target_label).split())
        target_words.update(_codex_norm(target_label).split())

        def priority(item):
            try:
                text = '%s %s %s' % (item.get('label') or '', item.get('title') or '', item.get('file') or '')
                text = text.lower()
                score = 0
                for word in target_words:
                    if word and len(word) > 2 and word in text:
                        score -= 100
                for token in ('deutsch', 'germany', 'de ', 'de-', 'de |', 'private', 'hd plus', 'vip', 'event', 'dazn', 'hevc', 'raw', 'uhd', 'live'):
                    if token in text:
                        score -= 10
                for token in ('for ', 'adult', 'xxx', 'vod', 'movie', 'series', 'tr ', 'tr |', 'fr ', 'fr |', 'it ', 'it |', 'es ', 'es |', 'uk ', 'uk |', 'us ', 'us |'):
                    if token in text:
                        score += 25
                return score
            except Exception:
                return 0

        xbmc.log('[Talker3 Codex] targeted name scan started for %s' % target_label, xbmc.LOGWARNING)
        while queue and scanned < max_dirs:
            directory, depth = queue.pop(0)
            if not directory or directory in visited or depth > max_depth:
                continue
            visited.add(directory)
            request = {
                'jsonrpc': '2.0',
                'id': 'talker3-codex-name-scan',
                'method': 'Files.GetDirectory',
                'params': {
                    'directory': directory,
                    'media': 'video',
                    'properties': ['title', 'thumbnail']
                }
            }
            try:
                response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            except Exception:
                response = {}
            scanned += 1
            files = response.get('result', {}).get('files', []) if isinstance(response, dict) else []
            directories = []
            for item in files or []:
                try:
                    path = item.get('file') or ''
                    filetype = item.get('filetype') or ''
                    label = item.get('label') or item.get('title') or ''
                    icon = item.get('thumbnail') or ''
                    if ADDON_ID in path and 'action=tv_play' in path:
                        query = parse_qs(urlsplit(path).query, keep_blank_values=True)
                        cmd = unquote_plus((query.get('cmd') or [''])[0]).strip()
                        found_label = label or unquote_plus((query.get('name') or query.get('label') or [''])[0]).strip()
                        found_icon = icon or unquote_plus((query.get('icon') or [''])[0]).strip()
                        if cmd and found_label:
                            _codex_store_channel(found_label, cmd, found_icon)
                            if _codex_name_looks_like(target_label, found_label):
                                target_norm = _codex_norm(target_label)
                                found_norm = _codex_norm(found_label)
                                target_base = _codex_base(target_label)
                                found_base = _codex_base(found_label)
                                target_compact = target_norm.replace(' ', '').replace('.', '')
                                found_compact = found_norm.replace(' ', '').replace('.', '')
                                if (
                                    target_norm == found_norm
                                    or (target_base and target_base == found_base)
                                    or (target_compact and target_compact == found_compact)
                                ):
                                    xbmc.log('[Talker3 Codex] targeted name scan strong hit %s -> %s' % (found_label, cmd), xbmc.LOGWARNING)
                                    return True
                    elif (
                        filetype == 'directory'
                        and path.startswith(root)
                        and 'action=tv_play' not in path
                        and path not in visited
                    ):
                        directories.append(item)
                except Exception:
                    pass
            for item in sorted(directories, key=priority):
                try:
                    queue.append((item.get('file') or '', depth + 1))
                except Exception:
                    pass
        xbmc.log('[Talker3 Codex] targeted name scan finished for %s after %s dirs' % (target_label, scanned), xbmc.LOGWARNING)
    except Exception:
        return False
    return False


def _codex_find_cached_cmd(label):
    try:
        import json
        import os
        import xbmc
    except Exception:
        return None

    base = _codex_data_dir()
    if not base:
        return None

    def load_plays():
        path = os.path.join(base, 'codex_talker3_recent_plays.json')
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            plays = data.get('plays') if isinstance(data, dict) else {}
            return plays if isinstance(plays, dict) else {}
        except Exception:
            return {}

    target_quality = _codex_quality(label)
    target_norm = _codex_norm(label)
    target_compact = target_norm.replace(' ', '').replace('.', '')
    target_base = _codex_base(label)
    keys = _codex_aliases(label)
    plays = load_plays()

    def key_quality_matches(key):
        if not target_quality:
            return True
        key_norm = _codex_norm(key)
        key_compact = key_norm.replace(' ', '').replace('.', '')
        key_quality = _codex_quality(key)
        if key_quality.intersection(target_quality):
            return True
        for quality in target_quality:
            if key_compact.endswith(quality) or (' ' + quality + ' ') in (' ' + key_norm + ' '):
                return True
        return False

    exact_keys = []
    for key in (target_norm, target_compact):
        if key:
            exact_keys.append(key)
    for key in keys:
        if key and key_quality_matches(key) and key not in exact_keys:
            exact_keys.append(key)

    # Codex: Der frische Senderlisten-Scan ist die verlässlichste Quelle.
    # recent_plays kann alte, beim Abspielen gemerkte IDs enthalten und darf deshalb
    # nur noch als Fallback dienen, wenn der neue Scan-Cache keinen Treffer liefert.
    path = os.path.join(base, 'codex_talker3_channels_cache.json')
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        channels = data.get('channels') if isinstance(data, dict) else []
    except Exception:
        channels = []
    if isinstance(channels, list):
        best = None
        for channel in channels:
            if not isinstance(channel, dict):
                continue
            name = channel.get('name') or channel.get('title') or channel.get('label') or ''
            cmd = channel.get('cmd') or channel.get('command') or channel.get('url') or ''
            if not name or not cmd:
                continue
            name_norm = _codex_norm(name)
            name_base = _codex_base(name)
            name_compact = name_norm.replace(' ', '').replace('.', '')
            score = 0
            if target_norm and name_norm == target_norm:
                score += 120
            if target_base and name_base == target_base:
                score += 90
            if target_compact and name_compact == target_compact:
                score += 90
            if target_norm and (target_norm in name_norm or name_norm in target_norm):
                score += 45
            if target_base and (name_base.startswith(target_base + ' ') or target_base in name_base.split()):
                score += 35
            if target_compact and name_compact.startswith(target_compact):
                score += 35
            if score:
                name_quality = _codex_quality(name)
                quality_overlap = target_quality.intersection(name_quality)
                if target_quality:
                    if quality_overlap:
                        score += 80 * len(quality_overlap)
                    elif name_quality:
                        score -= 120
                    elif name_base == target_base:
                        score -= 40
                else:
                    score += 12 * len(quality_overlap)
            if score and (best is None or score > best[0]):
                best = (score, channel)
        if best is not None:
            try:
                xbmc.log('[Talker3 Codex] scan cache name match %s -> %s (%s)' % (label, best[1].get('name') or best[1].get('title') or best[1].get('label') or '', best[1].get('cmd') or best[1].get('command') or best[1].get('url') or ''), xbmc.LOGWARNING)
            except Exception:
                pass
            return {
                'cmd': str(best[1].get('cmd') or best[1].get('command') or best[1].get('url') or ''),
                'icon': str(best[1].get('icon') or best[1].get('logo') or ''),
            }

    for key in exact_keys:
        entry = plays.get(key)
        if isinstance(entry, dict) and entry.get('cmd'):
            try:
                xbmc.log('[Talker3 Codex] recent fallback exact quality name match %s -> %s (%s)' % (label, key, entry.get('cmd')), xbmc.LOGWARNING)
            except Exception:
                pass
            return entry

    target_aliases = set(keys)
    target_aliases.update(_codex_base(k) for k in list(target_aliases))
    target_aliases.update(k.replace(' ', '').replace('.', '') for k in list(target_aliases))
    best = None
    for play_key, entry in plays.items():
        if not isinstance(entry, dict) or not entry.get('cmd'):
            continue
        play_norm = _codex_norm(play_key)
        play_base = _codex_base(play_key)
        play_compact = play_norm.replace(' ', '').replace('.', '')
        play_aliases = {play_norm, play_base, play_compact}
        score = 0
        if target_aliases.intersection(play_aliases):
            score += 100
        for key in target_aliases:
            if not key or len(key) < 3:
                continue
            if play_norm.startswith(key + ' ') or play_base.startswith(key + ' ') or play_compact.startswith(key):
                score += 55
            elif key in play_norm.split():
                score += 25
        if score:
            play_quality = _codex_quality(play_key)
            quality_overlap = target_quality.intersection(play_quality)
            if target_quality:
                if quality_overlap:
                    score += 80 * len(quality_overlap)
                elif play_quality:
                    score -= 120
                elif play_base == target_base:
                    score -= 40
            else:
                score += 12 * len(quality_overlap)
        if score and (best is None or score > best[0]):
            best = (score, entry, play_key)
    if best is not None:
        try:
            xbmc.log('[Talker3 Codex] recent fallback name match %s -> %s (%s)' % (label, best[2], best[1].get('cmd')), xbmc.LOGWARNING)
        except Exception:
            pass
        return best[1]
    return None


def _codex_talker3_normalize_mac(value):
    try:
        if value is None:
            return ''
        macs = _codex_extract_macs_from_text(value, 1)
        if macs:
            return macs[0].upper()
    except Exception:
        pass
    return ''


def _codex_talker3_mac_session_path():
    try:
        import os
        base = _codex_data_dir()
        if base:
            return os.path.join(base, 'mac_session.json')
    except Exception:
        pass
    return ''


def _codex_talker3_load_current_mac():
    try:
        import json
        import os
        path = _codex_talker3_mac_session_path()
        if not path or not os.path.exists(path):
            return ''
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return ''
        mac = _codex_talker3_normalize_mac(data.get('current_mac') or data.get('mac') or '')
        verified = data.get('verified')
        if mac and verified is not False:
            return mac
    except Exception:
        pass
    return ''


def _codex_talker3_save_current_mac(mac, reason=''):
    mac = _codex_talker3_normalize_mac(mac)
    if not mac:
        return False
    try:
        import json
        import os
        import time
        import xbmc
        path = _codex_talker3_mac_session_path()
        if not path:
            return False
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder, exist_ok=True)
        payload = {
            'current_mac': mac,
            'current_at': time.time(),
            'verified': True,
            'reason': str(reason or ''),
        }
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
        try:
            xbmc.log('[Talker3 Codex] verified current MAC saved reason=%s mac=%s' % (
                reason or '-',
                _codex_redact_mac(mac),
            ), xbmc.LOGWARNING)
            _codex_log_mac_analytics('Portal2/Talker3', 'verified-current-mac-saved', 'reason=%s mac=%s' % (
                reason or '-',
                _codex_redact_mac(mac),
            ))
        except Exception:
            pass
        return True
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] verified current MAC save failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    return False


def _codex_talker3_clear_current_mac(reason=''):
    try:
        import os
        import xbmc
        path = _codex_talker3_mac_session_path()
        if path and os.path.exists(path):
            os.remove(path)
        try:
            xbmc.log('[Talker3 Codex] verified current MAC cleared reason=%s' % (reason or '-'), xbmc.LOGWARNING)
            _codex_log_mac_analytics('Portal2/Talker3', 'verified-current-mac-cleared', str(reason or ''))
        except Exception:
            pass
        return True
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] verified current MAC clear failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    return False


def _codex_talker3_native_objects(native_service=None, native_addon=None):
    objects = []
    try:
        import sys
        for obj in (native_service, native_addon):
            if obj is not None and obj not in objects:
                objects.append(obj)
            try:
                portal = getattr(obj, 'stalker_portal', None)
                if portal is not None and portal not in objects:
                    objects.append(portal)
            except Exception:
                pass
        for module_name in ('lib.service', 'lib.addon', 'lib.config', 'lib.stalker_net'):
            mod = sys.modules.get(module_name)
            if mod is not None and mod not in objects:
                objects.append(mod)
            try:
                portal = getattr(mod, 'stalker_portal', None)
                if portal is not None and portal not in objects:
                    objects.append(portal)
            except Exception:
                pass
        expanded = []
        for obj in list(objects):
            for attr in ('portal', 'portal_config', 'config', 'G', 'settings'):
                try:
                    nested = getattr(obj, attr, None)
                    if nested is not None and nested not in objects and nested not in expanded:
                        expanded.append(nested)
                except Exception:
                    pass
        objects.extend(expanded)
        for obj in list(expanded):
            for attr in ('portal_config', 'config'):
                try:
                    nested = getattr(obj, attr, None)
                    if nested is not None and nested not in objects:
                        objects.append(nested)
                except Exception:
                    pass
    except Exception:
        pass
    return objects


def _codex_talker3_extract_native_mac(native_service=None, native_addon=None, extra_text=''):
    try:
        for obj in _codex_talker3_native_objects(native_service, native_addon):
            for attr in ('mac', 'MAC', 'mac_address', 'device_mac'):
                try:
                    mac = _codex_talker3_normalize_mac(getattr(obj, attr, None))
                    if mac:
                        return mac
                except Exception:
                    pass
        mac = _codex_talker3_normalize_mac(extra_text)
        if mac:
            return mac
    except Exception:
        pass
    return ''


def _codex_talker3_apply_current_mac_to_native(mac, native_service=None, native_addon=None, reason=''):
    mac = _codex_talker3_normalize_mac(mac)
    if not mac:
        return False
    changed = 0
    try:
        import xbmc
        for obj in _codex_talker3_native_objects(native_service, native_addon):
            for attr in ('mac', 'MAC', 'mac_address', 'device_mac'):
                try:
                    if hasattr(obj, attr):
                        setattr(obj, attr, mac)
                        changed += 1
                except Exception:
                    pass
        if changed:
            xbmc.log('[Talker3 Codex] verified current MAC applied reason=%s mac=%s targets=%d' % (
                reason or '-',
                _codex_redact_mac(mac),
                changed,
            ), xbmc.LOGWARNING)
            _codex_log_mac_analytics('Portal2/Talker3', 'verified-current-mac-applied', 'reason=%s mac=%s targets=%d' % (
                reason or '-',
                _codex_redact_mac(mac),
                changed,
            ))
            return True
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] verified current MAC apply failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    return False


def _codex_handle_talker3_safe_tv_play(argv):
    try:
        import sys
        import xbmc
        import xbmcgui
        import xbmcplugin
        from urllib.parse import parse_qs, unquote_plus, urlencode
    except Exception:
        return False

    try:
        query = argv[2] if len(argv) > 2 else ''
        if query.startswith('?'):
            query = query[1:]
        params = parse_qs(query, keep_blank_values=True)
        action = (params.get('action') or [''])[0].strip().lower()
        if action != 'codex_talker3_bridge_play':
            return False

        handle = int(argv[1]) if len(argv) > 1 else -1
        label = unquote_plus((params.get('label') or params.get('name') or ['Live TV 2'])[0]).strip() or 'Live TV 2'
        cmd = unquote_plus((params.get('cmd') or [''])[0]).strip()
        icon = unquote_plus((params.get('icon') or [''])[0]).strip()

        def _finish_failed(message='Kanal nicht erreichbar'):
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            except Exception:
                pass
            try:
                xbmc.log('[Talker3 Codex] SAFE-TV-PLAY abort %s cmd=%s: %s' % (label, cmd, message), xbmc.LOGWARNING)
            except Exception:
                pass
            try:
                if handle >= 0:
                    li = xbmcgui.ListItem(label=label)
                    xbmcplugin.setResolvedUrl(handle, False, li)
            except Exception:
                pass
            try:
                xbmcgui.Dialog().notification('Live TV 2', message, xbmcgui.NOTIFICATION_ERROR, 2200)
            except Exception:
                pass

        if not cmd:
            _finish_failed('Kein Sender-Link')
            return True

        cooldown = _codex_talker3_live_cooldown_remaining()
        if cooldown:
            try:
                xbmc.log('[Talker3 Codex] SAFE-TV-PLAY skip while portal cooldown is active (%d seconds left): %s' % (cooldown, label), xbmc.LOGWARNING)
            except Exception:
                pass
            _finish_failed('Portal beruhigt sich kurz (%ds)' % cooldown)
            return True

        _codex_talker3_live_prestop_player_before_bridge(label)

        stream_url = ''
        native_addon = None
        native_service = None
        original_argv2 = None
        stored_mac = _codex_talker3_load_current_mac()

        try:
            # Wichtig: Beim Import nicht den alten tv_play-Pfad triggern.
            # Diese Bridge soll wie Live TV 3 kontrolliert laufen:
            # ein Sender = ein Warm-up/create_link-Versuch, keine Retry-Kaskade.
            if len(sys.argv) > 2:
                original_argv2 = sys.argv[2]
                sys.argv[2] = '?action=codex_talker3_bridge_play'

            import lib.addon as native_addon
            try:
                import lib.service as native_service
            except Exception:
                native_service = None
        except Exception as import_exc:
            _finish_failed('Portal nicht erreichbar')
            try:
                xbmc.log('[Talker3 Codex] SAFE-TV-PLAY native import failed: %s' % import_exc, xbmc.LOGERROR)
            except Exception:
                pass
            return True
        finally:
            try:
                if original_argv2 is not None and len(sys.argv) > 2:
                    sys.argv[2] = original_argv2
            except Exception:
                pass

        if stored_mac:
            _codex_talker3_apply_current_mac_to_native(stored_mac, native_service, native_addon, 'safe-tv-play')

        try:
            # Live TV 2: Der alte get_tv_genres()-Vor-Warm-up hat intern trotz
            # attempts=1 zwei schnelle Auth-Anfragen erzeugt. Für Kanalstarts ist
            # create_link selbst der sauberere, leichte Warm-up: ein Kanal, ein
            # kontrollierter Portal-Aufruf. Der manuelle Handshake bleibt separat.
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY LIVE warmup direct-create-link only; skip get_tv_genres preflight', xbmc.LOGWARNING)
        except Exception:
            pass

        play_error = None
        try:
            portal = getattr(native_service, 'stalker_portal', None) if native_service is not None else None
            if portal is not None and hasattr(portal, 'get_stream_link'):
                stream_url = portal.get_stream_link(cmd, content_type='itv') or ''
            elif hasattr(native_addon, 'get_tv_stream_url'):
                stream_url = native_addon.get_tv_stream_url(cmd) or ''
            elif hasattr(native_addon, 'get_stream_link'):
                stream_url = native_addon.get_stream_link(cmd) or ''
        except Exception as play_exc:
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY create_link failed without retry/MAC rotation cmd=%s: %s' % (cmd, play_exc), xbmc.LOGWARNING)
            play_error = play_exc
            if _codex_talker3_live_is_transient_error(play_exc):
                _codex_talker3_live_set_cooldown('create_link failed for %s: %s' % (label or '-', play_exc), 8)
            stream_url = ''

        if not stream_url:
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY no stream for %s cmd=%s; abort immediately without fallback/MAC rotation' % (label, cmd), xbmc.LOGWARNING)
            if stored_mac:
                _codex_talker3_clear_current_mac('safe-tv-play produced no stream for %s' % (label or '-'))
            if play_error is not None:
                _codex_talker3_live_abort_busy_state('create_link failed: %s' % (label or '-'))
            _finish_failed('Kanal nicht erreichbar')
            return True

        resolved_mac = _codex_talker3_normalize_mac(stream_url) or _codex_talker3_extract_native_mac(native_service, native_addon, stream_url)

        try:
            if '|' not in stream_url:
                headers = {}
                portal = getattr(native_service, 'stalker_portal', None) if native_service is not None else None
                if portal is not None:
                    for method_name in ('headers', 'headers_2', 'get_headers'):
                        try:
                            method = getattr(portal, method_name, None)
                            if callable(method):
                                got = method() or {}
                                if isinstance(got, dict):
                                    headers.update(got)
                        except Exception:
                            pass
                    try:
                        mac = getattr(portal, 'mac', '') or ''
                        if mac and not any(str(k).lower() == 'cookie' for k in headers.keys()):
                            headers['Cookie'] = 'mac=%s; stb_lang=en; timezone=Europe/Amsterdam' % mac
                    except Exception:
                        pass
                    try:
                        referer = getattr(portal, 'org_url', '') or getattr(portal, 'url', '') or ''
                        if referer and not any(str(k).lower() == 'referer' for k in headers.keys()):
                            headers['Referer'] = referer
                    except Exception:
                        pass
                if not any(str(k).lower() == 'user-agent' for k in headers.keys()):
                    headers['User-Agent'] = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'
                if not any(str(k).lower() == 'x-user-agent' for k in headers.keys()):
                    headers['X-User-Agent'] = 'Model: MAG250; Link: WiFi'
                allowed = {'user-agent', 'referer', 'cookie', 'x-user-agent', 'accept', 'connection'}
                clean = {}
                for key, value in (headers or {}).items():
                    if str(key).lower() in allowed and value:
                        clean[str(key)] = str(value)
                if clean:
                    stream_url = stream_url + '|' + urlencode(clean)
        except Exception as header_exc:
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY header attach skipped: %s' % header_exc, xbmc.LOGDEBUG)

        try:
            li = xbmcgui.ListItem(label=label, path=stream_url)
            li.setProperty('IsPlayable', 'true')
            if icon:
                try:
                    li.setArt({'icon': icon, 'thumb': icon})
                except Exception:
                    pass
            try:
                li.setInfo(type='Video', infoLabels={'mediatype': 'movie', 'Title': label})
            except Exception:
                pass
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY resolved %s cmd=%s' % (label, cmd), xbmc.LOGWARNING)
            if resolved_mac:
                _codex_talker3_save_current_mac(resolved_mac, 'safe-tv-play resolved %s' % (label or '-'))
            xbmcplugin.setResolvedUrl(handle, True, li)
        except Exception as resolved_exc:
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY setResolvedUrl failed: %s' % resolved_exc, xbmc.LOGERROR)
            _finish_failed('Kanal nicht erreichbar')
        return True
    except Exception:
        try:
            import traceback
            import xbmc
            import xbmcplugin
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY fatal: %s' % traceback.format_exc(), xbmc.LOGERROR)
            if len(argv) > 1:
                xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
        return True

def _codex_talker3_live_cooldown_path():
    try:
        import os
        base = _codex_data_dir()
        if base:
            return os.path.join(base, 'codex_talker3_live_cooldown.json')
    except Exception:
        pass
    return ''


def _codex_talker3_live_set_cooldown(reason='', seconds=8):
    try:
        import json
        import time
        path = _codex_talker3_live_cooldown_path()
        if not path:
            return
        data = {
            'until': time.time() + max(1, int(seconds or 8)),
            'reason': str(reason or ''),
            'updated_at': time.time(),
        }
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        pass


def _codex_talker3_live_cooldown_remaining():
    try:
        import json
        import os
        import time
        path = _codex_talker3_live_cooldown_path()
        if not path or not os.path.exists(path):
            return 0
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh) or {}
        remaining = int(float(data.get('until') or 0) - time.time())
        if remaining <= 0:
            try:
                os.remove(path)
            except Exception:
                pass
            return 0
        return max(1, remaining)
    except Exception:
        return 0


def _codex_talker3_live_is_transient_error(exc_or_text):
    try:
        text = str(exc_or_text or '').lower()
    except Exception:
        text = ''
    markers = (
        'kein token',
        'authentication failed',
        'auth failed',
        'connecttimeout',
        'connect timeout',
        'read timed out',
        'timed out',
        'timeout',
        'temporary failure',
        'connection aborted',
        'connection reset',
        'portal nicht erreichbar',
    )
    return any(marker in text for marker in markers)


def _codex_talker3_live_abort_busy_state(reason=''):
    try:
        import xbmc
        xbmc.log('[Talker3 Codex] SAFE-TV-PLAY cleanup: %s' % (reason or '-'), xbmc.LOGWARNING)
    except Exception:
        xbmc = None
    try:
        if xbmc:
            xbmc.executebuiltin('Dialog.Close(busydialog,true)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
    except Exception:
        pass
    try:
        if xbmc and xbmc.Player().isPlaying():
            xbmc.executebuiltin('PlayerControl(Stop)')
    except Exception:
        pass
    try:
        if xbmc:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass


def _codex_talker3_live_prestop_player_before_bridge(label=''):
    """Live-TV-2 Schutz wie Live TV 3: alten/hängenden Kodi-Player vor neuer Bridge lösen."""
    try:
        import time
        import xbmc
        player = xbmc.Player()
        was_playing = False
        try:
            was_playing = bool(player.isPlaying())
        except Exception:
            was_playing = False
        try:
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY pre-stop Kodi player before bridge: %s active=%s' % (
                label or '-',
                '1' if was_playing else '0',
            ), xbmc.LOGWARNING)
        except Exception:
            pass
        try:
            # Wie bei Live TV 3 bewusst PlayerControl statt xbmc.Player().stop():
            # blockiert nicht ewig, falls der alte InputStream noch im Timeout hängt.
            xbmc.executebuiltin('PlayerControl(Stop)')
        except Exception:
            pass
        try:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        except Exception:
            pass
        for _idx in range(8):
            try:
                if not xbmc.Player().isPlaying():
                    break
            except Exception:
                break
            try:
                xbmc.sleep(100)
            except Exception:
                time.sleep(0.1)
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] SAFE-TV-PLAY pre-stop skipped: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass


def _codex_handle_name_bridge(argv):
    try:
        import threading
        import time
        import xbmc
        import xbmcgui
        import xbmcplugin
        from urllib.parse import parse_qs, unquote_plus, urlencode
    except Exception:
        return False

    try:
        query = argv[2] if len(argv) > 2 else ''
        if query.startswith('?'):
            query = query[1:]
        params = parse_qs(query, keep_blank_values=True)
        action = (params.get('action') or [''])[0]
        if action not in ('codex_launch_name', 'codex_play_name'):
            return False

        label = unquote_plus((params.get('label') or params.get('name') or [''])[0]).strip()
        icon = unquote_plus((params.get('icon') or [''])[0]).strip()
        fallback_cmd = unquote_plus((params.get('fallback_cmd') or params.get('cmd') or [''])[0]).strip()
        hit = _codex_find_cached_cmd(label)
        if not hit:
            _codex_refresh_name_cache(label)
            hit = _codex_find_cached_cmd(label)
        chosen_cmd = hit.get('cmd') if isinstance(hit, dict) else ''
        chosen_icon = (hit.get('icon') if isinstance(hit, dict) else '') or icon

        if not chosen_cmd:
            if fallback_cmd:
                xbmc.log('[Talker3 Codex] no current name match for %s; stale fallback ignored: %s' % (label, fallback_cmd), xbmc.LOGWARNING)
            else:
                xbmc.log('[Talker3 Codex] no cmd for name bridge: %s' % label, xbmc.LOGERROR)
            try:
                handle = int(argv[1]) if len(argv) > 1 else -1
                if handle >= 0:
                    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(label or 'Talker3 Live-TV'))
                return True
            except Exception:
                return False

        # Live TV 2 muss den nativen Talker3-tv_play-Pfad benutzen.
        # Der Direkt-Resolver codex_talker3_bridge_play startete zwar, fiel im Log
        # aber nach kurzer Zeit mit "stream stalled" aus. Der alte stabile JULI\9
        # Build hat die PVR-Bruecke ebenfalls in tv_play zurueckgegeben.
        native_query = {'action': 'tv_play', 'cmd': chosen_cmd, 'source': 'codex_pvr', 'label': label}
        if chosen_icon:
            native_query['icon'] = chosen_icon
        native_query['plot'] = ''
        native_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(native_query))

        if action == 'codex_launch_name':
            handle = int(argv[1]) if len(argv) > 1 else -1
            xbmc.log('[Talker3 Codex] PVR launcher %s -> %s' % (label, native_url), xbmc.LOGWARNING)
            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(label or 'Talker3 Live-TV'))

            def delayed_play():
                try:
                    time.sleep(0.45)
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    xbmc.executebuiltin('PlayMedia(%s)' % native_url)
                except Exception:
                    pass

            threading.Thread(target=delayed_play, name='Talker3CodexNameBridge', daemon=True).start()
            return True

        argv[2] = '?' + urlencode(native_query)
        return False
    except Exception:
        try:
            import traceback
            import xbmc
            xbmc.log('[Talker3 Codex] name bridge failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
        except Exception:
            pass
        return False


def _codex_is_root_launch(argv):
    try:
        if not isinstance(argv, (list, tuple)) or len(argv) < 3:
            return False
        query = str(argv[2] or '').strip()
        return query in ('', '?')
    except Exception:
        return False


def _codex_add_root_item(handle, label, action, icon=''):
    try:
        import xbmcgui
        import xbmcplugin
        from urllib.parse import urlencode
        url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
            'action': action,
            'page': '1',
            'update_listing': 'False',
        }))
        item = xbmcgui.ListItem(label=label)
        if icon:
            try:
                item.setArt({'icon': icon, 'thumb': icon})
            except Exception:
                pass
        try:
            item.setInfo(type='Video', infoLabels={'title': label})
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, url, item, True)
    except Exception:
        pass


def _codex_resource_path(*parts):
    try:
        import os
        import xbmcaddon
        import xbmcvfs
        base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))
        return os.path.join(base, *parts)
    except Exception:
        try:
            import os
            return os.path.join(os.path.dirname(__file__), *parts)
        except Exception:
            return ''


def _codex_profile_file(filename):
    try:
        import os
        import xbmcaddon
        import xbmcvfs
        profile = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, filename)
    except Exception:
        return ''


def _codex_root_icon(name):
    if name == 'movies':
        return _codex_resource_path('resources', 'media', 'genres', 'movies.png')
    if name == 'series':
        return _codex_resource_path('resources', 'media', 'genres', 'series.png')
    if name == 'favorites':
        return _codex_resource_path('resources', 'media', 'gold_star.png')
    return ''


def _codex_favorites_path():
    return _codex_profile_file(TALKER3_FAVORITES_FILE)


def _codex_favorite_id(title, media_type, original_url):
    try:
        import hashlib
        seed = ('%s|%s|%s' % (title or '', media_type or '', original_url or '')).encode('utf-8', 'ignore')
        return hashlib.sha1(seed).hexdigest()
    except Exception:
        return str(abs(hash('%s|%s|%s' % (title or '', media_type or '', original_url or ''))))


def _codex_load_talker3_favorites():
    try:
        import json
        import os
        path = _codex_favorites_path()
        if path and os.path.exists(path):
            with open(path, 'r', encoding='utf-8-sig') as fh:
                data = json.load(fh)
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] favorites read failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    return []


def _codex_save_talker3_favorites(items):
    try:
        import json
        path = _codex_favorites_path()
        if not path:
            return False
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(items or [], fh, ensure_ascii=False, indent=2, sort_keys=True)
        return True
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] favorites write failed: %s' % exc, xbmc.LOGERROR)
        except Exception:
            pass
    return False


def _codex_add_talker3_favorite(title, media_type, original_url, original_is_folder, year='', plot='', genre='', rating='', votes='', tmdb_id='', imdb_id='', icon=''):
    try:
        import time
        clean_title = _codex_clean_meta_value(title) or 'Favorit'
        fav = {
            'id': _codex_favorite_id(clean_title, media_type, original_url),
            'title': clean_title,
            'media_type': media_type or 'movie',
            'original_url': original_url or '',
            'original_is_folder': bool(original_is_folder),
            'year': year or '',
            'plot': plot or '',
            'genre': genre or '',
            'rating': rating or '',
            'votes': votes or '',
            'tmdb_id': tmdb_id or '',
            'imdb_id': imdb_id or '',
            'icon': icon or '',
            'added_at': int(time.time()),
        }
        items = _codex_load_talker3_favorites()
        items = [item for item in items if item.get('id') != fav['id']]
        items.insert(0, fav)
        return fav if _codex_save_talker3_favorites(items) else None
    except Exception:
        return None


def _codex_remove_talker3_favorite(fav_id):
    fav_id = str(fav_id or '').strip()
    if not fav_id:
        return False
    items = _codex_load_talker3_favorites()
    new_items = [item for item in items if str(item.get('id') or '') != fav_id]
    if len(new_items) == len(items):
        return False
    return _codex_save_talker3_favorites(new_items)


def _codex_clear_talker3_favorites():
    return _codex_save_talker3_favorites([])


def _codex_talker3_favorites_url():
    return 'plugin://%s/?action=codex_talker3_favorites' % ADDON_ID


def _codex_talker3_clear_favorites_url():
    return 'plugin://%s/?action=codex_talker3_clear_favorites' % ADDON_ID


def _codex_talker3_remove_favorite_url(fav_id):
    try:
        from urllib.parse import urlencode
        return 'plugin://%s/?%s' % (ADDON_ID, urlencode({
            'action': 'codex_talker3_remove_favorite',
            'fav_id': fav_id or '',
        }))
    except Exception:
        return ''


def _codex_favorite_to_choice_url(fav):
    try:
        from urllib.parse import urlencode
        return 'plugin://%s/?%s' % (ADDON_ID, urlencode({
            'action': 'codex_media_choice',
            'choice_url': fav.get('original_url') or '',
            'choice_title': fav.get('title') or 'Favorit',
            'choice_media_type': fav.get('media_type') or 'movie',
            'choice_is_folder': '1' if fav.get('original_is_folder') else '0',
            'choice_year': fav.get('year') or '',
            'choice_plot': fav.get('plot') or '',
            'choice_genre': fav.get('genre') or '',
            'choice_rating': fav.get('rating') or '',
            'choice_votes': fav.get('votes') or '',
            'choice_tmdb_id': fav.get('tmdb_id') or '',
            'choice_imdb_id': fav.get('imdb_id') or '',
            'choice_icon': fav.get('icon') or '',
        }))
    except Exception:
        return fav.get('original_url') or ''


def _codex_handle_talker3_favorites(argv, handle, params):
    try:
        import xbmc
        import xbmcgui
        import xbmcplugin
    except Exception:
        return True
    action = (params.get('action') or [''])[0]
    if action == 'codex_talker3_remove_favorite':
        ok = _codex_remove_talker3_favorite((params.get('fav_id') or [''])[0])
        try:
            xbmcgui.Dialog().notification('Favoriten', 'Favorit entfernt' if ok else 'Favorit nicht gefunden', xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 2200)
            xbmc.executebuiltin('Container.Refresh')
        except Exception:
            pass
        return True
    if action == 'codex_talker3_clear_favorites':
        try:
            confirmed = xbmcgui.Dialog().yesno('Favoriten', 'Alle Stalker Portal 2 Favoriten löschen?')
        except Exception:
            confirmed = True
        if confirmed:
            ok = _codex_clear_talker3_favorites()
            try:
                xbmcgui.Dialog().notification('Favoriten', 'Alle Favoriten gelöscht' if ok else 'Favoriten konnten nicht gelöscht werden', xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 2500)
                xbmc.executebuiltin('Container.Refresh')
            except Exception:
                pass
        return True
    if action != 'codex_talker3_favorites':
        return False

    favorites = _codex_load_talker3_favorites()
    try:
        xbmcplugin.setContent(handle, 'movies')
    except Exception:
        pass
    fav_art = _codex_root_icon('favorites')
    if not favorites:
        li = xbmcgui.ListItem('Keine Favoriten gespeichert')
        try:
            li.setArt({'icon': fav_art, 'thumb': fav_art})
            li.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, '', li, False)
        xbmcplugin.endOfDirectory(handle, True, False, False)
        return True

    clear_li = xbmcgui.ListItem('Alle Favoriten löschen')
    try:
        clear_li.setArt({'icon': fav_art, 'thumb': fav_art})
        clear_li.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(handle, _codex_talker3_clear_favorites_url(), clear_li, False)

    for fav in favorites:
        try:
            label = fav.get('title') or 'Favorit'
            li = xbmcgui.ListItem(label=label)
            icon = fav.get('icon') or fav_art
            try:
                li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
            except Exception:
                pass
            try:
                li.setInfo(type='Video', infoLabels={
                    'title': label,
                    'plot': fav.get('plot') or '',
                    'genre': fav.get('genre') or '',
                    'rating': _codex_parse_rating_float(fav.get('rating')) or 0,
                    'year': int(fav.get('year') or 0) if str(fav.get('year') or '').isdigit() else 0,
                    'mediatype': fav.get('media_type') or 'movie',
                })
            except Exception:
                pass
            try:
                li.addContextMenuItems([
                    ('Aus Talker3 Favoriten entfernen', 'RunPlugin(%s)' % _codex_talker3_remove_favorite_url(fav.get('id') or '')),
                ])
            except Exception:
                pass
            xbmcplugin.addDirectoryItem(handle, _codex_favorite_to_choice_url(fav), li, False)
        except Exception:
            pass
    xbmcplugin.endOfDirectory(handle, True, False, True)
    return True


_CODEX_ROOT_ENV_WARMED = False


def _codex_warmup_root_environment():
    """Load the native Talker3/Stalker session before showing the restored root menu."""
    global _CODEX_ROOT_ENV_WARMED
    if _CODEX_ROOT_ENV_WARMED:
        return True
    try:
        import importlib
        import time
        import xbmc
    except Exception:
        return False

    try:
        import lib.addon as native_addon
    except Exception as exc:
        try:
            xbmc.log('[Talker3 Codex] root environment warmup import failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return False

    native_ref = {'addon': native_addon}
    last_error = None
    checks = (
        ('LIVE', 'get_tv_genres'),
        ('VOD', 'get_categories'),
        ('SERIES', 'get_ser_categories'),
    )

    for outer in range(1, 2):
        mod = native_ref.get('addon')
        for label, getter_name in checks:
            getter = getattr(mod, getter_name, None)
            if not getter:
                continue
            try:
                if hasattr(mod, 'retry_call_with_mac_rotation'):
                    payload = mod.retry_call_with_mac_rotation(
                        getter,
                        base_delay=0.35,
                        attempts=1,
                        rotate_on_empty=False,
                        log_prefix='CODEX-ROOT-%s' % label,
                    )
                else:
                    payload = getter()
                categories = _codex_extract_category_list(payload)
                if categories:
                    _CODEX_ROOT_ENV_WARMED = True
                    try:
                        xbmc.log('[Talker3 Codex] root environment warmup ok: %s categories=%d' % (label, len(categories)), xbmc.LOGINFO)
                    except Exception:
                        pass
                    return True
            except Exception as exc:
                last_error = exc
                try:
                    xbmc.log('[Talker3 Codex] root environment warmup %s attempt %d failed: %s' % (label, outer, exc), xbmc.LOGWARNING)
                except Exception:
                    pass
        if outer < 1:
            try:
                native_ref['addon'] = importlib.reload(native_ref['addon'])
                xbmc.log('[Talker3 Codex] root environment warmup reloaded Talker3 session', xbmc.LOGWARNING)
            except Exception as exc:
                last_error = exc
                try:
                    xbmc.log('[Talker3 Codex] root environment warmup reload failed: %s' % exc, xbmc.LOGWARNING)
                except Exception:
                    pass
            try:
                time.sleep(0.25)
            except Exception:
                pass

    try:
        xbmc.log('[Talker3 Codex] root environment warmup ended without categories%s' % ((': %s' % last_error) if last_error else ''), xbmc.LOGWARNING)
    except Exception:
        pass
    return False


def _codex_show_original_root_menu(argv):
    if not _codex_is_root_launch(argv):
        return False
    try:
        import xbmc
        import xbmcplugin
        handle = int(argv[1]) if len(argv) > 1 else -1
        _codex_warmup_root_environment()
        xbmc.log('[Talker3 Codex] showing restored root menu', xbmc.LOGINFO)
        if handle >= 0:
            try:
                xbmcplugin.setContent(handle, 'files')
            except Exception:
                pass
            _codex_add_root_item(handle, 'Filme', 'codex_vod_root', _codex_root_icon('movies'))
            _codex_add_root_item(handle, 'Serien', 'codex_series_root', _codex_root_icon('series'))
            _codex_add_root_item(handle, 'Favoriten', 'codex_talker3_favorites', _codex_root_icon('favorites'))
            xbmcplugin.endOfDirectory(handle, True, False, True)
        return True
    except Exception:
        return False


def _codex_first_non_empty(mapping, keys, default=''):
    try:
        for key in keys:
            value = mapping.get(key)
            if value not in (None, ''):
                return value
    except Exception:
        pass
    return default


def _codex_extract_category_list(payload):
    if payload is None:
        return []
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'categories', 'results', 'js'):
            value = payload.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                nested = _codex_extract_category_list(value)
                if nested:
                    return nested
    return []


def _codex_category_icon(item, fallback=''):
    icon = _codex_first_non_empty(item, (
        'icon', 'logo', 'cover', 'poster', 'picture', 'img', 'image', 'screenshot_uri'
    ), fallback)
    try:
        return str(icon or fallback)
    except Exception:
        return fallback


def _codex_search_icon():
    try:
        import os
        icon = _codex_resource_path('resources', 'media', 'genres', 'search.png')
        if icon and os.path.exists(icon):
            return icon
    except Exception:
        pass
    try:
        import os
        icon = _codex_resource_path('resources', 'skins', 'Default', 'media', 'search.png')
        if icon and os.path.exists(icon):
            return icon
    except Exception:
        pass
    return ''


def _codex_is_all_category(label, cat_id=''):
    try:
        text = str(label or '').strip().lower()
        cid = str(cat_id or '').strip().lower()
        return text in ('all', 'alle') or cid in ('*', 'all', 'alle')
    except Exception:
        return False


def _codex_media_label(item, fallback=''):
    if not isinstance(item, dict):
        return fallback
    value = _codex_first_non_empty(item, (
        'name', 'title', 'o_name', 'fname', 'series_name', 'movie_name', 'label'
    ), fallback)
    try:
        return str(value or fallback).strip()
    except Exception:
        return fallback


def _codex_media_id(item, fallback=''):
    if not isinstance(item, dict):
        return fallback
    value = _codex_first_non_empty(item, (
        'id', 'video_id', 'movie_id', 'series_id', 'episode_id', 'ch_id'
    ), fallback)
    try:
        return str(value or fallback).strip()
    except Exception:
        return fallback


def _codex_media_cmd(item):
    if not isinstance(item, dict):
        return ''
    value = _codex_first_non_empty(item, (
        'cmd', 'command', 'url', 'stream_url', 'file', 'path'
    ), '')
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _codex_media_art(item, fallback=''):
    if not isinstance(item, dict):
        return fallback
    return _codex_category_icon(item, fallback)


def _codex_media_plot(item):
    if not isinstance(item, dict):
        return ''
    value = _codex_first_non_empty(item, (
        'description', 'descr', 'plot', 'overview', 'about', 'comment'
    ), '')
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _codex_clean_meta_value(value):
    try:
        if value is None:
            return ''
        text = str(value).replace('\r', ' ').replace('\n', ' ').strip()
        return ' '.join(text.split())
    except Exception:
        return ''


def _codex_extract_year(value):
    try:
        import re
        match = re.search(r'(19|20)\d{2}', _codex_clean_meta_value(value))
        return match.group(0) if match else ''
    except Exception:
        return ''


def _codex_clean_title_for_lookup(title):
    try:
        import re
        text = _codex_clean_meta_value(title)
        text = text.replace('â”ƒ', ' ').replace('|', ' ')
        text = re.sub(r'\[[^\]]*\]', ' ', text)
        text = re.sub(r'\([^\)]*(?:de|german|multi|4k|uhd|fhd|hd|hevc|raw|x264|x265|web|bluray)[^\)]*\)', ' ', text, flags=re.I)
        text = re.sub(r'\b(4k|uhd|fhd|fullhd|hd|hevc|raw|x264|x265|web[- ]?dl|bluray|german|deutsch|multi)\b', ' ', text, flags=re.I)
        text = re.sub(r'\b(19|20)\d{2}\b', ' ', text)
        return ' '.join(text.split()).strip(' -._')
    except Exception:
        return _codex_clean_meta_value(title)


def _codex_parse_rating_float(value):
    try:
        import re
        text = _codex_clean_meta_value(value).replace(',', '.')
        match = re.search(r'\d+(?:\.\d+)?', text)
        if not match:
            return None
        rating = float(match.group(0))
        if rating > 10 and rating <= 100:
            rating = rating / 10.0
        if 0 <= rating <= 10:
            return rating
    except Exception:
        pass
    return None


def _codex_format_rating(value):
    rating = _codex_parse_rating_float(value)
    if rating is None:
        return ''
    return '%.1f' % rating


def _codex_parse_int(value):
    try:
        import re
        text = _codex_clean_meta_value(value).replace('.', '').replace(',', '')
        match = re.search(r'\d+', text)
        return int(match.group(0)) if match else 0
    except Exception:
        return 0


def _codex_tmdb_image_size(url, size):
    try:
        url = str(url or '')
        if 'image.tmdb.org/t/p/' not in url:
            return url
        left, right = url.split('/t/p/', 1)
        if '/' not in right:
            return url
        return left + '/t/p/' + size + '/' + right.split('/', 1)[1]
    except Exception:
        return url


def _codex_tmdb_request(endpoint, params):
    import json
    import urllib.parse
    import urllib.request
    params = dict(params or {})
    params['api_key'] = CODEX_TMDB_API_KEY
    query = urllib.parse.urlencode(params)
    url = 'https://api.themoviedb.org/3/%s?%s' % (endpoint, query)
    request = urllib.request.Request(url, headers={'User-Agent': 'Kodi-Talker3-Metadata/1.0'})
    with urllib.request.urlopen(request, timeout=4) as response:
        return json.loads(response.read().decode('utf-8'))


def _codex_tmdb_lookup(title, year='', media_type='movie', force=False):
    clean_title = _codex_clean_title_for_lookup(title)
    clean_year = _codex_extract_year(year) or _codex_extract_year(title)
    if not clean_title:
        return {}
    cache_key = (clean_title.lower(), clean_year, str(media_type or '').lower(), bool(force))
    if cache_key in _CODEX_TMDB_CACHE:
        return _CODEX_TMDB_CACHE.get(cache_key) or {}
    searches = ['search/tv', 'search/movie'] if media_type in ('tvshow', 'season', 'episode', 'series') else ['search/movie', 'search/tv']
    meta = {}
    for endpoint in searches:
        try:
            params = {'query': clean_title, 'language': 'de-DE', 'include_adult': 'false'}
            if clean_year:
                if endpoint == 'search/movie':
                    params['year'] = clean_year
                else:
                    params['first_air_date_year'] = clean_year
            data = _codex_tmdb_request(endpoint, params)
        except Exception:
            continue
        results = data.get('results') or []
        if not results:
            continue
        result = results[0]
        release = result.get('release_date') or result.get('first_air_date') or ''
        meta = {
            'title': result.get('title') or result.get('name') or clean_title,
            'plot': result.get('overview') or '',
            'rating': _codex_format_rating(result.get('vote_average')),
            'votes': _codex_clean_meta_value(result.get('vote_count')),
            'year': _codex_extract_year(release) or clean_year,
            'tmdb_id': _codex_clean_meta_value(result.get('id')),
            'tmdb_type': 'tv' if endpoint == 'search/tv' else 'movie',
        }
        poster = result.get('poster_path') or ''
        fanart = result.get('backdrop_path') or ''
        if poster:
            meta['poster'] = 'https://image.tmdb.org/t/p/w185%s' % poster
        if fanart:
            meta['fanart'] = 'https://image.tmdb.org/t/p/w300%s' % fanart
        break
    if force and meta.get('tmdb_id'):
        try:
            details = _codex_tmdb_request(
                '%s/%s' % (meta.get('tmdb_type') or 'movie', meta.get('tmdb_id')),
                {'language': 'de-DE', 'append_to_response': 'external_ids,credits'}
            )
            meta['plot'] = details.get('overview') or meta.get('plot', '')
            meta['rating'] = _codex_format_rating(details.get('vote_average')) or meta.get('rating', '')
            meta['votes'] = _codex_clean_meta_value(details.get('vote_count')) or meta.get('votes', '')
            meta['year'] = _codex_extract_year(details.get('release_date') or details.get('first_air_date')) or meta.get('year', '')
            meta['imdb_id'] = _codex_clean_meta_value((details.get('external_ids') or {}).get('imdb_id') or details.get('imdb_id'))
            runtime = details.get('runtime')
            if not runtime and details.get('episode_run_time'):
                try:
                    runtime = details.get('episode_run_time')[0]
                except Exception:
                    runtime = ''
            meta['runtime'] = _codex_clean_meta_value(runtime)
            credits = details.get('credits') or {}
            crew = credits.get('crew') or []
            directors = [c.get('name') for c in crew if c.get('job') == 'Director' and c.get('name')]
            writers = [c.get('name') for c in crew if c.get('job') in ('Writer', 'Screenplay', 'Author') and c.get('name')]
            if directors:
                meta['director'] = ' / '.join(directors[:3])
            if writers:
                meta['writer'] = ' / '.join(writers[:3])
            if details.get('poster_path'):
                meta['poster'] = 'https://image.tmdb.org/t/p/w185%s' % details.get('poster_path')
            if details.get('backdrop_path'):
                meta['fanart'] = 'https://image.tmdb.org/t/p/w300%s' % details.get('backdrop_path')
        except Exception:
            pass
    _CODEX_TMDB_CACHE[cache_key] = meta
    return meta


def _codex_meta_from_item(item, label, mediatype):
    item = item if isinstance(item, dict) else {}
    meta = {
        'title': label,
        'plot': _codex_media_plot(item),
        'year': _codex_first_non_empty(item, ('year', 'released', 'release_year', 'release_date', 'added'), ''),
        'genre': _codex_first_non_empty(item, ('genre', 'genres_str', 'genres', 'category_name'), ''),
        'rating': _codex_first_non_empty(item, ('rating_imdb', 'imdb', 'rating', 'vote_average', 'tmdb_rating', 'TMDb_Rating', 'rate'), ''),
        'tmdb_rating': _codex_first_non_empty(item, ('vote_average', 'tmdb_rating', 'TMDb_Rating', 'themoviedb'), ''),
        'trakt_rating': _codex_first_non_empty(item, ('rating_trakt', 'trakt_rating', 'Trakt_Rating'), ''),
        'votes': _codex_first_non_empty(item, ('votes_imdb', 'votes', 'vote_count', 'rating_count_imdb'), ''),
        'tmdb_id': _codex_first_non_empty(item, ('tmdb_id', 'tmdb', 'tmdbid'), ''),
        'imdb_id': _codex_first_non_empty(item, ('imdb_id', 'imdbid'), ''),
        'mediatype': mediatype,
    }
    poster = _codex_media_art(item)
    fanart = _codex_first_non_empty(item, ('fanart', 'backdrop', 'backdrop_path', 'background', 'landscape'), '')
    if poster:
        meta['poster'] = poster
    if fanart:
        meta['fanart'] = fanart
    return meta


def _codex_apply_video_metadata(li, label, item=None, mediatype='video', playable=False):
    meta = _codex_meta_from_item(item or {}, label, mediatype)
    rating_text = _codex_format_rating(meta.get('rating') or meta.get('tmdb_rating') or meta.get('trakt_rating'))
    tmdb_rating_text = _codex_format_rating(meta.get('tmdb_rating') or meta.get('rating'))
    trakt_rating_text = _codex_format_rating(meta.get('trakt_rating'))
    votes_value = _codex_parse_int(meta.get('votes'))
    year_value = _codex_parse_int(_codex_extract_year(meta.get('year')))
    plot_text = _codex_clean_meta_value(meta.get('plot'))
    genre_text = _codex_clean_meta_value(meta.get('genre'))
    try:
        art = {}
        if meta.get('poster'):
            poster = _codex_tmdb_image_size(meta.get('poster'), 'w185')
            art.update({'icon': poster, 'thumb': poster, 'poster': poster})
        if meta.get('fanart'):
            art['fanart'] = _codex_tmdb_image_size(meta.get('fanart'), 'w300')
        if art:
            li.setArt(art)
    except Exception:
        pass
    try:
        info = {'title': label, 'mediatype': mediatype}
        if plot_text:
            info['plot'] = plot_text
        if genre_text:
            info['genre'] = genre_text
        if year_value:
            info['year'] = year_value
        rating_value = _codex_parse_rating_float(rating_text)
        if rating_value is not None:
            info['rating'] = rating_value
        if votes_value:
            info['votes'] = votes_value
        li.setInfo(type='Video', infoLabels=info)
    except Exception:
        pass
    try:
        tag = li.getVideoInfoTag()
        try:
            tag.setMediaType(mediatype)
        except Exception:
            pass
        try:
            tag.setTitle(label)
        except Exception:
            pass
        if plot_text:
            try:
                tag.setPlot(plot_text)
            except Exception:
                pass
        rating_value = _codex_parse_rating_float(rating_text)
        if rating_value is not None:
            try:
                tag.setRating(rating_value, votes_value, 'tmdb', True)
            except Exception:
                pass
        if meta.get('tmdb_id'):
            try:
                tag.setUniqueID(str(meta.get('tmdb_id')), 'tmdb')
            except Exception:
                pass
        if meta.get('imdb_id'):
            try:
                tag.setUniqueID(str(meta.get('imdb_id')), 'imdb')
            except Exception:
                pass
    except Exception:
        pass
    for key, value in {
        'Rating': rating_text,
        'IMDb_Rating': rating_text,
        'TMDb_Rating': tmdb_rating_text or rating_text,
        'Trakt_Rating': trakt_rating_text,
        'TmdbId': meta.get('tmdb_id', ''),
        'tmdb_id': meta.get('tmdb_id', ''),
        'imdb_id': meta.get('imdb_id', ''),
        'mediatype': mediatype,
        'dbtype': mediatype,
    }.items():
        if value:
            try:
                li.setProperty(key, str(value))
            except Exception:
                pass
    try:
        ids = {}
        if meta.get('tmdb_id'):
            ids['tmdb'] = str(meta.get('tmdb_id'))
        if meta.get('imdb_id'):
            ids['imdb'] = str(meta.get('imdb_id'))
        if ids:
            li.setUniqueIDs(ids)
    except Exception:
        pass
    if playable:
        try:
            li.setProperty('IsPlayable', 'true')
        except Exception:
            pass
    return meta


def _codex_set_art_and_info(li, label, item=None, mediatype='video', playable=False):
    _codex_apply_video_metadata(li, label, item or {}, mediatype, playable)


def _codex_add_category_item(handle, label, url, icon='', media_type='files'):
    try:
        import xbmcgui
        import xbmcplugin
        li = xbmcgui.ListItem(label=label)
        if icon:
            try:
                li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
            except Exception:
                pass
        try:
            li.setInfo(type='Video', infoLabels={'title': label, 'mediatype': media_type})
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, url, li, True)
    except Exception:
        pass


def _codex_title_view_prefs_path():
    try:
        import os
        import xbmcaddon
        import xbmcvfs
        profile = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, 'view_prefs.json')
    except Exception:
        return ''


def _codex_ensure_title_view_pref():
    try:
        import json
        path = _codex_title_view_prefs_path()
        if not path:
            return
        prefs = {}
        try:
            import os
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8-sig') as fh:
                    prefs = json.load(fh) or {}
        except Exception:
            prefs = {}
        prefs['video_titles'] = {
            'skin': 'skin.aeon.nox.silvo',
            'sortAttributes': 0,
            'sortMethod': 0,
            'sortOrder': 1,
            'viewMode': CODEX_TITLE_VIEW_MODE,
        }
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(prefs, fh, sort_keys=True)
    except Exception:
        pass


def _codex_view_db_path():
    try:
        import os
        import xbmcvfs
        db_dir = xbmcvfs.translatePath('special://database/')
        candidates = [
            name for name in os.listdir(db_dir)
            if name.lower().startswith('viewmodes') and name.lower().endswith('.db')
        ]
        if candidates:
            candidates.sort()
            return os.path.join(db_dir, candidates[-1])
        return os.path.join(db_dir, 'ViewModes6.db')
    except Exception:
        return ''


def _codex_current_plugin_url():
    try:
        import sys
        base = sys.argv[0] if len(sys.argv) > 0 else 'plugin://%s/' % ADDON_ID
        query = sys.argv[2] if len(sys.argv) > 2 else ''
        return '%s%s' % (base, query or '')
    except Exception:
        return ''


def _codex_is_title_listing_path(path):
    try:
        from urllib.parse import unquote
        text = unquote(path or '').lower()
    except Exception:
        text = (path or '').lower()
    if ADDON_ID not in text:
        return False
    return 'action=codex_vod_listing' in text or 'action=codex_series_listing' in text


def _codex_title_view_row_from_pref():
    try:
        import json
        import os
        path = _codex_title_view_prefs_path()
        if not path or not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8-sig') as fh:
            prefs = json.load(fh) or {}
        data = prefs.get('video_titles') or {}
        view_mode = int(data.get('viewMode') or 0)
        if not view_mode:
            return None
        return (
            0,
            view_mode,
            int(data.get('sortMethod') or 0),
            int(data.get('sortOrder') or 1),
            int(data.get('sortAttributes') or 0),
            data.get('skin') or 'skin.aeon.nox.silvo',
        )
    except Exception:
        return None


def _codex_remember_title_view_row(row):
    try:
        import json
        if not row or not int(row[1] or 0):
            return
        path = _codex_title_view_prefs_path()
        if not path:
            return
        prefs = {}
        try:
            import os
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8-sig') as fh:
                    prefs = json.load(fh) or {}
        except Exception:
            prefs = {}
        prefs['video_titles'] = {
            'skin': row[5] or 'skin.aeon.nox.silvo',
            'sortAttributes': int(row[4] or 0),
            'sortMethod': int(row[2] or 0),
            'sortOrder': int(row[3] or 1),
            'viewMode': int(row[1] or 0),
        }
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(prefs, fh, sort_keys=True)
    except Exception:
        pass


def _codex_get_title_view_row(con, path):
    try:
        return con.execute(
            'select idView, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path=?',
            (10025, path)
        ).fetchone()
    except Exception:
        return None


def _codex_latest_title_view_row(con):
    try:
        current = _codex_current_plugin_url()
        current_row = _codex_get_title_view_row(con, current) if current else None
        if current_row and int(current_row[1] or 0):
            return current_row
    except Exception:
        pass
    pref = _codex_title_view_row_from_pref()
    if pref:
        return pref
    try:
        rows = con.execute(
            'select idView, path, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path like ? and viewMode<>0 order by idView desc limit 300',
            (10025, 'plugin://%s%%' % ADDON_ID)
        ).fetchall()
        for row in rows or []:
            if _codex_is_title_listing_path(row[1]):
                return (row[0], row[2], row[3], row[4], row[5], row[6])
        if rows:
            row = rows[0]
            return (row[0], row[2], row[3], row[4], row[5], row[6])
    except Exception:
        pass
    return (
        0,
        CODEX_TITLE_VIEW_MODE,
        0,
        1,
        0,
        'skin.aeon.nox.silvo',
    )


def _codex_set_title_view_row(con, path, source_row):
    try:
        if not path or not source_row or not int(source_row[1] or 0):
            return
        view_mode = int(source_row[1] or 0)
        sort_method = int(source_row[2] or 0)
        sort_order = int(source_row[3] or 1)
        sort_attributes = int(source_row[4] or 0)
        skin = source_row[5] or 'skin.aeon.nox.silvo'
        existing = _codex_get_title_view_row(con, path)
        if existing:
            con.execute(
                'update view set viewMode=?, sortMethod=?, sortOrder=?, sortAttributes=?, skin=? where idView=?',
                (view_mode, sort_method, sort_order, sort_attributes, skin, existing[0])
            )
        else:
            next_id = con.execute('select coalesce(max(idView), 0) + 1 from view').fetchone()[0]
            con.execute(
                'insert into view (idView, window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) values (?, ?, ?, ?, ?, ?, ?, ?)',
                (next_id, 10025, path, view_mode, sort_method, sort_order, sort_attributes, skin)
            )
    except Exception:
        pass


def _codex_sync_title_view_for_current_path(extra_paths=None, action='', category_id=''):
    try:
        import os
        import sqlite3
        current = _codex_current_plugin_url()
        paths = []
        if current:
            paths.append(current)
        for path in (extra_paths or []):
            if path and path not in paths:
                paths.append(path)
        paths = [path for path in paths if _codex_is_title_listing_path(path)]
        if not paths and not action:
            return
        db_path = _codex_view_db_path()
        if not db_path or not os.path.exists(db_path):
            return
        con = sqlite3.connect(db_path, timeout=0.75)
        try:
            source = _codex_latest_title_view_row(con)
            if source:
                for path in paths:
                    _codex_set_title_view_row(con, path, source)
                if action and category_id:
                    try:
                        like_action = '%action=%s%%' % action
                        like_category = '%category_id=%s%%' % str(category_id)
                        rows = con.execute(
                            'select path from view where window=? and path like ? and path like ?',
                            (10025, 'plugin://%s%%' % ADDON_ID, like_action)
                        ).fetchall()
                        for (path,) in rows or []:
                            if like_category.strip('%') in path and _codex_is_title_listing_path(path):
                                _codex_set_title_view_row(con, path, source)
                    except Exception:
                        pass
                _codex_remember_title_view_row(source)
                con.commit()
        finally:
            con.close()
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] title view sync failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass


def _codex_apply_title_view(action='', category_id=''):
    try:
        _codex_ensure_title_view_pref()
        _codex_sync_title_view_for_current_path(action=action, category_id=category_id)
    except Exception:
        pass


def _codex_choice_url(original_url, title, media_type, item=None, is_folder=False):
    try:
        from urllib.parse import urlencode
        item = item if isinstance(item, dict) else {}
        meta = _codex_meta_from_item(item, title, media_type)
        params = {
            'action': 'codex_media_choice',
            'choice_url': original_url,
            'choice_title': title,
            'choice_media_type': media_type,
            'choice_is_folder': '1' if is_folder else '0',
            'choice_year': _codex_clean_meta_value(meta.get('year')),
            'choice_plot': _codex_clean_meta_value(meta.get('plot')),
            'choice_genre': _codex_clean_meta_value(meta.get('genre')),
            'choice_rating': _codex_clean_meta_value(meta.get('rating') or meta.get('tmdb_rating') or meta.get('trakt_rating')),
            'choice_votes': _codex_clean_meta_value(meta.get('votes')),
            'choice_tmdb_id': _codex_clean_meta_value(meta.get('tmdb_id')),
            'choice_imdb_id': _codex_clean_meta_value(meta.get('imdb_id')),
            'choice_icon': _codex_clean_meta_value(meta.get('poster') or _codex_media_art(item)),
        }
        return 'plugin://%s/?%s' % (ADDON_ID, urlencode(params))
    except Exception:
        return original_url


def _codex_clean_series_id(value):
    value = str(value or '').strip()
    return value.split(':', 1)[0] if ':' in value else value


def _codex_clean_season_id(video_id='', season=''):
    raw = str(season or '').strip()
    if not raw and ':' in str(video_id or ''):
        raw = str(video_id or '').split(':', 1)[1]
    try:
        import re
        match = re.search(r'(\d+)', raw)
        return match.group(1) if match else raw
    except Exception:
        return raw


def _codex_episode_label(item, fallback_index=0, season_id=''):
    label = _codex_media_label(item, '')
    lower = str(label or '').strip().lower()
    if label and not (lower.startswith('season ') or lower.startswith('staffel ')):
        return label
    number = _codex_first_non_empty(item, ('episode', 'episode_number', 'series_number', 'number'), '')
    if number:
        return 'Episode %s' % number
    if season_id:
        return 'S%s E%s' % (season_id, fallback_index)
    return 'Episode %s' % fallback_index


def _codex_parse_episode_numbers(value):
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value or '').strip()
    if not text:
        return []
    try:
        import json
        parsed = json.loads(text)
        if isinstance(parsed, (list, tuple)):
            return [str(v).strip() for v in parsed if str(v).strip()]
    except Exception:
        pass
    try:
        import re
        return re.findall(r'\d+', text)
    except Exception:
        return []


def _codex_expand_season_rows_to_episodes(rows, wanted_season=''):
    expanded = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        label = _codex_media_label(row, '')
        lower_label = str(label or '').lower()
        numbers = _codex_parse_episode_numbers(row.get('series'))
        cmd = _codex_first_non_empty(row, ('cmd', 'url', 'stream_url', 'command'), '')
        video_id = _codex_media_id(row)
        season_no = _codex_clean_season_id(video_id, label) or str(wanted_season or '').strip()
        looks_like_season_row = bool(
            numbers
            and (cmd or video_id)
            and ('season' in lower_label or 'staffel' in lower_label or ':' in str(video_id or ''))
        )
        if not looks_like_season_row:
            expanded.append(row)
            continue
        for ep_no in numbers:
            item = dict(row)
            item['name'] = 'S%s E%s' % (season_no or wanted_season or '?', ep_no)
            item['title'] = item['name']
            item['episode_number'] = ep_no
            item['episode'] = ep_no
            item['series'] = ep_no
            item['video_id'] = ep_no
            item['is_codex_expanded_episode'] = True
            expanded.append(item)
    return expanded


def _codex_show_information_dialog(title, media_type='movie', year='', plot='', genre='', rating='', votes='', tmdb_id='', imdb_id='', icon=''):
    try:
        import xbmc
        import xbmcgui
        clean_title = _codex_clean_title_for_lookup(title) or _codex_clean_meta_value(title) or 'Informationen'
        meta = _codex_tmdb_lookup(clean_title, year=year, media_type=media_type, force=True)
        if not meta:
            meta = {}
        label = meta.get('title') or clean_title
        plot_text = meta.get('plot') or plot
        genre_text = meta.get('genre') or genre
        rating_text = _codex_format_rating(meta.get('rating') or rating)
        votes_value = _codex_parse_int(meta.get('votes') or votes)
        year_value = _codex_parse_int(_codex_extract_year(meta.get('year') or year))
        item = xbmcgui.ListItem(label=label)
        dbtype = 'tvshow' if media_type in ('tvshow', 'series', 'season', 'episode') or meta.get('tmdb_type') == 'tv' else 'movie'
        if media_type in ('season', 'episode'):
            dbtype = media_type
        info = {'title': label, 'mediatype': dbtype}
        if plot_text:
            info['plot'] = plot_text
        if genre_text:
            info['genre'] = genre_text
        if year_value:
            info['year'] = year_value
        rating_value = _codex_parse_rating_float(rating_text)
        if rating_value is not None:
            info['rating'] = rating_value
        if votes_value:
            info['votes'] = votes_value
        try:
            item.setInfo(type='Video', infoLabels=info)
        except Exception:
            pass
        art = {}
        poster = meta.get('poster') or icon
        if poster:
            poster = _codex_tmdb_image_size(poster, 'w185')
            art.update({'icon': poster, 'thumb': poster, 'poster': poster})
        if meta.get('fanart'):
            art['fanart'] = _codex_tmdb_image_size(meta.get('fanart'), 'w300')
        if art:
            try:
                item.setArt(art)
            except Exception:
                pass
        for key, value in {
            'TMDb_Rating': rating_text,
            'Rating': rating_text,
            'TmdbId': meta.get('tmdb_id') or tmdb_id,
            'tmdb_id': meta.get('tmdb_id') or tmdb_id,
            'imdb_id': meta.get('imdb_id') or imdb_id,
        }.items():
            if value:
                try:
                    item.setProperty(key, str(value))
                except Exception:
                    pass
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        except Exception:
            pass
        xbmcgui.Dialog().info(item)
    except Exception:
        try:
            import xbmcgui
            xbmcgui.Dialog().notification('Talker3', 'Keine Informationen gefunden', xbmcgui.NOTIFICATION_INFO, 2500)
        except Exception:
            pass


def _codex_handle_media_root(argv):
    try:
        import xbmc
        import xbmcplugin
        from urllib.parse import parse_qs, urlencode
    except Exception:
        return False

    try:
        query = argv[2] if len(argv) > 2 else ''
        if query.startswith('?'):
            query = query[1:]
        params = parse_qs(query, keep_blank_values=True)
        action = (params.get('action') or [''])[0]
        if action not in ('codex_vod_root', 'codex_series_root'):
            return False

        handle = int(argv[1]) if len(argv) > 1 else -1
        is_series = action == 'codex_series_root'
        xbmc.log('[Talker3 Codex] opening %s category root' % ('series' if is_series else 'vod'), xbmc.LOGINFO)

        try:
            import lib.addon as native_addon
        except Exception:
            xbmc.log('[Talker3 Codex] could not import Talker3 addon layer for media root', xbmc.LOGERROR)
            if handle >= 0:
                xbmcplugin.endOfDirectory(handle, False, False, False)
            return True

        payload = None
        categories = []
        last_exc = None
        root_prefix = 'CODEX-%s-ROOT' % ('SERIES' if is_series else 'VOD')
        getter_name = 'get_ser_categories' if is_series else 'get_categories'
        warmup_pairs = (
            (('SERIES', 'get_ser_categories'), ('VOD', 'get_categories'), ('LIVE', 'get_tv_genres'))
            if is_series else
            (('VOD', 'get_categories'), ('SERIES', 'get_ser_categories'), ('LIVE', 'get_tv_genres'))
        )
        try:
            import importlib
            import time
        except Exception:
            importlib = None
            time = None

        for outer in range(1, 3):
            try:
                fetcher = getattr(native_addon, getter_name)
                if hasattr(native_addon, 'retry_call_with_mac_rotation'):
                    payload = native_addon.retry_call_with_mac_rotation(
                        fetcher,
                        base_delay=0.35,
                        attempts=1,
                        rotate_on_empty=False,
                        log_prefix='%s %s/2' % (root_prefix, outer),
                    )
                else:
                    payload = fetcher()
                categories = _codex_extract_category_list(payload)
                if categories:
                    break
                xbmc.log('[Talker3 Codex] %s empty categories on attempt %s/2' % (root_prefix, outer), xbmc.LOGWARNING)
            except Exception as exc:
                last_exc = exc
                xbmc.log('[Talker3 Codex] %s fetch attempt %s/2 failed: %s' % (root_prefix, outer, exc), xbmc.LOGWARNING)

            if outer >= 2:
                break

            if importlib is not None:
                try:
                    native_addon = importlib.reload(native_addon)
                    xbmc.log('[Talker3 Codex] %s reloaded Talker3 addon session' % root_prefix, xbmc.LOGWARNING)
                except Exception as exc:
                    last_exc = exc
                    xbmc.log('[Talker3 Codex] %s reload failed: %s' % (root_prefix, exc), xbmc.LOGWARNING)

            for warm_label, warm_getter_name in warmup_pairs:
                try:
                    warm_getter = getattr(native_addon, warm_getter_name, None)
                    if not warm_getter:
                        continue
                    if hasattr(native_addon, 'retry_call_with_mac_rotation'):
                        warm_payload = native_addon.retry_call_with_mac_rotation(
                            warm_getter,
                            base_delay=0.35,
                            attempts=1,
                            rotate_on_empty=False,
                            log_prefix='%s %s warmup %s/2' % (root_prefix, warm_label, outer),
                        )
                    else:
                        warm_payload = warm_getter()
                    warm_categories = _codex_extract_category_list(warm_payload)
                    if warm_categories:
                        xbmc.log('[Talker3 Codex] %s warmup ok: %s categories=%d' % (root_prefix, warm_label, len(warm_categories)), xbmc.LOGINFO)
                        break
                except Exception as warm_exc:
                    xbmc.log('[Talker3 Codex] %s warmup %s failed: %s' % (root_prefix, warm_label, warm_exc), xbmc.LOGWARNING)
            try:
                if time is not None:
                    time.sleep(0.25 + (0.10 * outer))
            except Exception:
                pass

        if not categories and last_exc:
            xbmc.log('[Talker3 Codex] category root fetch failed after retries: %s' % last_exc, xbmc.LOGERROR)
        if handle >= 0:
            try:
                xbmcplugin.setContent(handle, 'tvshows' if is_series else 'movies')
            except Exception:
                pass

        added = 0
        title_view_paths = []
        search_action = 'codex_series_search' if is_series else 'codex_vod_search'
        search_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
            'action': search_action,
            'page': '1',
            'update_listing': 'False',
        }))
        _codex_add_category_item(handle, 'Suche', search_url, _codex_search_icon(), 'tvshow' if is_series else 'movie')
        title_view_paths.append(search_url)
        added += 1
        for item in categories:
            if not isinstance(item, dict):
                continue
            label = _codex_first_non_empty(item, (
                'title', 'name', 'category_name', 'genre_name', 'alias'
            ), '')
            cat_id = _codex_first_non_empty(item, (
                'id', 'category_id', 'genre_id', 'gid', 'cat_id'
            ), '')
            try:
                label = str(label or '').strip()
                cat_id = str(cat_id or '').strip()
            except Exception:
                label, cat_id = '', ''
            if not label or not cat_id:
                continue
            if _codex_is_all_category(label, cat_id):
                xbmc.log('[Talker3 Codex] hide All category in %s root: %r id=%r' % ('series' if is_series else 'vod', label, cat_id), xbmc.LOGINFO)
                continue

            if is_series:
                native_query = {
                    'type': 'series',
                    'action': 'codex_series_listing',
                    'category_id': cat_id,
                    'category_title': label,
                    'page': '1',
                    'update_listing': 'False',
                }
                media_type = 'tvshow'
            else:
                native_query = {
                    'type': 'vod',
                    'action': 'codex_vod_listing',
                    'category_id': cat_id,
                    'category_title': label,
                    'page': '1',
                    'update_listing': 'False',
                }
                media_type = 'movie'

            url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(native_query))
            title_view_paths.append(url)
            _codex_add_category_item(handle, label, url, _codex_category_icon(item), media_type)
            added += 1

        if title_view_paths:
            _codex_ensure_title_view_pref()
            _codex_sync_title_view_for_current_path(extra_paths=title_view_paths)
        xbmc.log('[Talker3 Codex] %s category root added %d entries' % ('series' if is_series else 'vod', added), xbmc.LOGINFO)
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, True)
        return True
    except Exception:
        try:
            import traceback
            import xbmc
            import xbmcplugin
            xbmc.log('[Talker3 Codex] media root failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
            if len(argv) > 1:
                xbmcplugin.endOfDirectory(int(argv[1]), False, False, False)
        except Exception:
            pass
        return True


def _codex_handle_media_listing(argv):
    try:
        import xbmc
        import xbmcgui
        import xbmcplugin
        from urllib.parse import parse_qs, urlencode, unquote_plus
    except Exception:
        return False

    try:
        query = argv[2] if len(argv) > 2 else ''
        if query.startswith('?'):
            query = query[1:]
        params = parse_qs(query, keep_blank_values=True)
        action = (params.get('action') or [''])[0]
        handled = (
            'codex_media_choice',
            'codex_talker3_favorites',
            'codex_talker3_clear_favorites',
            'codex_talker3_remove_favorite',
            'codex_vod_search',
            'codex_series_search',
            'codex_vod_search_results',
            'codex_series_search_results',
            'codex_vod_listing',
            'codex_series_listing',
            'codex_series_seasons',
            'codex_series_episodes',
            'codex_vod_play',
            'codex_episode_play',
        )
        if action not in handled:
            return False

        handle = int(argv[1]) if len(argv) > 1 else -1
        if action in ('codex_talker3_favorites', 'codex_talker3_clear_favorites', 'codex_talker3_remove_favorite'):
            return _codex_handle_talker3_favorites(argv, handle, params)

        import lib.addon as native_addon
        native_ref = {'addon': native_addon}

        def _reload_native(prefix=''):
            try:
                import importlib
                native_ref['addon'] = importlib.reload(native_ref['addon'])
                try:
                    xbmc.log('[Talker3 Codex] %s reloaded Talker3 addon session' % prefix, xbmc.LOGWARNING)
                except Exception:
                    pass
            except Exception as reload_exc:
                try:
                    xbmc.log('[Talker3 Codex] %s reload failed: %s' % (prefix, reload_exc), xbmc.LOGWARNING)
                except Exception:
                    pass
            return native_ref['addon']

        def _warmup_native(prefix=''):
            mod = native_ref['addon']
            for label, getter_name in (('VOD', 'get_categories'), ('series', 'get_ser_categories')):
                try:
                    getter = getattr(mod, getter_name, None)
                    if not getter:
                        continue
                    if hasattr(mod, 'retry_call_with_mac_rotation'):
                        warm = mod.retry_call_with_mac_rotation(
                            getter,
                            base_delay=0.25,
                            attempts=1,
                            rotate_on_empty=False,
                            log_prefix='%s %s warmup' % (prefix, label),
                        )
                    else:
                        warm = getter()
                    cats = _codex_extract_category_list(warm)
                    if cats:
                        try:
                            xbmc.log('[Talker3 Codex] %s %s warmup ok: %d categories' % (prefix, label, len(cats)), xbmc.LOGINFO)
                        except Exception:
                            pass
                        return True
                except Exception:
                    pass
            return False

        def _retry_call(func_factory, prefix, outer_attempts=6, inner_attempts=3):
            import time
            last_exc = None
            safe_outer_attempts = max(1, min(int(outer_attempts), 2))
            safe_inner_attempts = max(1, min(int(inner_attempts), 1))
            for outer in range(1, safe_outer_attempts + 1):
                mod = native_ref['addon']
                try:
                    func = func_factory(mod)
                    if hasattr(mod, 'retry_call_with_mac_rotation'):
                        result = mod.retry_call_with_mac_rotation(
                            func,
                            base_delay=0.35,
                            attempts=safe_inner_attempts,
                            rotate_on_empty=False,
                            log_prefix='%s %s/%s calm' % (prefix, outer, safe_outer_attempts),
                        )
                    else:
                        result = func()
                    data, _total, _page_items = _codex_extract_channel_page(result)
                    if data or result:
                        return result
                except Exception as exc:
                    last_exc = exc
                    try:
                        xbmc.log('[Talker3 Codex] %s attempt %s/%s failed: %s' % (prefix, outer, safe_outer_attempts, exc), xbmc.LOGWARNING)
                    except Exception:
                        pass
                if outer < safe_outer_attempts:
                    _reload_native(prefix)
                    try:
                        time.sleep(0.25 + (0.15 * outer))
                    except Exception:
                        pass
            if last_exc:
                raise last_exc
            return {}

        def _fetch_client_page(fetch_factory, prefix, client_page):
            client_page = _codex_positive_int(client_page, 1)
            page_size = int(CODEX_MEDIA_PAGE_SIZE)
            total_items = 0
            server_page_items = 0
            server_start = 1
            skip = (client_page - 1) * page_size

            collected = []
            current_server_page = max(1, int(server_start))
            fetched_pages = 0
            while len(collected) < (skip + page_size) and fetched_pages < 12:
                payload = _retry_call(
                    lambda mod, p=str(current_server_page): (lambda: fetch_factory(mod, p)),
                    '%s-PAGE-%s' % (prefix, current_server_page),
                    outer_attempts=5,
                    inner_attempts=2,
                )
                data, total, page_items = _codex_extract_channel_page(payload)
                if total:
                    total_items = int(total)
                if page_items:
                    server_page_items = max(1, int(page_items))
                if not data:
                    break
                collected.extend(data)
                fetched_pages += 1
                if total_items and server_page_items and current_server_page * server_page_items >= total_items:
                    break
                current_server_page += 1

            visible = collected[skip:skip + page_size]
            has_previous = client_page > 1
            if not visible:
                has_next = False
            elif total_items:
                has_next = client_page * page_size < total_items
            else:
                has_next = len(collected) > skip + page_size
            try:
                xbmc.log('[Talker3 Codex] %s client page=%s visible=%s collected=%s total=%s server_page_items=%s server_start=%s' % (
                    prefix, client_page, len(visible), len(collected), total_items, server_page_items, server_start
                ), xbmc.LOGINFO)
            except Exception:
                pass
            return visible, total_items, has_previous, has_next

        def _dedupe_media_items(items):
            result = []
            seen = set()
            for item in items or []:
                if isinstance(item, dict):
                    key = (
                        str(_codex_media_id(item) or ''),
                        str(_codex_media_cmd(item) or ''),
                        str(_codex_media_label(item, '') or ''),
                    )
                else:
                    key = repr(item)
                if key in seen:
                    continue
                seen.add(key)
                result.append(item)
            return result

        def _fetch_search_client_page(is_series_search, search_term, client_page):
            client_page = _codex_positive_int(client_page, 1)
            page_size = int(CODEX_MEDIA_PAGE_SIZE)
            skip = (client_page - 1) * page_size
            search_term = (search_term or '').strip()
            if not search_term:
                return [], 0, False, False

            getter_name = 'get_ser_categories' if is_series_search else 'get_categories'
            categories_payload = _retry_call(lambda mod: (lambda: getattr(mod, getter_name)()), 'CODEX-SEARCH-CATEGORIES-%s' % ('SERIES' if is_series_search else 'VOD'), outer_attempts=5, inner_attempts=2)
            categories = _codex_extract_category_list(categories_payload)
            collected = []
            scanned = 0
            wanted = skip + page_size + 1

            for category in categories or []:
                if not isinstance(category, dict):
                    continue
                label = _codex_first_non_empty(category, ('title', 'name', 'category_name', 'genre_name', 'alias'), '')
                cat_id = _codex_first_non_empty(category, ('id', 'category_id', 'genre_id', 'gid', 'cat_id'), '')
                try:
                    label = str(label or '').strip()
                    cat_id = str(cat_id or '').strip()
                except Exception:
                    label, cat_id = '', ''
                if not cat_id or _codex_is_all_category(label, cat_id):
                    continue
                scanned += 1
                for server_page in range(1, 4):
                    try:
                        if is_series_search:
                            payload = _retry_call(
                                lambda mod, c=cat_id, p=str(server_page), s=search_term: (lambda: mod.get_series(c, p, s)),
                                'CODEX-SERIES-SEARCH-%s-P%s' % (cat_id, server_page),
                                outer_attempts=3,
                                inner_attempts=2,
                            )
                        else:
                            payload = _retry_call(
                                lambda mod, c=cat_id, p=str(server_page), s=search_term: (lambda: mod.get_videos(c, p, s)),
                                'CODEX-VOD-SEARCH-%s-P%s' % (cat_id, server_page),
                                outer_attempts=3,
                                inner_attempts=2,
                            )
                        data, total, page_items = _codex_extract_channel_page(payload)
                        if data:
                            for found_item in data:
                                if isinstance(found_item, dict):
                                    try:
                                        found_item = dict(found_item)
                                        found_item.setdefault('_codex_search_category_id', cat_id)
                                        found_item.setdefault('_codex_search_category_title', label)
                                    except Exception:
                                        pass
                                collected.append(found_item)
                        try:
                            if not data or not total or (page_items and server_page * int(page_items) >= int(total)):
                                break
                        except Exception:
                            if not data:
                                break
                    except Exception as exc:
                        try:
                            xbmc.log('[Talker3 Codex] search category failed %s %s: %s' % (cat_id, label, exc), xbmc.LOGWARNING)
                        except Exception:
                            pass
                        break
                collected = _dedupe_media_items(collected)
                if len(collected) >= wanted:
                    break

            visible = collected[skip:skip + page_size]
            has_previous = client_page > 1
            has_next = len(collected) > skip + page_size
            try:
                xbmc.log('[Talker3 Codex] %s search term=%r scanned=%d found=%d page=%d visible=%d' % (
                    'series' if is_series_search else 'vod', search_term, scanned, len(collected), client_page, len(visible)
                ), xbmc.LOGINFO)
            except Exception:
                pass
            return visible, len(collected), has_previous, has_next

        def _add_search_page_item(handle, label, action, search_term, page, next_page=True):
            try:
                import xbmcgui
                import xbmcplugin
                icon = _codex_page_art(next_page)
                url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                    'action': action,
                    'search_term': search_term or '',
                    'page': str(page),
                    'update_listing': 'False',
                }))
                li = xbmcgui.ListItem(label=label)
                if icon:
                    li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
                try:
                    li.setInfo(type='Video', infoLabels={'title': label})
                    li.setProperty('IsPlayable', 'false')
                except Exception:
                    pass
                xbmcplugin.addDirectoryItem(handle, url, li, True)
            except Exception:
                pass

        def _stream_headers_from_native(mod):
            headers = {}
            try:
                import sys
                candidates = [mod]
                for module_name in ('lib.service', 'resources.lib.service', 'service'):
                    module = sys.modules.get(module_name)
                    if module is not None and module not in candidates:
                        candidates.append(module)
                for candidate in list(sys.modules.values()):
                    try:
                        if getattr(candidate, 'stalker_portal', None) is not None and candidate not in candidates:
                            candidates.append(candidate)
                    except Exception:
                        pass
                for candidate in candidates:
                    portal = getattr(candidate, 'stalker_portal', None)
                    if portal is None:
                        continue
                    for method_name in ('headers', 'headers_2', 'get_headers'):
                        try:
                            method = getattr(portal, method_name, None)
                            if callable(method):
                                got = method() or {}
                                if isinstance(got, dict):
                                    headers.update(got)
                        except Exception:
                            pass
                    try:
                        mac = getattr(portal, 'mac', '') or ''
                        if mac and not any(str(k).lower() == 'cookie' for k in headers.keys()):
                            headers['Cookie'] = 'mac=%s; stb_lang=en; timezone=Europe/Amsterdam' % mac
                    except Exception:
                        pass
                    try:
                        referer = getattr(portal, 'org_url', '') or getattr(portal, 'url', '') or ''
                        if referer and not any(str(k).lower() == 'referer' for k in headers.keys()):
                            headers['Referer'] = referer
                    except Exception:
                        pass
                    break
            except Exception:
                pass
            if not any(str(k).lower() == 'user-agent' for k in headers.keys()):
                headers['User-Agent'] = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'
            if not any(str(k).lower() == 'x-user-agent' for k in headers.keys()):
                headers['X-User-Agent'] = 'Model: MAG250; Link: WiFi'
            clean = {}
            allowed = {'user-agent', 'referer', 'cookie', 'x-user-agent', 'accept', 'connection'}
            for key, value in (headers or {}).items():
                lk = str(key).lower()
                if lk in allowed and value:
                    clean[str(key)] = str(value)
            return clean

        def _with_stream_headers(stream_url, mod):
            if not stream_url or '|' in stream_url:
                return stream_url
            try:
                from urllib.parse import urlencode
                headers = _stream_headers_from_native(mod)
                if headers:
                    return stream_url + '|' + urlencode(headers)
            except Exception:
                pass
            return stream_url

        def _resolve_vod_stream(cmd):
            if not cmd:
                return ''
            _warmup_native('CODEX-VOD-PLAY-PRE')
            def _factory(mod):
                def _play():
                    try:
                        import lib.service as native_service
                        portal = getattr(native_service, 'stalker_portal', None)
                        if portal is not None and hasattr(portal, 'get_stream_link'):
                            direct = portal.get_stream_link(cmd, content_type='vod')
                            if direct:
                                return _with_stream_headers(direct, mod)
                    except Exception as direct_exc:
                        try:
                            xbmc.log('[Talker3 Codex] CODEX-VOD-PLAY direct portal failed: %s' % direct_exc, xbmc.LOGWARNING)
                        except Exception:
                            pass
                    stream = mod.get_vod_stream_url(cmd)
                    return _with_stream_headers(stream, mod)
                return _play
            return _retry_call(_factory, 'CODEX-VOD-PLAY', outer_attempts=2, inner_attempts=1)

        def _resolve_episode_stream(video_id, series, cmd=''):
            if not video_id and not cmd:
                return ''
            _warmup_native('CODEX-SERIES-EP-PLAY-PRE')
            def _factory(mod):
                def _play():
                    try:
                        import lib.service as native_service
                        portal = getattr(native_service, 'stalker_portal', None)
                        if portal is not None and hasattr(portal, 'get_stream_link'):
                            if cmd:
                                direct = portal.get_stream_link(cmd, content_type='series', ep_id=series or video_id)
                                if direct:
                                    return _with_stream_headers(direct, mod)
                            direct = portal.get_stream_link(video_id, content_type='series', ep_id=series or video_id)
                            if direct:
                                return _with_stream_headers(direct, mod)
                    except Exception as direct_exc:
                        try:
                            xbmc.log('[Talker3 Codex] CODEX-SERIES-EP-PLAY direct portal failed: %s' % direct_exc, xbmc.LOGWARNING)
                        except Exception:
                            pass
                    if not video_id:
                        return ''
                    stream = mod.get_episode_stream_url(video_id, series)
                    return _with_stream_headers(stream, mod)
                return _play
            return _retry_call(_factory, 'CODEX-SERIES-EP-PLAY', outer_attempts=2, inner_attempts=1)

        if action in ('codex_vod_search', 'codex_series_search'):
            title = 'Seriensuche' if action == 'codex_series_search' else 'Filmsuche'
            try:
                term = xbmcgui.Dialog().input(title, type=xbmcgui.INPUT_ALPHANUM)
            except Exception:
                term = ''
            term = (term or '').strip()
            if not term:
                try:
                    xbmcplugin.endOfDirectory(handle, False, False, False)
                except Exception:
                    pass
                return True
            result_action = 'codex_series_search_results' if action == 'codex_series_search' else 'codex_vod_search_results'
            result_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                'action': result_action,
                'search_term': term,
                'page': '1',
                'update_listing': 'False',
            }))
            try:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            except Exception:
                pass
            xbmc.executebuiltin('Container.Update(%s,replace)' % result_url)
            return True

        if action in ('codex_vod_search_results', 'codex_series_search_results'):
            is_series_search = action == 'codex_series_search_results'
            search_term = unquote_plus((params.get('search_term') or [''])[0]).strip()
            page = unquote_plus((params.get('page') or ['1'])[0]).strip() or '1'
            xbmc.log('[Talker3 Codex] opening %s search results for %r' % ('series' if is_series_search else 'vod', search_term), xbmc.LOGINFO)
            items, total_items, has_previous, has_next = _fetch_search_client_page(is_series_search, search_term, page)
            try:
                xbmcplugin.setContent(handle, 'tvshows' if is_series_search else 'movies')
            except Exception:
                pass
            page_num = _codex_positive_int(page, 1)
            if has_previous:
                _add_search_page_item(handle, 'Zurück', action, search_term, page_num - 1, next_page=False)
            added = 0
            for item in items:
                if not isinstance(item, dict):
                    continue
                if is_series_search:
                    label = _codex_media_label(item, 'Serie')
                    series_id = _codex_media_id(item)
                    icon = _codex_media_art(item)
                    category_id = _codex_first_non_empty(item, ('_codex_search_category_id', 'category_id', 'category', 'cat_id', 'genre_id'), '')
                    if not series_id:
                        continue
                    url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                        'action': 'codex_series_seasons',
                        'category_id': str(category_id or ''),
                        'series_id': series_id,
                        'label': label,
                        'icon': icon,
                        'page': '1',
                    }))
                    choice_url = _codex_choice_url(url, label, 'tvshow', item, is_folder=True)
                    li = xbmcgui.ListItem(label=label)
                    _codex_set_art_and_info(li, label, item, 'tvshow', False)
                    xbmcplugin.addDirectoryItem(handle, choice_url, li, True)
                else:
                    label = _codex_media_label(item, 'Film')
                    cmd = _codex_media_cmd(item)
                    icon = _codex_media_art(item)
                    if not cmd:
                        continue
                    url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                        'action': 'codex_vod_play',
                        'cmd': cmd,
                        'label': label,
                        'icon': icon,
                    }))
                    choice_url = _codex_choice_url(url, label, 'movie', item, is_folder=False)
                    li = xbmcgui.ListItem(label=label)
                    _codex_set_art_and_info(li, label, item, 'movie', False)
                    try:
                        li.setProperty('IsPlayable', 'false')
                    except Exception:
                        pass
                    xbmcplugin.addDirectoryItem(handle, choice_url, li, False)
                added += 1
            if has_next:
                _add_search_page_item(handle, 'Weiter', action, search_term, page_num + 1, next_page=True)
            xbmc.log('[Talker3 Codex] %s search results added %d entries from %d' % ('series' if is_series_search else 'vod', added, len(items or [])), xbmc.LOGINFO)
            _codex_sync_title_view_for_current_path(action=action)
            xbmcplugin.endOfDirectory(handle, True, False, True)
            _codex_apply_title_view()
            return True

        if action == 'codex_media_choice':
            title = unquote_plus((params.get('choice_title') or [''])[0]).strip() or 'Auswahl'
            original_url = unquote_plus((params.get('choice_url') or [''])[0]).strip()
            media_type = unquote_plus((params.get('choice_media_type') or ['movie'])[0]).strip() or 'movie'
            original_is_folder = unquote_plus((params.get('choice_is_folder') or ['0'])[0]).strip() == '1'
            year = unquote_plus((params.get('choice_year') or [''])[0]).strip()
            plot = unquote_plus((params.get('choice_plot') or [''])[0]).strip()
            genre = unquote_plus((params.get('choice_genre') or [''])[0]).strip()
            rating = unquote_plus((params.get('choice_rating') or [''])[0]).strip()
            votes = unquote_plus((params.get('choice_votes') or [''])[0]).strip()
            tmdb_id = unquote_plus((params.get('choice_tmdb_id') or [''])[0]).strip()
            imdb_id = unquote_plus((params.get('choice_imdb_id') or [''])[0]).strip()
            icon = unquote_plus((params.get('choice_icon') or [''])[0]).strip()
            if media_type == 'episode':
                play_label = 'Episode wiedergeben'
            elif media_type == 'season':
                play_label = 'Staffel wiedergeben'
            elif media_type in ('tvshow', 'series'):
                play_label = 'Serie wiedergeben'
            else:
                play_label = 'Film wiedergeben'
            choice = xbmcgui.Dialog().select(_codex_clean_title_for_lookup(title) or title, [play_label, 'Informationen', 'zu Favoriten hinzufügen'])
            if choice == 0 and original_url:
                try:
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                except Exception:
                    pass
                try:
                    xbmcplugin.endOfDirectory(handle, True, False, False)
                except Exception:
                    pass
                if original_is_folder:
                    xbmc.executebuiltin('Container.Update(%s,replace)' % original_url)
                else:
                    xbmc.executebuiltin('PlayMedia(%s)' % original_url)
                return True
            if choice == 1:
                _codex_show_information_dialog(
                    title,
                    media_type=media_type,
                    year=year,
                    plot=plot,
                    genre=genre,
                    rating=rating,
                    votes=votes,
                    tmdb_id=tmdb_id,
                    imdb_id=imdb_id,
                    icon=icon,
                )
            if choice == 2:
                fav = _codex_add_talker3_favorite(
                    title,
                    media_type,
                    original_url,
                    original_is_folder,
                    year=year,
                    plot=plot,
                    genre=genre,
                    rating=rating,
                    votes=votes,
                    tmdb_id=tmdb_id,
                    imdb_id=imdb_id,
                    icon=icon,
                )
                if fav:
                    try:
                        xbmcgui.Dialog().notification('Favoriten', 'zu Stalker Portal 2 Favoriten hinzugefügt', xbmcgui.NOTIFICATION_INFO, 2500)
                    except Exception:
                        pass
                    try:
                        xbmcplugin.endOfDirectory(handle, False, False, False)
                    except Exception:
                        pass
                    return True
                try:
                    xbmcgui.Dialog().notification('Favoriten', 'Zu Talker3 Favoriten hinzugefügt' if fav else 'Favorit konnte nicht gespeichert werden', xbmcgui.NOTIFICATION_INFO if fav else xbmcgui.NOTIFICATION_ERROR, 2500)
                except Exception:
                    pass
            try:
                xbmcplugin.endOfDirectory(handle, False, False, False)
            except Exception:
                pass
            return True

        if action == 'codex_vod_play':
            cmd = unquote_plus((params.get('cmd') or [''])[0]).strip()
            label = unquote_plus((params.get('label') or ['Film'])[0]).strip() or 'Film'
            icon = unquote_plus((params.get('icon') or [''])[0]).strip()
            try:
                stream_url = _resolve_vod_stream(cmd)
            except Exception as exc:
                xbmc.log('[Talker3 Codex] VOD play failed: %s' % exc, xbmc.LOGERROR)
                stream_url = ''
            li = xbmcgui.ListItem(label=label)
            try:
                li.setProperty('IsPlayable', 'true')
            except Exception:
                pass
            if icon:
                try:
                    li.setArt({'icon': icon, 'thumb': icon})
                except Exception:
                    pass
            if stream_url:
                try:
                    li.setPath(stream_url)
                except Exception:
                    pass
                xbmcplugin.setResolvedUrl(handle, True, li)
            else:
                xbmcplugin.setResolvedUrl(handle, False, li)
            return True

        if action == 'codex_episode_play':
            video_id = unquote_plus((params.get('video_id') or [''])[0]).strip()
            series = unquote_plus((params.get('series') or [''])[0]).strip() or video_id
            cmd = unquote_plus((params.get('cmd') or [''])[0]).strip()
            label = unquote_plus((params.get('label') or ['Episode'])[0]).strip() or 'Episode'
            icon = unquote_plus((params.get('icon') or [''])[0]).strip()
            try:
                xbmc.log('[Talker3 Codex] episode play params video=%r series=%r cmd=%s' % (video_id, series, 'yes' if cmd else 'no'), xbmc.LOGINFO)
                stream_url = _resolve_episode_stream(video_id, series, cmd)
            except Exception as exc:
                xbmc.log('[Talker3 Codex] episode play failed: %s' % exc, xbmc.LOGERROR)
                stream_url = ''
            li = xbmcgui.ListItem(label=label)
            try:
                li.setProperty('IsPlayable', 'true')
            except Exception:
                pass
            if icon:
                try:
                    li.setArt({'icon': icon, 'thumb': icon})
                except Exception:
                    pass
            if stream_url:
                try:
                    li.setPath(stream_url)
                except Exception:
                    pass
                xbmcplugin.setResolvedUrl(handle, True, li)
            else:
                xbmcplugin.setResolvedUrl(handle, False, li)
            return True

        category_id = unquote_plus((params.get('category_id') or [''])[0]).strip()
        category_title = unquote_plus((params.get('category_title') or [''])[0]).strip()
        page = unquote_plus((params.get('page') or ['1'])[0]).strip() or '1'

        if action == 'codex_vod_listing':
            xbmc.log('[Talker3 Codex] opening VOD listing category=%s %s' % (category_id, category_title), xbmc.LOGINFO)
            items, total_items, has_previous, has_next = _fetch_client_page(lambda mod, p: mod.get_videos(category_id, p, ''), 'CODEX-VOD-LISTING', page) if category_id else ([], 0, False, False)
            try:
                xbmcplugin.setContent(handle, 'movies')
            except Exception:
                pass
            page_num = _codex_positive_int(page, 1)
            if has_previous:
                _codex_add_page_item(handle, 'ZurÃ¼ck', 'codex_vod_listing', category_id, category_title, page_num - 1, next_page=False, media_type='vod')
            added = 0
            for item in items:
                if not isinstance(item, dict):
                    continue
                label = _codex_media_label(item, 'Film')
                cmd = _codex_media_cmd(item)
                icon = _codex_media_art(item)
                if not cmd:
                    continue
                url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                    'action': 'codex_vod_play',
                    'cmd': cmd,
                    'label': label,
                    'icon': icon,
                }))
                choice_url = _codex_choice_url(url, label, 'movie', item, is_folder=False)
                li = xbmcgui.ListItem(label=label)
                _codex_set_art_and_info(li, label, item, 'movie', False)
                try:
                    li.setProperty('IsPlayable', 'false')
                except Exception:
                    pass
                xbmcplugin.addDirectoryItem(handle, choice_url, li, False)
                added += 1
            if has_next:
                _codex_add_page_item(handle, 'Weiter', 'codex_vod_listing', category_id, category_title, page_num + 1, next_page=True, media_type='vod')
            xbmc.log('[Talker3 Codex] VOD listing added %d entries from %d' % (added, len(items or [])), xbmc.LOGINFO)
            _codex_sync_title_view_for_current_path(action='codex_vod_listing', category_id=category_id)
            xbmcplugin.endOfDirectory(handle, True, False, True)
            _codex_apply_title_view()
            return True

        if action == 'codex_series_listing':
            xbmc.log('[Talker3 Codex] opening series listing category=%s %s' % (category_id, category_title), xbmc.LOGINFO)
            items, total_items, has_previous, has_next = _fetch_client_page(lambda mod, p: mod.get_series(category_id, p, ''), 'CODEX-SERIES-LISTING', page) if category_id else ([], 0, False, False)
            try:
                xbmcplugin.setContent(handle, 'tvshows')
            except Exception:
                pass
            page_num = _codex_positive_int(page, 1)
            if has_previous:
                _codex_add_page_item(handle, 'ZurÃ¼ck', 'codex_series_listing', category_id, category_title, page_num - 1, next_page=False, media_type='series')
            added = 0
            for item in items:
                if not isinstance(item, dict):
                    continue
                label = _codex_media_label(item, 'Serie')
                series_id = _codex_media_id(item)
                icon = _codex_media_art(item)
                if not series_id:
                    continue
                url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                    'action': 'codex_series_seasons',
                    'category_id': category_id,
                    'series_id': series_id,
                    'label': label,
                    'icon': icon,
                    'page': '1',
                }))
                choice_url = _codex_choice_url(url, label, 'tvshow', item, is_folder=True)
                li = xbmcgui.ListItem(label=label)
                _codex_set_art_and_info(li, label, item, 'tvshow', False)
                xbmcplugin.addDirectoryItem(handle, choice_url, li, True)
                added += 1
            if has_next:
                _codex_add_page_item(handle, 'Weiter', 'codex_series_listing', category_id, category_title, page_num + 1, next_page=True, media_type='series')
            xbmc.log('[Talker3 Codex] series listing added %d entries from %d' % (added, len(items or [])), xbmc.LOGINFO)
            _codex_sync_title_view_for_current_path(action='codex_series_listing', category_id=category_id)
            xbmcplugin.endOfDirectory(handle, True, False, True)
            _codex_apply_title_view()
            return True

        if action == 'codex_series_seasons':
            series_id = _codex_clean_series_id(unquote_plus((params.get('series_id') or [''])[0]).strip())
            title = unquote_plus((params.get('label') or ['Serie'])[0]).strip() or 'Serie'
            icon = unquote_plus((params.get('icon') or [''])[0]).strip()
            payload = _retry_call(lambda mod: (lambda: mod.get_seasons(series_id, category_id, page)), 'CODEX-SERIES-SEASONS', outer_attempts=7, inner_attempts=2) if series_id else {}
            items, total_items, page_items = _codex_extract_channel_page(payload)
            try:
                xbmcplugin.setContent(handle, 'seasons')
            except Exception:
                pass
            added = 0
            seen = set()
            for idx, item in enumerate(items or [], 1):
                if not isinstance(item, dict):
                    continue
                raw_season = _codex_first_non_empty(item, ('season_id', 'season', 'season_number', 'season_num', 'series'), '')
                video_id = _codex_media_id(item)
                season_no = ''
                try:
                    import re
                    joined = ' '.join(str(v or '') for v in (raw_season, video_id, _codex_media_label(item, '')))
                    m = re.search(r'(?i)(?:season|staffel|s)\s*0*(\d+)', joined) or re.search(r':0*(\d+)\b', joined)
                    if m:
                        season_no = str(int(m.group(1)))
                except Exception:
                    season_no = ''
                if not season_no:
                    season_no = str(idx)
                if season_no in seen:
                    continue
                seen.add(season_no)
                label = 'Season %s' % season_no
                url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                    'action': 'codex_series_episodes',
                    'category_id': category_id,
                    'series_id': series_id,
                    'season_id': season_no,
                    'label': title,
                    'icon': icon,
                    'page': '1',
                }))
                li = xbmcgui.ListItem(label=label)
                _codex_set_art_and_info(li, label, item, 'season', False)
                if icon:
                    try:
                        li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
                    except Exception:
                        pass
                xbmcplugin.addDirectoryItem(handle, url, li, True)
                added += 1
            xbmc.log('[Talker3 Codex] seasons listing added %d entries from %d' % (added, len(items or [])), xbmc.LOGINFO)
            xbmcplugin.endOfDirectory(handle, True, False, True)
            return True

        if action == 'codex_series_episodes':
            series_id = _codex_clean_series_id(unquote_plus((params.get('series_id') or [''])[0]).strip())
            season_id = _codex_clean_season_id('', unquote_plus((params.get('season_id') or [''])[0]).strip())
            icon = unquote_plus((params.get('icon') or [''])[0]).strip()
            payload = _retry_call(lambda mod: (lambda: mod.get_episodes(series_id, season_id, page)), 'CODEX-SERIES-EPISODES', outer_attempts=7, inner_attempts=2) if series_id and season_id else {}
            items, total_items, page_items = _codex_extract_channel_page(payload)
            raw_count = len(items or [])
            items = _codex_expand_season_rows_to_episodes(items, season_id)
            try:
                xbmcplugin.setContent(handle, 'episodes')
            except Exception:
                pass
            added = 0
            for idx, item in enumerate(items or [], 1):
                if not isinstance(item, dict):
                    continue
                label = _codex_episode_label(item, idx, season_id)
                video_id = _codex_media_id(item)
                cmd = _codex_media_cmd(item)
                series_param = _codex_first_non_empty(item, ('series', 'series_id', 'season_id'), season_id)
                if idx == 1:
                    try:
                        xbmc.log('[Talker3 Codex] first episode row video=%r series=%r cmd=%s keys=%r' % (
                            video_id, series_param, 'yes' if cmd else 'no', sorted(list(item.keys()))[:24]
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                item_icon = _codex_media_art(item, icon)
                if not video_id and not cmd:
                    continue
                url = 'plugin://%s/?%s' % (ADDON_ID, urlencode({
                    'action': 'codex_episode_play',
                    'video_id': video_id,
                    'series': series_param,
                    'cmd': cmd,
                    'label': label,
                    'icon': item_icon,
                }))
                li = xbmcgui.ListItem(label=label)
                _codex_set_art_and_info(li, label, item, 'episode', True)
                if item_icon:
                    try:
                        li.setArt({'icon': item_icon, 'thumb': item_icon, 'poster': item_icon})
                    except Exception:
                        pass
                xbmcplugin.addDirectoryItem(handle, url, li, False)
                added += 1
            xbmc.log('[Talker3 Codex] episode listing added %d entries from %d raw=%d' % (added, len(items or []), raw_count), xbmc.LOGINFO)
            xbmcplugin.endOfDirectory(handle, True, False, True)
            return True
    except Exception:
        try:
            import traceback
            import xbmc
            import xbmcplugin
            xbmc.log('[Talker3 Codex] media listing failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
            if len(argv) > 1:
                xbmcplugin.endOfDirectory(int(argv[1]), False, False, False)
        except Exception:
            pass
        return True
    return False

def _codex_talker3_write_handshake_status_file(path, payload):
    try:
        if not path:
            return
        try:
            import xbmcvfs
            if str(path).startswith('special://'):
                path = xbmcvfs.translatePath(path)
        except Exception:
            pass
        import io
        import json
        import os
        import time
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except Exception:
                pass
        data = dict(payload or {})
        data['ts'] = time.time()
        with io.open(path, 'w', encoding='utf-8') as fh:
            fh.write(json.dumps(data, ensure_ascii=False, sort_keys=True))
    except Exception:
        try:
            import xbmc
            xbmc.log('[Talker3 Codex] manual handshake status file write failed', xbmc.LOGWARNING)
        except Exception:
            pass


def _codex_handle_talker3_handshake(argv):
    try:
        from urllib.parse import parse_qs
        params = parse_qs((argv[2] or '').lstrip('?')) if len(argv) > 2 else {}
    except Exception:
        return False
    action = (params.get('action') or [''])[0].strip().lower()
    if action != 'codex_talker3_handshake':
        return False
    quiet = (params.get('quiet') or ['0'])[0].strip().lower() in ('1', 'true', 'yes')
    force_new_mac = (params.get('force_new') or params.get('codex_force_new') or ['0'])[0].strip().lower() in ('1', 'true', 'yes')
    status_file = (params.get('codex_status_file') or params.get('status_file') or [''])[0].strip()

    global _CODEX_ROOT_ENV_WARMED
    try:
        import importlib
        import os
        import sys
        import time
        import xbmc
        import xbmcaddon
        import xbmcgui
        import xbmcplugin
        import xbmcvfs
    except Exception:
        return True

    progress = None
    try:
        if not quiet:
            progress = xbmcgui.DialogProgress()
            progress.create('Handshake', 'Handshake läuft...')
            progress.update(5, 'Handshake läuft...')
    except Exception:
        progress = None

    ok = False
    last_error = None
    _CODEX_ROOT_ENV_WARMED = False
    previous_current_mac = _codex_talker3_load_current_mac()
    if force_new_mac:
        try:
            _codex_talker3_clear_current_mac('manual handshake force_new requested')
        except Exception:
            pass
        previous_current_mac = ''
    _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-start')

    try:
        if progress:
            progress.update(20, 'Session wird vorbereitet...')
        profile = xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')
        data_dir = xbmcvfs.translatePath(profile)
        volatile_names = set((
            'session.json',
            'token.json',
            'profile.json',
            'handshake.json',
            'auth.json',
            'portal_session.json',
        ))
        moved = 0
        if data_dir and os.path.isdir(data_dir):
            for name in os.listdir(data_dir):
                path = os.path.join(data_dir, name)
                lname = name.lower()
                if not os.path.isfile(path):
                    continue
                if lname == 'mac_session.json' and not force_new_mac:
                    continue
                should_move = lname in volatile_names or (
                    lname.endswith(('.json', '.txt', '.dat', '.cache'))
                    and any(marker in lname for marker in ('token', 'session', 'handshake', 'auth', 'profile'))
                )
                if not should_move:
                    continue
                try:
                    os.remove(path)
                    moved += 1
                except Exception as move_exc:
                    try:
                        xbmc.log('[Talker3 Codex] manual handshake volatile file not removed %s: %s' % (name, move_exc), xbmc.LOGWARNING)
                    except Exception:
                        pass
        try:
            xbmc.log('[Talker3 Codex] manual handshake removed volatile session files: %d' % moved, xbmc.LOGINFO)
            _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-session-files-removed', 'removed=%d' % moved)
        except Exception:
            pass
    except Exception as prep_exc:
        try:
            xbmc.log('[Talker3 Codex] manual handshake session prep failed: %s' % prep_exc, xbmc.LOGWARNING)
        except Exception:
            pass

    for module_name in (
        'lib.addon',
        'lib.service',
        'lib.config',
        'lib.stalker_net',
        'lib.tmdb',
        'lib.utils',
    ):
        try:
            sys.modules.pop(module_name, None)
        except Exception:
            pass

    checks = (
        ('LIVE', 'get_tv_genres'),
    )

    try:
        native_addon = importlib.import_module('lib.addon')
        _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-native-imported')
        if previous_current_mac and not force_new_mac:
            # Die geprüfte aktuelle MAC bleibt während des Handshakes gültig.
            # Erst wenn eine neue MAC wirklich erfolgreich warmgelaufen ist,
            # wird sie ersetzt. Sonst fällt Live TV 2 nach einem schlechten
            # Random-MAC-Versuch nicht in ein leeres Loch.
            _codex_talker3_apply_current_mac_to_native(previous_current_mac, None, native_addon, 'manual-handshake-preserve-current')
        elif force_new_mac:
            try:
                xbmc.log('[Talker3 Codex] manual handshake force_new active: previous MAC not preserved', xbmc.LOGWARNING)
                _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-force-new-active')
            except Exception:
                pass
        for outer in range(1, 2):
            if progress:
                progress.update(55, 'Live-Warm-up läuft...')
            for label, getter_name in checks:
                getter = getattr(native_addon, getter_name, None)
                if not getter:
                    continue
                try:
                    if hasattr(native_addon, 'retry_call_with_mac_rotation'):
                        payload = native_addon.retry_call_with_mac_rotation(
                            getter,
                            base_delay=0.35,
                            attempts=1,
                            rotate_on_empty=False,
                            log_prefix='CODEX-TALKER3-HANDSHAKE-%s' % label,
                        )
                    else:
                        payload = getter()
                    categories = _codex_extract_category_list(payload)
                    if categories:
                        ok = True
                        _CODEX_ROOT_ENV_WARMED = True
                        try:
                            xbmc.log('[Talker3 Codex] manual handshake ok: %s categories=%d' % (label, len(categories)), xbmc.LOGINFO)
                            _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-ok', '%s categories=%d' % (label, len(categories)))
                        except Exception:
                            pass
                        try:
                            native_service = sys.modules.get('lib.service')
                            if native_service is None:
                                try:
                                    native_service = importlib.import_module('lib.service')
                                except Exception:
                                    native_service = None
                            handshake_mac = _codex_talker3_extract_native_mac(native_service, native_addon)
                            if handshake_mac:
                                _codex_talker3_save_current_mac(handshake_mac, 'manual handshake %s categories=%d' % (label, len(categories)))
                            elif previous_current_mac:
                                _codex_talker3_save_current_mac(previous_current_mac, 'manual handshake %s categories=%d preserved previous' % (label, len(categories)))
                            else:
                                xbmc.log('[Talker3 Codex] manual handshake ok but no native MAC detected', xbmc.LOGWARNING)
                        except Exception as save_exc:
                            try:
                                xbmc.log('[Talker3 Codex] manual handshake MAC save skipped: %s' % save_exc, xbmc.LOGWARNING)
                            except Exception:
                                pass
                        break
                except Exception as exc:
                    last_error = exc
                    try:
                        xbmc.log('[Talker3 Codex] manual handshake %s attempt %d failed: %s' % (label, outer, exc), xbmc.LOGWARNING)
                        _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-attempt-failed', '%s attempt=%d error=%s' % (label, outer, exc))
                    except Exception:
                        pass
            if ok:
                break
            if outer < 1:
                try:
                    native_addon = importlib.reload(native_addon)
                    xbmc.log('[Talker3 Codex] manual handshake reloaded Talker3 session', xbmc.LOGWARNING)
                except Exception as exc:
                    last_error = exc
                try:
                    time.sleep(0.25)
                except Exception:
                    pass
    except Exception as exc:
        last_error = exc

    try:
        if ok:
            if progress:
                progress.update(100, 'Handshake erfolgreich')
                xbmc.sleep(250)
            _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-finished-ok')
            if not quiet:
                xbmcgui.Dialog().notification('Handshake', 'Handshake erfolgreich', time=1800)
        else:
            xbmc.log('[Talker3 Codex] manual handshake ended without categories%s' % ((': %s' % last_error) if last_error else ''), xbmc.LOGWARNING)
            if previous_current_mac:
                _codex_talker3_save_current_mac(previous_current_mac, 'manual handshake failed; previous current MAC preserved')
            else:
                _codex_talker3_clear_current_mac('manual handshake failed')
            if progress:
                progress.update(100, 'Handshake fehlgeschlagen')
                xbmc.sleep(250)
            _codex_log_mac_analytics('Portal2/Talker3', 'manual-handshake-finished-failed', str(last_error or ''))
            if not quiet:
                xbmcgui.Dialog().notification('Handshake', 'Handshake fehlgeschlagen', xbmcgui.NOTIFICATION_ERROR, 3000)
    except Exception:
        pass
    finally:
        if progress:
            try:
                progress.close()
            except Exception:
                pass
        if status_file:
            try:
                _codex_talker3_write_handshake_status_file(status_file, {
                    'ok': bool(ok),
                    'addon': ADDON_ID,
                    'force_new': bool(force_new_mac),
                    'mac': _codex_redact_mac(_codex_talker3_load_current_mac()),
                    'error': '' if ok else str(last_error or 'no categories'),
                })
            except Exception:
                pass

    try:
        if len(argv) > 1:
            xbmcplugin.endOfDirectory(int(argv[1]), ok, False, False)
    except Exception:
        pass
    return True


if __name__ == '__main__':
    from sys import argv
    _install_talker3_runtime_patch()
    _codex_install_directory_cache()
    try:
        if _codex_handle_talker3_handshake(argv):
            raise SystemExit
        if _codex_show_original_root_menu(argv):
            raise SystemExit
        if _codex_handle_media_root(argv):
            raise SystemExit
        if _codex_handle_media_listing(argv):
            raise SystemExit
        if _codex_handle_de_channels(argv):
            raise SystemExit
        if _codex_handle_talker3_safe_tv_play(argv):
            raise SystemExit
        if _codex_handle_name_bridge(argv):
            raise SystemExit
        from lib.addon import run
        run(argv)
    except Exception as exc:
        try:
            import traceback
            import xbmc
            import xbmcplugin
            xbmc.log('[Talker3 Macsimum] startup failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if len(argv) > 1:
                xbmcplugin.endOfDirectory(int(argv[1]), False)
        except Exception:
            pass

