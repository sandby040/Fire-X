from __future__ import absolute_import, division, unicode_literals

# Absichtlich leer.
#
# Die Talker3/PVR-Brücke läuft über plugin://...action=codex_launch_name
# in der IPTV-Simple-Playlist. Es soll beim Kodi-Start KEIN automatischer
# Handshake, KEIN DE-Scan und KEIN Brücken-Sync gestartet werden.
#
# Die Datei bleibt nur als harmloser Platzhalter vorhanden, falls Kodi noch
# einen alten Service-Eintrag im Addon-Cache hat.

