# -*- coding: utf-8 -*-
from __future__ import absolute_import

import json
import os
import time
import datetime
from xml.etree import ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs


ADDON_ID = "service.talker3.autobridge"
TALKER3_ADDON_ID = "plugin.video.stalker.macsimum.talker3"
IPTVMASTER_ADDON_ID = "plugin.video.iptvmaster"
IPTVSIMPLE_ADDON_ID = "pvr.iptvsimple"
STOPONBACK_ADDON_ID = "service.stoponback"

MAX_ATTEMPTS = 2
RETRY_DELAY_SECONDS = 4.0
SCAN_TIMEOUT_SECONDS = 220.0
PVR_STABLE_SECONDS = 0.9
POLL_SECONDS = 0.45
EPG_EXPORT_MIN_BYTES = 1024
EPG_EXPORT_CHECK_SECONDS = 300.0
AUTO_SENDERLIST_UPDATE_ENABLED = False


PVR_CONDITIONS = (
    "Window.IsActive(10700)",
    "Window.IsVisible(10700)",
)


monitor = xbmc.Monitor()


def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Talker3AutoBridge] {}".format(message), level)
    except Exception:
        pass


def translate_path(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


def notify(title, message="", ms=2400, icon=xbmcgui.NOTIFICATION_INFO):
    try:
        xbmcgui.Dialog().notification(title, message, icon, ms)
    except Exception:
        pass


def get_talker3_data_dir():
    path = translate_path("special://profile/addon_data/{}".format(TALKER3_ADDON_ID))
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        pass
    return path or ""


def get_addon_data_dir(addon_id):
    path = translate_path("special://profile/addon_data/{}".format(addon_id))
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        pass
    return path or ""


def _xmltv_time(ts):
    try:
        return datetime.datetime.utcfromtimestamp(int(ts)).strftime("%Y%m%d%H%M%S +0000")
    except Exception:
        return ""


def _safe_text(value):
    try:
        return str(value or "")
    except Exception:
        return ""


def _latest_iptvmaster_epg_cache():
    cache_dir = os.path.join(get_addon_data_dir(IPTVMASTER_ADDON_ID), "cache")
    if not cache_dir or not os.path.isdir(cache_dir):
        return ""
    candidates = []
    try:
        for name in os.listdir(cache_dir):
            if not name.lower().endswith(".json"):
                continue
            path = os.path.join(cache_dir, name)
            try:
                if os.path.getsize(path) > EPG_EXPORT_MIN_BYTES:
                    candidates.append((os.path.getmtime(path), path))
            except Exception:
                pass
    except Exception:
        return ""
    if not candidates:
        return ""
    candidates.sort(reverse=True)
    return candidates[0][1]


def export_iptvmaster_epg_to_xmltv(force=False):
    """IPTV Master haelt die EPG als JSON-Cache. IPTV Simple braucht XMLTV.
    Diese Funktion recycelt den vorhandenen Cache lokal, damit IPTV Simple
    nicht noch einmal dieselbe Online-EPG laden muss.
    """
    src = _latest_iptvmaster_epg_cache()
    if not src:
        log("IPTV-Master-EPG-Cache nicht gefunden", xbmc.LOGWARNING)
        return False

    providers_dir = os.path.join(get_addon_data_dir(IPTVSIMPLE_ADDON_ID), "providers")
    try:
        if providers_dir and not os.path.isdir(providers_dir):
            os.makedirs(providers_dir)
    except Exception:
        pass
    dst = os.path.join(providers_dir, "iptvmaster_epg.xml")
    meta = os.path.join(providers_dir, "iptvmaster_epg.meta.json")

    try:
        src_mtime = os.path.getmtime(src)
        if (not force and os.path.exists(dst) and os.path.getsize(dst) > EPG_EXPORT_MIN_BYTES
                and os.path.getmtime(dst) >= src_mtime):
            log("Lokale IPTV-Master-EPG ist aktuell: {}".format(dst))
            return True
    except Exception:
        pass

    try:
        with open(src, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        data = payload.get("data", {}) if isinstance(payload, dict) else {}
        if not isinstance(data, dict) or not data:
            log("IPTV-Master-EPG-Cache ist leer/ungueltig", xbmc.LOGWARNING)
            return False

        tv = ET.Element("tv", {
            "generator-info-name": "IPTV Master Cache via Talker3 Auto Bridge",
            "generator-info-url": "plugin.video.iptvmaster",
        })
        programme_count = 0

        for channel_id in sorted(data.keys(), key=lambda x: str(x).lower()):
            entries = data.get(channel_id) or []
            if not isinstance(entries, list) or not entries:
                continue
            channel_el = ET.SubElement(tv, "channel", {"id": _safe_text(channel_id)})
            ET.SubElement(channel_el, "display-name").text = _safe_text(channel_id)

        for channel_id in sorted(data.keys(), key=lambda x: str(x).lower()):
            entries = data.get(channel_id) or []
            if not isinstance(entries, list):
                continue
            try:
                entries = sorted(entries, key=lambda ev: int((ev or {}).get("start_timestamp", 0) or 0))
            except Exception:
                pass
            for ev in entries:
                if not isinstance(ev, dict):
                    continue
                start = _xmltv_time(ev.get("start_timestamp"))
                stop = _xmltv_time(ev.get("stop_timestamp"))
                title = _safe_text(ev.get("name")).strip()
                if not start or not stop or not title:
                    continue
                prog_el = ET.SubElement(tv, "programme", {
                    "start": start,
                    "stop": stop,
                    "channel": _safe_text(channel_id),
                })
                ET.SubElement(prog_el, "title", {"lang": "de"}).text = title
                desc = _safe_text(ev.get("descr")).strip()
                if desc:
                    ET.SubElement(prog_el, "desc", {"lang": "de"}).text = desc
                category = _safe_text(ev.get("category")).strip()
                if category:
                    ET.SubElement(prog_el, "category", {"lang": "de"}).text = category
                icon = _safe_text(ev.get("screenshot_uri")).strip()
                if icon:
                    ET.SubElement(prog_el, "icon", {"src": icon})
                episode = _safe_text(ev.get("episode")).strip()
                if episode:
                    ET.SubElement(prog_el, "episode-num", {"system": "onscreen"}).text = episode
                rating = _safe_text(ev.get("rating")).strip()
                if rating:
                    rating_el = ET.SubElement(prog_el, "rating")
                    ET.SubElement(rating_el, "value").text = rating
                programme_count += 1

        tree = ET.ElementTree(tv)
        try:
            ET.indent(tree, space="  ")
        except Exception:
            pass
        tree.write(dst, encoding="utf-8", xml_declaration=True)
        try:
            with open(meta, "w", encoding="utf-8") as fh:
                json.dump({
                    "source": src,
                    "source_mtime": os.path.getmtime(src),
                    "written": time.time(),
                    "channels": len(data),
                    "programmes": programme_count,
                }, fh, ensure_ascii=False, indent=2)
        except Exception:
            pass
        log("Lokale IPTV-Master-EPG exportiert: {} Kanaele, {} Sendungen -> {}".format(len(data), programme_count, dst))
        return programme_count > 0
    except Exception as exc:
        log("IPTV-Master-EPG-Export fehlgeschlagen: {}".format(exc), xbmc.LOGWARNING)
        return False


def status_paths():
    data_dir = get_talker3_data_dir()
    return (
        os.path.join(data_dir, "codex_talker3_de_scan_status.json"),
        os.path.join(data_dir, "codex_talker3_de_scan.lock"),
    )


def read_json(path, min_mtime=None):
    try:
        if not path or not os.path.exists(path):
            return {}
        if min_mtime is not None and os.path.getmtime(path) < min_mtime - 1.0:
            return {}
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def remove_file(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def is_status_success(status):
    if not status:
        return False
    try:
        if not status.get("ok"):
            return False
        if int(status.get("scanned", 0) or 0) <= 0:
            return False
        if int(status.get("matched", 0) or 0) <= 0:
            return False
        return True
    except Exception:
        return False


def is_auth_like_failure(status):
    reason = str((status or {}).get("reason", "") or "").lower()
    if reason in ("no_live_categories", "no_channels_scanned", "no_status", "start_failed"):
        return True
    if not status:
        return True
    try:
        return not status.get("ok") or int(status.get("scanned", 0) or 0) <= 0
    except Exception:
        return True


def current_window_text():
    labels = []
    for key in ("System.CurrentWindow", "System.CurrentControl", "Container.FolderPath"):
        try:
            value = xbmc.getInfoLabel(key)
            if value:
                labels.append(value)
        except Exception:
            pass
    return " | ".join(labels)


def is_pvr_manager_visible():
    for condition in PVR_CONDITIONS:
        try:
            if xbmc.getCondVisibility(condition):
                return True
        except Exception:
            pass

    try:
        folder_path = (xbmc.getInfoLabel("Container.FolderPath") or "").strip().lower()
        if folder_path.startswith("pvr://"):
            return True
    except Exception:
        pass

    try:
        current = (xbmc.getInfoLabel("System.CurrentWindow") or "").strip().lower()
        if current and any(token in current for token in ("pvr", "tv-kan", "tv kan", "sender", "live tv", "livetv")):
            folder_path = (xbmc.getInfoLabel("Container.FolderPath") or "").strip().lower()
            if folder_path.startswith("pvr://") or "channel" in current or "sender" in current:
                return True
    except Exception:
        pass
    return False


def wait_for_scan_result(started_at):
    status_path, lock_path = status_paths()
    saw_activity = False
    wait_started = time.time()

    while not monitor.abortRequested() and time.time() - wait_started < 10.0:
        if lock_path and os.path.exists(lock_path):
            saw_activity = True
            break
        status = read_json(status_path, started_at)
        if status:
            saw_activity = True
            break
        xbmc.sleep(150)

    if not saw_activity:
        return {"ok": False, "reason": "no_status", "matched": 0, "targets": 0, "scanned": 0}

    while not monitor.abortRequested():
        elapsed = time.time() - started_at
        status = read_json(status_path, started_at)
        if status and not status.get("running"):
            return status
        if elapsed > SCAN_TIMEOUT_SECONDS:
            log("Scan-Wartezeit nach {:.1f}s abgebrochen".format(elapsed), xbmc.LOGWARNING)
            return status or {"ok": False, "reason": "timeout", "matched": 0, "targets": 0, "scanned": 0}
        if lock_path and not os.path.exists(lock_path):
            status = read_json(status_path, started_at)
            if status:
                return status
        xbmc.sleep(int(POLL_SECONDS * 1000))

    return {"ok": False, "reason": "aborted", "matched": 0, "targets": 0, "scanned": 0}


def trigger_manual_senderlist_update(attempt):
    status_path, lock_path = status_paths()

    # Alte oder haengengebliebene Laufzeitdateien aufraeumen, aber keine aktive manuelle Aktion stoeren.
    try:
        if lock_path and os.path.exists(lock_path) and time.time() - os.path.getmtime(lock_path) > 180:
            remove_file(lock_path)
    except Exception:
        pass
    if not (lock_path and os.path.exists(lock_path)):
        remove_file(status_path)

    started_at = time.time()
    log("Automatische Senderlisten-Aktualisierung Versuch {}/{} gestartet; window={}".format(attempt, MAX_ATTEMPTS, current_window_text()))
    try:
        xbmc.executebuiltin("RunScript({},senderliste)".format(STOPONBACK_ADDON_ID))
    except Exception as exc:
        log("RunScript fuer Senderliste fehlgeschlagen: {}".format(exc), xbmc.LOGWARNING)
        return {"ok": False, "reason": "start_failed", "matched": 0, "targets": 0, "scanned": 0}

    status = wait_for_scan_result(started_at)
    log("Automatische Senderlisten-Aktualisierung Versuch {} Status: {}".format(attempt, status))
    return status


def run_once_with_retry():
    last_status = {}
    for attempt in range(1, MAX_ATTEMPTS + 1):
        if monitor.abortRequested():
            return False
        last_status = trigger_manual_senderlist_update(attempt)
        if is_status_success(last_status):
            try:
                matched = int(last_status.get("matched", 0) or 0)
                targets = int(last_status.get("targets", 0) or 0)
                log("Automatische Senderlisten-Aktualisierung erfolgreich: {} von {}".format(matched, targets))
            except Exception:
                log("Automatische Senderlisten-Aktualisierung erfolgreich")
            return True

        if attempt < MAX_ATTEMPTS and is_auth_like_failure(last_status):
            notify("Senderliste", "Authentifizierung fehlgeschlagen - neuer Versuch", 2600, xbmcgui.NOTIFICATION_WARNING)
            log("Auth-/Startfehler erkannt, starte Senderliste erneut: {}".format(last_status), xbmc.LOGWARNING)
            if monitor.waitForAbort(RETRY_DELAY_SECONDS):
                return False
            continue
        break

    log("Automatische Senderlisten-Aktualisierung nicht erfolgreich: {}".format(last_status), xbmc.LOGWARNING)
    return False


def main():
    log("Service gestartet")
    if not AUTO_SENDERLIST_UPDATE_ENABLED:
        log("Automatische Senderlisten-Aktualisierung ist deaktiviert; manuelle Quicknavigation bleibt aktiv")
        return
    already_ran_this_kodi_start = False
    pvr_first_seen = None
    running = False

    while not monitor.abortRequested():
        visible = is_pvr_manager_visible()

        if already_ran_this_kodi_start or running:
            if monitor.waitForAbort(POLL_SECONDS):
                break
            continue

        if visible:
            if pvr_first_seen is None:
                pvr_first_seen = time.time()
                log("PVR-Manager erkannt; warte auf stabiles Fenster: {}".format(current_window_text()))
            elif time.time() - pvr_first_seen >= PVR_STABLE_SECONDS:
                running = True
                try:
                    run_once_with_retry()
                finally:
                    already_ran_this_kodi_start = True
                    running = False
                    log("Automatik fuer diesen Kodi-Start erledigt")
        else:
            pvr_first_seen = None

        if monitor.waitForAbort(POLL_SECONDS):
            break

    log("Service beendet")


if __name__ == "__main__":
    main()
