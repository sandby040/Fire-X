# -*- coding: UTF-8 -*-

import re
import sys
import time
from urllib.parse import quote_plus

import xbmc
import xbmcgui


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[Archiv Navigator Trailer Starter] %s' % message, level)
    except Exception:
        pass


def _ensure_youtube_available():
    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            return True
    except Exception as exc:
        _log('YouTube availability check failed: %s' % exc, xbmc.LOGERROR)
    return xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')


video_id = sys.argv[1] if len(sys.argv) > 1 else ''
video_id = re.sub(r'[^A-Za-z0-9_-]', '', str(video_id or ''))

if video_id:
    token = str(time.time())
    try:
        xbmcgui.Window(10000).setProperty('nova_active_trailer_token', token)
    except Exception:
        pass
    xbmc.sleep(150)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if not _ensure_youtube_available():
        _log('YouTube addon unavailable, trailer cannot start', xbmc.LOGERROR)
        xbmc.executebuiltin('Notification(Trailer, YouTube Add-on nicht aktiv - Kodi neu starten, 4500)')
        sys.exit(0)
    try:
        if xbmcgui.Window(10000).getProperty('nova_active_trailer_token') != token:
            _log('Superseded trailer start aborted for %s' % video_id)
            sys.exit(0)
    except Exception:
        pass
    # Use the same stable progressive trailer path as Streaming Archiv.
    url = 'plugin://plugin.video.youtube/play/?video_id=%s&codex_trailer=1' % quote_plus(video_id)
    _log('PlayMedia %s' % video_id)
    xbmc.executebuiltin('PlayMedia(%s)' % url)
    for _ in range(24):
        xbmc.sleep(250)
        try:
            if xbmcgui.Window(10000).getProperty('nova_active_trailer_token') != token:
                _log('Active trailer changed, breaking poll loop for %s' % video_id)
                break
        except Exception:
            pass
        if xbmc.Player().isPlayingVideo():
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            break
