# -*- coding: utf-8 -*-
"""Operation Player, 2026-10-08. Local copy: no service/provider dependency.

Stop is acknowledged on Kodi's main thread before another playback handoff.
Never fetch a URL here; signed paths, MACs, headers and DRM remain native.
"""
import threading
import time
import uuid
import os

import xbmc
import xbmcgui
import xbmcvfs

# Share the existing Live TV 1 barrier, so its controller also waits for us.
BARRIER = 'LiveTV1.Auto.PlayerBarrier'
REQUEST = 'Nova.OperationPlayer.Request'
LAST_STOP = 'Nova.OperationPlayer.LastStop'


def _claim_stop_lock(deadline, monitor):
    """Serialize different Kodi Python interpreters, including double-clicks.

    One empty temp file; the OS releases its lock even when Kodi is killed.
    Unlike a MAC/session file, it contains no data and has no time-to-live.
    """
    handle = open(xbmcvfs.translatePath('special://temp/nova_operation_player.stop.lock'), 'a+b')
    while True:
        try:
            if os.name == 'nt':
                import msvcrt
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return handle
        except OSError:
            if time.monotonic() >= deadline or monitor.waitForAbort(0.025):
                handle.close()
                return None


class PlayerBusy(RuntimeError):
    pass


def prepare_item(item):
    """Avoid Kodi's extra ContentLookup/Stat without altering native options."""
    if item is None:
        return item
    path = str(item.getPath() or '')
    if not path or path.startswith('plugin://'):
        return item  # The native target addon still has to resolve this URL.
    item.setContentLookup(False)
    # Kodi 21 has no Python getMimeType(). Do not guess/overwrite native MIME,
    # DRM, inputstream or seeking properties. ContentLookup(False) suffices here.
    return item


class OperationPlayer:
    """One instance per playback invocation, not a permanent Player callback."""
    def __init__(self, addon_id):
        self.addon_id = addon_id
        self.stopped = False
        self.ticket = ''

    def _log(self, text, warning=False):
        xbmc.log('[Operation Player] %s %s' % (self.addon_id, text),
                 xbmc.LOGWARNING if warning else xbmc.LOGINFO)

    def stop_previous(self, timeout=10.0):
        started = time.monotonic()
        deadline = started + timeout
        window = xbmcgui.Window(10000)
        monitor = xbmc.Monitor()
        if not self.ticket:
            self.ticket = uuid.uuid4().hex
            window.setProperty(REQUEST, self.ticket)
            # Revoke a still-resolving Live TV 1 worker before switching addons.
            # Its existing native permission check rejects any late play().
            # No Live TV 1 files, source cursor, provider tokens or MACs change.
            window.clearProperty('LiveTV1.Auto.Active')
        elif window.getProperty(REQUEST) != self.ticket:
            self._log('superseded request; no late playback handoff', True)
            return False
        # A previous queued Stop must not execute after our new stream starts.
        while window.getProperty(BARRIER):
            if time.monotonic() >= deadline or monitor.waitForAbort(0.025):
                self._log('previous stop still pending; new start blocked', True)
                return False
        if window.getProperty(REQUEST) != self.ticket:
            return False
        if self.stopped:
            return True
        try:
            stop_lock = _claim_stop_lock(deadline, monitor)
        except Exception:
            self._log('cannot claim stop lock; new start blocked', True)
            return False
        if stop_lock is None:
            return False
        # A newer request may have arrived while we waited for the OS lock.
        if window.getProperty(REQUEST) != self.ticket:
            stop_lock.close()
            return False
        if window.getProperty(BARRIER):
            # The legacy Live TV 1 controller does not use our OS lock.
            stop_lock.close()
            self._log('external stop appeared; new start blocked', True)
            return False
        owner = uuid.uuid4().hex
        window.setProperty(BARRIER, owner)
        done = threading.Event()
        outcome = {'ok': False}

        def stop_and_ack():
            try:
                if window.getProperty(BARRIER) != owner:
                    return
                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                xbmc.executebuiltin('PlayerControl(Stop)', True)
                # Inspect the player only AFTER the Stop command was acknowledged.
                player = xbmc.Player()
                while player.isPlaying():
                    if time.monotonic() >= deadline or monitor.waitForAbort(0.025):
                        return
                outcome['ok'] = True
                window.setProperty(LAST_STOP, self.ticket)
            except Exception:
                self._log('stop failed; new start blocked', True)
            finally:
                stop_lock.close()
                if window.getProperty(BARRIER) == owner:
                    window.clearProperty(BARRIER)
                done.set()

        try:
            threading.Thread(target=stop_and_ack, name='NovaOperationPlayerStop',
                             daemon=True).start()
        except Exception:
            stop_lock.close()
            if window.getProperty(BARRIER) == owner:
                window.clearProperty(BARRIER)
            self._log('cannot start stop helper; new start blocked', True)
            return False
        self._log('stop requested')
        while not done.is_set():
            if time.monotonic() >= deadline or monitor.waitForAbort(0.025):
                # DO NOT clear the barrier here: the queued Stop may still run.
                self._log('stop timeout; no new stream handed to Kodi', True)
                return False
        self.stopped = outcome['ok'] and window.getProperty(REQUEST) == self.ticket
        if self.stopped:
            self._log('stop acknowledged elapsed_ms=%d' %
                      int((time.monotonic() - started) * 1000))
        return self.stopped

    def fail(self, handle=None, resolve=None):
        self.stopped = False
        self._log('playback deferred until old player is released', True)
        xbmcgui.Dialog().notification('Nova', 'Bitte nochmal versuchen', time=2500)
        if resolve is not None and handle is not None and int(handle) >= 0:
            return resolve(int(handle), False, xbmcgui.ListItem())
        return False

    def abort_playback(self):
        # A late failed resolver must NEVER stop a subsequently selected stream.
        window = xbmcgui.Window(10000)
        if not self.ticket or window.getProperty(REQUEST) != self.ticket:
            self._log('stale/non-playback cleanup; no player stop')
            return False
        self.stopped = False
        return self.stop_previous()

    def resolved(self, original, handle, succeeded, item, *args, **kwargs):
        if succeeded:
            if not self.stop_previous():
                return self.fail(handle, original)
            prepare_item(item)
            self._log('native resolved handoff')
        return original(handle, succeeded, item, *args, **kwargs)

    def install_resolved_hook(self):
        import xbmcplugin
        original = xbmcplugin.setResolvedUrl

        def resolved(handle, succeeded, item, *args, **kwargs):
            return self.resolved(original, handle, succeeded, item, *args, **kwargs)
        xbmcplugin.setResolvedUrl = resolved
