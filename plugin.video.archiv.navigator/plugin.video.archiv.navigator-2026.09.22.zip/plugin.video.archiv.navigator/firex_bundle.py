"""Deploy bundled provider CODE only; never export a user's entire profile."""
import hashlib
import json
import os
import shutil
import xml.etree.ElementTree as ET


def seed():
    import xbmc
    import xbmcaddon
    import xbmcvfs
    addon = xbmcaddon.Addon('plugin.video.archiv.navigator')
    home = addon.getAddonInfo('path')
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    bundle = os.path.join(home, 'resources', 'firex_cache')
    marker = os.path.join(profile, 'firex_provider_bundle.json')
    with open(os.path.join(bundle, 'domains.json'), encoding='utf-8') as stream:
        domains = json.load(stream)
    version = addon.getAddonInfo('version')
    try:
        with open(marker, encoding='utf-8') as stream:
            if json.load(stream).get('version') == version:
                return
    except (OSError, ValueError):
        pass
    old_settings = {}
    try:
        root = ET.parse(os.path.join(profile, 'settings.xml')).getroot()
        old_settings = {n.get('id'): n for n in root.iter('setting')}
    except (OSError, ET.ParseError):
        pass
    for key, value in domains.items():
        node = old_settings.get(key)
        # Explicitly chosen mirrors are retained. Only default/empty provider
        # domains move to the bundled current defaults, never account fields.
        if node is None or node.get('default') == 'true' or not node.text:
            addon.setSetting(key, value)
    source = os.path.join(bundle, 'remote_cache')
    target = os.path.join(profile, 'remote_cache')
    for folder, _, files in os.walk(source):
        for name in files:
            src = os.path.join(folder, name)
            rel = os.path.relpath(src, source)
            dest = os.path.join(target, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copyfile(src, dest + '.firex-tmp')
            os.replace(dest + '.firex-tmp', dest)
    os.makedirs(profile, exist_ok=True)
    with open(marker + '.tmp', 'w', encoding='utf-8') as stream:
        json.dump({'version': version}, stream)
    os.replace(marker + '.tmp', marker)
    xbmc.log('[Archiv Navigator] Fire-X provider code seeded: ' + version, xbmc.LOGINFO)
