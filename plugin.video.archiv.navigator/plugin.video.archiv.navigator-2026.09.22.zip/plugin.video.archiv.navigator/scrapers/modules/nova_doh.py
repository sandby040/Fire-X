# -*- coding: utf-8 -*-
"""Comprehensive Request-Safe Cloudflare & Google DoH helper for Archiv Navigator.

Resolves domains via Direct-IP Cloudflare / Google DoH (bypassing ISP DNS entirely,
including Vodafone CUII blocks), preserves Host and TLS SNI, dynamically resolves
HTTP/HTTPS redirects, and provides request-safe hooks for urllib3/requests and socket.
"""

import http.client
import ipaddress
import json
import os
import socket
import ssl
import time
import urllib.request
from urllib.parse import urlencode, urlparse

try:
    import certifi
except Exception:
    certifi = None

try:
    import xbmc
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcvfs = None

# Bootstrap IPs and hosts that must never be recursively resolved
BOOTSTRAP_HOSTS = {
    '1.1.1.1', '1.0.0.1', '8.8.8.8', '8.8.4.4', '9.9.9.9',
    'cloudflare-dns.com', 'dns.google', 'dns.quad9.net',
    'localhost', '127.0.0.1',
}

DOH_ENDPOINTS = (
    # Direct IP endpoints - 100% immune to OS DNS hijacking or poisoning on Vodafone
    ('Cloudflare (1.1.1.1)', 'https://1.1.1.1/dns-query', 'cloudflare-dns.com'),
    ('Cloudflare (1.0.0.1)', 'https://1.0.0.1/dns-query', 'cloudflare-dns.com'),
    ('Google (8.8.8.8)', 'https://8.8.8.8/resolve', 'dns.google'),
    ('Google (8.8.4.4)', 'https://8.8.4.4/resolve', 'dns.google'),
    ('Quad9 (9.9.9.9)', 'https://9.9.9.9:5053/dns-query', 'dns.quad9.net'),
    # Hostname fallbacks
    ('Cloudflare Host', 'https://cloudflare-dns.com/dns-query', 'cloudflare-dns.com'),
    ('Google Host', 'https://dns.google/resolve', 'dns.google'),
)

_DOH_CACHE = {}
_DOH_CACHE_FILE = None
_DOH_CACHE_DIRTY = False


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log('[Archiv Navigator DoH] %s' % str(message), level or xbmc.LOGINFO)
    except Exception:
        pass


def enabled():
    return True


def _get_cache_file():
    global _DOH_CACHE_FILE
    if _DOH_CACHE_FILE is not None:
        return _DOH_CACHE_FILE
    try:
        if xbmcvfs is not None and hasattr(xbmcvfs, 'translatePath'):
            profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.archiv.navigator')
            if profile:
                os.makedirs(profile, exist_ok=True)
                _DOH_CACHE_FILE = os.path.join(profile, 'doh_cache.json')
                return _DOH_CACHE_FILE
    except Exception:
        pass
    _DOH_CACHE_FILE = ''
    return ''


def _load_disk_cache():
    path = _get_cache_file()
    if not path or not os.path.exists(path):
        return
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        now = time.time()
        for k, v in data.items():
            if isinstance(v, list) and len(v) == 2 and v[1] > now:
                _DOH_CACHE[k] = (v[0], v[1])
    except Exception:
        pass


def _save_disk_cache():
    global _DOH_CACHE_DIRTY
    if not _DOH_CACHE_DIRTY:
        return
    path = _get_cache_file()
    if not path:
        return
    try:
        now = time.time()
        valid = {k: list(v) for k, v in _DOH_CACHE.items() if v[1] > now}
        with open(path + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(valid, f)
        os.replace(path + '.tmp', path)
        _DOH_CACHE_DIRTY = False
    except Exception:
        pass


_load_disk_cache()


def _is_ip(hostname):
    try:
        ipaddress.ip_address(hostname)
        return True
    except Exception:
        return False


def _candidate(hostname):
    hostname = (hostname or '').lower()
    if not hostname or hostname in BOOTSTRAP_HOSTS:
        return False
    if _is_ip(hostname):
        return False
    if hostname.endswith('.local') or hostname.endswith('.fritz.box') or hostname.endswith('.home'):
        return False
    return True


def _ssl_context(verify=False):
    ctx = ssl.create_default_context()
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


class IPHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host, ip=None, port=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        self.ip = ip
        super().__init__(host, port, timeout=timeout)

    def connect(self):
        if self.ip:
            self.sock = self._create_connection((self.ip, self.port), self.timeout)
        else:
            super().connect()


class IPHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, ip=None, port=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, context=None):
        self.ip = ip
        self.context = context
        self.actual_host = host
        super().__init__(host, port, timeout=timeout, context=context)

    def connect(self):
        if self.ip:
            self.sock = self._create_connection((self.ip, self.port), self.timeout)
            if getattr(self, '_tunnel_host', None):
                self._tunnel()
            self.sock = self.context.wrap_socket(self.sock, server_hostname=self.actual_host)
        else:
            super().connect()


class DoHHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self, ip_map=None):
        self.ip_map = dict(ip_map or {})
        super().__init__()

    def http_open(self, req):
        host = (urlparse(req.full_url).hostname or '').lower()
        ip = self.ip_map.get(host)
        if not ip and _candidate(host):
            ip = resolve(host)
            if ip:
                self.ip_map[host] = ip
        def factory(*args, **kwargs):
            return IPHTTPConnection(host, ip=ip, timeout=req.timeout)
        return self.do_open(factory, req)


class DoHHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, ip_map=None, verify=False):
        if verify and certifi is not None:
            context = ssl.create_default_context(cafile=certifi.where())
            context.check_hostname = True
            context.verify_mode = ssl.CERT_REQUIRED
        else:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        self.ip_map = dict(ip_map or {})
        self.context = context
        super().__init__(context=context)

    def https_open(self, req):
        host = (urlparse(req.full_url).hostname or '').lower()
        ip = self.ip_map.get(host)
        if not ip and _candidate(host):
            ip = resolve(host)
            if ip:
                self.ip_map[host] = ip
        def factory(*args, **kwargs):
            return IPHTTPSConnection(host, ip=ip, timeout=req.timeout, context=self.context)
        return self.do_open(factory, req)


def resolve(hostname):
    global _DOH_CACHE_DIRTY
    hostname = (hostname or '').lower().strip('.')
    if not _candidate(hostname):
        return None
    cached = _DOH_CACHE.get(hostname)
    if cached and cached[1] > time.time():
        return cached[0]

    for name, endpoint, host_header in DOH_ENDPOINTS:
        url = '%s?%s' % (endpoint, urlencode({'name': hostname, 'type': 'A'}))
        req = urllib.request.Request(url)
        req.add_header('Accept', 'application/dns-json')
        if host_header:
            req.add_header('Host', host_header)
        try:
            resp = urllib.request.urlopen(req, timeout=3.5, context=_ssl_context(verify=False))
            payload = json.loads(resp.read().decode('utf-8', 'replace'))
            if payload.get('Status') == 3:  # NXDOMAIN
                _DOH_CACHE[hostname] = (None, time.time() + 60)
                _DOH_CACHE_DIRTY = True
                return None
            ttl = 600
            for answer in payload.get('Answer') or []:
                if answer.get('type') != 1:
                    continue
                ip = answer.get('data')
                try:
                    ipaddress.ip_address(ip)
                except Exception:
                    continue
                ttl = int(answer.get('TTL') or ttl)
                ttl = max(60, min(ttl, 3600))
                _DOH_CACHE[hostname] = (ip, time.time() + ttl)
                _DOH_CACHE_DIRTY = True
                _log('%s %s -> %s (TTL %ds)' % (name, hostname, ip, ttl))
                _save_disk_cache()
                return ip
        except Exception as exc:
            pass
    return None


def urlopen(request, timeout=None):
    if not enabled():
        return urllib.request.urlopen(request, timeout=timeout)
    url = request.full_url if hasattr(request, 'full_url') else str(request)
    host = (urlparse(url).hostname or '').lower()
    ip = resolve(host)
    ip_map = {host: ip} if (host and ip) else {}
    opener = urllib.request.build_opener(
        DoHHTTPHandler(ip_map),
        DoHHTTPSHandler(ip_map, verify=False),
    )
    return opener.open(request, timeout=timeout)


_URLLIB3_HOOK_ACTIVE = False
_SOCKET_HOOK_ACTIVE = False
_ORIGINAL_GETADDRINFO = None
_ORIGINAL_CREATE_CONNECTION = None


def install_urllib3_doh():
    """Hook urllib3's create_connection so requests automatically uses DoH."""
    global _URLLIB3_HOOK_ACTIVE, _ORIGINAL_CREATE_CONNECTION
    try:
        import urllib3.util.connection
        if _URLLIB3_HOOK_ACTIVE or getattr(urllib3.util.connection, '_nova_doh_active', False):
            return True
        _ORIGINAL_CREATE_CONNECTION = urllib3.util.connection.create_connection

        def doh_create_connection(address, *args, **kwargs):
            try:
                host, port = address
                if _candidate(host):
                    ip = resolve(host)
                    if ip:
                        return _ORIGINAL_CREATE_CONNECTION((ip, port), *args, **kwargs)
            except Exception:
                pass
            return _ORIGINAL_CREATE_CONNECTION(address, *args, **kwargs)

        urllib3.util.connection.create_connection = doh_create_connection
        urllib3.util.connection._nova_doh_active = True
        _URLLIB3_HOOK_ACTIVE = True
        _log('urllib3 create_connection DoH hook installed')
        return True
    except Exception as exc:
        _log('install_urllib3_doh failed: %s' % exc, getattr(xbmc, 'LOGWARNING', None))
        return False


def install_socket_doh():
    """Hook socket.getaddrinfo as safe fallback for any direct socket / urllib connections."""
    global _SOCKET_HOOK_ACTIVE, _ORIGINAL_GETADDRINFO
    try:
        if _SOCKET_HOOK_ACTIVE or getattr(socket, '_nova_doh_active', False):
            return True
        _ORIGINAL_GETADDRINFO = socket.getaddrinfo

        def doh_getaddrinfo(host, port, *args, **kwargs):
            try:
                if _candidate(host):
                    ip = resolve(host)
                    if ip:
                        return _ORIGINAL_GETADDRINFO(ip, port, *args, **kwargs)
            except Exception:
                pass
            return _ORIGINAL_GETADDRINFO(host, port, *args, **kwargs)

        socket.getaddrinfo = doh_getaddrinfo
        socket._nova_doh_active = True
        _SOCKET_HOOK_ACTIVE = True
        _log('socket.getaddrinfo DoH hook installed')
        return True
    except Exception as exc:
        _log('install_socket_doh failed: %s' % exc, getattr(xbmc, 'LOGWARNING', None))
        return False


def install_doh_globally():
    """Activate DoH everywhere across urllib3, requests, and socket."""
    u_ok = install_urllib3_doh()
    s_ok = install_socket_doh()
    _log('install_doh_globally: urllib3=%s socket=%s' % (u_ok, s_ok))
    return u_ok or s_ok
