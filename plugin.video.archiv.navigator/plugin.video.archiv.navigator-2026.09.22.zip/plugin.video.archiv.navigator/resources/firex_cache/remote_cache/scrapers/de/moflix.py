# -*- coding: UTF-8 -*-
import json
import re
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, source_utils
from resources.lib.control import getSetting, quote
import xbmc

SITE_IDENTIFIER = 'moflix'
SITE_DOMAIN = 'moflix-stream.xyz'
SITE_NAME = SITE_IDENTIFIER.upper()
MOFLIX_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'


def _append_stream_headers(url):
    url = str(url or '')
    if not url or '|' in url:
        return url
    if '.m3u8' not in url:
        return url
    return (
        url
        + '|User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A140.0%29+Gecko%2F20100101+Firefox%2F140.0'
        + '&Referer=https%3A%2F%2Fmoflix-stream.xyz%2F'
        + '&Origin=https%3A%2F%2Fmoflix-stream.xyz'
        + '&verifypeer=false'
    )


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        if not self.domain:
            self.domain = SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.search_movie = self.base_link + '/api/v1/channel/movies?channelType=channel&restriction=&paginate=simple&perPage=100&query=%s'
        self.search_series = self.base_link + '/api/v1/channel/series?channelType=channel&restriction=&paginate=simple&perPage=100&query=%s'
        self.sources = []

    def _log(self, msg, level=xbmc.LOGINFO):
        try:
            xbmc.log('[ArchivNavigator Moflix] %s' % str(msg), level)
        except Exception:
            pass

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            cleaned_targets = []
            for t_item in set(titles or []):
                if t_item:
                    c = cleantitle.get(t_item)
                    if c and c not in cleaned_targets:
                        cleaned_targets.append(c)

            self._log('run() titles=%s year=%s season=%s episode=%s targets=%s' % (
                str(titles), str(year), str(season), str(episode), str(cleaned_targets)
            ))

            links = []
            seen_ids = set()
            search_template = self.search_movie if (season == 0) else self.search_series

            # Build list of search query candidates
            search_queries = []
            for title in (titles or []):
                if not title or title in search_queries:
                    continue
                search_queries.append(title)
                # Also try without parenthetical annotations like "(Extended)" or "(2011)"
                clean_q = re.sub(r'\s*\([^)]*\)', '', title).strip()
                if clean_q and clean_q not in search_queries:
                    search_queries.append(clean_q)

            for query_text in search_queries:
                url = search_template % quote(query_text)
                self._log('Fetching search URL: %s' % url)

                try:
                    oRequest = cRequestHandler(url, bypass_dns=True)
                    oRequest.addHeaderEntry('User-Agent', MOFLIX_UA)
                    oRequest.addHeaderEntry('Referer', self.base_link + '/')
                    raw = oRequest.request()
                except Exception as req_exc:
                    self._log('Search request exception: %s' % req_exc, xbmc.LOGWARNING)
                    continue

                if not raw:
                    self._log('Empty search response for: %s' % query_text, xbmc.LOGDEBUG)
                    continue

                try:
                    jSearch = json.loads(raw)
                except Exception as json_exc:
                    self._log('Search json decode error: %s' % json_exc, xbmc.LOGWARNING)
                    continue

                aResults = []
                if isinstance(jSearch, dict):
                    if 'channel' in jSearch and isinstance(jSearch['channel'], dict):
                        content = jSearch['channel'].get('content')
                        if isinstance(content, dict):
                            aResults = content.get('data', [])
                    elif 'results' in jSearch:
                        aResults = jSearch['results']

                self._log('Results count from API for "%s": %d' % (query_text, len(aResults)))

                for i in aResults:
                    if not isinstance(i, dict):
                        continue
                    item_id = str(i.get('id') or '')
                    if not item_id or item_id in seen_ids:
                        continue

                    # IMDb exact match check
                    if imdb and i.get('imdb_id') and str(i.get('imdb_id')).strip() == str(imdb).strip():
                        seen_ids.add(item_id)
                        links.append({'id': item_id, 'name': i.get('name') or i.get('title') or ''})
                        self._log('IMDb match: id=%s name=%s' % (item_id, i.get('name')))
                        break

                    # Year matching
                    i_year = ''
                    if i.get('release_date'):
                        i_year = str(i['release_date']).split('-')[0].strip()
                    elif i.get('year'):
                        i_year = str(i['year']).strip()

                    if year and i_year:
                        try:
                            if abs(int(year) - int(i_year)) > 1:
                                continue
                        except Exception:
                            if str(year).strip() != i_year:
                                continue

                    # Series vs Movie filtering
                    if season == 0:
                        if i.get('is_series'):
                            continue
                    else:
                        if 'is_series' in i and not i['is_series']:
                            continue

                    c_name = cleantitle.get(i.get('name') or i.get('title') or '')
                    matched = (
                        c_name in cleaned_targets
                        or any(c_name in ct or ct in c_name for ct in cleaned_targets if ct)
                    )
                    if matched:
                        seen_ids.add(item_id)
                        links.append({'id': item_id, 'name': i.get('name') or i.get('title') or ''})
                        self._log('Title matched: id=%s name="%s" (clean=%s)' % (item_id, i.get('name'), c_name))

                if len(links) > 0:
                    break

            if not links:
                self._log('No matching titles found on Moflix')
                return self.sources

            self._log('Matched %d title(s) on Moflix: %s' % (len(links), str([l['name'] for l in links])))

            for link in links:
                t_id = link['id']
                if season == 0:
                    detail_url = self.base_link + '/api/v1/titles/%s?load=images,genres,productionCountries,keywords,videos,primaryVideo,seasons,compactCredits' % t_id
                else:
                    detail_url = self.base_link + '/api/v1/titles/%s/seasons/%s/episodes/%s?load=videos,compactCredits,primaryVideo' % (t_id, season, episode)

                self._log('Fetching detail URL: %s' % detail_url)
                try:
                    oRequest = cRequestHandler(detail_url, bypass_dns=True)
                    oRequest.addHeaderEntry('User-Agent', MOFLIX_UA)
                    oRequest.addHeaderEntry('Referer', detail_url)
                    raw = oRequest.request()
                except Exception as req_exc:
                    self._log('Detail request failed for id %s: %s' % (t_id, req_exc), xbmc.LOGWARNING)
                    continue

                if not raw:
                    continue

                try:
                    jDetail = json.loads(raw)
                except Exception as exc:
                    self._log('Detail json error for id %s: %s' % (t_id, exc), xbmc.LOGWARNING)
                    continue

                if not isinstance(jDetail, dict):
                    continue

                jVideos = []
                if season == 0:
                    title_obj = jDetail.get('title', {})
                    if isinstance(title_obj, dict):
                        jVideos = title_obj.get('videos', []) or []
                        if not jVideos and title_obj.get('primaryVideo'):
                            jVideos.append(title_obj['primaryVideo'])
                else:
                    ep_obj = jDetail.get('episode', {})
                    if isinstance(ep_obj, dict):
                        jVideos = ep_obj.get('videos', []) or []
                        if not jVideos and ep_obj.get('primaryVideo'):
                            jVideos.append(ep_obj['primaryVideo'])

                self._log('Found %d video candidates for id %s' % (len(jVideos), t_id))

                for j in jVideos:
                    try:
                        src = str(j.get('src') or '').strip()
                        if not src or 'youtube' in src.lower():
                            continue

                        quality_raw = str(j.get('quality') or 'SD')
                        if '2160' in quality_raw or '4K' in quality_raw.upper():
                            quality = '4K'
                        elif '1440' in quality_raw or '2K' in quality_raw.upper():
                            quality = '1440p'
                        elif '1080' in quality_raw:
                            quality = '1080p'
                        elif '720' in quality_raw:
                            quality = '720p'
                        elif '480' in quality_raw:
                            quality = '480p'
                        elif '360' in quality_raw:
                            quality = '360p'
                        else:
                            quality = 'SD'

                        is_direct = ('.m3u8' in src)
                        hoster_name = str(j.get('name') or '').split('-')[0].strip() or 'Moflix'

                        # Moflix direct HLS streams on *.moflix-stream.day are labeled "Premium (No Ads)".
                        # Their sub-playlists/segments return HTTP 403 Forbidden without a premium account.
                        v_name = str(j.get('name') or '').strip().lower()
                        if 'moflix-stream.day' in src.lower() or 'premium' in v_name:
                            continue

                        valid, resolved_hoster = source_utils.is_host_valid(src, hostDict)
                        if valid and resolved_hoster:
                            hoster = resolved_hoster
                        elif is_direct or 'moflix' in src.lower() or 'vidara' in src.lower() or 'streamtape' in src.lower():
                            valid = True
                            if 'moflix-stream.click' in src.lower():
                                hoster = 'moflix-stream.click'
                            elif 'vidara' in src.lower():
                                hoster = 'vidara.to'
                            elif 'streamtape' in src.lower():
                                hoster = 'streamtape.com'
                            else:
                                hoster = 'Moflix'
                        else:
                            # Also allow standard moflix mirrors
                            valid = True
                            hoster = hoster_name

                        if not valid:
                            continue

                        final_url = _append_stream_headers(src) if is_direct else src

                        self.sources.append({
                            'source': hoster,
                            'quality': quality,
                            'language': 'de',
                            'url': final_url,
                            'info': j.get('language') or 'DE',
                            'direct': is_direct
                        })
                    except Exception:
                        pass

            self._log('Completed run(), collected %d sources' % len(self.sources))
            return self.sources
        except Exception as exc:
            self._log('General run() exception: %s' % exc, xbmc.LOGERROR)
            return self.sources

    def resolve(self, url):
        return url
