# -*- coding: UTF-8 -*-

import xbmc


BASE_URL = ''
password = ''


def _disabled(*args, **kwargs):
    xbmc.log('[Archiv Navigator] Admin-Chat-Konfiguration ist deaktiviert.', xbmc.LOGINFO)
    return {'success': False, 'error': 'disabled'}


def main(*args, **kwargs):
    return None


def __getattr__(name):
    return _disabled
