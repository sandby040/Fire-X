# -*- coding: UTF-8 -*-

import sys

import xbmc
import xbmcgui
import xbmcplugin


def _disabled(*args, **kwargs):
    xbmc.log('[Archiv Navigator] Support/Admin-Chat ist deaktiviert.', xbmc.LOGINFO)
    try:
        xbmcgui.Dialog().notification('Archiv Navigator', 'Support/Admin-Chat deaktiviert', time=2000)
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), False)
    except Exception:
        pass
    return None


def GetMenu(*args, **kwargs):
    return _disabled(*args, **kwargs)


def ChatName(*args, **kwargs):
    return _disabled(*args, **kwargs)


def ChatRoom(*args, **kwargs):
    return _disabled(*args, **kwargs)


def ChatRooms(*args, **kwargs):
    return _disabled(*args, **kwargs)


def add_chatroom(*args, **kwargs):
    return _disabled(*args, **kwargs)


def add_chatroom2(*args, **kwargs):
    return _disabled(*args, **kwargs)


def delete_chatroom(*args, **kwargs):
    return _disabled(*args, **kwargs)


def update_admin_password(*args, **kwargs):
    return _disabled(*args, **kwargs)


def del_admin_password(*args, **kwargs):
    return _disabled(*args, **kwargs)


def chatroominfo(*args, **kwargs):
    return _disabled(*args, **kwargs)


def __getattr__(name):
    return _disabled
