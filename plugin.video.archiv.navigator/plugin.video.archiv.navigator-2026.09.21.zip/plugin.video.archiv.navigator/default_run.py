# -*- coding: UTF-8 -*-

import json
import hashlib
import os
import concurrent.futures
import re
import sqlite3
import socket
import sys
import threading
import time
import unicodedata
import xml.etree.ElementTree as ET
from urllib.parse import parse_qs, quote_plus, unquote_plus, urlencode, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


ADDON_ID = 'plugin.video.archiv.navigator'
OLD_ADDON_ID = 'plugin.video.lastship.reborn'
TMDB_API_KEY = '86dd18b04874d9c94afadde7993d94e3'
CHOICE_PARAM = 'nova_archiv_navigator_choice'
PASSTHROUGH_PARAM = 'nova_archiv_navigator_passthrough'
PASSTHROUGH_TOKEN_PARAM = 'nova_archiv_navigator_passthrough_token'
CLEAR_FAVOURITES_PARAM = 'nova_clear_all_favourites'
FAVOURITE_DIRECT_PARAM = 'nova_from_favourites'
VIEW_PREFS_FILE = 'nova_view_prefs.json'
TITLE_VIEW_KEY = 'archiv_navigator_titles'
SEASON_VIEW_KEY = 'archiv_navigator_seasons'
CATEGORY_VIEW_KEY = 'archiv_navigator_categories'
DEFAULT_CATEGORY_VIEW_ROW = (0, 65591, 0, 1, 0, 'skin.aeon.nox.silvo')
NEXT_PAGE_ART = 'special://home/addons/%s/resources/art/next_page.png' % ADDON_ID
NEXT_PAGE_LABEL_WORDS = ('nächste', 'naechste', 'weiter', 'next')
SHOW_ARCHIV_NAVIGATOR_ROOT_TOOLS = False
CLEAR_FAVOURITES_LABEL = 'Alle Favoriten löschen'
CLEAR_FAVOURITES_ICON = 'special://home/addons/plugin.video.stalker.macsimum/resources/media/gold_star.png'

_view_candidates = {
    'movie': 0,
    'series': 0,
    'season': 0,
    'episode': 0,
}
_tmdb_external_ids_cache = {}
_pending_view_mode = 0
_pending_view_key = ''
_movie_navigator_buffer = []
_tv_navigator_buffer = []
_original_add_directory_items = None
_listing_lite_meta_cache = {}


def _log(message, level=xbmc.LOGINFO):
    try:
        message = str(message)
        if len(message) > 500:
            message = message[:500] + '...'
        xbmc.log('[Archiv Navigator Wrapper] %s' % message, level)
    except Exception:
        pass


def _nova_urlopen(request, timeout=None):
    try:
        from scrapers.modules import nova_doh
        return nova_doh.urlopen(request, timeout=timeout)
    except Exception:
        return urlopen(request, timeout=timeout)


def _disable_moviedream_runtime():
    """Keep the dead MovieDream provider out even if remote cache refreshes it."""
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        for key in ('provider.moviedream', 'global_search_moviedream', 'provider.moviedream.check'):
            try:
                addon.setSetting(key, 'false')
            except Exception:
                pass

        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not profile:
            return

        plugin_db = os.path.join(profile, 'pluginDB')
        if os.path.exists(plugin_db):
            try:
                with open(plugin_db, 'r', encoding='utf-8') as handle:
                    data = json.load(handle)
                if isinstance(data, dict) and data.pop('moviedream', None) is not None:
                    with open(plugin_db, 'w', encoding='utf-8') as handle:
                        json.dump(data, handle, ensure_ascii=False, separators=(',', ':'))
                    _log('MovieDream removed from pluginDB')
            except Exception as exc:
                _log('MovieDream pluginDB cleanup failed: %s' % exc, xbmc.LOGWARNING)

        manifest_path = os.path.join(profile, 'remote_cache', 'manifest.json')
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, 'r', encoding='utf-8') as handle:
                    manifest = json.load(handle)
                changed = False
                for section in ('scrapers', 'sites'):
                    items = manifest.get(section)
                    if isinstance(items, list):
                        kept = [item for item in items if not (isinstance(item, dict) and item.get('name') == 'moviedream')]
                        if len(kept) != len(items):
                            manifest[section] = kept
                            changed = True
                if changed:
                    with open(manifest_path, 'w', encoding='utf-8') as handle:
                        json.dump(manifest, handle, ensure_ascii=False, indent=2)
                    _log('MovieDream removed from remote manifest')
            except Exception as exc:
                _log('MovieDream manifest cleanup failed: %s' % exc, xbmc.LOGWARNING)
    except Exception as exc:
        _log('MovieDream runtime disable failed: %s' % exc, xbmc.LOGWARNING)


def _patch_network_fast_fail():
    """Keep dead source providers from blocking the final result screen for ages."""
    try:
        socket.setdefaulttimeout(7.0)
        _log('network fast-fail active: default socket timeout 7.0s')
    except Exception as exc:
        _log('network fast-fail socket setup failed: %s' % exc, xbmc.LOGWARNING)

    try:
        import requests
        original_request = requests.sessions.Session.request
        if getattr(requests.sessions.Session, '_nova_fast_fail_active', False):
            return

        def request_fast_fail(self, method, url, **kwargs):
            timeout = kwargs.get('timeout')
            if timeout is None:
                kwargs['timeout'] = 7
            elif isinstance(timeout, (int, float)) and timeout > 7:
                kwargs['timeout'] = 7
            elif isinstance(timeout, tuple):
                connect = min(timeout[0], 7) if timeout and timeout[0] else 7
                read = min(timeout[1], 7) if len(timeout) > 1 and timeout[1] else 7
                kwargs['timeout'] = (connect, read)
            return original_request(self, method, url, **kwargs)

        requests.sessions.Session.request = request_fast_fail
        requests.sessions.Session._nova_fast_fail_active = True
        _log('network fast-fail active: requests timeout max 7.0s')
    except Exception as exc:
        _log('network fast-fail requests setup failed: %s' % exc, xbmc.LOGWARNING)


def _patch_slow_source_logging():
    try:
        import threading
        import resources.lib.workers as workers
    except Exception as exc:
        _log('slow source logger setup import failed: %s' % exc, xbmc.LOGWARNING)
        return

    try:
        if getattr(workers, '_nova_slow_source_logging_active', False):
            return

        original_thread = workers.Thread
        slow_after = 5.0
        repeat_after = 5.0

        def source_label(target, args):
            try:
                target_name = getattr(target, '__name__', '') or ''
                if target_name == '_getSource' and len(args) >= 7:
                    return str(args[6] or 'unknown')
                if target_name == 'sourcesResolve' and args:
                    item = args[0]
                    if isinstance(item, dict):
                        return '%s/%s' % (item.get('provider') or 'unknown', item.get('source') or 'unknown')
                if args:
                    last = args[-1]
                    if isinstance(last, str) and len(last) < 80:
                        return last
                return target_name or 'unknown'
            except Exception:
                return 'unknown'

        def is_source_worker(target):
            try:
                return getattr(target, '__name__', '') in ('_getSource', 'sourcesResolve')
            except Exception:
                return False

        class DiagnosticThread(original_thread):
            def __init__(self, target, *args):
                target_name = getattr(target, '__name__', '') or ''
                label = source_label(target, args)
                original_thread.__init__(self, target, *args)
                self._nova_target_name = target_name
                self._nova_source_label = label
                self._nova_track_slow = is_source_worker(target)
                self._nova_started_at = 0.0
                self._nova_reported_timeout = False
                try:
                    if self._nova_track_slow:
                        self.daemon = True
                except Exception:
                    pass

            def is_alive(self):
                try:
                    alive = original_thread.is_alive(self)
                    if not alive:
                        return False
                    if self._nova_track_slow and self._nova_started_at:
                        elapsed = time.time() - self._nova_started_at
                        if elapsed >= slow_after:
                            if not self._nova_reported_timeout:
                                self._nova_reported_timeout = True
                                _log('source worker timed out for wait queue after %.1fs: %s (%s)' % (
                                    elapsed,
                                    self._nova_source_label,
                                    self._nova_target_name,
                                ), xbmc.LOGWARNING)
                            return False
                    return alive
                except Exception:
                    try:
                        return original_thread.is_alive(self)
                    except Exception:
                        return False

            def start(self):
                result = None
                try:
                    self._nova_started_at = time.time()
                    result = original_thread.start(self)
                    if self._nova_track_slow and self.is_alive():
                        _log('source worker started: %s (%s)' % (self._nova_source_label, self._nova_target_name), xbmc.LOGDEBUG)
                        monitor = threading.Thread(target=self._nova_monitor_slow_source)
                        monitor.daemon = True
                        monitor.start()
                except Exception:
                    pass
                return result

            def _nova_monitor_slow_source(self):
                try:
                    next_log = slow_after
                    while True:
                        time.sleep(0.5)
                        if not self.is_alive():
                            return
                        elapsed = time.time() - self._nova_started_at
                        if elapsed >= next_log:
                            _log('SLOW SOURCE still running after %.1fs: %s (%s)' % (
                                elapsed,
                                self._nova_source_label,
                                self._nova_target_name,
                            ), xbmc.LOGWARNING)
                            next_log += repeat_after
                except Exception:
                    pass

            def run(self):
                try:
                    return original_thread.run(self)
                finally:
                    try:
                        if self._nova_track_slow and self._nova_started_at:
                            elapsed = time.time() - self._nova_started_at
                            if elapsed >= slow_after:
                                _log('SLOW SOURCE finished after %.1fs: %s (%s)' % (
                                    elapsed,
                                    self._nova_source_label,
                                    self._nova_target_name,
                                ), xbmc.LOGWARNING)
                    except Exception:
                        pass

        workers.Thread = DiagnosticThread
        workers._nova_slow_source_logging_active = True
        _log('slow source logger active: threshold %.1fs' % slow_after)
    except Exception as exc:
        _log('slow source logger setup failed: %s' % exc, xbmc.LOGWARNING)


def _nova_source_provider_key(item):
    try:
        text = ' '.join([
            str(item.get('provider') or ''),
            str(item.get('source') or ''),
            str(item.get('url') or ''),
        ]).lower()
        if 'moflix' in text or 'vidara' in text or 'rpmplay' in text:
            return 0
        if 'filmpalast' in text or 'film palast' in text:
            return 1
        return 20
    except Exception:
        return 20


def _nova_source_quality_height(item):
    try:
        if item.get('_nova_detected_quality'):
            text = str(item.get('_nova_detected_quality') or '').lower()
            matches = []
            for match in re.finditer(r'(?<!\d)(\d{3,4})\s*p\b', text, flags=re.I):
                try:
                    value = int(match.group(1))
                    if 240 <= value <= 2160:
                        matches.append(value)
                except Exception:
                    pass
            if matches:
                return max(matches)
            return 0
        texts = [
            str(item.get('quality') or ''),
            str(item.get('info') or ''),
            str(item.get('label') or ''),
        ]
        text = ' '.join(texts).lower()
        if '4k' in text or '2160' in text:
            return 2160
        if '2k' in text or '1440' in text:
            return 1440
        matches = []
        for match in re.finditer(r'(?<!\d)(\d{3,4})\s*p\b', text, flags=re.I):
            try:
                value = int(match.group(1))
                if 240 <= value <= 2160:
                    matches.append(value)
            except Exception:
                pass
        if matches:
            return max(matches)
        if re.search(r'\bfhd\b', text):
            return 1080
        if re.search(r'\bhd\b', text):
            return 720
        if re.search(r'\bsd\b', text):
            return 480
    except Exception:
        pass
    return 0


def _nova_source_quality_key(item):
    height = _nova_source_quality_height(item)
    if height > 0:
        if not item.get('_nova_detected_quality'):
            return 9000 - min(height, 480)
        return -height
    return 9999


def _nova_display_quality(item):
    try:
        if item.get('_nova_detected_quality'):
            return str(item.get('_nova_detected_quality') or '')
        reason = str(item.get('_nova_precheck_reason') or '').lower()
        if reason in ('hls', 'video', 'bytes', 'octet-stream') or reason.startswith('hls') or reason.startswith('video') or reason.startswith('bytes'):
            return 'SD?'
        return str(item.get('quality') or '')
    except Exception:
        return str(item.get('quality') or '')


def _nova_source_language_key(item):
    try:
        text = ' '.join([
            str(item.get('provider') or ''),
            str(item.get('source') or ''),
            str(item.get('info') or ''),
            str(item.get('label') or ''),
            str(item.get('url') or ''),
        ]).lower()
        if re.search(r'(\(|\[|\b)(de|ger|german|deutsch)(\)|\]|\b)', text):
            return 0
        if re.search(r'[\(\[]\s*in\s*[\)\]]', text):
            return 8
        if re.search(r'(\(|\[|\b)(en|eng|english|englisch|fr|french|franz|it|ital|es|span|pl|pol|tr|turk|jap|jpn|jp)(\)|\]|\b)', text):
            return 8
        if any(marker in text for marker in (
            'serienstream', 'aniworld', 'kinokiste', 'kkiste',
            'movie2k', 'filmpalast', 'film palast', 'megakino',
            'streaming-archiv', 'archivnavigator',
        )):
            return 0
        return 3
    except Exception:
        return 3


def _nova_source_hoster_key(item):
    text = ' '.join([
        str(item.get('source') or ''),
        str(item.get('url') or ''),
        str(item.get('info') or ''),
    ]).lower()
    # Moflix: keep the same practical order as Streaming-Archiv, then let
    # the real precheck response time decide between the reachable mirrors.
    if 'upns' in text or 'mirror 5' in text:
        return 0
    if 'rpmplay' in text or 'mirror 7' in text:
        return 1
    if 'moflix-stream.click' in text or 'mirror 2' in text:
        return 8
    # Vidara-Movflix mirrors are reachable sometimes, but they are the ones
    # that most often start slower or return stale HLS links. Keep Movflix as
    # the top provider group, but put this mirror at the end of that group.
    if 'vidara' in text or 'mirror 3' in text:
        return 9
    return 20


def _nova_is_moflix_hls_url(url):
    try:
        text = unquote_plus(str(url or '')).lower()
        if '.m3u8' not in text:
            return False
        if 'moflix' in text:
            return True
        # Fast Moflix app mirrors resolve to these IP hosts; the useful
        # referer/origin marker is normally still in the Kodi header suffix.
        return '185.237.106.' in text or '185.237.107.' in text
    except Exception:
        return False


def _nova_apply_moflix_hls_playback(listitem, url):
    try:
        if listitem is None or not _nova_is_moflix_hls_url(url):
            return False
        return _nova_apply_hls_playback(listitem, url)
    except Exception:
        return False


def _nova_apply_hls_playback(listitem, url):
    try:
        if listitem is None or '.m3u8' not in str(url or '').lower():
            return False
        try:
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except Exception:
            pass
        try:
            listitem.setMimeType('application/vnd.apple.mpegurl')
        except Exception:
            pass
        try:
            if '|' in str(url or ''):
                header = str(url).split('|', 1)[1]
                listitem.setProperty('inputstream.adaptive.stream_headers', header)
                try:
                    version = int(str(xbmc.getInfoLabel('System.BuildVersion') or '0').split('.', 1)[0])
                except Exception:
                    version = 21
                if version > 19:
                    listitem.setProperty('inputstream.adaptive.manifest_headers', header)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _nova_is_vidsonic_hls_url(url, marker=''):
    try:
        text = unquote_plus(' '.join([str(url or ''), str(marker or '')])).lower()
        return '.m3u8' in text and ('vidsonic' in text or 'st-us-01.vidsonic.net' in text)
    except Exception:
        return False


def _nova_join_kodi_url_headers(base, headers):
    try:
        headers = headers or {}
        parts = []
        for key, value in headers.items():
            if not key or value is None:
                continue
            parts.append('%s=%s' % (str(key), quote_plus(str(value))))
        return str(base or '') + (('|' + '&'.join(parts)) if parts else '')
    except Exception:
        return str(base or '')


def _nova_normalize_vidsonic_hls_url(url):
    try:
        if not _nova_is_vidsonic_hls_url(url):
            return url, False
        base, headers = _nova_split_kodi_url_headers(url)
        if not base:
            return url, False
        headers = dict(headers or {})
        # DEZOR/VoD-Huhu plays the same Vidsonic HLS links smoothly with this
        # browser header set and without forcing inputstream.adaptive. Keep the
        # Archiv Navigator direct-play handoff aligned with that path.
        headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36'
        headers['Referer'] = 'https://vidsonic.net/'
        headers['Origin'] = 'https://vidsonic.net'
        return _nova_join_kodi_url_headers(base, headers), True
    except Exception:
        return url, False


def _nova_apply_native_hls_playback(listitem, url):
    try:
        if listitem is None or '.m3u8' not in str(url or '').lower():
            return False
        try:
            listitem.setMimeType('application/vnd.apple.mpegurl')
        except Exception:
            pass
        try:
            listitem.setProperty('IsPlayable', 'true')
        except Exception:
            pass
        return True
    except Exception:
        return False


def _nova_apply_direct_video_playback(listitem, url):
    try:
        if listitem is None or '://' not in str(url or ''):
            return False
        try:
            listitem.setProperty('IsPlayable', 'true')
        except Exception:
            pass
        if '.m3u8' in str(url or '').lower():
            return _nova_apply_hls_playback(listitem, url)
        try:
            listitem.setMimeType('video/mp4')
        except Exception:
            pass
        return True
    except Exception:
        return False


def _handle_direct_prechecked_hls_playitem(query):
    """Bypass stale provider resolvers for already prechecked direct HLS links.

    VAVOO/Vidsonic sources are resolved during our Quellenpruefung and the
    playable master.m3u8 is stored in the source item. The original playItem
    path can still call the VAVOO resolver afterwards, which may return
    "kein Ergebnis" even though the checked HLS URL works. If the item is
    already direct and prechecked, play that HLS URL immediately.
    """
    try:
        params = _query_params(query)
        if _first(params, 'action') != 'playItem':
            return False
        source_blob = _first(params, 'source')
        if not source_blob:
            return False
        data = json.loads(source_blob)
        item = data[0] if isinstance(data, list) and data else data
        if not isinstance(item, dict):
            return False
        url = str(item.get('url') or '')
        marker = ' '.join([
            str(item.get('provider') or ''),
            str(item.get('source') or ''),
            str(item.get('label') or ''),
            str(item.get('info') or ''),
        ]).lower()
        if item.get('direct') is not True or '://' not in url:
            return False
        if _nova_is_bad_moflix_streamclick(item, url):
            _log('direct prechecked playItem blocked stale Moflix mirror: source=%s domain=%s' % (
                item.get('source'),
                _nova_domain_from_url(url),
            ), xbmc.LOGWARNING)
            return False

        vidsonic_hls = _nova_is_vidsonic_hls_url(url, marker)
        if vidsonic_hls:
            url, normalized = _nova_normalize_vidsonic_hls_url(url)
            if normalized:
                _log('Vidsonic HLS headers normalized for native playback: %s' % _nova_domain_from_url(url))

        listitem = xbmcgui.ListItem(path=url)
        try:
            listitem.setLabel(_first(params, 'title') or str(item.get('title') or item.get('label') or ''))
        except Exception:
            pass
        if vidsonic_hls:
            _nova_apply_native_hls_playback(listitem, url)
        else:
            _nova_apply_direct_video_playback(listitem, url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        _log('direct prechecked playItem resolved: provider=%s source=%s domain=%s reason=%s' % (
            item.get('provider'),
            item.get('source'),
            _nova_domain_from_url(url),
            item.get('_nova_precheck_reason') or '',
        ))
        return True
    except Exception as exc:
        _log('direct prechecked HLS playItem failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _patch_moflix_hls_playback():
    """Play Moflix HLS streams the same way Streaming-Archiv does.

    Archiv Navigator's compiled player creates a normal ListItem and hands the
    HLS URL to Kodi. On Android that can start slowly or buffer more heavily.
    Streaming-Archiv explicitly marks Moflix .m3u8 as HLS/inputstream.adaptive
    and passes the stream headers through; mirror playback is noticeably
    smoother there. Patch the generic ListItem/resolve path before the add-on
    imports its control aliases, so every Movflix item gets those properties.
    """
    try:
        if getattr(xbmcgui, '_nova_moflix_hls_active', False):
            return

        original_listitem = xbmcgui.ListItem

        def listitem_moflix_hls(*args, **kwargs):
            item = original_listitem(*args, **kwargs)
            try:
                path = kwargs.get('path') or ''
                if not path and len(args) == 1 and isinstance(args[0], str) and '://' in args[0]:
                    path = args[0]
                if _nova_apply_moflix_hls_playback(item, path):
                    _log('Moflix HLS inputstream active on ListItem: %s' % _nova_domain_from_url(path))
            except Exception:
                pass
            return item

        xbmcgui.ListItem = listitem_moflix_hls
        xbmcgui._nova_moflix_hls_active = True

        original_resolved = xbmcplugin.setResolvedUrl

        def set_resolved_moflix_hls(handle, succeeded, listitem, *args, **kwargs):
            try:
                path = ''
                try:
                    path = listitem.getPath()
                except Exception:
                    path = ''
                if _nova_apply_moflix_hls_playback(listitem, path):
                    _log('Moflix HLS inputstream active on setResolvedUrl: %s' % _nova_domain_from_url(path))
            except Exception:
                pass
            return original_resolved(handle, succeeded, listitem, *args, **kwargs)

        xbmcplugin.setResolvedUrl = set_resolved_moflix_hls
        _log('Moflix HLS playback patch active')
    except Exception as exc:
        _log('Moflix HLS playback patch failed: %s' % exc, xbmc.LOGWARNING)


def _nova_source_label(index, item):
    try:
        provider = str(item.get('provider') or '').upper()
        source = str(item.get('source') or '')
        quality = _nova_display_quality(item)
        info = _nova_clean_source_info_label(item)
        parts = ['%02d' % index]
        if provider:
            parts.append('[B]%s[/B]' % provider)
        if source:
            parts.append(source)
        if quality:
            parts.append('[B][I]%s[/I][/B]' % quality)
        if info:
            parts.append(info)
        return ' | '.join(parts)
    except Exception:
        return item.get('label') or ''


def _nova_clean_source_info_label(item):
    try:
        info = str(item.get('info') or '').strip()
        language = str(item.get('language') or '').strip().lower()
        text = info.replace('_', ' ').strip()
        text = re.sub(r'\b(vavoo|huhu|vod)\b', ' ', text, flags=re.I)
        text = re.sub(r'\b(4k|2160p|1440p|1080p|720p|576p|540p|480p|360p|fhd|hd|sd)\b', ' ', text, flags=re.I)
        text = re.sub(r'\s+', ' ', text).strip(' -_/|')
        if not text:
            if language in ('de', 'ger', 'german', 'deutsch'):
                return 'DE'
            if language in ('en', 'eng', 'english', 'englisch'):
                return 'EN'
            return ''
        if text.lower() in ('de', 'ger', 'german', 'deutsch'):
            return 'DE'
        if text.lower() in ('en', 'eng', 'english', 'englisch'):
            return 'EN'
        return text
    except Exception:
        return str(item.get('info') or '').strip()


def _nova_split_kodi_url_headers(url):
    url = str(url or '')
    if '|' not in url:
        return url, {}
    base, header_blob = url.split('|', 1)
    headers = {}
    for part in header_blob.split('&'):
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        key = key.strip()
        if not key:
            continue
        try:
            headers[key] = unquote_plus(value)
        except Exception:
            headers[key] = value
    return base, headers


def _nova_domain_from_url(url):
    try:
        url = _nova_split_kodi_url_headers(url)[0]
        return urlsplit(str(url or '')).netloc.lower()
    except Exception:
        return ''


def _nova_is_bad_moflix_streamclick(item, resolved_url=''):
    """Known stale Movflix mirror that passes playlist check but fails in Kodi."""
    try:
        text = ' '.join([
            str(item.get('provider') or ''),
            str(item.get('source') or ''),
            str(item.get('label') or ''),
            str(item.get('url') or ''),
            str(resolved_url or ''),
        ]).lower()
        if 'moflix' not in text:
            return False
        if 'moflix-stream.click' not in text:
            return False
        # Seen in Kodi log as precheck OK, then OpenDemuxStream demuxer error.
        # Other Movflix mirrors such as vidara.to and streamtape.com stay alive.
        if 'directwholesale.shop' in text or 'datastorageservice.space' in text or 'aurorionhealth.store' in text:
            return True
        if '/hls3/' in text and 'master.txt' in text:
            return True
    except Exception:
        pass
    return False


def _nova_hls_quality_from_bytes(data):
    try:
        text = (data or b'').decode('utf-8', 'ignore')
        heights = []
        for match in re.finditer(r'RESOLUTION\s*=\s*\d+\s*x\s*(\d+)', text, flags=re.I):
            try:
                height = int(match.group(1))
                if height > 0:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _nova_mp4_quality_from_bytes(data):
    try:
        blob = data or b''
        heights = []
        start = 0
        while True:
            pos = blob.find(b'tkhd', start)
            if pos < 4:
                break
            atom_start = pos - 4
            try:
                atom_size = int.from_bytes(blob[atom_start:atom_start + 4], 'big')
                atom_end = atom_start + atom_size
                if 32 <= atom_size <= len(blob) - atom_start and atom_end <= len(blob):
                    width = int.from_bytes(blob[atom_end - 8:atom_end - 4], 'big') >> 16
                    height = int.from_bytes(blob[atom_end - 4:atom_end], 'big') >> 16
                    if 240 <= height <= 2160 and 320 <= width <= 4096:
                        heights.append(height)
            except Exception:
                pass
            start = pos + 4
        for codec in (b'avc1', b'hvc1', b'hev1', b'mp4v', b'encv'):
            start = 0
            while True:
                pos = blob.find(codec, start)
                if pos < 4:
                    break
                atom_start = pos - 4
                if atom_start + 28 <= len(blob):
                    try:
                        width = int.from_bytes(blob[atom_start + 24:atom_start + 26], 'big')
                        height = int.from_bytes(blob[atom_start + 26:atom_start + 28], 'big')
                        if 240 <= height <= 2160 and 320 <= width <= 4096:
                            heights.append(height)
                    except Exception:
                        pass
                start = pos + 4
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _nova_quality_from_url(url):
    try:
        text = unquote_plus(str(url or '')).lower()
        matches = re.findall(r'(?<!\d)(\d{3,4})p(?!\d)', text)
        heights = []
        for match in matches:
            try:
                height = int(match)
                if 240 <= height <= 2160:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _nova_tail_quality_from_url(base_url, headers, timeout=3.0):
    try:
        tail_headers = dict(headers or {})
        tail_headers['Range'] = 'bytes=-1048576'
        request = Request(base_url, headers=tail_headers)
        response = _nova_urlopen(request, timeout=min(float(timeout or 3.0), 2.5))
        data = response.read(1048576) or b''
        return _nova_mp4_quality_from_bytes(data)
    except Exception:
        return ''


def _nova_probe_stream_url(url, timeout=3.0):
    """Small real reachability check for the resolved stream URL.

    This does not download the movie. It only requests the first bytes and
    rejects obvious non-video responses like HTML/JSON/PNG error pages.
    """
    try:
        base_url, headers = _nova_split_kodi_url_headers(url)
        if not base_url or '://' not in base_url:
            return False, 'empty'
        headers = dict(headers or {})
        headers.setdefault('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
        headers.setdefault('Accept', '*/*')
        headers.setdefault('Range', 'bytes=0-524287')
        request = Request(base_url, headers=headers)
        response = _nova_urlopen(request, timeout=timeout)
        content_type = str(response.headers.get('Content-Type') or '').lower()
        data = response.read(524288) or b''
        lower_head = data[:256].lower()

        if 'image/' in content_type or data.startswith(b'\x89PNG') or data.startswith(b'GIF8') or data.startswith(b'\xff\xd8'):
            return False, 'image'
        if 'text/html' in content_type or b'<html' in lower_head or b'<!doctype html' in lower_head:
            return False, 'html'
        if 'application/json' in content_type and b'#extm3u' not in lower_head:
            return False, 'json'

        if '.m3u8' in base_url.lower() or 'mpegurl' in content_type or b'#extm3u' in lower_head:
            if b'#extm3u' in lower_head or 'mpegurl' in content_type:
                real_quality = _nova_hls_quality_from_bytes(data) or _nova_quality_from_url(base_url)
                return True, 'hls:%s' % real_quality if real_quality else 'hls'
            return False, 'hls-empty'
        if 'video/' in content_type or 'octet-stream' in content_type:
            real_quality = _nova_mp4_quality_from_bytes(data) or _nova_quality_from_url(base_url) or _nova_tail_quality_from_url(base_url, headers, timeout)
            return True, 'video:%s' % real_quality if real_quality else 'video'
        if data and not lower_head.strip().startswith((b'{', b'[', b'<')):
            real_quality = _nova_mp4_quality_from_bytes(data) or _nova_quality_from_url(base_url) or _nova_tail_quality_from_url(base_url, headers, timeout)
            return True, 'bytes:%s' % real_quality if real_quality else (content_type or 'bytes')
        return False, content_type or 'unknown'
    except Exception as exc:
        return False, str(exc)[:80]


def _nova_apply_detected_quality(item, probe_reason):
    try:
        match = re.search(r'(?:hls|video|bytes):(\d{3,4}p)', str(probe_reason or ''), flags=re.I)
        if not match:
            return
        real_quality = match.group(1).lower()
        old_quality = str(item.get('quality') or '')
        item['_nova_detected_quality'] = real_quality
        if old_quality.lower() != real_quality:
            item['_nova_original_quality'] = old_quality
            item['quality'] = real_quality
    except Exception:
        pass


def _nova_resolve_source_for_precheck(source_owner, item):
    try:
        provider = item.get('provider')
        call = None
        for provider_name, provider_call in getattr(source_owner, 'sourceDict', []) or []:
            if provider_name == provider:
                call = provider_call
                break
        if call is None:
            return None, 'provider-missing'

        url = item.get('url')
        direct = item.get('direct')
        local = item.get('local', False)
        resolved = call.resolve(url)
        if resolved is None or ('://' not in str(resolved) and not local):
            return None, 'no-resolve'

        if direct is not True:
            try:
                import resolveurl as resolver
                hmf = resolver.HostedMediaFile(url=resolved, include_disabled=True, include_universal=False)
                if hmf.valid_url():
                    resolved2 = hmf.resolve()
                    if resolved2:
                        resolved = resolved2
            except Exception:
                pass
        return resolved, 'resolved'
    except Exception as exc:
        return None, str(exc)[:80]


def _nova_precheck_sources_batched(source_owner, ordered):
    """Playable-source check without flooding Kodi/ResolveURL.

    The previous all-at-once check could keep resolver threads alive while the
    user already started a stream. Waiting for all of them fixed that stall, but
    could freeze the dialog at 90% when one resolver ignored cancellation. This
    version checks only small batches and never blocks forever on a bad hoster.
    """
    try:
        candidates = list(ordered or [])
        if not candidates:
            return ordered
        max_items = min(len(candidates), 30)
        timeout = 3.0
        global_budget = 18.0
        batch_size = 4
        target_playable = 14
        started = time.time()
        checked = []
        completed = 0
        playable_count = 0
        progress = None

        def progress_update(percent, message=''):
            try:
                if progress is not None:
                    progress.update(int(max(0, min(100, percent))), message=message)
            except TypeError:
                try:
                    progress.update(int(max(0, min(100, percent))), message)
                except Exception:
                    pass
            except Exception:
                pass

        def check_one(index_item):
            index, item = index_item
            item = dict(item)
            item['_nova_precheck_index'] = index
            item['_nova_raw_domain'] = _nova_domain_from_url(item.get('url'))
            t0 = time.time()
            resolved, resolve_reason = _nova_resolve_source_for_precheck(source_owner, item)
            if not resolved:
                return False, time.time() - t0, item, resolve_reason
            item['_nova_resolved_domain'] = _nova_domain_from_url(resolved)
            if _nova_is_bad_moflix_streamclick(item, resolved):
                return False, time.time() - t0, item, 'stale-moflix-streamclick'
            ok, probe_reason = _nova_probe_stream_url(resolved, timeout=timeout)
            elapsed = time.time() - t0
            if ok:
                item['url'] = resolved
                item['direct'] = True
                _nova_apply_detected_quality(item, probe_reason)
                item['_nova_precheck_elapsed'] = elapsed
                item['_nova_precheck_reason'] = probe_reason
            return ok, elapsed, item, probe_reason

        try:
            progress = xbmcgui.DialogProgress()
            progress.create('Quellenprüfung', 'Streams werden geprüft...')
            progress_update(0, '0 von %d geprüft' % max_items)
        except Exception as exc:
            progress = None
            _log('source precheck progress setup failed: %s' % exc, xbmc.LOGWARNING)

        remaining = list(enumerate(candidates[:max_items]))
        stop_requested = False
        while remaining and not stop_requested:
            if time.time() - started >= global_budget:
                _log('source precheck reached %.1fs budget' % global_budget, xbmc.LOGWARNING)
                break
            if playable_count >= target_playable:
                _log('source precheck target reached: %d playable sources' % playable_count)
                break

            batch = remaining[:batch_size]
            remaining = remaining[batch_size:]
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=min(batch_size, len(batch)))
            futures = [executor.submit(check_one, index_item) for index_item in batch]
            timed_out = False
            try:
                batch_timeout = max(1.0, min(6.0, global_budget - (time.time() - started)))
                for future in concurrent.futures.as_completed(futures, timeout=batch_timeout):
                    try:
                        ok, elapsed, item, reason = future.result(timeout=0)
                        checked.append((ok, elapsed, item, reason))
                        completed += 1
                        if ok:
                            playable_count += 1
                        _log('source precheck %s %.2fs: %s / %s / raw=%s / resolved=%s / %s' % (
                            'OK' if ok else 'DROP',
                            elapsed,
                            item.get('provider'),
                            '%s %s' % (item.get('source'), ('real=%s' % item.get('_nova_detected_quality')) if item.get('_nova_detected_quality') else ''),
                            item.get('_nova_raw_domain') or _nova_domain_from_url(item.get('url')),
                            item.get('_nova_resolved_domain') or '-',
                            reason,
                        ))
                    except Exception as exc:
                        completed += 1
                        _log('source precheck future failed: %s' % exc, xbmc.LOGWARNING)
                    progress_update(
                        100.0 * completed / float(max_items or 1),
                        '%d funktionierende von %d geprüft' % (playable_count, completed)
                    )
                    if playable_count >= target_playable or time.time() - started >= global_budget:
                        stop_requested = True
                        break
            except concurrent.futures.TimeoutError:
                timed_out = True
                # Do not abort the whole precheck just because one provider in
                # the current small batch hangs.  Skip that slow batch item and
                # continue with the remaining candidates while the global budget
                # still allows it; otherwise the first run may keep only the
                # early Moflix entries and miss later playable sources.
                _log('source precheck batch timeout; skipping slow batch items and continuing', xbmc.LOGWARNING)
            finally:
                for future in futures:
                    try:
                        future.cancel()
                    except Exception:
                        pass
                try:
                    executor.shutdown(wait=not timed_out, cancel_futures=True)
                except TypeError:
                    executor.shutdown(wait=not timed_out)

        try:
            progress_update(100, '%d funktionierende Quellen' % playable_count)
            if progress is not None:
                progress.close()
        except Exception:
            pass

        good = [item for ok, elapsed, item, reason in checked if ok]
        if not good:
            _log('source precheck found no playable source; keeping original list', xbmc.LOGWARNING)
            return ordered

        good = sorted(
            good,
            key=lambda item: (
                _nova_source_language_key(item),
                _nova_source_quality_key(item),
                _nova_source_provider_key(item),
                _nova_source_hoster_key(item),
                float(item.get('_nova_precheck_elapsed') or 99.0),
            )
        )
        _log('source precheck kept %d/%d sources in %.1fs' % (len(good), max_items, time.time() - started))
        return good
    except Exception as exc:
        _log('source precheck batched failed: %s' % exc, xbmc.LOGWARNING)
        return ordered


def _nova_precheck_sources(source_owner, ordered):
    try:
        candidates = list(ordered or [])
        if not candidates:
            return ordered
        max_items = min(len(candidates), 30)
        timeout = 3.0
        global_budget = 20.0
        workers = min(8, max_items)
        started = time.time()
        checked = []
        completed = 0
        playable_count = 0
        progress = None

        def progress_update(percent, message=''):
            try:
                if progress is not None:
                    progress.update(int(max(0, min(100, percent))), message=message)
            except TypeError:
                try:
                    progress.update(int(max(0, min(100, percent))), message)
                except Exception:
                    pass
            except Exception:
                pass

        def check_one(index_item):
            index, item = index_item
            item = dict(item)
            item['_nova_precheck_index'] = index
            raw_domain = _nova_domain_from_url(item.get('url'))
            item['_nova_raw_domain'] = raw_domain
            t0 = time.time()
            resolved, resolve_reason = _nova_resolve_source_for_precheck(source_owner, item)
            if not resolved:
                return False, time.time() - t0, item, resolve_reason
            item['_nova_resolved_domain'] = _nova_domain_from_url(resolved)
            if _nova_is_bad_moflix_streamclick(item, resolved):
                return False, time.time() - t0, item, 'stale-moflix-streamclick'
            ok, probe_reason = _nova_probe_stream_url(resolved, timeout=timeout)
            elapsed = time.time() - t0
            if ok:
                item['url'] = resolved
                item['direct'] = True
                _nova_apply_detected_quality(item, probe_reason)
                item['_nova_precheck_elapsed'] = elapsed
                item['_nova_precheck_reason'] = probe_reason
            return ok, elapsed, item, probe_reason

        try:
            progress = xbmcgui.DialogProgress()
            progress.create('Quellenprüfung', 'Streams werden geprüft...')
            progress_update(0, '0 von %d geprüft' % max_items)
        except Exception as exc:
            progress = None
            _log('source precheck progress setup failed: %s' % exc, xbmc.LOGWARNING)

        # Check the whole candidate set in one pass.  The previous batched
        # variant could stop after an early slow batch and then only show the
        # first Moflix hits, while a second click found many more cached/late
        # sources.  Keep one global timeout, but do not split into batches.
        executor = None
        future_map = {}
        try:
            original_thread = threading.Thread

            def daemon_thread(*args, **kwargs):
                thread = original_thread(*args, **kwargs)
                try:
                    thread.daemon = True
                except Exception:
                    pass
                return thread

            threading.Thread = daemon_thread
            try:
                executor = concurrent.futures.ThreadPoolExecutor(max_workers=workers)
                future_map = {
                    executor.submit(check_one, (idx, item)): idx
                    for idx, item in enumerate(candidates[:max_items])
                }
            finally:
                threading.Thread = original_thread

            try:
                future_iter = concurrent.futures.as_completed(future_map, timeout=global_budget)
                for future in future_iter:
                    try:
                        ok, elapsed, item, reason = future.result(timeout=0)
                        checked.append((ok, elapsed, item, reason))
                        completed += 1
                        if ok:
                            playable_count += 1
                        _log('source precheck %s %.2fs: %s / %s / raw=%s / resolved=%s / %s' % (
                            'OK' if ok else 'DROP',
                            elapsed,
                            item.get('provider'),
                            '%s %s' % (item.get('source'), ('real=%s' % item.get('_nova_detected_quality')) if item.get('_nova_detected_quality') else ''),
                            item.get('_nova_raw_domain') or _nova_domain_from_url(item.get('url')),
                            item.get('_nova_resolved_domain') or '-',
                            reason,
                        ))
                    except Exception as exc:
                        completed += 1
                        _log('source precheck future failed: %s' % exc, xbmc.LOGWARNING)
                    progress_update(
                        100.0 * completed / float(max_items or 1),
                        '%d funktionierende von %d geprüft' % (playable_count, completed)
                    )
                    if time.time() - started >= global_budget:
                        break
            except concurrent.futures.TimeoutError:
                _log('source precheck reached %.1fs budget' % global_budget, xbmc.LOGWARNING)
        finally:
            for future in future_map:
                try:
                    future.cancel()
                except Exception:
                    pass
            try:
                if executor is not None:
                    executor.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                if executor is not None:
                    executor.shutdown(wait=False)
            try:
                progress_update(100, '%d funktionierende Quellen' % playable_count)
                if progress is not None:
                    progress.close()
            except Exception:
                pass

        good = [item for ok, elapsed, item, reason in checked if ok]
        if not good:
            _log('source precheck found no playable source; keeping original list', xbmc.LOGWARNING)
            return ordered

        good_keys = set()
        for item in good:
            good_keys.add((item.get('provider'), item.get('source'), item.get('url')))

        # If the budget ended before all candidates were checked, do not append
        # unchecked items. The user asked for a clean playable list.
        good = sorted(
            good,
            key=lambda item: (
                _nova_source_language_key(item),
                _nova_source_quality_key(item),
                _nova_source_provider_key(item),
                _nova_source_hoster_key(item),
                float(item.get('_nova_precheck_elapsed') or 99.0),
            )
        )
        _log('source precheck kept %d/%d sources in %.1fs' % (len(good), len(candidates[:max_items]), time.time() - started))
        return good
    except concurrent.futures.TimeoutError:
        try:
            good = []
            _log('source precheck global timeout; keeping original list', xbmc.LOGWARNING)
            return ordered
        except Exception:
            return ordered
    except Exception as exc:
        _log('source precheck failed: %s' % exc, xbmc.LOGWARNING)
        return ordered


def _patch_source_result_order():
    """Put useful playable streams first after the add-on has collected them.

    The upstream source filter shuffles sources before applying the quality
    filter. That makes bad/slow mirrors appear above the known-good ones. Keep
    the original filtering, but impose our practical order afterwards:
    1080p first, then Moflix/Filmpalast, then stable Moflix mirrors.
    """
    try:
        import resources.lib.sources as sources_module
        source_class = getattr(sources_module, 'sources', None)
        if source_class is None or getattr(source_class, '_nova_result_order_active', False):
            return
        original_filter = source_class.sourcesFilter

        def sources_filter_ordered(self, *args, **kwargs):
            result = original_filter(self, *args, **kwargs)
            try:
                ordered = sorted(
                    list(getattr(self, 'sources', []) or []),
                    key=lambda item: (
                        _nova_source_language_key(item),
                        _nova_source_quality_key(item),
                        _nova_source_provider_key(item),
                        _nova_source_hoster_key(item),
                        str(item.get('source') or '').lower(),
                    )
                )
                ordered = _nova_precheck_sources(self, ordered)
                for pos, item in enumerate(ordered, 1):
                    item['label'] = _nova_source_label(pos, item)
                self.sources = ordered
                _log('source result order active: %d sources sorted/prechecked' % len(ordered))
            except Exception as exc:
                _log('source result order failed: %s' % exc, xbmc.LOGWARNING)
            return result

        source_class.sourcesFilter = sources_filter_ordered
        source_class._nova_result_order_active = True
        _log('source result order patch active')
    except Exception as exc:
        _log('source result order patch failed: %s' % exc, xbmc.LOGWARNING)


def _rewrite_old_addon_refs(value):
    if isinstance(value, str) and OLD_ADDON_ID in value:
        return value.replace(OLD_ADDON_ID, ADDON_ID)
    return value


def _patch_old_addon_id_aliases():
    try:
        original_addon = xbmcaddon.Addon

        def addon_alias(addon_id=None, *args, **kwargs):
            if addon_id == OLD_ADDON_ID:
                addon_id = ADDON_ID
            return original_addon(addon_id, *args, **kwargs) if addon_id is not None else original_addon(*args, **kwargs)

        xbmcaddon.Addon = addon_alias
    except Exception as exc:
        _log('old id Addon alias failed: %s' % exc, xbmc.LOGWARNING)

    try:
        original_xbmcvfs_translate = xbmcvfs.translatePath

        def xbmcvfs_translate_alias(path):
            return original_xbmcvfs_translate(_rewrite_old_addon_refs(path))

        xbmcvfs.translatePath = xbmcvfs_translate_alias
    except Exception as exc:
        _log('old id xbmcvfs translate alias failed: %s' % exc, xbmc.LOGWARNING)

    try:
        original_xbmc_translate = xbmc.translatePath

        def xbmc_translate_alias(path):
            return original_xbmc_translate(_rewrite_old_addon_refs(path))

        xbmc.translatePath = xbmc_translate_alias
    except Exception:
        pass

    try:
        original_execute_builtin = xbmc.executebuiltin

        def execute_builtin_alias(command, *args, **kwargs):
            return original_execute_builtin(_rewrite_old_addon_refs(command), *args, **kwargs)

        xbmc.executebuiltin = execute_builtin_alias
    except Exception as exc:
        _log('old id builtin alias failed: %s' % exc, xbmc.LOGWARNING)

    try:
        _log('old id aliases active: %s -> %s' % (OLD_ADDON_ID, ADDON_ID))
    except Exception:
        pass


def _tmdb_image_size(url, size):
    url = str(url or '')
    if 'image.tmdb.org/t/p/' not in url:
        return url
    parts = url.split('/t/p/', 1)
    if len(parts) != 2 or '/' not in parts[1]:
        return url
    return parts[0] + '/t/p/' + size + '/' + parts[1].split('/', 1)[1]


def _tmdb_image_from_path(path, size='w154'):
    path = str(path or '')
    if not path:
        return ''
    if path.startswith('http://') or path.startswith('https://'):
        return _tmdb_image_size(path, size)
    return 'https://image.tmdb.org/t/p/%s%s' % (size, path if path.startswith('/') else '/' + path)


def _year_from_date(value):
    try:
        match = re.search(r'\b(19|20)\d{2}\b', str(value or ''))
        return int(match.group(0)) if match else 0
    except Exception:
        return 0


def _lite_plot(item):
    try:
        rating = float(item.get('vote_average') or 0)
    except Exception:
        rating = 0.0
    try:
        votes = int(item.get('vote_count') or 0)
    except Exception:
        votes = 0
    overview = str(item.get('overview') or '').strip()
    if rating or votes:
        return '[COLOR blue]Bewertung :  %.1f  (%s)[/COLOR]%s%s' % (
            rating,
            ('{:,}'.format(votes)).replace(',', '.'),
            '\n\n' if overview else '',
            overview,
        )
    return overview


def _lite_meta_from_tmdb_result(item, media_type):
    try:
        item = dict(item or {})
        tmdb_id = str(item.get('id') or '')
        if not tmdb_id:
            return None
        is_tv = str(media_type or '').lower() in ('tv', 'tvshow', 'series', 'serie')
        title = str(item.get('name') if is_tv else item.get('title') or '').strip()
        if not title:
            title = str(item.get('original_name') if is_tv else item.get('original_title') or '').strip()
        if not title:
            return None
        original_title = str(item.get('original_name') if is_tv else item.get('original_title') or title).strip() or title
        premiered = str(item.get('first_air_date') if is_tv else item.get('release_date') or '').strip()
        poster = _tmdb_image_from_path(item.get('poster_path'), 'w154')
        fanart = _tmdb_image_from_path(item.get('backdrop_path'), 'w300')
        meta = {
            'tmdb_id': tmdb_id,
            'imdb_id': '',
            'imdbnumber': '',
            'tvdb_id': '',
            'mediatype': 'tvshow' if is_tv else 'movie',
            'media_type': 'tvshow' if is_tv else 'movie',
            'title': title,
            'originaltitle': original_title,
            'plot': _lite_plot(item),
            'premiered': premiered,
            'year': _year_from_date(premiered),
            'poster': poster,
            'cover_url': poster,
            'fanart': fanart,
            'backdrop_url': fanart,
            'rating': float(item.get('vote_average') or 0),
            'votes': int(item.get('vote_count') or 0),
            'playcount': 0,
            'overlay': 6,
            'aliases': [],
            'cast': [],
            'genre': [],
            'studio': [],
            'country': [],
            'writer': [],
            'director': [],
            'budget': '',
            'revenue': '',
            'status': '',
            'duration': 0,
            'tagline': '',
        }
        if is_tv:
            meta['number_of_seasons'] = int(item.get('number_of_seasons') or 0) if str(item.get('number_of_seasons') or '').isdigit() else 0
        return meta
    except Exception as exc:
        _log('lite meta build failed: %s' % exc, xbmc.LOGWARNING)
        return None


def _search_normalize(value):
    value = str(value or '').lower()
    try:
        value = ''.join(
            char for char in unicodedata.normalize('NFKD', value)
            if not unicodedata.combining(char)
        )
    except Exception:
        pass
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    return re.sub(r'\s+', ' ', value).strip()


def _search_title_candidates(item, media_type):
    is_tv = str(media_type or '').lower() in ('tv', 'tvshow', 'series', 'serie')
    keys = ('name',) if is_tv else ('title',)
    candidates = []
    for key in keys:
        value = str((item or {}).get(key) or '').strip()
        if value and value not in candidates:
            candidates.append(value)
    return candidates


def _tmdb_search_title_match(item, media_type, query_text):
    query_norm = _search_normalize(query_text)
    if not query_norm:
        return True
    query_tokens = query_norm.split()
    phrase_pattern = r'(^| )%s($| )' % re.escape(query_norm)
    for title in _search_title_candidates(item, media_type):
        title_norm = _search_normalize(title)
        if not title_norm:
            continue
        if len(query_tokens) == 1:
            if re.search(phrase_pattern, title_norm):
                return True
        elif re.search(phrase_pattern, title_norm):
            return True
    return False


def _tmdb_search_title_rank(item, media_type, query_text):
    query_norm = _search_normalize(query_text)
    best = 99
    for title in _search_title_candidates(item, media_type):
        title_norm = _search_normalize(title)
        if not title_norm:
            continue
        if title_norm == query_norm:
            best = min(best, 0)
        elif title_norm.startswith(query_norm + ' '):
            best = min(best, 1)
        elif re.search(r'(^| )%s($| )' % re.escape(query_norm), title_norm):
            best = min(best, 2)
    try:
        popularity_rank = -float((item or {}).get('popularity') or 0)
    except Exception:
        popularity_rank = 0
    try:
        vote_rank = -float((item or {}).get('vote_count') or 0)
    except Exception:
        vote_rank = 0
    return (best, popularity_rank, vote_rank, str((item or {}).get('id') or ''))


def _tmdb_search_cached_id_rank(media_type, tmdb_id, query_text):
    cache_media = 'tvshow' if str(media_type or '').lower() in ('tv', 'tvshow', 'series', 'serie') else 'movie'
    meta = _listing_lite_meta_cache.get(_listing_cache_key(cache_media, tmdb_id)) or {}
    title = str(meta.get('title') or meta.get('name') or '').strip()
    fake_item = {
        'id': tmdb_id,
        'title': title,
        'name': title,
        'popularity': meta.get('popularity') or 0,
        'vote_count': meta.get('votes') or 0,
    }
    return _tmdb_search_title_rank(fake_item, cache_media, query_text)


def _tmdb_search_term_page(media_type, name, page=1):
    media_key = str(media_type or '').lower().strip()
    if media_key in ('tvshow', 'tv', 'series', 'serie'):
        endpoint = 'search/tv'
        cache_media = 'tvshow'
    elif media_key == 'person':
        endpoint = 'search/person'
        cache_media = 'person'
    else:
        endpoint = 'search/movie'
        cache_media = 'movie'

    try:
        page = max(1, int(page or 1))
    except Exception:
        page = 1

    params = {
        'api_key': TMDB_API_KEY,
        'language': 'de-DE',
        'query': str(name or '').strip(),
        'page': page,
        'include_adult': 'false',
    }
    if cache_media == 'movie':
        params['region'] = 'DE'

    url = 'https://api.themoviedb.org/3/%s?%s' % (endpoint, urlencode(params))
    request = Request(url, headers={'User-Agent': 'Archiv-Navigator-Search/1.0'})
    data = json.loads(_nova_urlopen(request, timeout=8).read().decode('utf-8', 'ignore'))
    results = data.get('results') if isinstance(data, dict) else []
    if not isinstance(results, list):
        results = []

    query_text = str(name or '').strip()

    if cache_media == 'person':
        items = []
        for entry in results:
            if not isinstance(entry, dict):
                continue
            person_id = entry.get('id')
            name_value = str(entry.get('name') or '').strip()
            if not person_id or not name_value:
                continue
            department = str(entry.get('known_for_department') or '').strip()
            if department and department.lower() != 'acting':
                continue
            poster = _tmdb_image_from_path(entry.get('profile_path'), 'w342')
            items.append({
                'id': int(person_id),
                'name': name_value,
                'poster': poster,
                'profile_path': entry.get('profile_path') or '',
                'popularity': entry.get('popularity') or 0,
            })
        return items, int(data.get('total_pages') or 0), results

    filtered_results = []
    for entry in results:
        if not isinstance(entry, dict):
            continue
        tmdb_id = str(entry.get('id') or '').strip()
        if not tmdb_id:
            continue
        if not _tmdb_search_title_match(entry, cache_media, query_text):
            continue
        filtered_results.append(entry)

    filtered_results.sort(key=lambda entry: _tmdb_search_title_rank(entry, cache_media, query_text))

    ids = []
    for entry in filtered_results:
        tmdb_id = str(entry.get('id') or '').strip()
        lite_meta = _lite_meta_from_tmdb_result(entry, cache_media)
        if lite_meta:
            _listing_lite_meta_cache[_listing_cache_key(cache_media, tmdb_id)] = lite_meta
        ids.append(tmdb_id)
    return ids, int(data.get('total_pages') or 0), results


def _tmdb_movie_external_ids(tmdb_id):
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id:
        return {}
    cache_key = 'movie:%s' % tmdb_id
    if cache_key in _tmdb_external_ids_cache:
        return dict(_tmdb_external_ids_cache.get(cache_key) or {})
    try:
        endpoint = 'https://api.themoviedb.org/3/movie/%s/external_ids?api_key=%s' % (tmdb_id, TMDB_API_KEY)
        request = Request(endpoint, headers={'User-Agent': 'Archiv-Navigator-ExternalIDs/1.0'})
        data = json.loads(_nova_urlopen(request, timeout=6).read().decode('utf-8', 'ignore'))
        if not isinstance(data, dict) or data.get('success') is False:
            data = {}
        _tmdb_external_ids_cache[cache_key] = data
        return dict(data)
    except Exception as exc:
        _log('movie external ids lookup failed: tmdb=%s / %s' % (tmdb_id, exc), xbmc.LOGWARNING)
        _tmdb_external_ids_cache[cache_key] = {}
        return {}


def _tmdb_movie_search_imdb_id(title, year=''):
    title = str(title or '').strip()
    if not title:
        return ''
    cache_key = 'movie-search:%s:%s' % (title.lower(), str(year or '').strip())
    if cache_key in _tmdb_external_ids_cache:
        return str((_tmdb_external_ids_cache.get(cache_key) or {}).get('imdb_id') or '')
    try:
        query = {
            'api_key': TMDB_API_KEY,
            'query': title,
            'language': 'de-DE',
            'include_adult': 'false',
        }
        if year:
            query['year'] = str(year).split('-', 1)[0]
        endpoint = 'https://api.themoviedb.org/3/search/movie?%s' % urlencode(query)
        request = Request(endpoint, headers={'User-Agent': 'Archiv-Navigator-ExternalIDs/1.0'})
        data = json.loads(_nova_urlopen(request, timeout=6).read().decode('utf-8', 'ignore'))
        results = data.get('results') if isinstance(data, dict) else []
        if not results:
            _tmdb_external_ids_cache[cache_key] = {}
            return ''
        tmdb_id = str((results[0] or {}).get('id') or '')
        ids = _tmdb_movie_external_ids(tmdb_id)
        imdb_id = str(ids.get('imdb_id') or '')
        _tmdb_external_ids_cache[cache_key] = {'imdb_id': imdb_id, 'tmdb_id': tmdb_id}
        return imdb_id
    except Exception as exc:
        _log('movie imdb search failed: %s (%s) / %s' % (title, year, exc), xbmc.LOGWARNING)
        _tmdb_external_ids_cache[cache_key] = {}
        return ''


def _ensure_movie_imdb_in_url(original_url):
    original_url = str(original_url or '')
    if 'sysmeta=' not in original_url and 'meta=' not in original_url:
        return original_url
    try:
        params = _query_params(original_url)
        meta = _decode_sysmeta(params)
        if not isinstance(meta, dict) or not meta:
            return original_url
        media_type = str(_meta_first(meta, 'mediatype', 'media_type', 'mediaType', 'type') or '').lower()
        if media_type not in ('movie', 'film'):
            return original_url
        current_imdb = str(_meta_first(meta, 'imdb_id', 'imdbnumber') or '').strip()
        if current_imdb.startswith('tt'):
            return original_url

        tmdb_id = str(_meta_first(meta, 'tmdb_id', 'tmdbid', 'id') or '').strip()
        imdb_id = ''
        if tmdb_id:
            imdb_id = str(_tmdb_movie_external_ids(tmdb_id).get('imdb_id') or '').strip()
        if not imdb_id:
            title = _clean_label(_meta_first(meta, 'title', 'name', 'systitle', 'originaltitle'))
            year = str(_meta_first(meta, 'year', 'premiered') or '').strip()
            imdb_id = _tmdb_movie_search_imdb_id(title, year)
        if not imdb_id:
            return original_url

        enriched = dict(meta)
        enriched['imdb_id'] = imdb_id
        enriched['imdbnumber'] = imdb_id

        split = urlsplit(original_url)
        rebuilt = {}
        for key, values in params.items():
            if key in ('sysmeta', 'meta'):
                continue
            if values:
                rebuilt[key] = values[0]
        rebuilt['sysmeta'] = json.dumps(enriched, ensure_ascii=False, separators=(',', ':'))
        fixed_url = '%s://%s%s?%s' % (split.scheme or 'plugin', split.netloc or ADDON_ID, split.path or '/', urlencode(rebuilt))
        _log('enriched movie imdb id for source search: %s -> %s' % (tmdb_id or '-', imdb_id))
        return fixed_url
    except Exception as exc:
        _log('movie imdb url enrichment failed: %s' % exc, xbmc.LOGWARNING)
        return original_url


def _listing_cache_key(media_type, tmdb_id):
    media_type = 'tvshow' if str(media_type or '').lower() in ('tv', 'tvshow', 'series', 'serie') else 'movie'
    return '%s:%s' % (media_type, str(tmdb_id or ''))


def _normalize_art_dict(art):
    if not isinstance(art, dict):
        return art
    normalized = dict(art)
    for key, value in list(normalized.items()):
        if not value:
            continue
        key_name = str(key or '').lower()
        if any(name in key_name for name in ('fanart', 'backdrop', 'background', 'landscape')):
            normalized[key] = _tmdb_image_size(value, 'w300')
        else:
            normalized[key] = _tmdb_image_size(value, 'w154')
    return normalized


def _normalize_listitem_art(listitem):
    try:
        art = listitem.getArt() or {}
    except Exception:
        return
    try:
        listitem.setArt(_normalize_art_dict(art))
    except Exception:
        pass


def _clean_label(value):
    value = str(value or '')
    value = re.sub(r'\[/?(?:B|I|COLOR[^\]]*|UPPERCASE|LOWERCASE|CAPITALIZE)\]', '', value, flags=re.I)
    value = re.sub(r'\s+', ' ', value)
    return value.strip()


def _clean_studio_values(value, limit=1):
    if value in (None, ''):
        return []
    if isinstance(value, tuple):
        value = list(value)
    entries = value if isinstance(value, list) else [value]
    studios = []
    seen = set()
    for entry in entries:
        for studio in re.split(r'\s*/\s*|\s*\|\s*', str(entry or '')):
            studio = _clean_label(studio)
            if not studio or studio.lower() in ('none', 'null', 'n/a'):
                continue
            key = studio.lower()
            if key in seen:
                continue
            seen.add(key)
            studios.append(studio)
            if len(studios) >= limit:
                return studios
    return studios


def _apply_clean_studios(listitem, url=''):
    studios = []
    try:
        meta = _decode_sysmeta(_query_params(url))
        studios = _clean_studio_values(_meta_first(meta, 'studio', 'studios', 'production_company', 'production_companies'))
    except Exception:
        studios = []
    try:
        if not studios:
            tag = listitem.getVideoInfoTag()
            current = []
            try:
                current = tag.getStudios()
            except Exception:
                current = []
            studios = _clean_studio_values(current)
        if studios:
            listitem.getVideoInfoTag().setStudios(studios)
    except Exception:
        pass


def _clean_trailer_label(value):
    value = _clean_label(value)
    value = re.sub(r'\([^\)]*\bmulti(?:language)?\b[^\)]*\)', ' ', value, flags=re.I)
    value = re.sub(r'\[[^\]]*\bmulti(?:language)?\b[^\]]*\]', ' ', value, flags=re.I)
    value = re.sub(r'\bmulti(?:language)?\b', ' ', value, flags=re.I)
    value = re.sub(r'\bS\d{1,2}E\d{1,3}\b', ' ', value, flags=re.I)
    value = re.sub(r'\b\d{1,2}x\d{1,3}\b', ' ', value, flags=re.I)
    value = re.sub(r'\s+', ' ', value)
    return value.strip(' -:|')


def _query_params(url):
    try:
        return parse_qs(urlsplit(str(url or '')).query)
    except Exception:
        return {}


def _first(params, *names):
    for name in names:
        values = params.get(name)
        if values:
            return values[0]
    return ''


def _listitem_label(listitem):
    try:
        return _clean_label(listitem.getLabel())
    except Exception:
        return ''


def _is_next_page_item(url, listitem, is_folder):
    if not is_folder:
        return False
    params = _query_params(url)
    if 'next_pages' in params:
        return True
    action = _first(params, 'action', 'function').lower()
    if action in ('next', 'nextpage', 'next_page', 'page_next'):
        return True
    label = _listitem_label(listitem).lower()
    compact = label.replace('...', '').strip()
    if compact in ('weiter', 'next', 'next page', 'nächste', 'naechste', 'nächste seite', 'naechste seite'):
        return True
    return (
        ('seite' in label or 'page' in label)
        and any(word in label for word in NEXT_PAGE_LABEL_WORDS)
    )


def _apply_next_page_art(url, listitem, is_folder):
    if not _is_next_page_item(url, listitem, is_folder):
        return
    try:
        listitem.setArt({
            'icon': NEXT_PAGE_ART,
            'thumb': NEXT_PAGE_ART,
            'poster': NEXT_PAGE_ART,
        })
    except Exception as exc:
        _log('next page art failed: %s' % exc, xbmc.LOGWARNING)


def _decode_sysmeta(params):
    raw = _first(params, 'sysmeta', 'meta')
    if not raw:
        return {}
    try:
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8', 'ignore')
        raw = unquote_plus(str(raw))
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _compact_plugin_sysmeta_url(original_url):
    """Drop huge Kodi/TMDB payloads from Archiv Navigator folder URLs.

    Some series/season items carry complete cast/crew/episode arrays inside
    sysmeta. That can inflate a normal season URL to hundreds of KB and Kodi
    may sit in a busy loop before it ever shows the next folder. The indexer
    only needs the identifying fields to continue, so keep those and discard
    the bulky lists.
    """
    original_url = str(original_url or '')
    if 'sysmeta=' not in original_url and 'meta=' not in original_url:
        return original_url
    try:
        params = _query_params(original_url)
        action = _first(params, 'action', 'function')
        if action == 'seasons':
            # Do not strip the series -> seasons URL. Archiv Navigator uses
            # data inside sysmeta to build the season folder; compacting this
            # URL made the next page open as an empty folder.
            return original_url
        meta = _decode_sysmeta(params)
        if not meta:
            return original_url

        keep_keys = (
            'tmdb_id', 'imdbnumber', 'tvdb_id', 'imdb_id',
            'mediatype', 'media_type', 'mediaType', 'type',
            'title', 'originaltitle', 'systitle', 'sysname', 'tvshowtitle', 'TVShowTitle', 'showtitle',
            'year', 'premiered', 'season',
            'number_of_seasons', 'number_of_episodes',
            'poster', 'cover_url', 'fanart', 'backdrop_url',
        )
        if action == 'episodes':
            keep_keys = keep_keys + ('episodes',)
        compact_meta = {}
        lowered = {str(key).lower(): key for key in meta.keys()}
        for key in keep_keys:
            value = meta.get(key)
            if value is None and key.lower() in lowered:
                value = meta.get(lowered[key.lower()])
            if value not in (None, '', [], {}):
                compact_meta[key] = value

        season_value = _first(params, 'season', 'sSeasonNr')
        if season_value and 'season' not in compact_meta:
            compact_meta['season'] = season_value

        rebuilt = {}
        for key, values in params.items():
            if key in ('sysmeta', 'meta'):
                continue
            if values:
                rebuilt[key] = values[0]
        rebuilt['sysmeta'] = json.dumps(compact_meta, ensure_ascii=False, separators=(',', ':'))
        compact_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(rebuilt))
        if len(compact_url) < len(original_url):
            _log('compacted folder url from %d to %d chars action=%s' % (
                len(original_url),
                len(compact_url),
                rebuilt.get('action') or rebuilt.get('function') or '',
            ))
            return compact_url
    except Exception as exc:
        _log('compact sysmeta url failed: %s' % exc, xbmc.LOGWARNING)
    return original_url


def _meta_first(meta, *names):
    if not isinstance(meta, dict):
        return ''
    lowered = {str(k).lower(): v for k, v in meta.items()}
    for name in names:
        value = meta.get(name)
        if value is None:
            value = lowered.get(str(name).lower())
        if value not in (None, ''):
            return value
    return ''


def _tag_value(tag, method):
    try:
        func = getattr(tag, method, None)
        if func:
            value = func()
            return '' if value is None else str(value)
    except Exception:
        pass
    return ''


def _item_meta(listitem, url):
    params = _query_params(url)
    sysmeta = _decode_sysmeta(params)
    label = ''
    try:
        label = listitem.getLabel()
    except Exception:
        pass
    label = _clean_label(label)

    tag = None
    try:
        tag = listitem.getVideoInfoTag()
    except Exception:
        tag = None

    media_type = (
        _first(params, 'media_type', 'mediaType', 'mediatype', 'sMediaType')
        or _meta_first(sysmeta, 'mediatype', 'mediaType', 'sMediaType', 'type')
    ).lower()
    title = (
        _first(params, 'MovieTitle', 'title', 'name', 'infoTitle')
        or _meta_first(sysmeta, 'title', 'name', 'systitle', 'originaltitle')
    )
    tvshow_title = (
        _first(params, 'TVShowTitle', 'tvshowtitle', 'showtitle', 'name')
        or _meta_first(sysmeta, 'tvshowtitle', 'TVShowTitle', 'showtitle', 'sysname')
    )
    year = _first(params, 'year', 'sYear') or _meta_first(sysmeta, 'year', 'premiered')
    season = _first(params, 'season') or _meta_first(sysmeta, 'season')
    episode = _first(params, 'episode') or _meta_first(sysmeta, 'episode')

    if tag is not None:
        media_type = (media_type or _tag_value(tag, 'getMediaType')).lower()
        title = title or _tag_value(tag, 'getTitle')
        tvshow_title = tvshow_title or _tag_value(tag, 'getTVShowTitle')
        year = year or _tag_value(tag, 'getYear')
        season = season or _tag_value(tag, 'getSeason')
        episode = episode or _tag_value(tag, 'getEpisode')

    title = _clean_label(title) or label
    tvshow_title = _clean_label(tvshow_title)

    return {
        'label': label,
        'title': title,
        'tvshow_title': tvshow_title,
        'media_type': media_type,
        'year': str(year or '').strip(),
        'season': str(season or '').strip(),
        'episode': str(episode or '').strip(),
        'action': _first(params, 'action', 'function').strip(),
        'has_sysmeta': bool(sysmeta),
    }


GENRE_LABELS = {
    'action', 'abenteuer', 'animation', 'biografie', 'comedy', 'komoedie', 'komodie',
    'komödie', 'krimi', 'doku', 'dokumentation', 'drama', 'familie', 'fantasy',
    'history', 'historie', 'horror', 'krieg', 'musik', 'mystery', 'romance',
    'romantik', 'science fiction', 'sci-fi', 'thriller', 'western',
}

CATEGORY_WORDS = (
    'filme ', 'serien ', 'genre', 'jahr', 'jahre', 'suche', 'such', 'popular',
    'populaer', 'populär', 'bewertet', 'einspielergebnis', 'neu', 'trending',
    'settings', 'einstellung', 'cache', 'resolver', 'hoster', 'konto', 'tools',
    'download', 'navigator', 'person', 'weiter', 'naechste', 'nächste',
)

CATEGORY_ACTIONS = {
    'root', 'movieNavigator', 'tvNavigator', 'toolNavigator', 'settings',
    'addonSettings', 'resetSettings', 'resolverSettings', 'downloadNavigator',
    'movieYears', 'movieGenres', 'tvGenres', 'searchNew', 'searchClear',
    'searchDelTerm', 'personSearch', 'personCredits', 'listings',
}

CATEGORY_PATH_ACTIONS = CATEGORY_ACTIONS - {'listings'}


def _is_category(meta):
    label = meta['label'].lower()
    action = meta['action']
    if not label:
        return True
    if action in CATEGORY_ACTIONS:
        return True
    if re.match(r'^\d{4}$', label):
        return True
    if label in GENRE_LABELS:
        return True
    return any(word in label for word in CATEGORY_WORDS)


def _is_root_path():
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        action = _first(params, 'action', 'function')
        return not action or action == 'root'
    except Exception:
        return False


def _should_hide_root_item(url, listitem):
    if SHOW_ARCHIV_NAVIGATOR_ROOT_TOOLS or not _is_root_path():
        return False
    try:
        meta = _item_meta(listitem, url)
        label = (meta.get('label') or meta.get('title') or '').lower()
        action = meta.get('action') or ''
        if 'moviedream' in label or 'moviedream' in str(url or '').lower():
            return True
        return action == 'toolNavigator' or label in ('werkzeuge', 'tools')
    except Exception:
        return False


def _rename_root_item_label(listitem):
    if not _is_root_path():
        return
    try:
        label = listitem.getLabel() or ''
        replacements = {
            'TV-Serien': 'Serien',
            'Suche TV-Serien': 'Suche Serien',
        }
        new_label = replacements.get(label)
        if new_label:
            listitem.setLabel(new_label)
            _log('renamed root item: %s -> %s' % (label, new_label))
    except Exception:
        pass


def _track_view_candidate(url, listitem, is_folder):
    try:
        params = _query_params(url)
        if CHOICE_PARAM in params or PASSTHROUGH_PARAM in params:
            return

        meta = _item_meta(listitem, url)
        label_season = _season_number_from_label(meta.get('label'))
        if label_season and not meta.get('season'):
            meta['season'] = label_season

        media_type = str(meta.get('media_type') or '').lower()
        action = str(meta.get('action') or '')
        if meta.get('episode') or media_type == 'episode':
            _view_candidates['episode'] += 1
            return
        if is_folder and (media_type == 'season' or label_season or (meta.get('season') and action == 'episodes')):
            _view_candidates['season'] += 1
            return
        if media_type in ('tvshow', 'show', 'series', 'serie') or action == 'seasons':
            if not _is_category(meta):
                _view_candidates['series'] += 1
            return
        if media_type == 'movie':
            if not _is_category(meta):
                _view_candidates['movie'] += 1
            return
        if meta.get('year') and not meta.get('season') and not _is_category(meta):
            _view_candidates['movie'] += 1
    except Exception:
        pass


def _current_plugin_url():
    try:
        base = str(sys.argv[0] or '')
        query = str(sys.argv[2] or '') if len(sys.argv) > 2 else ''
        return base + query
    except Exception:
        return 'plugin://%s/' % ADDON_ID


def _current_action():
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        return _first(params, 'action', 'function')
    except Exception:
        return ''


def _is_lightweight_menu_route():
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        action_l = _first(params, 'action', 'function').strip().lower()
        if not action_l:
            return True
        if action_l in (
            'moviessearch', 'tvshowssearch', 'personsearch',
            'searchclear', 'searchdelterm', 'searchnew',
            'movienavigator', 'tvnavigator',
            'movieyears', 'moviegenres', 'tvgenres',
            'toolnavigator', 'settings', 'addonsettings',
        ):
            return True
        return False
    except Exception:
        return False


def _needs_listing_runtime_patches():
    if _is_lightweight_menu_route():
        return False
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        action_l = _first(params, 'action', 'function').strip().lower()
        if action_l in ('movies', 'tvshows', 'listings', 'seasons', 'episodes', 'person', 'personcredits', 'play', 'playfromperson'):
            return True
        if CHOICE_PARAM in params or PASSTHROUGH_PARAM in params or PASSTHROUGH_TOKEN_PARAM in params:
            return True
        return False
    except Exception:
        return True


def _needs_stream_runtime_patches():
    if _is_lightweight_menu_route():
        return False
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        action_l = _first(params, 'action', 'function').strip().lower()
        if action_l in ('play', 'playfromperson', 'playitem', 'sourcesresolve'):
            return True
        if CHOICE_PARAM in params or PASSTHROUGH_PARAM in params or PASSTHROUGH_TOKEN_PARAM in params:
            return True
        return False
    except Exception:
        return True


def _append_query_flag(url, name, value='1'):
    try:
        url = str(url or '')
        if not url:
            return url
        if name in _query_params(url):
            return url
        joiner = '&' if '?' in url else '?'
        return '%s%s%s=%s' % (url, joiner, name, value)
    except Exception:
        return url


def _is_favourite_direct_context():
    try:
        return FAVOURITE_DIRECT_PARAM in _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
    except Exception:
        return False


def _favourite_return_guard_path():
    try:
        profile = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, 'nova_favourite_return_guard.json')
    except Exception:
        return ''


def _favourite_guard_load():
    path = _favourite_return_guard_path()
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8-sig') as file_obj:
            data = json.load(file_obj)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _favourite_guard_save(data):
    path = _favourite_return_guard_path()
    if not path:
        return False
    try:
        with open(path, 'w', encoding='utf-8') as file_obj:
            json.dump(data if isinstance(data, dict) else {}, file_obj, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as exc:
        _log('favourite return guard save failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _favourite_title_from_query(query):
    try:
        params = _query_params(query)
        meta = _decode_sysmeta(params)
        title = (
            _first(params, 'title', 'name', 'MovieTitle')
            or _meta_first(meta, 'title', 'systitle', 'name', 'originaltitle')
        )
        return _clean_label(title).strip().lower()
    except Exception:
        return ''


def _show_favourite_movie_loading_hint(query):
    try:
        params = _query_params(query)
        if FAVOURITE_DIRECT_PARAM not in params:
            return False
        action = (_first(params, 'action', 'function') or '').strip().lower()
        if action != 'play':
            return False
        meta = _decode_sysmeta(params)
        media_type = (
            _first(params, 'media_type', 'mediatype')
            or _meta_first(meta, 'media_type', 'mediatype', 'type')
        ).strip().lower()
        if media_type and media_type not in ('movie', 'film'):
            return False
        title = _favourite_title_from_query(query)
        data = _favourite_guard_load()
        last = data.get('loading_hint') if isinstance(data.get('loading_hint'), dict) else {}
        if title and last.get('title') == title and time.time() - float(last.get('ts') or 0) < 45:
            _log('favourite movie loading hint suppressed duplicate: %s' % title)
            return False
        xbmcgui.Dialog().notification('Wird geladen...', '', time=6000, sound=False)
        if title:
            data['loading_hint'] = {'title': title, 'ts': time.time()}
            _favourite_guard_save(data)
        _log('favourite movie loading hint shown')
        return True
    except Exception as exc:
        _log('favourite movie loading hint failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _remember_favourite_source_listing(query):
    try:
        if FAVOURITE_DIRECT_PARAM not in _query_params(query):
            return False
        title = _favourite_title_from_query(query)
        if not title:
            return False
        data = _favourite_guard_load()
        data['active'] = {'title': title, 'ts': time.time()}
        data.pop('guard', None)
        _favourite_guard_save(data)
        _log('favourite source listing active: %s' % title)
        return True
    except Exception as exc:
        _log('favourite source listing guard failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _mark_favourite_source_started(query):
    try:
        params = _query_params(query)
        action = (_first(params, 'action', 'function') or '').lower()
        if action not in ('additem', 'playitem'):
            return False
        title = _favourite_title_from_query(query)
        if not title:
            return False
        data = _favourite_guard_load()
        active = data.get('active') if isinstance(data.get('active'), dict) else {}
        if active.get('title') != title or time.time() - float(active.get('ts') or 0) > 600:
            return False
        data['guard'] = {'title': title, 'ts': time.time(), 'consumed': False}
        _favourite_guard_save(data)
        _log('favourite source play marked for back guard: %s' % title)
        return True
    except Exception as exc:
        _log('favourite source play guard failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _consume_favourite_back_reload(query):
    try:
        params = _query_params(query)
        action = (_first(params, 'action', 'function') or '').lower()
        if action != 'play' or FAVOURITE_DIRECT_PARAM not in params:
            return False
        title = _favourite_title_from_query(query)
        if not title:
            return False
        data = _favourite_guard_load()
        guard = data.get('guard') if isinstance(data.get('guard'), dict) else {}
        if guard.get('consumed') or guard.get('title') != title:
            return False
        if time.time() - float(guard.get('ts') or 0) > 180:
            return False
        guard['consumed'] = True
        data['guard'] = guard
        data.pop('active', None)
        _favourite_guard_save(data)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('ActivateWindow(10134)')
        _log('favourite back reload consumed; returning to favourites: %s' % title)
        _finish_directory(True)
        return True
    except Exception as exc:
        _log('favourite back reload guard failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _is_movie_navigator_path():
    return str(_current_action() or '').lower() == 'movienavigator'


def _is_tv_navigator_path():
    return str(_current_action() or '').lower() == 'tvnavigator'


def _movie_navigator_sort_rank(item, index):
    try:
        listitem = item[1]
        label = _listitem_label(listitem).lower()
        compact = re.sub(r'[^a-z0-9äöüß]+', ' ', label, flags=re.I).strip()
        words = set(compact.split())
        if 'filme' in words and ('jahr' in words or 'jahre' in words):
            return (90, index)
        if 'filme' in words and ('genre' in words or 'genres' in words):
            return (91, index)
        return (0, index)
    except Exception:
        return (0, index)


def _tv_navigator_sort_rank(item, index):
    try:
        listitem = item[1]
        label = _listitem_label(listitem).lower()
        compact = re.sub(r'[^a-z0-9äöüß]+', ' ', label, flags=re.I).strip()
        words = set(compact.split())
        if ('serien' in words or 'serie' in words) and ('genre' in words or 'genres' in words):
            return (90, index)
        return (0, index)
    except Exception:
        return (0, index)


def _reorder_movie_navigator_items(items):
    try:
        if not _is_movie_navigator_path():
            return items
        reordered = sorted(enumerate(list(items or [])), key=lambda pair: _movie_navigator_sort_rank(pair[1], pair[0]))
        reordered = [item for index, item in reordered]
        labels = [_listitem_label(item[1]) for item in reordered]
        if labels:
            _log('movie navigator order active: %s' % ' | '.join(labels[:10]))
        return reordered
    except Exception as exc:
        _log('movie navigator reorder failed: %s' % exc, xbmc.LOGWARNING)
        return items


def _reorder_tv_navigator_items(items):
    try:
        if not _is_tv_navigator_path():
            return items
        reordered = sorted(enumerate(list(items or [])), key=lambda pair: _tv_navigator_sort_rank(pair[1], pair[0]))
        reordered = [item for index, item in reordered]
        labels = [_listitem_label(item[1]) for item in reordered]
        if labels:
            _log('tv navigator order active: %s' % ' | '.join(labels[:10]))
        return reordered
    except Exception as exc:
        _log('tv navigator reorder failed: %s' % exc, xbmc.LOGWARNING)
        return items


def _flush_movie_navigator_buffer():
    global _movie_navigator_buffer
    try:
        if not _movie_navigator_buffer:
            return
        buffered = list(_movie_navigator_buffer)
        _movie_navigator_buffer = []
        handle = buffered[0][0]
        items = [(url, listitem, is_folder) for handle, url, listitem, is_folder in buffered]
        items = _reorder_movie_navigator_items(items)
        add_items = _original_add_directory_items or xbmcplugin.addDirectoryItems
        add_items(handle, items, len(items))
    except Exception as exc:
        _log('movie navigator buffer flush failed: %s' % exc, xbmc.LOGWARNING)


def _flush_tv_navigator_buffer():
    global _tv_navigator_buffer
    try:
        if not _tv_navigator_buffer:
            return
        buffered = list(_tv_navigator_buffer)
        _tv_navigator_buffer = []
        handle = buffered[0][0]
        items = [(url, listitem, is_folder) for handle, url, listitem, is_folder in buffered]
        items = _reorder_tv_navigator_items(items)
        add_items = _original_add_directory_items or xbmcplugin.addDirectoryItems
        add_items(handle, items, len(items))
    except Exception as exc:
        _log('tv navigator buffer flush failed: %s' % exc, xbmc.LOGWARNING)


def _view_db_path():
    try:
        db_dir = xbmcvfs.translatePath('special://database/')
        candidates = [
            name for name in os.listdir(db_dir)
            if name.lower().startswith('viewmodes') and name.lower().endswith('.db')
        ]
        if candidates:
            candidates.sort()
            return os.path.join(db_dir, candidates[-1])
        return os.path.join(db_dir, 'ViewModes6.db')
    except Exception:
        return ''


def _view_prefs_path():
    try:
        profile = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, VIEW_PREFS_FILE)
    except Exception:
        return ''


def _passthrough_store_dir():
    try:
        path = xbmcvfs.translatePath('special://profile/addon_data/%s/passthrough/' % ADDON_ID)
        os.makedirs(path, exist_ok=True)
        return path
    except Exception:
        return ''


def _store_passthrough_url(url):
    url = str(url or '')
    store_dir = _passthrough_store_dir()
    if not url or not store_dir:
        return url
    try:
        token = hashlib.sha1(('%s|%s' % (url, time.time())).encode('utf-8')).hexdigest()
        path = os.path.join(store_dir, token + '.json')
        with open(path, 'w', encoding='utf-8') as file_obj:
            json.dump({'url': url}, file_obj)
        return 'plugin://%s/?%s=%s' % (ADDON_ID, PASSTHROUGH_TOKEN_PARAM, token)
    except Exception as exc:
        _log('store passthrough failed: %s' % exc, xbmc.LOGWARNING)
        return url


def _load_passthrough_url(token):
    token = re.sub(r'[^A-Fa-f0-9]', '', str(token or ''))
    store_dir = _passthrough_store_dir()
    if not token or not store_dir:
        return ''
    try:
        path = os.path.join(store_dir, token + '.json')
        with open(path, 'r', encoding='utf-8-sig') as file_obj:
            data = json.load(file_obj)
        return str(data.get('url') or '')
    except Exception as exc:
        _log('load passthrough failed: %s' % exc, xbmc.LOGWARNING)
        return ''


def _resolve_passthrough_token_url(url):
    url = str(url or '')
    try:
        params = _query_params(url)
        token = _first(params, PASSTHROUGH_TOKEN_PARAM)
        if token:
            resolved = _load_passthrough_url(token)
            if resolved:
                _log('resolved passthrough token=%s url_len=%s' % (token[:12], len(resolved)))
                return resolved
    except Exception as exc:
        _log('resolve passthrough token failed: %s' % exc, xbmc.LOGWARNING)
    return url


def _activate_passthrough_token(query):
    params = _query_params(query)
    token = _first(params, PASSTHROUGH_TOKEN_PARAM)
    if not token:
        return False
    original_url = _load_passthrough_url(token)
    if not original_url:
        return False
    passthrough = _passthrough_url(original_url)
    parsed = urlsplit(passthrough)
    sys.argv[2] = '?' + parsed.query if parsed.query else ''
    _log('activated passthrough token=%s action=%s' % (token[:12], _first(_query_params(sys.argv[2]), 'action', 'function')))
    return True


def _is_search_path(path):
    try:
        params = _query_params(path)
        action = _first(params, 'action', 'function').lower()
        query_values = (
            _first(params, 'query', 'search', 'searchTerm', 'search_term', 'keyword', 'term')
            or _first(params, 'q', 'name')
        )
        if 'search' in action or 'suche' in action:
            return True
        if query_values and action in ('listings', 'moviepage', 'tvpage'):
            return True
    except Exception:
        pass
    return False


def _load_view_prefs():
    try:
        path = _view_prefs_path()
        if path and os.path.exists(path):
            with open(path, 'r', encoding='utf-8-sig') as file_obj:
                data = json.load(file_obj)
                return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _save_view_prefs(prefs):
    try:
        path = _view_prefs_path()
        if path:
            with open(path, 'w', encoding='utf-8') as file_obj:
                json.dump(prefs, file_obj, sort_keys=True)
    except Exception:
        pass


def _view_key_from_path(path):
    try:
        if _is_search_path(path):
            return ''
        params = _query_params(path)
        media_type = _first(params, 'media_type', 'mediaType', 'mediatype', 'sMediaType').lower()
        action = _first(params, 'action', 'function')
        if action == 'seasons':
            return SEASON_VIEW_KEY
        if action in ('episodes', 'play'):
            return ''
        if action in CATEGORY_PATH_ACTIONS:
            return CATEGORY_VIEW_KEY
        sysmeta = _decode_sysmeta(params)
        sys_media = str(_meta_first(sysmeta, 'mediatype', 'mediaType', 'type') or '').lower()

        if media_type == 'movie' or sys_media == 'movie':
            return TITLE_VIEW_KEY
        if media_type in ('tv', 'tvshow', 'show', 'series', 'serie') or sys_media in ('tvshow', 'show', 'series', 'serie'):
            return TITLE_VIEW_KEY
        if action in ('moviePage', 'movieSearch') and (media_type == 'movie' or sys_media == 'movie'):
            return TITLE_VIEW_KEY
        if action in ('tvPage', 'tvSearch', 'seasons') and (
            media_type in ('tv', 'tvshow', 'show', 'series', 'serie')
            or sys_media in ('tvshow', 'show', 'series', 'serie')
        ):
            return TITLE_VIEW_KEY
    except Exception:
        pass
    return ''


def _current_view_key():
    try:
        if _is_search_path(_current_plugin_url()):
            return ''
        if _view_candidates.get('season', 0) > 0:
            return SEASON_VIEW_KEY
        if _view_candidates.get('movie', 0) > 0 and _view_candidates.get('movie', 0) >= _view_candidates.get('series', 0):
            return TITLE_VIEW_KEY
        if _view_candidates.get('series', 0) > 0:
            return TITLE_VIEW_KEY
        path_key = _view_key_from_path(_current_plugin_url())
        if path_key in (TITLE_VIEW_KEY, SEASON_VIEW_KEY, CATEGORY_VIEW_KEY):
            return path_key
    except Exception:
        pass
    return ''


def _current_listing_content():
    try:
        path = _current_plugin_url()
        params = _query_params(path)
        action = _first(params, 'action', 'function')
        if action == 'seasons':
            return 'seasons'
        if _is_search_path(path) or action in ('episodes', 'play'):
            return ''
        media_type = _first(params, 'media_type', 'mediaType', 'mediatype', 'sMediaType').lower()
        if media_type == 'movie' or _view_candidates.get('movie', 0) > 0:
            return 'movies'
        if media_type in ('tv', 'tvshow', 'show', 'series', 'serie') or _view_candidates.get('series', 0) > 0:
            return 'tvshows'
    except Exception:
        pass
    return ''


def _row_from_pref(key):
    if not key:
        return None
    try:
        data = _load_view_prefs().get(key)
        if data and int(data.get('viewMode') or 0):
            return (
                0,
                int(data.get('viewMode') or 0),
                int(data.get('sortMethod') or 0),
                int(data.get('sortOrder') or 1),
                int(data.get('sortAttributes') or 0),
                data.get('skin') or 'skin.aeon.nox.silvo',
            )
    except Exception:
        pass
    return None


def _remember_view_row(key, row):
    if not key:
        return
    try:
        view_mode = int(row[1] or 0)
        if not view_mode:
            return
        prefs = _load_view_prefs()
        prefs[key] = {
            'viewMode': view_mode,
            'sortMethod': int(row[2] or 0),
            'sortOrder': int(row[3] or 1),
            'sortAttributes': int(row[4] or 0),
            'skin': row[5] or 'skin.aeon.nox.silvo',
        }
        _save_view_prefs(prefs)
    except Exception:
        pass


def _last_path_pref_name(key):
    if key == TITLE_VIEW_KEY:
        return 'last_title_path'
    if key == SEASON_VIEW_KEY:
        return 'last_season_path'
    if key == CATEGORY_VIEW_KEY:
        return 'last_category_path'
    return ''


def _remember_last_view_path(key, path):
    pref_name = _last_path_pref_name(key)
    if not pref_name or not path:
        return
    try:
        prefs = _load_view_prefs()
        prefs[pref_name] = path
        _save_view_prefs(prefs)
    except Exception:
        pass


def _get_view_row(con, path):
    try:
        return con.execute(
            'select idView, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path=? order by idView desc',
            (10025, path)
        ).fetchone()
    except Exception:
        return None


def _capture_previous_view(con, key, current):
    try:
        pref_name = _last_path_pref_name(key)
        if not pref_name:
            return
        prefs = _load_view_prefs()
        previous = prefs.get(pref_name) or ''
        if not previous or previous == current or _view_key_from_path(previous) != key:
            return
        row = _get_view_row(con, previous)
        if row and int(row[1] or 0):
            _remember_view_row(key, row)
            _sync_existing_view_rows(con, key, row)
    except Exception:
        pass


def _sync_existing_view_rows(con, key, source_row):
    if not source_row or not int(source_row[1] or 0):
        return
    try:
        rows = con.execute(
            'select path from view where window=? and path like ? and viewMode<>0',
            (10025, 'plugin://%s%%' % ADDON_ID)
        ).fetchall()
        for row in rows:
            path = row[0] or ''
            if _view_key_from_path(path) == key:
                _set_view_row(con, path, source_row)
    except Exception:
        pass


def _capture_known_previous_views(con, current):
    _capture_previous_view(con, TITLE_VIEW_KEY, current)
    _capture_previous_view(con, SEASON_VIEW_KEY, current)
    _capture_previous_view(con, CATEGORY_VIEW_KEY, current)


def _latest_view_row(con, key, exclude_path=''):
    try:
        rows = con.execute(
            'select idView, path, viewMode, sortMethod, sortOrder, sortAttributes, skin from view '
            'where window=? and path like ? and viewMode<>0 order by idView desc limit 500',
            (10025, 'plugin://%s%%' % ADDON_ID)
        ).fetchall()
        for row in rows:
            path = row[1] or ''
            if exclude_path and path == exclude_path:
                continue
            candidate = (row[0], row[2], row[3], row[4], row[5], row[6])
            row_key = _view_key_from_path(path)
            if row_key == key:
                return candidate
    except Exception:
        pass
    return _row_from_pref(key)


def _set_view_row(con, path, source_row):
    if not source_row or not int(source_row[1] or 0):
        return
    view_mode = int(source_row[1] or 0)
    sort_method = int(source_row[2] or 0)
    sort_order = int(source_row[3] or 1)
    sort_attributes = int(source_row[4] or 0)
    skin = source_row[5] or 'skin.aeon.nox.silvo'
    existing = _get_view_row(con, path)
    if existing:
        con.execute(
            'update view set viewMode=?, sortMethod=?, sortOrder=?, sortAttributes=?, skin=? where window=? and path=?',
            (view_mode, sort_method, sort_order, sort_attributes, skin, 10025, path)
        )
    else:
        next_id = con.execute('select coalesce(max(idView), 0) + 1 from view').fetchone()[0]
        con.execute(
            'insert into view (idView, window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) '
            'values (?, ?, ?, ?, ?, ?, ?, ?)',
            (next_id, 10025, path, view_mode, sort_method, sort_order, sort_attributes, skin)
        )


def _sync_view_before_end():
    global _pending_view_key, _pending_view_mode
    _pending_view_mode = 0
    _pending_view_key = ''
    key = _current_view_key()
    current = _current_plugin_url()
    db_path = _view_db_path()
    content = _current_listing_content()
    if content:
        try:
            xbmcplugin.setContent(int(sys.argv[1]), content)
        except Exception:
            pass
    if not db_path or not os.path.exists(db_path):
        return
    try:
        con = sqlite3.connect(db_path, timeout=0.5)
        try:
            _capture_known_previous_views(con, current)
            if key not in (TITLE_VIEW_KEY, SEASON_VIEW_KEY, CATEGORY_VIEW_KEY):
                con.commit()
                return
            row = _get_view_row(con, current)
            source = _row_from_pref(key) or _latest_view_row(con, key, current)
            if key == CATEGORY_VIEW_KEY and not source:
                source = DEFAULT_CATEGORY_VIEW_ROW
            if source:
                _set_view_row(con, current, source)
                _remember_view_row(key, source)
                _remember_last_view_path(key, current)
                if key == CATEGORY_VIEW_KEY:
                    _pending_view_mode = int(source[1] or 0)
                    _pending_view_key = key
                _log('view sync apply key=%s content=%s view=%s path=%s' % (key, content, _pending_view_mode, current))
                con.commit()
                return
            if row and int(row[1] or 0):
                _remember_view_row(key, row)
                _remember_last_view_path(key, current)
                if key == CATEGORY_VIEW_KEY:
                    _pending_view_mode = int(row[1] or 0)
                    _pending_view_key = key
                _log('view sync remember key=%s content=%s view=%s path=%s' % (key, content, _pending_view_mode, current))
                return
        finally:
            con.close()
    except Exception as exc:
        _log('view sync failed: %s' % exc, xbmc.LOGWARNING)


def _patched_end_of_directory(original_func):
    def wrapped(*args, **kwargs):
        try:
            _flush_movie_navigator_buffer()
        except Exception as exc:
            _log('movie navigator flush wrapper failed: %s' % exc, xbmc.LOGWARNING)
        try:
            _flush_tv_navigator_buffer()
        except Exception as exc:
            _log('tv navigator flush wrapper failed: %s' % exc, xbmc.LOGWARNING)
        try:
            _sync_view_before_end()
        except Exception as exc:
            _log('view sync wrapper failed: %s' % exc, xbmc.LOGWARNING)
        result = original_func(*args, **kwargs)
        try:
            view_mode = int(_pending_view_mode or 0)
            if view_mode and _pending_view_key == CATEGORY_VIEW_KEY:
                view_id = view_mode % 65536
                xbmc.executebuiltin('Container.SetViewMode(%d)' % view_id)
                _log('view sync builtin view_id=%s mode=%s' % (view_id, view_mode))
        except Exception as exc:
            _log('view sync builtin failed: %s' % exc, xbmc.LOGWARNING)
        return result
    return wrapped


def _season_number_from_label(label):
    match = re.search(r'(?:\bstaffel\b|\bseason\b|^s)\s*0*(\d+)\b', label or '', re.I)
    if not match:
        match = re.search(r'\b0*(\d+)\.?\s*staffel\b', label or '', re.I)
    return match.group(1) if match else ''


def _choice_play_label(media_type):
    media_type = str(media_type or '').lower()
    if media_type == 'season':
        return 'Staffel wiedergeben'
    if media_type in ('tvshow', 'show', 'series', 'serie', 'tv'):
        return 'Serie wiedergeben'
    return 'Film wiedergeben'


def _should_wrap(url, listitem, is_folder):
    params = _query_params(url)
    if CHOICE_PARAM in params or PASSTHROUGH_PARAM in params:
        return None
    if FAVOURITE_DIRECT_PARAM in params or _is_favourite_direct_context():
        return None

    meta = _item_meta(listitem, url)
    label_season = _season_number_from_label(meta['label'])
    if label_season and not meta['season']:
        meta['season'] = label_season

    if meta['episode'] or meta['media_type'] == 'episode':
        return None

    if meta['media_type'] in ('tvshow', 'show', 'series', 'serie') or meta['action'] == 'seasons':
        return None

    if is_folder and (meta['media_type'] == 'season' or label_season or (meta['season'] and meta['action'] == 'episodes')):
        meta['media_type'] = 'season'
        if label_season and meta['title'] and not meta['title'].lower().startswith('staffel') and not meta['tvshow_title']:
            meta['tvshow_title'] = meta['title']
        if meta['action'] == 'episodes' and meta['season']:
            if not meta['tvshow_title'] and meta['title'] and not meta['title'].lower().startswith('staffel'):
                meta['tvshow_title'] = meta['title']
            if not label_season:
                meta['title'] = 'Staffel %s' % meta['season']
        if label_season:
            meta['title'] = meta['label']
        elif not meta['title']:
            meta['title'] = meta['label']
        return meta

    if meta['media_type'] == 'movie':
        return None if _is_category(meta) else meta

    if meta['year'] and not meta['season'] and not _is_category(meta):
        meta['media_type'] = 'movie'
        return meta

    return None


def _wrapper_url(original_url, original_is_folder, meta):
    if original_is_folder:
        action = _first(_query_params(original_url), 'action', 'function')
        if action == 'episodes':
            original_url = _compact_plugin_sysmeta_url(original_url)
        if action == 'episodes' and len(str(original_url or '')) > 12000:
            stored_url = _store_passthrough_url(original_url)
            if stored_url != original_url:
                _log('stored large folder url action=episodes from %d chars' % len(str(original_url or '')))
                original_url = stored_url
        elif action != 'episodes':
            original_url = _compact_plugin_sysmeta_url(original_url)
    params = {
        CHOICE_PARAM: '1',
        'original_url': original_url,
        'original_is_folder': '1' if original_is_folder else '0',
        'media_type': meta.get('media_type') or 'movie',
        'title': meta.get('title') or meta.get('label') or '',
    }
    for key in ('year', 'tvshow_title', 'season', 'episode'):
        value = meta.get(key)
        if value:
            params[key] = value
    return 'plugin://%s/?%s' % (ADDON_ID, urlencode(params))


def _passthrough_url(url):
    url = str(url or '')
    if not url or PASSTHROUGH_PARAM in _query_params(url):
        return url
    joiner = '&' if '?' in url else '?'
    return '%s%s%s=1' % (url, joiner, PASSTHROUGH_PARAM)


def _builtin_arg(value):
    value = str(value or '')
    return '"%s"' % value.replace('\\', '\\\\').replace('"', '\\"')


def _open_original_url(original_url, original_is_folder):
    original_url = _resolve_passthrough_token_url(original_url)
    if original_is_folder:
        original_url = _enrich_tvshow_seasons_url(original_url)
        original_url = _enrich_episode_season_url(original_url)
        original_url = _compact_plugin_sysmeta_url(original_url)
    url = _passthrough_url(original_url)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if original_is_folder:
        short_url = _store_passthrough_url(original_url)
        _log('open folder passthrough token url_len=%s short=%s' % (len(url), short_url))
        xbmc.executebuiltin('Container.Update(%s)' % _builtin_arg(short_url))
    else:
        _log('run plugin passthrough: %s' % url)
        xbmc.executebuiltin('RunPlugin(%s)' % _builtin_arg(url))


def _container_update_original_url(original_url):
    original_url = _resolve_passthrough_token_url(original_url)
    original_url = _compact_plugin_sysmeta_url(original_url)
    short_url = _store_passthrough_url(original_url)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    _log('container update favourite original url_len=%s short=%s' % (len(str(original_url or '')), short_url))
    xbmc.executebuiltin('Container.Update(%s,replace)' % _builtin_arg(short_url))


def _continue_with_original_folder(original_url):
    original_url = _resolve_passthrough_token_url(original_url)
    original_url = _enrich_tvshow_seasons_url(original_url)
    original_url = _enrich_episode_season_url(original_url)
    original_url = _compact_plugin_sysmeta_url(original_url)
    passthrough = _passthrough_url(original_url)
    parsed = urlsplit(passthrough)
    sys.argv[2] = '?' + parsed.query if parsed.query else ''
    _log('continue folder in-process action=%s url_len=%s' % (
        _first(_query_params(sys.argv[2]), 'action', 'function'),
        len(passthrough),
    ))
    return True


def _continue_with_original_plugin(original_url):
    original_url = _resolve_passthrough_token_url(original_url)
    original_url = _compact_plugin_sysmeta_url(original_url)
    passthrough = _passthrough_url(original_url)
    parsed = urlsplit(passthrough)
    sys.argv[2] = '?' + parsed.query if parsed.query else ''
    _remember_favourite_source_listing(sys.argv[2])
    _log('continue plugin in-process action=%s url_len=%s' % (
        _first(_query_params(sys.argv[2]), 'action', 'function'),
        len(passthrough),
    ))
    return True


def _patched_add_directory_item(original_func):
    def wrapped(handle, url, listitem, isFolder=False, totalItems=0):
        try:
            url = _rewrite_old_addon_refs(url)
            if _should_hide_root_item(url, listitem):
                _log('hidden root item: Werkzeuge')
                return True
            _rename_root_item_label(listitem)
            _normalize_listitem_art(listitem)
            _apply_clean_studios(listitem, url)
            _track_view_candidate(url, listitem, isFolder)
            _apply_next_page_art(url, listitem, isFolder)
            if _is_favourite_direct_context() and str(url or '').startswith('plugin://%s/' % ADDON_ID):
                url = _append_query_flag(url, FAVOURITE_DIRECT_PARAM)
            meta = _should_wrap(url, listitem, isFolder)
            if meta:
                url = _wrapper_url(url, isFolder, meta)
                _log('wrapped %s: %s' % (meta.get('media_type'), meta.get('title')))
            if _is_movie_navigator_path():
                _movie_navigator_buffer.append((handle, url, listitem, isFolder))
                return True
            if _is_tv_navigator_path():
                _tv_navigator_buffer.append((handle, url, listitem, isFolder))
                return True
        except Exception as exc:
            _log('wrap failed: %s' % exc, xbmc.LOGWARNING)
        return original_func(handle, url, listitem, isFolder, totalItems)
    return wrapped


def _patched_add_directory_items(original_func):
    global _original_add_directory_items
    _original_add_directory_items = original_func
    def wrapped(handle, items, totalItems=0):
        patched = []
        for item in items:
            try:
                url, listitem, is_folder = item[:3]
                url = _rewrite_old_addon_refs(url)
                if _should_hide_root_item(url, listitem):
                    _log('hidden bulk root item: Werkzeuge')
                    continue
                _rename_root_item_label(listitem)
                _normalize_listitem_art(listitem)
                _apply_clean_studios(listitem, url)
                _track_view_candidate(url, listitem, is_folder)
                _apply_next_page_art(url, listitem, is_folder)
                if _is_favourite_direct_context() and str(url or '').startswith('plugin://%s/' % ADDON_ID):
                    url = _append_query_flag(url, FAVOURITE_DIRECT_PARAM)
                meta = _should_wrap(url, listitem, is_folder)
                if meta:
                    url = _wrapper_url(url, is_folder, meta)
                    item = (url, listitem, is_folder) + tuple(item[3:])
            except Exception as exc:
                _log('bulk wrap failed: %s' % exc, xbmc.LOGWARNING)
            patched.append(item)
        patched = _reorder_movie_navigator_items(patched)
        patched = _reorder_tv_navigator_items(patched)
        return original_func(handle, patched, totalItems)
    return wrapped


def _text_from_runs(data):
    if not data:
        return ''
    if isinstance(data, str):
        return data
    text = data.get('simpleText')
    if text:
        return text
    return ''.join([run.get('text', '') for run in data.get('runs', []) if isinstance(run, dict)])


def _walk_video_renderers(data):
    if isinstance(data, dict):
        renderer = data.get('videoRenderer')
        if renderer:
            yield renderer
        for value in data.values():
            for item in _walk_video_renderers(value):
                yield item
    elif isinstance(data, list):
        for value in data:
            for item in _walk_video_renderers(value):
                yield item


def _duration_seconds(renderer):
    text = _text_from_runs((renderer or {}).get('lengthText'))
    if not text:
        return 0
    try:
        parts = [int(part) for part in text.strip().split(':')]
    except Exception:
        return 0
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return parts[0] if parts else 0


def _find_youtube_trailer_id(title, year=''):
    base_title = _clean_trailer_label(title)
    query_parts = [base_title]
    if year and str(year) not in base_title:
        query_parts.append(str(year))
    base_query = ' '.join(part for part in query_parts if part).strip()
    if not base_query:
        return ''

    reject_words = (
        'review', 'kritik', 'analyse', 'erklaert', 'erklärt', 'reaction',
        'recap', 'zusammenfassung', 'ranking', 'theorie', 'erklaerung',
        'erklärung', 'komplett', 'ganze folge',
    )
    search_queries = (
        (base_query + ' KinoCheck Deutsch Trailer', True),
        (base_query + ' Offizieller Deutsch Trailer', False),
    )
    for query, require_kinocheck in search_queries:
        payload = json.dumps({
            'context': {
                'client': {
                    'clientName': 'WEB',
                    'clientVersion': '2.20250925.01.00',
                    'hl': 'de',
                    'gl': 'DE',
                },
            },
            'query': query,
        }).encode('utf-8')
        request = Request(
            'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'Origin': 'https://www.youtube.com',
                'User-Agent': (
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/140.0.0.0 Safari/537.36'
                ),
            },
        )
        data = json.loads(_nova_urlopen(request, timeout=10).read().decode('utf-8'))
        best = None
        for index, renderer in enumerate(_walk_video_renderers(data)):
            video_id = renderer.get('videoId')
            if not video_id:
                continue
            title_text = _text_from_runs(renderer.get('title'))
            renderer_title = title_text.lower()
            channel_text = ' '.join(
                _text_from_runs(renderer.get(key))
                for key in ('ownerText', 'longBylineText', 'shortBylineText')
            ).lower()
            is_kinocheck = 'kinocheck' in renderer_title or 'kinocheck' in channel_text
            has_german_marker = 'deutsch' in renderer_title or 'german' in renderer_title
            has_english_marker = 'english' in renderer_title or 'englisch' in renderer_title
            duration = _duration_seconds(renderer)
            if require_kinocheck and not is_kinocheck:
                continue
            if require_kinocheck and not has_german_marker:
                continue
            if has_english_marker and not has_german_marker:
                continue
            if 'trailer' not in renderer_title:
                continue
            if any(word in renderer_title for word in reject_words):
                continue
            if duration and duration > 600:
                continue
            score = 10 if is_kinocheck else 0
            if 'offiziell' in renderer_title or 'official' in renderer_title:
                score += 3
            if has_german_marker:
                score += 2
            if duration and 45 <= duration <= 300:
                score += 1
            candidate = (score, -index, video_id, title_text)
            if best is None or candidate[:3] > best[:3]:
                best = candidate
        if best:
            _log('trailer found for %s: %s - %s' % (query, best[2], best[3]))
            return best[2]
    return ''


def _normalize_trailer_title(title):
    text = str(title or '').replace('\u00df', 'ss').replace('\u1e9e', 'ss')
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    text = re.sub(r'[\[\]\(\)\{\}:|,._+!?/\\-]+', ' ', text.lower())
    return re.sub(r'\s+', ' ', text).strip()


def _without_leading_articles(title):
    return re.sub(r'^(the|der|die|das|ein|eine)\s+', '', _normalize_trailer_title(title)).strip()


def _meaningful_trailer_tokens(title):
    ignored = set(['der', 'die', 'das', 'the', 'ein', 'eine', 'und', 'oder', 'of', 'and', 'a',
                   'trailer', 'official', 'offiziell', 'deutsch', 'german', 'english', 'hd',
                   'film', 'movie', 'kino', 'kinocheck', 'extended', 'director', 'directors',
                   'cut', 'unrated', 'uncut', 'remastered', 'remaster', 'ultimate', 'special',
                   'edition', 'fassung', 'langfassung', 'kinofassung'])
    return [token for token in _normalize_trailer_title(title).split() if len(token) > 1 and token not in ignored]


def _youtube_title_matches_request(request_title, result_title, year=''):
    request_year = str(year or '')[:4]
    if not request_year:
        year_match = re.search(r'\b(?:19|20)\d{2}\b', str(request_title or ''))
        request_year = year_match.group(0) if year_match else ''
    request_tokens = [
        token for token in _meaningful_trailer_tokens(request_title)
        if not re.match(r'^(?:19|20)\d{2}$', token)
    ]
    result_tokens = set(_meaningful_trailer_tokens(result_title))
    if not request_tokens:
        return True
    if len(request_tokens) == 1:
        token = request_tokens[0]
        result_norm = _normalize_trailer_title(result_title)
        compact_initialisms = [re.sub(r'\s+', '', match) for match in re.findall(r'(?:\b[a-z0-9]\b\s*){2,}', result_norm)]
        if request_year:
            result_years = re.findall(r'\b(?:19|20)\d{2}\b', str(result_title))
            if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
                return False
        if token in compact_initialisms:
            return True
        result_tokens_clean = [
            item for item in _meaningful_trailer_tokens(result_title)
            if not re.match(r'^#?\d+$', item)
            and not re.match(r'^(?:19|20)\d{2}$', item)
        ]
        return result_tokens_clean == [token]
    missing = [token for token in request_tokens if token not in result_tokens]
    if request_year:
        result_years = re.findall(r'\b(?:19|20)\d{2}\b', str(result_title))
        if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
            return False
    return len(missing) <= max(0, len(request_tokens) // 4)


def _tmdb_title_matches(item, lookup_title):
    lookup_norm = _normalize_trailer_title(lookup_title)
    lookup_article = _without_leading_articles(lookup_title)
    for key in ('title', 'name', 'original_title', 'original_name'):
        candidate = item.get(key) or ''
        if _normalize_trailer_title(candidate) == lookup_norm:
            return True
        if _normalize_trailer_title(candidate).replace(' ', '') == lookup_norm.replace(' ', ''):
            return True
        if _without_leading_articles(candidate) == lookup_article:
            return True
    return False


def _tmdb_year(item, media_type):
    value = item.get('release_date') if media_type == 'movie' else item.get('first_air_date')
    return str(value or '')[:4]


def _year_close(expected, actual):
    try:
        return not expected or not actual or abs(int(str(expected)[:4]) - int(str(actual)[:4])) <= 1
    except Exception:
        return True


def _tmdb_get(endpoint, params):
    params = dict(params)
    params['api_key'] = TMDB_API_KEY
    url = 'https://api.themoviedb.org/3/%s?%s' % (endpoint, urlencode(params))
    request = Request(url, headers={'User-Agent': 'Kodi-Trailer-Lookup/1.0'})
    return json.loads(_nova_urlopen(request, timeout=6).read().decode('utf-8', 'ignore'))


def _find_tmdb_trailer_id(title, media_type='movie', year='', preferred_language='de'):
    try:
        lookup_title = _clean_trailer_label(title)
        clean_year = str(year or '')[:4]
        lookup_title = re.sub(r'\(?\b(?:19|20)\d{2}\b\)?', ' ', lookup_title)
        lookup_title = re.sub(r'\s+', ' ', lookup_title).strip(' -:|')
        if not lookup_title:
            return ''
        lookup_type = 'tv' if media_type in ('tvshow', 'season', 'episode', 'tv') else 'movie'
        search_endpoint = 'search/tv' if lookup_type == 'tv' else 'search/movie'
        year_key = 'first_air_date_year' if lookup_type == 'tv' else 'primary_release_year'
        params = {'query': lookup_title, 'language': 'de-DE', 'include_adult': 'false'}
        if clean_year:
            params[year_key] = clean_year
        results = (_tmdb_get(search_endpoint, params).get('results') or [])
        if not results and clean_year:
            params.pop(year_key, None)
            results = (_tmdb_get(search_endpoint, params).get('results') or [])
        tmdb_id = ''
        for item in results:
            if _year_close(clean_year, _tmdb_year(item, lookup_type)) and _tmdb_title_matches(item, lookup_title):
                tmdb_id = str(item.get('id') or '')
                break
        if not tmdb_id and results and _year_close(clean_year, _tmdb_year(results[0], lookup_type)):
            tmdb_id = str(results[0].get('id') or '')
        if not tmdb_id:
            return ''
        lang_code = 'de' if preferred_language == 'de' else 'en'
        data = _tmdb_get('%s/%s' % (lookup_type, tmdb_id), {
            'language': 'de-DE' if preferred_language == 'de' else 'en-US',
            'append_to_response': 'videos',
            'include_video_language': lang_code,
        })
        best = None
        for index, video in enumerate((data.get('videos') or {}).get('results') or []):
            if (video.get('site') or '').lower() != 'youtube':
                continue
            if (video.get('iso_639_1') or '').lower() != lang_code:
                continue
            video_type = (video.get('type') or '').lower()
            name = video.get('name') or ''
            if video_type != 'trailer' and 'trailer' not in name.lower():
                continue
            score = (10 if video.get('official') else 0) + (3 if video_type == 'trailer' else 0) - index
            candidate = (score, video.get('key'), name)
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best and best[1]:
            _log('TMDB trailer found (%s): %s - %s' % (preferred_language, best[1], best[2]))
            return best[1]
    except Exception as exc:
        _log('TMDB trailer failed: %s' % exc, xbmc.LOGERROR)
    return ''


def _find_youtube_trailer_id_language(title, year='', preferred_language='de', strict_german_marker=True):
    base_title = _clean_trailer_label(title)
    base_query = ' '.join(part for part in (base_title, str(year) if year and str(year) not in base_title else '') if part).strip()
    if not base_query:
        return ''
    reject_words = ('review', 'kritik', 'analyse', 'erklaert', 'erklärt', 'reaction',
                    'recap', 'zusammenfassung', 'ranking', 'theorie', 'erklaerung',
                    'erklärung', 'komplett', 'ganze folge')
    if preferred_language == 'kinocheck':
        search_queries = ((base_query + ' KinoCheck Deutsch Trailer', True),)
        hl, gl = 'de', 'DE'
    elif preferred_language == 'de':
        if strict_german_marker:
            search_queries = ((base_query + ' KinoCheck Deutsch Trailer', True), (base_query + ' Offizieller Deutsch Trailer', False))
        else:
            search_queries = ((base_query + ' Trailer Deutsch', False), (base_query + ' Offizieller Deutsch Trailer', False))
        hl, gl = 'de', 'DE'
    else:
        search_queries = ((base_query + ' Official Trailer', False), (base_query + ' Trailer', False))
        hl, gl = 'en', 'US'
    for query, require_kinocheck in search_queries:
        payload = json.dumps({'context': {'client': {'clientName': 'WEB', 'clientVersion': '2.20250925.01.00', 'hl': hl, 'gl': gl}}, 'query': query}).encode('utf-8')
        request = Request('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', data=payload, headers={'Content-Type': 'application/json', 'Origin': 'https://www.youtube.com', 'User-Agent': 'Mozilla/5.0'})
        data = json.loads(_nova_urlopen(request, timeout=10).read().decode('utf-8'))
        best = None
        for index, renderer in enumerate(_walk_video_renderers(data)):
            video_id = renderer.get('videoId')
            if not video_id:
                continue
            title_text = _text_from_runs(renderer.get('title'))
            renderer_title = title_text.lower()
            channel_text = ' '.join(_text_from_runs(renderer.get(key)) for key in ('ownerText', 'longBylineText', 'shortBylineText')).lower()
            is_kinocheck = 'kinocheck' in renderer_title or 'kinocheck' in channel_text
            has_german_marker = 'deutsch' in renderer_title or 'german' in renderer_title
            if require_kinocheck and (not is_kinocheck or not has_german_marker):
                continue
            if strict_german_marker and preferred_language in ('de', 'kinocheck') and not has_german_marker:
                continue
            if preferred_language == 'en' and has_german_marker:
                continue
            if 'trailer' not in renderer_title or any(word in renderer_title for word in reject_words):
                continue
            duration = _duration_seconds(renderer)
            if duration and duration > 600:
                continue
            if not _youtube_title_matches_request(base_title, title_text, year):
                continue
            score = (10 if is_kinocheck else 0) + (3 if 'offiziell' in renderer_title or 'official' in renderer_title else 0) + (2 if has_german_marker else 0) + (1 if duration and 45 <= duration <= 300 else 0)
            candidate = (score, -index, video_id, title_text)
            if best is None or candidate[:3] > best[:3]:
                best = candidate
        if best:
            _log('YouTube trailer found (%s): %s - %s' % (preferred_language, best[2], best[3]))
            return best[2]
    return ''


def _find_best_trailer_id(title, media_type='movie', year=''):
    return (
        _find_youtube_trailer_id_language(title, year, 'kinocheck')
        or _find_tmdb_trailer_id(title, media_type, year, 'de')
        or _find_youtube_trailer_id_language(title, year, 'de')
        or _find_tmdb_trailer_id(title, media_type, year, 'en')
        or _find_youtube_trailer_id_language(title, year, 'en')
        or _find_youtube_trailer_id_language(title, year, 'de', False)
    )


def _trailer_search_title(title, media_type, tvshow_title='', season='', episode=''):
    media_type = str(media_type or '').lower()
    base = _clean_trailer_label(tvshow_title or title)
    if media_type == 'season' and season:
        return '%s Staffel %s' % (base, season)
    if media_type == 'episode':
        parts = [base]
        if season:
            parts.append('Staffel %s' % season)
        if episode:
            parts.append('Episode %s' % episode)
        clean_title = _clean_trailer_label(title)
        if clean_title and clean_title not in parts:
            parts.append(clean_title)
        return ' '.join(parts).strip()
    return _clean_trailer_label(title or base)


def _play_youtube(video_id):
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    script = 'special://home/addons/%s/nova_play_youtube.py' % ADDON_ID
    safe_video_id = re.sub(r'[^A-Za-z0-9_-]', '', str(video_id or ''))
    if safe_video_id:
        xbmc.executebuiltin('RunScript(%s,%s)' % (script, safe_video_id))


def _finish_directory(success=False):
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), bool(success))
    except Exception:
        pass


def _addon_art(name, fallback='DefaultFolder.png'):
    name = str(name or '').strip()
    fallback = str(fallback or 'DefaultFolder.png').strip()
    if not name:
        return fallback or 'special://home/addons/%s/icon.png' % ADDON_ID
    if name.startswith('special://') or name.startswith('http://') or name.startswith('https://'):
        return name
    for subdir in ('resources/art', 'resources/images', ''):
        try:
            candidate_path = os.path.join(
                xbmcvfs.translatePath('special://home/addons/%s' % ADDON_ID),
                subdir,
                name,
            )
            if os.path.exists(candidate_path):
                return 'special://home/addons/%s/%s/%s' % (ADDON_ID, subdir, name) if subdir else 'special://home/addons/%s/%s' % (ADDON_ID, name)
        except Exception:
            pass
    return fallback or name


def _fast_plugin_url(query):
    query = str(query or '').strip()
    if query.startswith('?'):
        return '%s%s' % (sys.argv[0], query)
    if query.startswith('action='):
        return '%s?%s' % (sys.argv[0], query)
    return '%s?action=%s' % (sys.argv[0], query)


def _fast_add_item(label, query, thumb='', fallback_icon='DefaultFolder.png', is_folder=True):
    try:
        item = xbmcgui.ListItem(label=str(label or ''))
    except TypeError:
        item = xbmcgui.ListItem(str(label or ''))
    icon = _addon_art(thumb, fallback_icon)
    try:
        item.setArt({
            'icon': icon,
            'thumb': icon,
            'poster': icon,
            'banner': icon,
            'fanart': 'special://home/addons/%s/fanart.jpg' % ADDON_ID,
        })
    except Exception:
        pass
    try:
        item.setInfo('video', {'title': _clean_label(label)})
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), _fast_plugin_url(query), item, bool(is_folder))


def _fast_end(content=''):
    try:
        if content:
            xbmcplugin.setContent(int(sys.argv[1]), content)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(int(sys.argv[1]), True)
    return True


def _fast_search_terms(table):
    try:
        from resources.lib import searchDB
        terms = searchDB.getSearchTerms(table)
        if isinstance(terms, list):
            return terms
    except Exception as exc:
        _log('fast search terms failed %s: %s' % (table, exc), xbmc.LOGWARNING)
    return []


def _fast_render_search_menu(table, label, target_action, icon):
    _fast_add_item('[B]%s - neue Suche[/B]' % label, 'searchNew&table=%s' % table, icon, 'DefaultAddonsSearch.png', False)
    terms = _fast_search_terms(table)
    seen = set()
    count = 0
    for entry in terms:
        term = ''
        try:
            term = str(entry.get('query') if isinstance(entry, dict) else entry or '').strip()
        except Exception:
            term = ''
        if not term or term.lower() in seen:
            continue
        seen.add(term.lower())
        count += 1
        _fast_add_item(term, '%s&page=1&query=%s' % (target_action, quote_plus(term)), icon, 'DefaultAddonsSearch.png', True)
    if count:
        _fast_add_item('[B]Suchverlauf löschen[/B]', 'searchClear&table=%s' % table, 'tools.png', 'DefaultAddonProgram.png', False)
    _log('fast search menu rendered: %s (%s history)' % (table, count))
    return _fast_end('')


def _fast_search_new(table):
    table = str(table or '').strip()
    target = {'movies': 'movies', 'tvshows': 'tvshows', 'person': 'person'}.get(table)
    if not target:
        return False
    keyboard = xbmc.Keyboard('', 'Suche')
    keyboard.doModal()
    if keyboard.isConfirmed():
        term = str(keyboard.getText() or '').strip()
        if term:
            try:
                from resources.lib import searchDB
                searchDB.save_query(term, table)
            except Exception:
                pass
            xbmc.executebuiltin('Container.Update(%s)' % _builtin_arg(_fast_plugin_url('%s&page=1&query=%s' % (target, quote_plus(term)))))
    _finish_directory(False)
    return True


def _fast_search_clear(table):
    try:
        from resources.lib import searchDB
        searchDB.remove_all_query(str(table or ''))
    except Exception as exc:
        _log('fast search clear failed %s: %s' % (table, exc), xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    _finish_directory(False)
    return True


def _fast_render_root():
    _fast_add_item('Filme', 'movieNavigator', 'movies.png', 'DefaultMovies.png', True)
    _fast_add_item('Serien', 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png', True)
    _fast_add_item('Suche Filme', 'moviesSearch', '_search.png', 'DefaultAddonsSearch.png', True)
    _fast_add_item('Suche Serien', 'tvshowsSearch', '_search.png', 'DefaultAddonsSearch.png', True)
    _fast_add_item('Darsteller - Suche nach Person', 'personSearch', '_people-search.png', 'DefaultAddonsSearch.png', True)
    _log('fast root menu rendered')
    return _fast_end('')


def _fast_render_movie_navigator():
    _fast_add_item('[B]Filme[/B] - Neu', 'listings&media_type=movie&url=kino', 'in-theaters.png', 'DefaultRecentlyAddedMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Am populärsten', 'listings&media_type=movie&url=production_status=released%26sort_by=popularity.desc', 'most-popular.png', 'DefaultMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Am besten bewertet', 'listings&media_type=movie&url=production_status=released%26sort_by=vote_average.desc', 'highly-rated.png', 'DefaultMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Meist bewertet', 'listings&media_type=movie&url=production_status=released%26sort_by=vote_count.desc', 'most-voted.png', 'DefaultMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Bestes Einspielergebnis', 'listings&media_type=movie&url=production_status=released%26sort_by=revenue.desc', 'box-office.png', 'DefaultMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Jahr', 'movieYears', 'years.png', 'DefaultMovies.png', True)
    _fast_add_item('[B]Filme[/B] - Genres', 'movieGenres', 'genres.png', 'DefaultMovies.png', True)
    _log('fast movie navigator rendered')
    return _fast_end('')


def _fast_render_tv_navigator():
    _fast_add_item('[B]Serien[/B] - Am populärsten', 'listings&media_type=tv&url=sort_by=popularity.desc', 'most-popular.png', 'DefaultTVShows.png', True)
    _fast_add_item('[B]Serien[/B] - Am besten bewertet', 'listings&media_type=tv&url=sort_by=vote_average.desc', 'highly-rated.png', 'DefaultTVShows.png', True)
    _fast_add_item('[B]Serien[/B] - Meist bewertet', 'listings&media_type=tv&url=sort_by=vote_count.desc', 'most-voted.png', 'DefaultTVShows.png', True)
    _fast_add_item('[B]Serien[/B] - Genres', 'tvGenres', 'genres.png', 'DefaultTVShows.png', True)
    _log('fast tv navigator rendered')
    return _fast_end('')


def _handle_fast_menu_route():
    try:
        params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
        action_l = _first(params, 'action', 'function').strip().lower()
        if not action_l or action_l == 'root':
            return _fast_render_root()
        if action_l == 'movienavigator':
            return _fast_render_movie_navigator()
        if action_l == 'tvnavigator':
            return _fast_render_tv_navigator()
        if action_l == 'moviessearch':
            return _fast_render_search_menu('movies', 'Filme', 'movies', '_search.png')
        if action_l == 'tvshowssearch':
            return _fast_render_search_menu('tvshows', 'Serien', 'tvshows', '_search.png')
        if action_l == 'personsearch':
            return _fast_render_search_menu('person', 'Darsteller', 'person', '_people-search.png')
        if action_l == 'searchnew':
            return _fast_search_new(_first(params, 'table'))
        if action_l == 'searchclear':
            return _fast_search_clear(_first(params, 'table'))
    except Exception as exc:
        _log('fast menu route failed: %s' % exc, xbmc.LOGWARNING)
    return False


def _favourite_label(title, media_type='', tvshow_title='', season='', episode=''):
    title = _clean_label(title)
    tvshow_title = _clean_label(tvshow_title)
    media_type = str(media_type or '').lower()
    if media_type == 'season' and tvshow_title:
        return '%s - %s' % (tvshow_title, title or ('Staffel %s' % season))
    if media_type == 'episode' and tvshow_title:
        parts = [tvshow_title]
        if season:
            parts.append('S%s' % season)
        if episode:
            parts.append('E%s' % episode)
        if title and title != tvshow_title:
            parts.append(title)
        return ' '.join(parts)
    return title or tvshow_title or 'Favorit'


def _favourite_thumb_from_url(url):
    params = _query_params(url)
    sysmeta = _decode_sysmeta(params)
    return (
        _first(params, 'thumb', 'trumb', 'sThumbnail', 'thumbnail', 'iconimage')
        or _meta_first(sysmeta, 'poster', 'thumb', 'thumbnail', 'cover_url', 'icon')
        or ''
    )


def _favourites_xml_path():
    try:
        return xbmcvfs.translatePath('special://profile/favourites.xml')
    except Exception:
        return os.path.join(xbmcvfs.translatePath('special://profile/'), 'favourites.xml')


def _clear_favourites_command():
    return 'RunPlugin(plugin://%s/?%s=1)' % (ADDON_ID, CLEAR_FAVOURITES_PARAM)


def _is_clear_favourites_entry(element):
    try:
        name = element.get('name') or ''
        text = element.text or ''
        return name == CLEAR_FAVOURITES_LABEL or CLEAR_FAVOURITES_PARAM in text
    except Exception:
        return False


def _indent_xml(element, level=0):
    indent = '\n' + ('    ' * level)
    child_indent = '\n' + ('    ' * (level + 1))
    children = list(element)
    if children:
        if not element.text or not element.text.strip():
            element.text = child_indent
        for child in children:
            _indent_xml(child, level + 1)
        if not children[-1].tail or not children[-1].tail.strip():
            children[-1].tail = indent
    if level and (not element.tail or not element.tail.strip()):
        element.tail = indent


def _load_favourites_root():
    path = _favourites_xml_path()
    try:
        if path and os.path.exists(path):
            return ET.parse(path).getroot(), path
    except Exception as exc:
        _log('load favourites.xml failed, recreating root: %s' % exc, xbmc.LOGWARNING)
    return ET.Element('favourites'), path


def _write_favourites_root(root, path):
    try:
        directory = os.path.dirname(path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        _indent_xml(root)
        tree = ET.ElementTree(root)
        tree.write(path, encoding='utf-8', xml_declaration=False)
        return True
    except Exception as exc:
        _log('write favourites.xml failed: %s' % exc, xbmc.LOGERROR)
        return False


def _jsonrpc(method, params=None):
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': method,
    }
    if params is not None:
        request['params'] = params
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if response.get('error'):
        raise RuntimeError(response.get('error'))
    return response.get('result') or {}


def _remove_runtime_favourite(favourite):
    try:
        title = favourite.get('title') or favourite.get('name') or ''
        if not title or title == CLEAR_FAVOURITES_LABEL:
            return False
        favourite_type = favourite.get('type') or ''
        params = {
            'title': title,
            'type': favourite_type,
        }
        if favourite_type == 'window':
            params['window'] = favourite.get('window') or 'videos'
            params['windowparameter'] = favourite.get('windowparameter') or favourite.get('path') or ''
        else:
            params['path'] = favourite.get('path') or favourite.get('windowparameter') or ''
        if favourite.get('thumbnail'):
            params['thumbnail'] = favourite.get('thumbnail')
        _jsonrpc('Favourites.RemoveFavourite', params)
        return True
    except Exception as exc:
        _log('runtime favourite remove failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _clear_runtime_favourites():
    removed = 0
    try:
        result = _jsonrpc('Favourites.GetFavourites', {
            'properties': ['path', 'window', 'windowparameter', 'thumbnail']
        })
        for favourite in result.get('favourites') or []:
            if _remove_runtime_favourite(favourite):
                removed += 1
        if removed:
            _log('runtime favourites removed=%s' % removed)
    except Exception as exc:
        _log('runtime favourites clear failed: %s' % exc, xbmc.LOGWARNING)
    return removed


def _delete_visible_favourites_via_ui(count):
    if count <= 0:
        return 0
    deleted = 0
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.executebuiltin('ActivateWindow(FavouritesBrowser)')
        xbmc.sleep(500)
        xbmc.executebuiltin('Control.SetFocus(50,0,absolute)')
        xbmc.sleep(200)
        for _idx in range(count):
            xbmc.executebuiltin('Control.SetFocus(50,1,absolute)')
            xbmc.sleep(200)
            xbmc.executebuiltin('Action(Delete)')
            xbmc.sleep(500)
            deleted += 1
        xbmc.executebuiltin('Control.SetFocus(50,0,absolute)')
        xbmc.sleep(150)
        xbmc.executebuiltin('Container.Refresh')
    except Exception as exc:
        _log('visible favourites ui delete failed: %s' % exc, xbmc.LOGWARNING)
    return deleted


def _ensure_clear_favourites_entry():
    root, path = _load_favourites_root()
    if root is None or not path:
        return False
    try:
        keep = [element for element in list(root) if not _is_clear_favourites_entry(element)]
        clear = ET.Element('favourite', {
            'name': CLEAR_FAVOURITES_LABEL,
            'thumb': CLEAR_FAVOURITES_ICON,
        })
        clear.text = _clear_favourites_command()
        root[:] = [clear] + keep
        if _write_favourites_root(root, path):
            _log('clear favourites entry ensured on top')
            return True
    except Exception as exc:
        _log('ensure clear favourites entry failed: %s' % exc, xbmc.LOGERROR)
    return False


def _mark_archiv_navigator_favourites_direct():
    try:
        root, path = _load_favourites_root()
        if root is None or not path:
            return False
        changed = 0

        def mark_url(url):
            try:
                params = _query_params(url)
                if CLEAR_FAVOURITES_PARAM in params or CHOICE_PARAM in params or FAVOURITE_DIRECT_PARAM in params:
                    return url
                return _append_query_flag(url, FAVOURITE_DIRECT_PARAM)
            except Exception:
                return url

        for element in list(root):
            command = element.text or ''
            if 'plugin://%s/' % ADDON_ID not in command:
                continue
            if FAVOURITE_DIRECT_PARAM in command or CLEAR_FAVOURITES_PARAM in command:
                continue
            new_command = re.sub(
                r'(ActivateWindow\(10025,")([^"]+)(",return\))',
                lambda match: match.group(1) + mark_url(match.group(2)) + match.group(3),
                command,
            )
            if new_command == command and command.startswith('RunPlugin(') and command.endswith(')'):
                url = command[len('RunPlugin('):-1]
                new_command = 'RunPlugin(%s)' % mark_url(url)
            if new_command != command:
                element.text = new_command
                changed += 1
        if changed and _write_favourites_root(root, path):
            _log('marked Archiv Navigator favourites direct=%s' % changed)
            return True
    except Exception as exc:
        _log('mark Archiv Navigator favourites direct failed: %s' % exc, xbmc.LOGWARNING)
    return False


def _clear_all_favourites():
    if not xbmcgui.Dialog().yesno('Favoriten', 'Alle Favoriten löschen?'):
        return False
    root, path = _load_favourites_root()
    if root is None or not path:
        xbmcgui.Dialog().notification('Favoriten', 'Favoriten konnten nicht gelesen werden', time=2500)
        return False
    try:
        removed = len([element for element in list(root) if not _is_clear_favourites_entry(element)])
        _delete_visible_favourites_via_ui(removed)
        clear = ET.Element('favourite', {
            'name': CLEAR_FAVOURITES_LABEL,
            'thumb': CLEAR_FAVOURITES_ICON,
        })
        clear.text = _clear_favourites_command()
        root[:] = [clear]
        if _write_favourites_root(root, path):
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmc.executebuiltin('Container.Refresh')
                xbmc.sleep(250)
                xbmc.executebuiltin('Container.Refresh(favourites://)')
                xbmc.sleep(250)
                xbmc.executebuiltin('ActivateWindow(FavouritesBrowser)')
                xbmc.sleep(250)
                xbmc.executebuiltin('Container.Refresh(favourites://)')
            except Exception:
                pass
            xbmcgui.Dialog().notification('Favoriten', '%s Favoriten gelöscht' % removed, time=2500)
            _log('cleared favourites, removed=%s' % removed)
            return True
    except Exception as exc:
        _log('clear all favourites failed: %s' % exc, xbmc.LOGERROR)
    xbmcgui.Dialog().notification('Favoriten', 'Favoriten konnten nicht gelöscht werden', time=2500)
    return False


def _add_kodi_favourite(title, favourite_url, media_type='', tvshow_title='', season='', episode='', thumb=''):
    label = _favourite_label(title, media_type, tvshow_title, season, episode)
    if str(favourite_url or '').startswith('plugin://%s/' % ADDON_ID):
        favourite_url = _append_query_flag(favourite_url, FAVOURITE_DIRECT_PARAM)
    thumb = thumb or _favourite_thumb_from_url(favourite_url)
    try:
        favourite_params = {
            'title': label,
            'thumbnail': thumb,
        }
        if str(favourite_url or '').startswith('plugin://'):
            favourite_params.update({
                'type': 'window',
                'window': 'videos',
                'windowparameter': favourite_url,
            })
        else:
            favourite_params.update({
                'type': 'media',
                'path': favourite_url,
            })
        request = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'Favourites.AddFavourite',
            'params': favourite_params,
        }
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        if response.get('error'):
            raise RuntimeError(response.get('error'))
        _ensure_clear_favourites_entry()
        _log('added favourite via Kodi JSON-RPC: %s' % label, xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log('add favourite failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Archiv Navigator', 'Favorit konnte nicht gespeichert werden', time=2500)
        return False


def _handle_choice():
    params = _query_params(sys.argv[2] if len(sys.argv) > 2 else '')
    original_url = _first(params, 'original_url')
    original_is_folder = _first(params, 'original_is_folder') == '1'
    media_type = _first(params, 'media_type') or 'movie'
    title = _clean_label(_first(params, 'title'))
    year = _first(params, 'year')
    tvshow_title = _clean_label(_first(params, 'tvshow_title'))
    season = _first(params, 'season')
    episode = _first(params, 'episode')

    play_label = _choice_play_label(media_type)
    dialog_title = title
    if media_type == 'season' and tvshow_title:
        dialog_title = '%s - %s' % (tvshow_title, title)

    if _is_favourite_direct_context():
        selection = 0
    else:
        selection = xbmcgui.Dialog().select(dialog_title or 'Archiv Navigator', [play_label, 'Trailer abspielen', 'Informationen', 'Zu Favoriten hinzufügen'])
    if selection == 0:
        if original_is_folder:
            return _continue_with_original_folder(original_url)
        if _is_favourite_direct_context():
            return _continue_with_original_plugin(original_url)
        _open_original_url(original_url, original_is_folder)
        return False
    elif selection == 1:
        try:
            search_title = _trailer_search_title(title, media_type, tvshow_title, season, episode)
            video_id = _find_best_trailer_id(search_title, media_type, year)
            if video_id:
                _play_youtube(video_id)
                _finish_directory(False)
                return False
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            xbmcgui.Dialog().notification('Archiv Navigator', 'Kein Trailer gefunden', time=2500)
        except Exception as exc:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            _log('trailer failed: %s' % exc, xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Archiv Navigator', 'Trailer konnte nicht gestartet werden', time=2500)
    elif selection == 2:
        xbmc.executebuiltin('Action(Info)')
    elif selection == 3:
        favourite_url = original_url if original_is_folder and original_url else _current_plugin_url()
        _add_kodi_favourite(title, favourite_url, media_type, tvshow_title, season, episode)
    _finish_directory(False)
    return False


def _direct_choice_meta(query):
    params = _query_params(query)
    if CHOICE_PARAM in params or PASSTHROUGH_PARAM in params:
        return None
    action = _first(params, 'action', 'function')
    sysmeta = _decode_sysmeta(params)
    media_type = str(
        _meta_first(sysmeta, 'mediatype', 'mediaType', 'type')
        or _first(params, 'media_type', 'mediaType', 'mediatype', 'sMediaType')
        or ''
    ).lower()
    title = _clean_label(_meta_first(sysmeta, 'title', 'name', 'systitle', 'originaltitle') or _first(params, 'title', 'name'))
    tvshow_title = _clean_label(_meta_first(sysmeta, 'tvshowtitle', 'TVShowTitle', 'showtitle', 'systitle', 'title'))
    year = str(_meta_first(sysmeta, 'year', 'premiered') or _first(params, 'year', 'sYear') or '').strip()
    season = str(_meta_first(sysmeta, 'season', 'season_number') or _first(params, 'season') or '').strip()
    episode = str(_meta_first(sysmeta, 'episode', 'episode_number') or _first(params, 'episode') or '').strip()

    if '-' in year:
        year = year.split('-', 1)[0]

    original_url = 'plugin://%s/%s' % (ADDON_ID, query if str(query or '').startswith('?') else '?' + str(query or ''))
    if action == 'playfromPerson' and media_type == 'movie':
        try:
            rebuilt = dict((key, list(value)) for key, value in params.items())
            rebuilt['action'] = ['play']
            if sysmeta:
                rebuilt['sysmeta'] = [json.dumps(sysmeta)]
            original_url = 'plugin://%s/?%s' % (
                ADDON_ID,
                urlencode([(key, item) for key, values in rebuilt.items() for item in values]),
            )
            action = 'play'
            _log('Darsteller-Film auf normalen Film-Playweg umgebogen: %s' % (title or _meta_first(sysmeta, 'tmdb_id', 'id') or '-'))
        except Exception as exc:
            _log('Darsteller-Film Playweg konnte nicht umgebogen werden: %s' % exc, xbmc.LOGWARNING)

    if action == 'play' and media_type == 'movie' and title and not episode:
        original_url = _ensure_movie_imdb_in_url(original_url)
        return {
            'original_url': original_url,
            'original_is_folder': '0',
            'media_type': 'movie',
            'title': title,
            'year': year,
            'play_label': 'Film wiedergeben',
        }

    if action == 'seasons' and media_type in ('tvshow', 'show', 'series', 'serie', 'tv') and title and not season and not episode:
        show_title = tvshow_title or title
        return {
            'original_url': original_url,
            'original_is_folder': '1',
            'media_type': 'tvshow',
            'title': show_title,
            'tvshow_title': show_title,
            'year': year,
            'play_label': 'Serie wiedergeben',
        }

    if action == 'episodes' and season and not episode:
        show_title = tvshow_title or title
        original_url = _compact_plugin_sysmeta_url(original_url)
        if len(str(original_url or '')) > 12000:
            stored_url = _store_passthrough_url(original_url)
            if stored_url != original_url:
                _log('stored large direct episodes url from %d chars' % len(str(original_url or '')))
                original_url = stored_url
        return {
            'original_url': original_url,
            'original_is_folder': '1',
            'media_type': 'season',
            'title': 'Staffel %s' % season,
            'tvshow_title': show_title,
            'year': year,
            'season': season,
            'play_label': 'Staffel wiedergeben',
        }

    return None


def _run_choice(meta):
    original_url = meta.get('original_url') or ''
    original_is_folder = meta.get('original_is_folder') == '1'
    media_type = meta.get('media_type') or 'movie'
    title = _clean_label(meta.get('title') or '')
    year = meta.get('year') or ''
    tvshow_title = _clean_label(meta.get('tvshow_title') or '')
    season = meta.get('season') or ''
    episode = meta.get('episode') or ''
    play_label = meta.get('play_label') or _choice_play_label(media_type)

    dialog_title = title
    if media_type == 'season' and tvshow_title:
        dialog_title = '%s - %s' % (tvshow_title, title)

    if _is_favourite_direct_context():
        selection = 0
    else:
        selection = xbmcgui.Dialog().select(dialog_title or 'Archiv Navigator', [play_label, 'Trailer abspielen', 'Informationen', 'Zu Favoriten hinzufügen'])
    if selection == 0:
        if original_is_folder:
            return _continue_with_original_folder(original_url)
        if _is_favourite_direct_context():
            return _continue_with_original_plugin(original_url)
        _open_original_url(original_url, original_is_folder)
        return False
    elif selection == 1:
        try:
            search_title = _trailer_search_title(title, media_type, tvshow_title, season, episode)
            video_id = _find_best_trailer_id(search_title, media_type, year)
            if video_id:
                _play_youtube(video_id)
                _finish_directory(False)
                return False
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            xbmcgui.Dialog().notification('Archiv Navigator', 'Kein Trailer gefunden', time=2500)
        except Exception as exc:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            _log('trailer failed: %s' % exc, xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Archiv Navigator', 'Trailer konnte nicht gestartet werden', time=2500)
    elif selection == 2:
        xbmc.executebuiltin('Action(Info)')
    elif selection == 3:
        favourite_url = original_url if original_is_folder and original_url else _current_plugin_url()
        _add_kodi_favourite(title, favourite_url, media_type, tvshow_title, season, episode)
    _finish_directory(False)
    return False


def _tmdb_discover_page(media_type, url, append_to_response=None):
    media_type = 'tv' if str(media_type or '').lower() in ('tv', 'tvshow', 'series', 'serie') else 'movie'
    query = str(url or '')
    if 'without_genres' not in query:
        query += '&without_genres=99'
    append_to_response = str(append_to_response or '')
    if append_to_response:
        query += '&%s' % append_to_response
    endpoint = (
        'https://api.themoviedb.org/3/discover/%s?api_key=%s'
        '&language=de-DE&region=DE&vote_count.gte=20&include_adult=false&include_video=false&%s'
    ) % (media_type, TMDB_API_KEY, query)
    request = Request(endpoint, headers={'User-Agent': 'Archiv-Navigator-LightListing/1.0'})
    data = json.loads(_nova_urlopen(request, timeout=8).read().decode('utf-8', 'ignore'))
    if data.get('status_code') == 34:
        return [], 0
    return data.get('results') or [], int(data.get('total_pages') or 0)


def _enrich_tvshow_seasons_url(original_url):
    original_url = str(original_url or '')
    try:
        params = _query_params(original_url)
        action = _first(params, 'action', 'function')
        if action != 'seasons':
            return original_url

        meta = _decode_sysmeta(params)
        media_type = str(_meta_first(meta, 'mediatype', 'media_type', 'mediaType', 'type') or '').lower()
        if media_type not in ('tvshow', 'show', 'series', 'serie', 'tv'):
            return original_url

        try:
            if int(meta.get('number_of_seasons') or 0) > 0 and meta.get('seasons'):
                return original_url
        except Exception:
            pass

        tmdb_id = str(_meta_first(meta, 'tmdb_id', 'id') or '').strip()
        if not tmdb_id:
            return original_url

        endpoint = (
            'https://api.themoviedb.org/3/tv/%s?api_key=%s'
            '&language=de-DE&append_to_response=external_ids'
        ) % (tmdb_id, TMDB_API_KEY)
        request = Request(endpoint, headers={'User-Agent': 'Archiv-Navigator-TVMeta/1.0'})
        details = json.loads(_nova_urlopen(request, timeout=8).read().decode('utf-8', 'ignore'))
        if not isinstance(details, dict) or details.get('success') is False:
            return original_url

        external_ids = details.get('external_ids') if isinstance(details.get('external_ids'), dict) else {}
        poster = _tmdb_image_from_path(details.get('poster_path'), 'w154') or meta.get('poster') or meta.get('cover_url') or ''
        fanart = _tmdb_image_from_path(details.get('backdrop_path'), 'w300') or meta.get('fanart') or meta.get('backdrop_url') or ''
        first_air = str(details.get('first_air_date') or meta.get('premiered') or '').strip()
        title = str(details.get('name') or meta.get('title') or meta.get('systitle') or '').strip()
        original_title = str(details.get('original_name') or meta.get('originaltitle') or title).strip() or title

        enriched = dict(meta)
        enriched.update({
            'tmdb_id': tmdb_id,
            'imdb_id': external_ids.get('imdb_id') or meta.get('imdb_id') or meta.get('imdbnumber') or '',
            'imdbnumber': external_ids.get('imdb_id') or meta.get('imdbnumber') or meta.get('imdb_id') or '',
            'tvdb_id': external_ids.get('tvdb_id') or meta.get('tvdb_id') or '',
            'mediatype': 'tvshow',
            'media_type': 'tvshow',
            'title': title,
            'originaltitle': original_title,
            'systitle': title,
            'sysname': title,
            'plot': _lite_plot({
                'vote_average': details.get('vote_average') or meta.get('rating') or 0,
                'vote_count': details.get('vote_count') or meta.get('votes') or 0,
                'overview': details.get('overview') or meta.get('plot') or '',
            }),
            'premiered': first_air,
            'year': _year_from_date(first_air) or meta.get('year') or '',
            'poster': poster,
            'cover_url': poster,
            'fanart': fanart,
            'backdrop_url': fanart,
            'rating': float(details.get('vote_average') or meta.get('rating') or 0),
            'votes': int(details.get('vote_count') or meta.get('votes') or 0),
            'status': details.get('status') or meta.get('status') or '',
            'tagline': details.get('tagline') or meta.get('tagline') or '',
            'number_of_seasons': int(details.get('number_of_seasons') or meta.get('number_of_seasons') or 0),
            'number_of_episodes': int(details.get('number_of_episodes') or meta.get('number_of_episodes') or 0),
            'seasons': details.get('seasons') or meta.get('seasons') or [],
            'genre': [item.get('name') for item in (details.get('genres') or []) if isinstance(item, dict) and item.get('name')],
            'studio': [item.get('name') for item in ((details.get('networks') or []) + (details.get('production_companies') or [])) if isinstance(item, dict) and item.get('name')],
            'country': details.get('origin_country') or meta.get('country') or [],
        })

        rebuilt = {}
        for key, values in params.items():
            if key in ('sysmeta', 'meta'):
                continue
            if values:
                rebuilt[key] = values[0]
        rebuilt['sysmeta'] = json.dumps(enriched, ensure_ascii=False, separators=(',', ':'))
        fixed_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(rebuilt))
        _log('enriched tvshow seasons metadata: %s seasons=%s url_len=%s' % (
            title or tmdb_id,
            enriched.get('number_of_seasons'),
            len(fixed_url),
        ))
        return fixed_url
    except Exception as exc:
        _log('tvshow seasons metadata enrich failed: %s' % exc, xbmc.LOGWARNING)
        return original_url


def _enrich_episode_season_url(original_url):
    original_url = str(original_url or '')
    try:
        params = _query_params(original_url)
        action = _first(params, 'action', 'function')
        if action != 'episodes':
            return original_url

        meta = _decode_sysmeta(params)
        if not meta:
            return original_url

        existing_episodes = meta.get('episodes')
        if isinstance(existing_episodes, list) and existing_episodes:
            return original_url

        tmdb_id = str(_meta_first(meta, 'tmdb_id', 'id') or '').strip()
        season = str(_meta_first(meta, 'season', 'season_number') or _first(params, 'season', 'sSeasonNr') or '').strip()
        if not tmdb_id or not season:
            return original_url

        try:
            season_number = int(float(season))
        except Exception:
            return original_url

        endpoint = (
            'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s'
            '&language=de-DE'
        ) % (tmdb_id, season_number, TMDB_API_KEY)
        request = Request(endpoint, headers={'User-Agent': 'Archiv-Navigator-EpisodeMeta/1.0'})
        details = json.loads(_nova_urlopen(request, timeout=8).read().decode('utf-8', 'ignore'))
        episodes = details.get('episodes') if isinstance(details, dict) else None
        if not isinstance(episodes, list) or not episodes:
            return original_url

        poster = _tmdb_image_from_path(details.get('poster_path'), 'w154') or meta.get('poster') or meta.get('cover_url') or ''
        fanart = meta.get('fanart') or meta.get('backdrop_url') or ''
        show_title = _meta_first(meta, 'tvshowtitle', 'TVShowTitle', 'showtitle', 'systitle', 'title') or ''
        compact_episodes = []
        for episode in episodes:
            if not isinstance(episode, dict):
                continue
            still = _tmdb_image_from_path(episode.get('still_path'), 'w300') or poster
            air_date = str(episode.get('air_date') or '').strip()
            episode_number = int(episode.get('episode_number') or 0)
            compact_episodes.append({
                'media_type': 'episode',
                'mediatype': 'episode',
                'name': episode.get('name') or 'Folge %s' % episode_number,
                'title': episode.get('name') or 'Folge %s' % episode_number,
                'overview': episode.get('overview') or '',
                'tvshowtitle': show_title,
                'season': season_number,
                'season_number': season_number,
                'episode': episode_number,
                'episode_number': episode_number,
                'premiered': air_date,
                'air_date': air_date,
                'year': _year_from_date(air_date) or meta.get('year') or '',
                'plot': episode.get('overview') or '',
                'still_path': episode.get('still_path') or '',
                'poster': still,
                'cover_url': still,
                'fanart': fanart,
                'backdrop_url': fanart,
                'rating': float(episode.get('vote_average') or 0),
                'votes': int(episode.get('vote_count') or 0),
                'runtime': episode.get('runtime') or details.get('runtime') or meta.get('runtime') or '',
                'tmdb_id': tmdb_id,
                'tvdb_id': meta.get('tvdb_id') or '',
                'imdb_id': meta.get('imdb_id') or meta.get('imdbnumber') or '',
                'imdbnumber': meta.get('imdbnumber') or meta.get('imdb_id') or '',
                'playcount': 0,
                'overlay': 6,
                'budget': '',
                'revenue': '',
                'seasons': [],
            })

        enriched = dict(meta)
        enriched.update({
            'media_type': 'season',
            'mediatype': 'season',
            'season': season_number,
            'number_of_episodes': len(compact_episodes),
            'episodes': compact_episodes,
            'poster': poster,
            'cover_url': poster,
            'fanart': fanart,
            'backdrop_url': fanart,
            'budget': '',
            'revenue': '',
            'seasons': [],
        })

        rebuilt = {}
        for key, values in params.items():
            if key in ('sysmeta', 'meta'):
                continue
            if values:
                rebuilt[key] = values[0]
        rebuilt['sysmeta'] = json.dumps(enriched, ensure_ascii=False, separators=(',', ':'))
        fixed_url = 'plugin://%s/?%s' % (ADDON_ID, urlencode(rebuilt))
        _log('enriched episodes metadata: %s S%s episodes=%s url_len=%s' % (
            show_title or tmdb_id,
            season_number,
            len(compact_episodes),
            len(fixed_url),
        ))
        return fixed_url
    except Exception as exc:
        _log('episode metadata enrich failed: %s' % exc, xbmc.LOGWARNING)
        return original_url


def _patch_lite_season_meta():
    try:
        from resources.lib.indexers import seasons as seasons_module
        cls = seasons_module.seasons
        if getattr(cls, '_nova_lite_season_meta', False):
            return

        original_super_meta = cls.super_meta

        def lite_season_super_meta(self, i):
            try:
                request = (getattr(self, 'list', []) or [])[i]
                season_number = int(request.get('season') or 0)
                show_meta = json.loads(getattr(self, 'sysmeta', '') or '{}')
                seasons_data = show_meta.get('seasons') if isinstance(show_meta, dict) else None
                if not isinstance(seasons_data, list) or not season_number:
                    return original_super_meta(self, i)

                season_entry = None
                for entry in seasons_data:
                    if not isinstance(entry, dict):
                        continue
                    try:
                        if int(entry.get('season_number') if entry.get('season_number') is not None else entry.get('season') or -1) == season_number:
                            season_entry = entry
                            break
                    except Exception:
                        continue
                if not season_entry:
                    return original_super_meta(self, i)

                show_title = _meta_first(show_meta, 'title', 'tvshowtitle', 'TVShowTitle', 'showtitle', 'systitle') or getattr(self, 'title', '') or ''
                air_date = str(season_entry.get('air_date') or '').strip()
                poster = _tmdb_image_from_path(season_entry.get('poster_path'), 'w154') or show_meta.get('poster') or show_meta.get('cover_url') or ''
                fanart = show_meta.get('fanart') or show_meta.get('backdrop_url') or ''
                episode_count = int(season_entry.get('episode_count') or 0)
                season_title = season_entry.get('name') or 'Staffel %s' % season_number

                meta = dict(show_meta)
                meta.update({
                    'media_type': 'season',
                    'mediatype': 'season',
                    'title': season_title,
                    'tvshowtitle': show_title,
                    'TVShowTitle': show_title,
                    'showtitle': show_title,
                    'season': season_number,
                    'number_of_episodes': episode_count,
                    'episodes': [],
                    'premiered': air_date,
                    'year': _year_from_date(air_date) or show_meta.get('year') or '',
                    'plot': season_entry.get('overview') or '',
                    'poster': poster,
                    'cover_url': poster,
                    'fanart': fanart,
                    'backdrop_url': fanart,
                    'rating': float(season_entry.get('vote_average') or 0),
                    'votes': int(season_entry.get('vote_count') or 0),
                    'budget': '',
                    'revenue': '',
                    'seasons': [],
                    'cast': [],
                    'playcount': 0,
                    'overlay': 6,
                })
                try:
                    from resources.lib import playcountDB
                    playcount = playcountDB.getPlaycount('season', 'title', show_title, season_number, None)
                    meta['playcount'] = playcount or 0
                    meta['overlay'] = 7 if meta['playcount'] > 0 else 6
                except Exception:
                    pass

                self.meta.append(meta)
                return meta
            except Exception:
                return original_super_meta(self, i)

        cls.super_meta = lite_season_super_meta
        cls._nova_lite_season_meta = True
        _log('Archiv Navigator lite season meta active')
    except Exception as exc:
        _log('lite season meta patch failed: %s' % exc, xbmc.LOGWARNING)


def _patch_lite_listing_meta():
    try:
        from resources.lib.indexers import movies as movies_module
        cls = movies_module.movies
        if not getattr(cls, '_nova_lite_listing_meta', False):
            original_super_meta = cls.super_meta
            original_worker = cls.worker

            def lite_movie_super_meta(self, i, id=''):
                try:
                    tmdb_id = id if id != '' else self.list[i]
                    meta = _listing_lite_meta_cache.get(_listing_cache_key('movie', tmdb_id))
                    if meta:
                        meta = dict(meta)
                        self.meta.append(meta)
                        return meta
                except Exception:
                    pass
                return original_super_meta(self, i, id)

            def search_order_movie_worker(self):
                if not (getattr(self, 'search_direct', False) or getattr(self, 'query', '')):
                    return original_worker(self)
                try:
                    self.meta = []
                    for i in range(0, len(getattr(self, 'list', []) or [])):
                        self.super_meta(i)
                    self.list = list(self.meta)
                    preview = ' | '.join([str((item or {}).get('title') or (item or {}).get('name') or '') for item in self.list[:8]])
                    _log('Archiv Navigator Filmsuche: Relevanz-Reihenfolge beibehalten (%s Treffer): %s' % (len(self.list), preview))
                    return self.list
                except Exception as exc:
                    _log('Archiv Navigator Filmsuche: Relevanz-Worker fallback: %s' % exc, xbmc.LOGWARNING)
                    return original_worker(self)

            cls.super_meta = lite_movie_super_meta
            cls.worker = search_order_movie_worker
            cls._nova_lite_listing_meta = True
            _log('Archiv Navigator lite movie listing meta active')
    except Exception as exc:
        _log('lite movie listing meta patch failed: %s' % exc, xbmc.LOGWARNING)

    try:
        from resources.lib.indexers import tvshows as tvshows_module
        cls = tvshows_module.tvshows
        if not getattr(cls, '_nova_lite_listing_meta', False):
            original_super_meta = cls.super_meta
            original_worker = cls.worker

            def lite_tv_super_meta(self, i, id=''):
                try:
                    tmdb_id = id if id != '' else self.list[i]
                    meta = _listing_lite_meta_cache.get(_listing_cache_key('tvshow', tmdb_id))
                    if meta:
                        meta = dict(meta)
                        self.meta.append(meta)
                        return meta
                except Exception:
                    pass
                return original_super_meta(self, i, id)

            def search_order_tv_worker(self):
                if not getattr(self, 'query', ''):
                    return original_worker(self)
                try:
                    self.meta = []
                    for i in range(0, len(getattr(self, 'list', []) or [])):
                        self.super_meta(i)
                    self.list = list(self.meta)
                    preview = ' | '.join([str((item or {}).get('title') or (item or {}).get('name') or '') for item in self.list[:8]])
                    _log('Archiv Navigator Seriensuche: Relevanz-Reihenfolge beibehalten (%s Treffer): %s' % (len(self.list), preview))
                    return self.list
                except Exception as exc:
                    _log('Archiv Navigator Seriensuche: Relevanz-Worker fallback: %s' % exc, xbmc.LOGWARNING)
                    return original_worker(self)

            cls.super_meta = lite_tv_super_meta
            cls.worker = search_order_tv_worker
            cls._nova_lite_listing_meta = True
            _log('Archiv Navigator lite tv listing meta active')
    except Exception as exc:
        _log('lite tv listing meta patch failed: %s' % exc, xbmc.LOGWARNING)


def _patch_archiv_navigator_page_size():
    """Show about 100 TMDB items per visible Archiv-Navigator page.

    TMDB itself returns 20 results per API page. The compiled indexers expect
    that native page model, so we keep their public page number as a 100-item
    block and internally fetch five native TMDB pages.
    """
    try:
        from resources.lib.tmdb import cTMDB
        if not getattr(cTMDB, '_nova_page_size_100', False):
            original_search_term = cTMDB.search_term

            def grouped_search_term(self, mediaType, name, page=1):
                try:
                    block_page = int(page or 1)
                except:
                    block_page = 1
                if block_page < 1:
                    block_page = 1

                first_native_page = ((block_page - 1) * 5) + 1
                combined = []
                native_total_pages = 0
                media_key = str(mediaType or '').lower().strip()
                for native_page in range(first_native_page, first_native_page + 5):
                    try:
                        page_items, page_total, _raw_results = _tmdb_search_term_page(mediaType, name, native_page)
                    except Exception as direct_exc:
                        _log('Archiv Navigator 100er-Suche: direkte TMDB-Suche fehlgeschlagen, fallback: %s Seite %s / %s' % (mediaType, native_page, direct_exc), xbmc.LOGWARNING)
                        result = original_search_term(self, mediaType, name, native_page)
                        if not result:
                            _log('Archiv Navigator 100er-Suche: leere/fehlende TMDB-Seite uebersprungen: %s Seite %s' % (mediaType, native_page), xbmc.LOGWARNING)
                            continue
                        page_items, page_total = result
                    try:
                        native_total_pages = max(native_total_pages, int(page_total or 0))
                    except:
                        pass
                    if not page_items:
                        _log('Archiv Navigator 100er-Suche: TMDB-Seite ohne Treffer uebersprungen: %s Seite %s' % (mediaType, native_page), xbmc.LOGWARNING)
                        continue
                    combined.extend(page_items)

                if media_key != 'person':
                    deduped = []
                    seen_ids = set()
                    for tmdb_id in combined:
                        tmdb_id = str(tmdb_id or '').strip()
                        if not tmdb_id or tmdb_id in seen_ids:
                            continue
                        seen_ids.add(tmdb_id)
                        deduped.append(tmdb_id)
                    combined = sorted(deduped, key=lambda tmdb_id: _tmdb_search_cached_id_rank(mediaType, tmdb_id, name))

                grouped_total_pages = int((native_total_pages + 4) / 5) if native_total_pages else 0
                _log('Archiv Navigator 100er-Suche: %s Trefferblock %s -> %s IDs' % (mediaType, block_page, len(combined)))
                return combined, grouped_total_pages

            cTMDB.search_term = grouped_search_term
            cTMDB._nova_page_size_100 = True
            _log('Archiv Navigator search page size patched to 100')
    except Exception as exc:
        _log('Archiv Navigator search page size patch failed: %s' % exc, xbmc.LOGWARNING)

    try:
        from resources.lib.indexers import listings
        cls = listings.listings
        if not getattr(cls, '_nova_page_size_100', False):
            original_call = cls._call

            def _extract_page(append_to_response):
                match = re.search(r'(?:^|&)page=(\d+)', str(append_to_response or ''))
                if not match:
                    return 1
                try:
                    return max(1, int(match.group(1)))
                except:
                    return 1

            def _replace_page(append_to_response, page):
                text = str(append_to_response or '')
                if re.search(r'(?:^|&)page=\d+', text):
                    return re.sub(r'(^|&)page=\d+', lambda match: match.group(1) + 'page=%s' % int(page), text, count=1)
                if text:
                    return text + '&page=%s' % int(page)
                return 'page=%s' % int(page)

            def grouped_call(self, url, append_to_response=None):
                block_page = _extract_page(append_to_response)
                first_native_page = ((block_page - 1) * 5) + 1
                combined = []
                native_total_pages = 0
                for native_page in range(first_native_page, first_native_page + 5):
                    native_append = _replace_page(append_to_response, native_page)
                    try:
                        page_results, page_total = _tmdb_discover_page(getattr(self, 'media_type', ''), url, native_append)
                        try:
                            native_total_pages = max(native_total_pages, int(page_total or 0))
                        except:
                            pass
                        if not page_results:
                            _log('Archiv Navigator 100er-Listing: TMDB-Seite ohne Treffer uebersprungen: %s Seite %s' % (getattr(self, 'media_type', ''), native_page), xbmc.LOGWARNING)
                            continue
                        for entry in page_results:
                            tmdb_id = str(entry.get('id') or '')
                            if not tmdb_id:
                                continue
                            lite_meta = _lite_meta_from_tmdb_result(entry, getattr(self, 'media_type', ''))
                            if lite_meta:
                                _listing_lite_meta_cache[_listing_cache_key(getattr(self, 'media_type', ''), tmdb_id)] = lite_meta
                            combined.append(tmdb_id)
                    except Exception as page_exc:
                        _log('Archiv Navigator 100er-Listing: Light-Seite fehlgeschlagen, fallback: %s Seite %s / %s' % (getattr(self, 'media_type', ''), native_page, page_exc), xbmc.LOGWARNING)
                        result = original_call(self, url, native_append)
                        if not result:
                            _log('Archiv Navigator 100er-Listing: leere/fehlende TMDB-Seite uebersprungen: %s Seite %s' % (getattr(self, 'media_type', ''), native_page), xbmc.LOGWARNING)
                            continue
                        page_items, page_total = result
                        try:
                            native_total_pages = max(native_total_pages, int(page_total or 0))
                        except:
                            pass
                        if not page_items:
                            _log('Archiv Navigator 100er-Listing: TMDB-Seite ohne Treffer uebersprungen: %s Seite %s' % (getattr(self, 'media_type', ''), native_page), xbmc.LOGWARNING)
                            continue
                        combined.extend(page_items)

                grouped_total_pages = int((native_total_pages + 4) / 5) if native_total_pages else 0
                _log('Archiv Navigator 100er-Listing Light: %s Block %s -> %s IDs / lite-cache %s' % (getattr(self, 'media_type', ''), block_page, len(combined), len(_listing_lite_meta_cache)))
                return combined, grouped_total_pages

            def _listing_param(params, key, default=''):
                try:
                    value = params.get(key, default)
                    if isinstance(value, (list, tuple)):
                        return value[0] if value else default
                    return value
                except Exception:
                    return default

            def robust_get(self, params):
                """Original listings.get flow, but without the silent dead-end.

                The compiled upstream method swallows every exception. When Kodi
                opens "Neu", "Am populärsten", genres or years, a tiny query
                mismatch then looks like a dead click/leerer Ordner. We keep the
                original route and downstream movie/tv directory builders, only
                normalising params and logging the real stage.
                """
                try:
                    _log('Archiv Navigator listings.get entered: %s' % params)
                    if params is None:
                        params = {}
                    try:
                        next_pages = int(_listing_param(params, 'next_pages', 1) or 1)
                    except Exception:
                        next_pages = 1
                    if next_pages < 1:
                        next_pages = 1
                    append_to_response = 'page=%s' % next_pages
                    self.media_type = str(_listing_param(params, 'media_type', '') or '').strip()
                    url = str(_listing_param(params, 'url', '') or '').strip()

                    if url == 'kino':
                        try:
                            from datetime import datetime, timedelta
                            today = datetime.today().date()
                            start = (today - timedelta(days=120)).strftime('%Y-%m-%d')
                            end = (today + timedelta(days=365)).strftime('%Y-%m-%d')
                            url = 'primary_release_date.gte=%s&primary_release_date.lte=%s&sort_by=primary_release_date.desc' % (start, end)
                        except Exception:
                            pass

                    item_ids, total_pages = self._call(url, append_to_response=append_to_response)
                    if not item_ids:
                        _log('Archiv Navigator listings.get: keine IDs fuer media=%s url=%s' % (self.media_type, url), xbmc.LOGWARNING)
                        item_ids = []
                    params.update({
                        'list': item_ids,
                        'next_pages': next_pages,
                        'total_pages': total_pages,
                        'media_type': self.media_type,
                    })
                    _log('Archiv Navigator listings.get: media=%s ids=%s total=%s' % (self.media_type, len(item_ids), total_pages))
                    if self.media_type == 'movie':
                        from resources.lib.indexers import movies
                        movies.movies().getDirectory(params)
                    else:
                        from resources.lib.indexers import tvshows
                        tvshows.tvshows().getDirectory(params)
                    return item_ids
                except Exception:
                    try:
                        import traceback
                        _log('Archiv Navigator listings.get failed: %s' % traceback.format_exc(), xbmc.LOGERROR)
                    except Exception:
                        pass
                    raise

            cls._call = grouped_call
            cls.get = robust_get
            cls._nova_page_size_100 = True
            _log('Archiv Navigator listings page size patched to 100')
    except Exception as exc:
        _log('Archiv Navigator listings page size patch failed: %s' % exc, xbmc.LOGWARNING)


def _patch_archiv_navigator_embedded_expiry():
    """Keep the original compiled Archiv-Navigator route usable after 2026-09-01.

    The bundled default.pyc executes a tiny zlib-compressed guard before its
    dispatcher:
        if date.today() > date(2026, 9, 1): sys.exit()
    That exits before movie/series listing routes can run. We do not replace
    the dispatcher; we only neutralise this one embedded expiry snippet while
    leaving normal sys.exit/route handling untouched.
    """
    try:
        import zlib
        if getattr(zlib, '_nova_archiv_navigator_expiry_guard', False):
            return
        original_decompress = zlib.decompress

        def guarded_decompress(data, *args, **kwargs):
            result = original_decompress(data, *args, **kwargs)
            try:
                text = result.decode('utf-8', 'ignore') if isinstance(result, (bytes, bytearray)) else str(result or '')
                if 'date(2026, 9, 1)' in text and 'sys.exit()' in text:
                    _log('Archiv Navigator embedded expiry neutralized')
                    return b'import sys\n'
            except Exception:
                pass
            return result

        zlib.decompress = guarded_decompress
        zlib._nova_archiv_navigator_expiry_guard = True
    except Exception as exc:
        _log('Archiv Navigator embedded expiry patch failed: %s' % exc, xbmc.LOGWARNING)


if __name__ == '__main__':
    _log('default_run wrapper active: %s' % (sys.argv[2] if len(sys.argv) > 2 else ''))
    if len(sys.argv) > 2 and _consume_favourite_back_reload(sys.argv[2]):
        sys.exit(0)
    if len(sys.argv) > 2:
        _show_favourite_movie_loading_hint(sys.argv[2])
    lightweight_route = _is_lightweight_menu_route()
    if not lightweight_route:
        _disable_moviedream_runtime()
    elif lightweight_route:
        _log('light menu route: moviedream cleanup skipped')
    if len(sys.argv) > 2 and CLEAR_FAVOURITES_PARAM in _query_params(sys.argv[2]):
        _clear_all_favourites()
        sys.exit(0)
    _ensure_clear_favourites_entry()
    _mark_archiv_navigator_favourites_direct()
    _patch_old_addon_id_aliases()
    needs_listing_runtime = _needs_listing_runtime_patches()
    needs_stream_runtime = _needs_stream_runtime_patches()
    if lightweight_route and _handle_fast_menu_route():
        sys.exit(0)
    if needs_stream_runtime:
        _patch_moflix_hls_playback()
    elif lightweight_route:
        _log('light menu route: stream patches skipped')
    if len(sys.argv) > 2:
        _mark_favourite_source_started(sys.argv[2])
    if len(sys.argv) > 2 and _handle_direct_prechecked_hls_playitem(sys.argv[2]):
        sys.exit(0)
    if len(sys.argv) > 2 and PASSTHROUGH_TOKEN_PARAM in _query_params(sys.argv[2]):
        _activate_passthrough_token(sys.argv[2])
    if len(sys.argv) > 2 and CHOICE_PARAM in _query_params(sys.argv[2]):
        if not _handle_choice():
            sys.exit(0)
    if len(sys.argv) > 2:
        direct_meta = _direct_choice_meta(sys.argv[2])
        if direct_meta:
            _log('direct choice %s: %s' % (direct_meta.get('media_type'), direct_meta.get('title')))
            if not _run_choice(direct_meta):
                sys.exit(0)

    xbmcplugin.addDirectoryItem = _patched_add_directory_item(xbmcplugin.addDirectoryItem)
    xbmcplugin.addDirectoryItems = _patched_add_directory_items(xbmcplugin.addDirectoryItems)
    xbmcplugin.endOfDirectory = _patched_end_of_directory(xbmcplugin.endOfDirectory)
    try:
        import resources.lib.control as archiv_navigator_control
        archiv_navigator_control.addItem = xbmcplugin.addDirectoryItem
        archiv_navigator_control.directory = xbmcplugin.endOfDirectory
        archiv_navigator_control.content = xbmcplugin.setContent
        archiv_navigator_control.item = xbmcgui.ListItem
        archiv_navigator_control.resolve = xbmcplugin.setResolvedUrl
        _log('patched resources.lib.control aliases')
    except Exception as exc:
        _log('control alias patch failed: %s' % exc, xbmc.LOGWARNING)
    if needs_stream_runtime:
        try:
            import scrapers.modules.control as scraper_control
            scraper_control.addItem = xbmcplugin.addDirectoryItem
            scraper_control.directory = xbmcplugin.endOfDirectory
            scraper_control.content = xbmcplugin.setContent
            scraper_control.item = xbmcgui.ListItem
            scraper_control.resolve = xbmcplugin.setResolvedUrl
            _log('patched scrapers.modules.control aliases')
        except Exception as exc:
            _log('scraper control alias patch failed: %s' % exc, xbmc.LOGWARNING)
    elif lightweight_route:
        _log('light menu route: scraper aliases skipped')
    try:
        indexer_names = (
            'resources.lib.indexers.listings',
            'resources.lib.indexers.movies',
            'resources.lib.indexers.tvshows',
            'resources.lib.indexers.seasons',
            'resources.lib.indexers.episodes',
            'resources.lib.indexers.navigator',
            'resources.lib.indexers.navigatorXS',
            'resources.lib.indexers.person',
        )
        for module_name in indexer_names:
            try:
                module = __import__(module_name, fromlist=['*'])
                module_control = getattr(module, 'control', None)
                if module_control is not None:
                    module_control.addItem = xbmcplugin.addDirectoryItem
                    module_control.directory = xbmcplugin.endOfDirectory
                    module_control.content = xbmcplugin.setContent
            except Exception as inner_exc:
                _log('indexer alias patch failed %s: %s' % (module_name, inner_exc), xbmc.LOGWARNING)
        _log('patched indexer control aliases')
    except Exception as exc:
        _log('indexer alias patch setup failed: %s' % exc, xbmc.LOGWARNING)

    if needs_listing_runtime:
        _patch_lite_listing_meta()
        _patch_lite_season_meta()
        _patch_archiv_navigator_page_size()
    elif lightweight_route:
        _log('light menu route: listing/search patches skipped')
    if needs_stream_runtime:
        _patch_network_fast_fail()
        _patch_slow_source_logging()
        _patch_source_result_order()
    elif lightweight_route:
        _log('light menu route: source patches skipped')

    _patch_archiv_navigator_embedded_expiry()
    from sys import argv
    import default
