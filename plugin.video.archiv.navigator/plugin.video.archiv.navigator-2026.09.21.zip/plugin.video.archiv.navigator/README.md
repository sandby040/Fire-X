# plugin.video.archiv.navigator

Archiv Navigator - Ein Kodi Video Addon für deutsche Streams