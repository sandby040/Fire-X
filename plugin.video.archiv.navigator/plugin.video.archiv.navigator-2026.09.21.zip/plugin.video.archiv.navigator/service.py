# -*- coding: UTF-8 -*-

from urllib.parse import parse_qs, urlsplit

import xbmc


ADDON_ID = 'plugin.video.archiv.navigator'
CATEGORY_VIEW_ID = 55
CATEGORY_ACTIONS = {
    'root',
    'movieNavigator',
    'tvNavigator',
    'toolNavigator',
    'downloadNavigator',
    'movieYears',
    'movieGenres',
    'tvGenres',
    'personSearch',
    'personCredits',
}


def _log(message):
    try:
        xbmc.log('[Archiv Navigator Service] %s' % message, xbmc.LOGINFO)
    except Exception:
        pass


def _action_from_path(path):
    try:
        params = parse_qs(urlsplit(str(path or '')).query)
        return (params.get('action') or params.get('function') or [''])[0]
    except Exception:
        return ''


def _enforce_category_view(path):
    if not str(path or '').startswith('plugin://%s' % ADDON_ID):
        return False
    action = _action_from_path(path)
    if action not in CATEGORY_ACTIONS:
        return False
    xbmc.executebuiltin('Container.SetViewMode(%d)' % CATEGORY_VIEW_ID)
    _log('category view set action=%s path=%s' % (action, path[:220]))
    return True


try:
    import addon
except Exception as exc:
    _log('addon import skipped: %s' % exc)


monitor = xbmc.Monitor()
last_path = ''
while not monitor.abortRequested():
    try:
        current_path = xbmc.getInfoLabel('Container.FolderPath') or ''
        if current_path != last_path:
            last_path = current_path
            _enforce_category_view(current_path)
    except Exception as exc:
        _log('view monitor failed: %s' % exc)
    if monitor.waitForAbort(0.25):
        break
