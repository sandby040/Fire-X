# -*- coding: UTF-8 -*-
import hashlib
import re
import time
from scrapers.modules import control
import pickle
try:
    from sqlite3 import dbapi2 as db, OperationalError
except ImportError:
    from pysqlite2 import dbapi2 as db, OperationalError

cache_table = 'cache'

def get(function, duration, *args, **kwargs):
    try:
        key = _hash_function(function, args, kwargs)
        cache_result = cache_get(key)
        if cache_result:
            if _is_cache_valid(cache_result['date'], duration):
                return pickle.loads(cache_result['value'])
            else:
                cache_delete(key)

        fresh_result = function(*args, **kwargs)

        if not fresh_result:
            if cache_result:
                return cache_result
            return None

        cache_insert(key, pickle.dumps(fresh_result))
        return fresh_result
    except Exception:
        return None

def timeout(function, *args):
    try:
        key = _hash_function(function, args)
        result = cache_get(key)
        return int(result['date'])
    except Exception:
        return None

def cache_get(key):
    try:
        cursor = _get_connection_cursor()
        cursor.execute("SELECT * FROM %s WHERE key = ?" % cache_table, [key])
        return cursor.fetchone()
    except OperationalError:
        return None

def cache_delete(key):
    try:
        cursor = _get_connection_cursor()
        cursor.execute("DELETE FROM %s WHERE key = ?" % cache_table, [key])
        cursor.connection.commit()

    except OperationalError:
        return None

def cache_insert(key, value):
    cursor = _get_connection_cursor()
    now = int(time.time())
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS %s (key TEXT, value TEXT, date INTEGER, UNIQUE(key))"
        % cache_table)

    update_result = cursor.execute(
        "UPDATE %s SET value=?,date=? WHERE key=?"
        % cache_table, (value, now, key))

    if update_result.rowcount == 0:
        cursor.execute(
            "INSERT INTO %s Values (?, ?, ?)"
            % cache_table, (key, value, now))
    cursor.connection.commit()

def cache_clear():
    try:
        cursor = _get_connection_cursor()
        for t in [cache_table, 'rel_list', 'rel_lib']:
            try:
                cursor.execute("DROP TABLE IF EXISTS %s" % t)
                cursor.execute("VACUUM")
                cursor.commit()
            except:
                pass
    except:
        pass

def cache_clear_meta():
    try:
        cursor = _get_connection_cursor_meta()
        for t in ['meta']:
            try:
                cursor.execute("DROP TABLE IF EXISTS %s" % t)
                cursor.execute("VACUUM")
                cursor.commit()
            except:
                pass

    except:
        pass

def cache_clear_providers():
    try:
        cursor = _get_connection_cursor_providers()
        for t in ['rel_src', 'rel_url', 'faultLog']:
            try:
                cursor.execute("DROP TABLE IF EXISTS %s" % t)
                cursor.execute("VACUUM")
                cursor.commit()
            except:
                pass
        cache_insert("source_fault_last_seen","0")
    except:
        pass

def cache_clear_search():
    try:
        cursor = _get_connection_cursor_search()
        for t in ['tvshow', 'movies']:
            try:
                cursor.execute("DROP TABLE IF EXISTS %s" % t)
                cursor.execute("VACUUM")
                cursor.commit()
            except:
                pass
    except:
        pass

def cache_clear_all():
    cache_clear()
    cache_clear_meta()
    cache_clear_providers()

def _get_connection_cursor():
    conn = _get_connection(control.cacheFile)
    conn.text_factory = str
    return conn.cursor()

def _get_connection(filename):
    control.makeFile(control.dataPath)
    conn = db.connect(filename)
    conn.row_factory = _dict_factory
    return conn

def _get_connection_cursor_meta():
    conn = _get_connection(control.metacacheFile)
    return conn.cursor()

def _get_connection_cursor_providers():
    conn = _get_connection(control.providercacheFile)
    return conn.cursor()

def _get_connection_cursor_search():
    conn = _get_connection(control.searchFile)
    return conn.cursor()

def _dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

def _hash_function(function_instance, *args):
    return _get_function_name(function_instance) + _generate_md5(args)

def _get_function_name(function_instance):
    return re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))

def _generate_md5(*args):
    md5_hash = hashlib.md5()
    [md5_hash.update(str(arg)) for arg in args]
    return str(md5_hash.hexdigest())

def _is_cache_valid(cached_time, cache_timeout):
    now = int(time.time())
    diff = now - cached_time
    return (cache_timeout * 3600) > diff

def cache_version_check():
    if _find_cache_version():
        cache_clear(); cache_clear_meta(); cache_clear_providers(); cache_clear_search()
        control.infoDialog("Vorgang abgeschlossen", sound=True, icon='INFO')

def _find_cache_version():
    import os
    versionFile = os.path.join(control.dataPath, 'cache.v')
    try:
        with open(versionFile, 'rb') as fh:
            oldVersion = fh.read()

    except:
        oldVersion = '0'

    try:
        curVersion = control.addon('plugin.video.archiv.navigator').getAddonInfo('version')
        if oldVersion != curVersion:
            with open(versionFile, 'wb') as fh:
                fh.write(curVersion)
            return True
        else:
            return False
    except:
        return False


