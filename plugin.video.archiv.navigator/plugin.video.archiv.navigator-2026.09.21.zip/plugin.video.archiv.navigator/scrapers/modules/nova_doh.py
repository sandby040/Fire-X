# -*- coding: utf-8 -*-
"""Request-safe Cloudflare DoH helper for Archiv Navigator.

This uses a request-safe DoH approach: resolve the hostname through Cloudflare DoH,
connect to the returned IP, but keep the original hostname for Host/SNI.  It
does not patch socket globally, so it cannot poison other Kodi add-ons.
"""

import http.client
import ipaddress
import json
import socket
import ssl
import time
import urllib.request
from urllib.parse import urlencode, urlparse

try:
    import certifi
except Exception:
    certifi = None

try:
    import xbmc
except Exception:
    xbmc = None

try:
    from resources.lib.control import getSetting
except Exception:
    def getSetting(name, default=''):
        return default


DOH_ENDPOINTS = (
    'https://cloudflare-dns.com/dns-query',
    'https://dns.google/resolve',
)
DOH_SERVER = DOH_ENDPOINTS[0]
_DOH_CACHE = {}


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log('[Archiv Navigator DoH] %s' % message, level or xbmc.LOGINFO)
    except Exception:
        pass


def enabled():
    # Codex request-safe DNS is intentionally independent from the old
    # addon DNS-Changer switch.  The old switch may stay off so it cannot
    # trigger stale hard-IP/proxy behaviour, while this request-safe DoH
    # helper still resolves per request.
    return True


def _is_ip(hostname):
    try:
        ipaddress.ip_address(hostname)
        return True
    except Exception:
        return False


def _candidate(hostname):
    hostname = (hostname or '').lower()
    return bool(hostname and hostname != 'localhost' and not _is_ip(hostname))


def _provider_name(endpoint):
    endpoint = (endpoint or '').lower()
    if 'cloudflare' in endpoint:
        return 'Cloudflare DoH'
    if 'google' in endpoint:
        return 'Google DoH'
    return endpoint or 'unknown DoH'


class IPHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host, ip=None, port=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        self.ip = ip
        super().__init__(host, port, timeout=timeout)

    def connect(self):
        if self.ip:
            self.sock = self._create_connection((self.ip, self.port), self.timeout)
        else:
            super().connect()


class IPHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, ip=None, port=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, context=None):
        self.ip = ip
        self.context = context
        self.actual_host = host
        super().__init__(host, port, timeout=timeout, context=context)

    def connect(self):
        if self.ip:
            self.sock = self._create_connection((self.ip, self.port), self.timeout)
            self.sock = self.context.wrap_socket(self.sock, server_hostname=self.actual_host)
        else:
            super().connect()


class DoHHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self, ip_map=None):
        self.ip_map = ip_map or {}
        super().__init__()

    def http_open(self, req):
        host = (urlparse(req.full_url).hostname or '').lower()
        ip = self.ip_map.get(host)
        def factory(*args, **kwargs):
            return IPHTTPConnection(host, ip=ip, timeout=req.timeout)
        return self.do_open(factory, req)


class DoHHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, ip_map=None, verify=False):
        if verify and certifi is not None:
            context = ssl.create_default_context(cafile=certifi.where())
            context.check_hostname = True
            context.verify_mode = ssl.CERT_REQUIRED
        else:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        self.ip_map = ip_map or {}
        self.context = context
        super().__init__(context=context)

    def https_open(self, req):
        host = (urlparse(req.full_url).hostname or '').lower()
        ip = self.ip_map.get(host)
        def factory(*args, **kwargs):
            return IPHTTPSConnection(host, ip=ip, timeout=req.timeout, context=self.context)
        return self.do_open(factory, req)


def resolve(hostname):
    hostname = (hostname or '').lower()
    if not _candidate(hostname):
        return None
    cached = _DOH_CACHE.get(hostname)
    if cached and cached[1] > time.time():
        _log('cache %s -> %s' % (hostname, cached[0]))
        return cached[0]

    for endpoint in DOH_ENDPOINTS:
        req = urllib.request.Request('%s?%s' % (endpoint, urlencode({'name': hostname, 'type': 'A'})))
        req.add_header('Accept', 'application/dns-json')
        try:
            context = ssl.create_default_context(cafile=certifi.where()) if certifi is not None else None
            response = urllib.request.urlopen(req, timeout=5, context=context)
            payload = json.loads(response.read().decode('utf-8', 'replace'))
            ttl = 600
            for answer in payload.get('Answer') or []:
                if answer.get('type') != 1:
                    continue
                ip = answer.get('data')
                try:
                    ipaddress.ip_address(ip)
                except Exception:
                    continue
                ttl = int(answer.get('TTL') or ttl)
                ttl = max(60, min(ttl, 3600))
                _DOH_CACHE[hostname] = (ip, time.time() + ttl)
                _log('%s %s -> %s' % (_provider_name(endpoint), hostname, ip))
                return ip
        except Exception as exc:
            _log('%s failed for %s: %s' % (_provider_name(endpoint), hostname, exc), getattr(xbmc, 'LOGDEBUG', None))
    return None


def urlopen(request, timeout=None):
    if not enabled():
        return urllib.request.urlopen(request, timeout=timeout)
    url = request.full_url if hasattr(request, 'full_url') else str(request)
    host = (urlparse(url).hostname or '').lower()
    ip = resolve(host)
    if not ip:
        return urllib.request.urlopen(request, timeout=timeout)
    opener = urllib.request.build_opener(
        DoHHTTPHandler({host: ip}),
        DoHHTTPSHandler({host: ip}, verify=False),
    )
    return opener.open(request, timeout=timeout)
