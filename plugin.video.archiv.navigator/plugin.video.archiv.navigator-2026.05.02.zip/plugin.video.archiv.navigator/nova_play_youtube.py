# -*- coding: UTF-8 -*-

import re
import sys
from urllib.parse import quote_plus

import xbmc


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[Archiv Navigator Trailer Starter] %s' % message, level)
    except Exception:
        pass


def _ensure_youtube_available():
    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            return True
    except Exception as exc:
        _log('YouTube availability check failed: %s' % exc, xbmc.LOGERROR)
    return xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')


video_id = sys.argv[1] if len(sys.argv) > 1 else ''
video_id = re.sub(r'[^A-Za-z0-9_-]', '', str(video_id or ''))

if video_id:
    xbmc.sleep(1400)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    xbmc.sleep(250)
    if not _ensure_youtube_available():
        _log('YouTube addon unavailable, trailer cannot start', xbmc.LOGERROR)
        xbmc.executebuiltin('Notification(Trailer, YouTube Add-on nicht aktiv - Kodi neu starten, 4500)')
        sys.exit(0)
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % quote_plus(video_id)
    _log('PlayMedia %s' % video_id)
    xbmc.executebuiltin('PlayMedia(%s)' % url)
    for _ in range(24):
        xbmc.sleep(250)
        if xbmc.Player().isPlayingVideo():
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            xbmc.sleep(250)
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            break
