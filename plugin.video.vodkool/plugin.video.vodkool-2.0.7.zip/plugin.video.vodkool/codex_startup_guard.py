"""Bound only our own live startup; no network probes or playback retries."""
import json
import sys
import time
import uuid

PROPERTY = 'VodkoolLiveStartup'
READY = 'VodkoolLiveStartupReady'
LIMIT_SECONDS = 12


def same_stream(path, payload):
    base = (path or '').partition('|')[0]
    return bool(base and base in (payload.get('url'), payload.get('origin')))


def decision(payload, ticket, current, now, available=False, ended=False, seen=False):
    if payload.get('ticket') != ticket:
        return 'superseded'
    if available or ended:
        return 'finished'
    start = payload.get('armed')
    if not isinstance(start, (int, float)):
        return 'waiting'
    # The previous player can still be closing before the new handoff occurs.
    # Only a change AFTER observing our own player invalidates this observer.
    if seen and current and not same_stream(current, payload):
        return 'other-player'
    if now - start < LIMIT_SECONDS:
        return 'waiting'
    # An unknown player must NEVER be stopped just because our timer expired.
    return 'timeout' if same_stream(current, payload) else 'unidentified'


def read(window):
    try:
        value = json.loads(window.getProperty(PROPERTY))
        return value if isinstance(value, dict) else {}
    except (ValueError, TypeError):
        return {}


def cancel(window, ticket):
    if read(window).get('ticket') == ticket:
        window.clearProperty(PROPERTY)
    if window.getProperty(READY) == ticket:
        window.clearProperty(READY)


def begin(xbmc, xbmcgui, stream_url, origin):
    """Register observer before setResolvedUrl. Signed addresses stay RAM-only."""
    window = xbmcgui.Window(10000)
    ticket = uuid.uuid4().hex
    payload = {'ticket': ticket, 'url': stream_url.partition('|')[0],
               'origin': origin.partition('|')[0]}
    window.setProperty(PROPERTY, json.dumps(payload))
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.vodkool/'
                        'codex_startup_guard.py,%s)' % ticket)
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + 0.75
    while window.getProperty(READY) != ticket:
        if time.monotonic() >= deadline or monitor.waitForAbort(0.025):
            cancel(window, ticket)
            xbmc.log('[vodkool] START-GUARD: Beobachter nicht bereit; nativer Start bleibt', xbmc.LOGWARNING)
            return ''
        if read(window).get('ticket') != ticket:
            return ''
    payload['armed'] = time.monotonic()
    window.setProperty(PROPERTY, json.dumps(payload))
    xbmc.log('[vodkool] START-GUARD: Live-Startfrist=12s; keine Zusatzanfrage', xbmc.LOGINFO)
    return ticket


def run(ticket):
    import xbmc
    import xbmcgui
    window = xbmcgui.Window(10000)
    if read(window).get('ticket') != ticket:
        return

    class Observer(xbmc.Player):
        available = False
        ended = False

        def current(self):
            # getPlayingFile can throw during OpenInputStream; GUI info often
            # already identifies the opening item. Never log this private URL.
            try:
                path = self.getPlayingFile()
            except RuntimeError:
                path = ''
            return path or xbmc.getInfoLabel('Player.Filenameandpath')

        def owned(self):
            payload = read(window)
            return payload.get('ticket') == ticket and same_stream(self.current(), payload)

        def onAVStarted(self):
            if self.owned():
                self.available = True

        def onPlayBackError(self):
            if self.owned():
                self.ended = True

        def onPlayBackStopped(self):
            if self.owned():
                self.ended = True

        def onPlayBackEnded(self):
            if self.owned():
                self.ended = True

    observer = Observer()
    monitor = xbmc.Monitor()
    window.setProperty(READY, ticket)
    boot_deadline = time.monotonic() + 3
    seen = False
    try:
        while not monitor.abortRequested():
            payload = read(window)
            current = observer.current()
            if 'armed' in payload and same_stream(current, payload):
                seen = True
            state = decision(payload, ticket, current, time.monotonic(),
                             observer.available, observer.ended, seen)
            if state != 'waiting':
                if state == 'timeout':
                    # Recheck ownership immediately before stopping; a newer
                    # VODKOOL start invalidates this ticket and takes precedence.
                    if observer.owned() and not observer.available:
                        xbmc.log('[vodkool] START-GUARD: nach 12s kein AV-Start; eigenen Start abbrechen', xbmc.LOGWARNING)
                        observer.stop()
                        if read(window).get('ticket') == ticket:
                            xbmcgui.Dialog().notification('VODKOOL',
                                'Sender reagiert nicht - Start abgebrochen',
                                'special://home/addons/plugin.video.vodkool/icon.png', 3500, False)
                elif state == 'finished':
                    xbmc.log('[vodkool] START-GUARD: AV-Start/Ende erkannt; Ueberwachung beendet', xbmc.LOGINFO)
                elif state == 'unidentified':
                    xbmc.log('[vodkool] START-GUARD: Player nicht eindeutig zugeordnet; kein Fremd-Stopp', xbmc.LOGWARNING)
                break
            if 'armed' not in payload and time.monotonic() >= boot_deadline:
                break
            if monitor.waitForAbort(0.1):
                break
    finally:
        cancel(window, ticket)


if __name__ == '__main__' and len(sys.argv) > 1:
    run(sys.argv[1])
