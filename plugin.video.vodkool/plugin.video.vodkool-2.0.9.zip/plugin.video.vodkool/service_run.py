import dns_bypass
import service
import xbmc
import xbmcgui
import xbmcvfs
import codex_service_guard
import codex_token_session
from codex_live_resolver import BASE_URL

dns_bypass.enable_dns_bypass()
service._CATALOG_URL = BASE_URL + '/mediahubmx-catalog.json'
codex_token_session.install_service(service, lambda message: xbmc.log(message, xbmc.LOGINFO))
codex_service_guard.install(service, xbmc.Monitor().waitForAbort, xbmcvfs.translatePath,
                            lambda: xbmcgui.Window(10000).getProperty('VodkoolCatalogRefreshRunning') == '1')


def _patched_service_run(self):
    service._log('Service gestartet')
    if not xbmcvfs.exists(service._BASE):
        xbmcvfs.mkdirs(service._BASE)
    xbmc.sleep(2000)
    while not self.abortRequested():
        try:
            sig = service.ensure_signature()
            if sig:
                service.ensure_channels(sig)
        except Exception as e:
            service._log('Service-Fehler: %s' % e, xbmc.LOGERROR)
        if self.waitForAbort(service._POLL_INTERVAL):
            break
    service._log('Service beendet')

service.VodkoolService.run = _patched_service_run

if __name__ == "__main__":
    service.VodkoolService().run()
