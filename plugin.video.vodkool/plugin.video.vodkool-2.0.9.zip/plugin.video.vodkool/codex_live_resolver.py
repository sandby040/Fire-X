"""Preserve MediaHubMX playback headers, as the VYPN client does.

Only the existing provider request is used. No token acquisition, automatic
source fallback, recursive resolveAgain or extra stream probe is performed.
"""
import re
import time
from urllib.parse import quote, unquote, urlsplit

CLIENT_VERSION = '3.1.0'
# Active MediaHubMX live stream resolver endpoint.
# Kool.to is verified online and returns stream endpoints immediately.
BASE_URL = 'https://www.kool.to'
RESOLVE_ENDPOINTS = (
    'https://www.kool.to/mediahubmx-resolve.json',
    'https://kool.to/mediahubmx-resolve.json',
    'https://vavoo.to/mediahubmx-resolve.json',
    'https://www.vavoo.to/mediahubmx-resolve.json',
)
_HEADER_NAME = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")


def _live1_watch(event, media_url=None, **fields):
    try:
        import sys
        import xbmcvfs
        path = xbmcvfs.translatePath('special://home/addons/plugin.video.iptvmaster/resources/lib')
        if path not in sys.path:
            sys.path.append(path)
        from livetv1_trace import provider_event, url_info
        provider_event('plugin.video.vodkool', event,
                       **dict(fields, **(url_info(media_url) if media_url else {})))
    except Exception:
        pass


def playback_url(response):
    """Normalize the first resolved source and append its HTTP headers safely."""
    if isinstance(response, list):
        if not response:
            raise ValueError('Keine Streamquelle vom Anbieter erhalten')
        source = response[0]
    else:
        source = response
    if isinstance(source, str):
        source = {'url': source}
    if not isinstance(source, dict) or source.get('resolveAgain'):
        raise ValueError('Keine direkt abspielbare Streamquelle erhalten')
    url = source.get('url')
    if not isinstance(url, str):
        raise ValueError('Streamadresse fehlt')
    base, _, options = url.partition('|')
    parsed = urlsplit(base)
    if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
        raise ValueError('Ungueltige Streamadresse')
    headers = source.get('headers') or {}
    if not isinstance(headers, dict):
        raise ValueError('Ungueltige Stream-Header')
    # Match header names case-insensitively; upstream headers take precedence
    # over any same-name URL option. Do not decode/re-encode the signed base URL.
    additions = {}
    for name, value in headers.items():
        if not isinstance(name, str) or not _HEADER_NAME.fullmatch(name):
            raise ValueError('Ungueltiger Stream-Headername')
        if not isinstance(value, str) or any(c in value for c in '\r\n\x00'):
            raise ValueError('Ungueltiger Stream-Headerwert')
        if name.lower() == 'referrer':
            name = 'Referer'
        additions[name.lower()] = (name, value)
    existing = [part for part in options.split('&') if part and
                unquote(part.split('=', 1)[0]).lower() not in additions]
    existing.extend(quote(name, safe='') + '=' + quote(value, safe='')
                    for name, value in additions.values())
    return base + ('|' + '&'.join(existing) if existing else '')


def install(provider, log):
    for attribute, action in (('_KOOL_CATALOG_URL', 'catalog'), ('_KOOL_RESOLVE_URL', 'resolve')):
        setattr(provider, attribute, BASE_URL + '/mediahubmx-' + action + '.json')
    def geturl(channel_url):
        started = time.monotonic()
        _live1_watch('provider_resolve_begin')
        endpoints = [getattr(provider, '_KOOL_RESOLVE_URL', '')] + [ep for ep in RESOLVE_ENDPOINTS if ep != getattr(provider, '_KOOL_RESOLVE_URL', '')]
        last_exc = None
        for endpoint in endpoints:
            if not endpoint:
                continue
            req_url = channel_url
            if isinstance(req_url, str):
                ep_host = (urlsplit(endpoint).hostname or '').lower()
                if 'kool' in ep_host:
                    req_url = req_url.replace('https://vavoo.to/vavoo-iptv', 'https://kool.to/kool-iptv')
                    req_url = req_url.replace('http://vavoo.to/vavoo-iptv', 'https://kool.to/kool-iptv')
                    req_url = req_url.replace('/vavoo-iptv/', '/kool-iptv/')
                    req_url = req_url.replace('vavoo.to', 'kool.to')
                elif 'vavoo' in ep_host:
                    req_url = req_url.replace('https://kool.to/kool-iptv', 'https://vavoo.to/vavoo-iptv')
                    req_url = req_url.replace('http://kool.to/kool-iptv', 'https://vavoo.to/vavoo-iptv')
                    req_url = req_url.replace('/kool-iptv/', '/vavoo-iptv/')
                    req_url = req_url.replace('kool.to', 'vavoo.to')
            try:
                response = provider._kool_live_request(endpoint, {
                    'language': 'de', 'region': 'AT', 'url': req_url,
                    'clientVersion': CLIENT_VERSION,
                })
                result = playback_url(response)
                source = response[0] if isinstance(response, list) and response else response
                count = len(source.get('headers') or {}) if isinstance(source, dict) else 0
                _live1_watch('provider_resolve_ready', media_url=result, header_count=count,
                             elapsed_ms=int((time.monotonic()-started)*1000))
                log('[vodkool] VYPN-COMPAT: resolve=1; endpoint=%s; clientVersion=%s; Stream-Header=%d' %
                    (endpoint, CLIENT_VERSION, count))
                return result
            except BaseException as exc:
                last_exc = exc
                continue
        _live1_watch('provider_resolve_error', error=type(last_exc).__name__,
                     elapsed_ms=int((time.monotonic()-started)*1000))
        if last_exc:
            raise last_exc
        raise ValueError('Keine direkt abspielbare Streamquelle erhalten')
    provider._kool_live_geturl = geturl
