import dns_bypass
import service

dns_bypass.enable_dns_bypass()

if __name__ == "__main__":
    service.VodkoolService().run()
