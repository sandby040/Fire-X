# -*- coding: utf-8 -*-

import json
import os
import socket
import threading
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcvfs


ADDON_ID = 'plugin.video.vodkool'
DOH_ENDPOINTS = (
    'https://cloudflare-dns.com/dns-query',
    'https://dns.google/resolve',
)
CACHE_TTL = 3600
BOOTSTRAP_HOSTS = {'cloudflare-dns.com', 'dns.google'}

_ORIGINALS = {}
_PATCHED = False
_PATCH_LOCK = threading.Lock()
_CACHE_LOCK = threading.Lock()
_DNS_CACHE = None


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[%s.dns] %s' % (ADDON_ID, message), level)
    except Exception:
        pass


def _get_profile_path():
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    except Exception:
        profile_path = xbmcvfs.translatePath('special://userdata/addon_data/%s' % ADDON_ID)

    if profile_path and not os.path.exists(profile_path):
        try:
            os.makedirs(profile_path)
        except Exception:
            pass
    return profile_path


def _get_cache_path():
    return os.path.join(_get_profile_path(), 'dns_cache.json')


def _load_cache():
    global _DNS_CACHE
    if _DNS_CACHE is not None:
        return _DNS_CACHE

    cache_path = _get_cache_path()
    cache_data = {}
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'r') as cache_file:
                cache_data = json.load(cache_file)
        except Exception:
            cache_data = {}

    if not isinstance(cache_data, dict):
        cache_data = {}

    _DNS_CACHE = cache_data
    return _DNS_CACHE


def _save_cache(cache_data):
    try:
        with open(_get_cache_path(), 'w') as cache_file:
            json.dump(cache_data, cache_file, indent=2, sort_keys=True)
    except Exception as exc:
        _log('DNS cache could not be written: %s' % exc, xbmc.LOGDEBUG)


def _normalize_host(host):
    if host is None:
        return ''

    if isinstance(host, bytes):
        try:
            host = host.decode('utf-8')
        except Exception:
            host = host.decode('latin-1', 'ignore')

    host = str(host).strip()
    if host.startswith('[') and host.endswith(']'):
        host = host[1:-1]
    return host.lower()


def _is_ip_address(host):
    if not host:
        return False

    try:
        socket.inet_aton(host)
        return True
    except Exception:
        pass

    try:
        socket.inet_pton(socket.AF_INET6, host)
        return True
    except Exception:
        return False


def _cache_lookup(host):
    now = time.time()
    with _CACHE_LOCK:
        cache_data = _load_cache()
        entry = cache_data.get(host)
        if not isinstance(entry, dict):
            return None

        ip_address = entry.get('ip')
        timestamp = float(entry.get('timestamp', 0))
        if ip_address and (now - timestamp) < CACHE_TTL:
            return entry

        if host in cache_data:
            del cache_data[host]
            _save_cache(cache_data)
    return None


def _cache_store(host, ip_address, provider):
    with _CACHE_LOCK:
        cache_data = _load_cache()
        cache_data[host] = {
            'ip': ip_address,
            'provider': provider,
            'timestamp': time.time(),
        }
        _save_cache(cache_data)


def _provider_name_from_endpoint(endpoint):
    endpoint = (endpoint or '').lower()
    if 'cloudflare' in endpoint:
        return 'Cloudflare DoH'
    if 'google' in endpoint:
        return 'Google DoH'
    return endpoint or 'unknown DoH'


def resolve_hostname(host):
    hostname = _normalize_host(host)
    if not hostname or hostname in ('localhost',) or _is_ip_address(hostname):
        return hostname

    cached_entry = _cache_lookup(hostname)
    if cached_entry:
        cached_ip = cached_entry.get('ip')
        cached_provider = cached_entry.get('provider') or 'cached DoH'
        _log('Resolved %s to %s via %s (cache)' % (hostname, cached_ip, cached_provider), xbmc.LOGINFO)
        return cached_ip

    headers = {'Accept': 'application/dns-json'}
    for endpoint in DOH_ENDPOINTS:
        try:
            response = requests.get(
                endpoint,
                params={'name': hostname, 'type': 'A'},
                headers=headers,
                timeout=5,
            )
            response.raise_for_status()
            payload = response.json()
            answers = payload.get('Answer') or []
            for answer in answers:
                if answer.get('type') == 1 and _is_ip_address(answer.get('data')):
                    ip_address = answer['data']
                    provider = _provider_name_from_endpoint(endpoint)
                    _cache_store(hostname, ip_address, provider)
                    _log('Resolved %s to %s via %s' % (hostname, ip_address, provider), xbmc.LOGINFO)
                    return ip_address
        except Exception as exc:
            _log('DoH lookup failed for %s via %s: %s' % (hostname, endpoint, exc), xbmc.LOGDEBUG)

    return None


def _patched_getaddrinfo(host, port, family=0, socktype=0, proto=0, flags=0):
    hostname = _normalize_host(host)
    if not hostname or hostname in BOOTSTRAP_HOSTS or hostname == 'localhost' or _is_ip_address(hostname):
        return _ORIGINALS['getaddrinfo'](host, port, family, socktype, proto, flags)

    if family == socket.AF_INET6:
        return _ORIGINALS['getaddrinfo'](host, port, family, socktype, proto, flags)

    ip_address = resolve_hostname(hostname)
    if ip_address:
        try:
            target_family = family if family in (0, socket.AF_INET) else socket.AF_INET
            return _ORIGINALS['getaddrinfo'](ip_address, port, target_family, socktype, proto, flags)
        except Exception as exc:
            _log('getaddrinfo fallback for %s failed: %s' % (hostname, exc), xbmc.LOGDEBUG)

    return _ORIGINALS['getaddrinfo'](host, port, family, socktype, proto, flags)


def _patched_gethostbyname(host):
    hostname = _normalize_host(host)
    if not hostname or hostname in BOOTSTRAP_HOSTS or hostname == 'localhost' or _is_ip_address(hostname):
        return _ORIGINALS['gethostbyname'](host)

    ip_address = resolve_hostname(hostname)
    if ip_address:
        return ip_address

    return _ORIGINALS['gethostbyname'](host)


def _patched_gethostbyname_ex(host):
    ip_address = _patched_gethostbyname(host)
    return host, [], [ip_address]


def enable_dns_bypass():
    global _PATCHED
    with _PATCH_LOCK:
        if _PATCHED:
            return

        _PATCHED = True
        _log('DNS bypass enabled in request-safe mode; global socket DNS hooks disabled', xbmc.LOGINFO)


def _split_kodi_options(url):
    if '|' not in url:
        return url, ''
    return url.split('|', 1)


def _append_kodi_option(option_string, key, value):
    if not option_string:
        return '%s=%s' % (key, urllib.parse.quote(value, safe=''))

    lower_options = option_string.lower()
    if ('%s=' % key.lower()) in lower_options:
        return option_string

    return '%s&%s=%s' % (option_string, key, urllib.parse.quote(value, safe=''))


def prepare_url_for_kodi(url):
    if not isinstance(url, str) or not url:
        return url

    base_url, option_string = _split_kodi_options(url)
    parsed = urllib.parse.urlsplit(base_url)
    hostname = _normalize_host(parsed.hostname)

    if parsed.scheme.lower() != 'http':
        return url

    if not hostname or hostname == 'localhost' or _is_ip_address(hostname):
        return url

    ip_address = resolve_hostname(hostname)
    if not ip_address:
        return url

    credentials = ''
    if parsed.username:
        credentials = parsed.username
        if parsed.password is not None:
            credentials += ':' + parsed.password
        credentials += '@'

    rewritten_netloc = credentials + ip_address
    if parsed.port:
        rewritten_netloc += ':%s' % parsed.port

    rewritten_url = urllib.parse.urlunsplit((
        parsed.scheme,
        rewritten_netloc,
        parsed.path,
        parsed.query,
        parsed.fragment,
    ))

    host_header = hostname
    if parsed.port:
        host_header += ':%s' % parsed.port

    option_string = _append_kodi_option(option_string, 'Host', host_header)
    return '%s|%s' % (rewritten_url, option_string)
