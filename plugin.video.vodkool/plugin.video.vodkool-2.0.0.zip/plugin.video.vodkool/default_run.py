# -*- coding: UTF-8 -*-
import json
import os
import re
import sys
import threading
try:
    from urllib.parse import parse_qsl, urlencode
    from urllib.request import Request, urlopen
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode
    from urllib2 import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import dns_bypass
try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

dns_bypass.enable_dns_bypass()

FANART = 'special://home/addons/plugin.video.vodkool/fanart.jpg'
CHANNELS_CACHE_FILE = 'special://userdata/addon_data/plugin.video.vodkool/channels_cache.json'
STREAM_GROUPS_FILE = 'special://userdata/addon_data/plugin.video.vodkool/codex_de_stream_groups.json'
COUNTRY_GROUPS_FILE = 'special://userdata/addon_data/plugin.video.vodkool/codex_country_stream_groups.json'
STREAM_ROTATION_FILE = 'special://userdata/addon_data/plugin.video.vodkool/codex_live_rotation.json'
REFERENCE_FILE = 'special://home/addons/plugin.video.vodkool/resources/sender_ordnerstruktur_voll_sortiert.txt'
SIMPLE_LIST_FILE = 'special://home/addons/plugin.video.vodkool/resources/deutsche_sender_einfache_liste.txt'
STREAM_CACHE_VERSION = 6

_orig_addDirectoryItem = xbmcplugin.addDirectoryItem
_orig_addDirectoryItems = xbmcplugin.addDirectoryItems
_orig_endOfDirectory = xbmcplugin.endOfDirectory
_orig_setResolvedUrl = xbmcplugin.setResolvedUrl

_CLEAN_CACHE = {}
_KEY_CACHE = {}
_REF_CACHE = None


CATEGORY_ORDER = [
    ('az', 'A bis Z'),
    ('football', 'Fussball'),
    ('dazn', 'DAZN'),
    ('private', 'HD Plus'),
    ('entertainment', 'Entertainment'),
    ('doku', 'Doku'),
    ('sport', 'Sport'),
    ('sky_bundesliga', 'Sky Bundesliga'),
    ('popular', 'Bekannte Sender'),
    ('sky_sport', 'Sky Sport'),
    ('sky', 'Sky'),
    ('events', 'Events'),
    ('movies', 'Filmsender'),
    ('other', 'Sonstiges')
]

COUNTRY_CATEGORY_ORDER = [
    ('az', 'A bis Z'),
    ('news', 'Nachrichten'),
    ('sport', 'Sport'),
    ('entertainment', 'Entertainment')
]

POPULAR_NAMES = [
    'Das Erste', 'ZDF', 'ZDFneo', 'ZDFinfo', '3sat', 'arte', 'Phoenix', 'ONE',
    'tagesschau24', 'BR Fernsehen', 'NDR Fernsehen', 'WDR', 'MDR Fernsehen',
    'SWR Fernsehen', 'HR Fernsehen', 'RBB Berlin', 'RTL', 'RTLZWEI', 'VOX',
    'ntv', 'Super RTL', 'TOGGO plus', 'Nitro', 'ProSieben', 'ProSieben MAXX',
    'SAT.1', 'SAT.1 Gold', 'Kabel Eins', 'Kabel Eins Doku', 'sixx', 'DMAX',
    'TLC', 'WELT', 'BILD TV', 'TELE 5', 'Comedy Central Deutschland',
    'Disney Channel Deutschland', 'Cartoon Network', 'Nickelodeon', 'KiKA',
    'MTV', 'Deluxe Music', 'HGTV', 'Sport1', 'Eurosport 1', 'Eurosport 2'
]

MOVIE_WORDS = [
    'kino', 'cinema', 'film', 'filme', 'movie', 'movies', 'cinedome',
    'filmbox', 'filmgold', 'kinowelt', 'heimatkanal', 'silverline',
    'sky cinema', 'sky box', 'warner tv film', 'action', 'thriller',
    'horror', 'komodie', 'komoedie', 'scifi', 'science fiction',
    'fantasy', 'drama', 'bollywood', 'liebesfilm', 'western'
]

NEWS_WORDS = [
    'news', 'nachrichten', 'haber', '24 horas', 'al jazeera', 'cnn', 'bbc news',
    'euronews', 'cnbc', 'bloomberg', 'sky news', 'france 24', 'ntv', 'welt',
    'tagesschau'
]

SPORT_WORDS = [
    'sport', 'sports', 'fussball', 'football', 'bundesliga', 'liga', 'dazn',
    'sky sport', 'arena sport', 'eurosport', 'tennis', 'golf', 'f1', 'formula',
    'motorsport', 'ufc', 'wwe', 'nba', 'nfl', 'nhl', 'match', 'event'
]

ENTERTAINMENT_WORDS = [
    'movie', 'movies', 'film', 'cinema', 'series', 'serie', 'show', 'shows',
    'comedy', 'kids', 'cartoon', 'nick', 'disney', 'warner', 'fox', 'hbo',
    'syfy', 'action', 'drama', 'thriller', 'horror', 'music', 'mtv'
]

EVENT_WORDS = [
    'event', 'events', 'match time', 'only during events', 'live during events only',
    'nur live', 'top event', 'select', 'popcorn select', 'premiere'
]


def _params_from_query(query):
    try:
        return dict(parse_qsl((query or '').lstrip('?')))
    except Exception:
        return {}


CURRENT_PARAMS = _params_from_query(sys.argv[2] if len(sys.argv) > 2 else '')


def _is_kool_live_channels():
    return CURRENT_PARAMS.get('action') == 'kool_live_channels'


def _is_main_menu():
    return not CURRENT_PARAMS.get('action')


def _is_live_germany():
    return CURRENT_PARAMS.get('action') == 'codex_de_live'


def _is_stream_category():
    return CURRENT_PARAMS.get('action') == 'codex_de_category'


def _is_stream_group():
    return CURRENT_PARAMS.get('action') == 'codex_de_group'


def _is_country_live():
    return CURRENT_PARAMS.get('action') == 'codex_country_live'


def _is_country_category():
    return CURRENT_PARAMS.get('action') == 'codex_country_category'


def _is_country_group():
    return CURRENT_PARAMS.get('action') == 'codex_country_group'


def _plugin_url(params):
    try:
        return sys.argv[0] + '?' + urlencode(params)
    except Exception:
        return ''


def _translate_path(path):
    try:
        if xbmcvfs is not None:
            return xbmcvfs.translatePath(path)
        return xbmc.translatePath(path)
    except Exception:
        return path


def _read_text(path):
    try:
        real_path = _translate_path(path)
        with open(real_path, 'r') as handle:
            return handle.read()
    except Exception:
        return ''


def _strip_kodi_tags(text):
    text = re.sub(r'\[/?(?:B|I|U|UPPERCASE|LOWERCASE)\]', ' ', text, flags=re.I)
    text = re.sub(r'\[/?COLOR[^\]]*\]', ' ', text, flags=re.I)
    return text


def _clean_label(label):
    cache_key = str(label or '')
    cached = _CLEAN_CACHE.get(cache_key)
    if cached is not None:
        return cached
    text = _strip_kodi_tags(cache_key)
    text = text.replace('ʜᴅ', 'HD').replace('ᴴᴰ', 'HD')
    text = re.sub(r'^\s*\[[^\]]+\]\s*', ' ', text)
    text = re.sub(r'\[[^\]]*\]', ' ', text)
    text = re.sub(
        r'\([^)]*(?:backup|not 24/7|geo|nur live|streaming|sat|bar|local|match time|only during events|live during events only|h\.?265|hevc|fhd|uhd|hd|sd|4k|[0-9]{3,4}p)[^)]*\)',
        ' ',
        text,
        flags=re.I
    )
    text = re.sub(r'\s+\.[a-z]\s*$', ' ', text, flags=re.I)
    text = re.sub(r'(?<![a-z0-9])(?:fhd|uhd|hd|sd|4k)\s*\+?(?=$|[^a-z0-9])', ' ', text, flags=re.I)
    text = re.sub(r'\b(?:hevc|h\.?\s?265|backup)\b', ' ', text, flags=re.I)
    text = re.sub(r'\b(?:de|ger|germany)\b$', ' ', text, flags=re.I)
    text = re.sub(r'\s+', ' ', text).strip()
    if not text:
        text = cache_key.strip()
    _CLEAN_CACHE[cache_key] = text
    return text


def _name_key(label):
    cache_key = str(label or '')
    cached = _KEY_CACHE.get(cache_key)
    if cached is not None:
        return cached
    text = _clean_label(label).lower()
    text = text.replace('ä', 'ae').replace('ö', 'oe').replace('ü', 'ue').replace('ß', 'ss')
    text = text.replace('&', ' and ').replace('+', ' plus ')
    text = re.sub(r'\b(?:hd|fhd|uhd|sd|4k)\b', ' ', text)
    text = re.sub(r'\b(?:tv|fernsehen|channel|deutschland|germany)\b$', ' ', text)
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    aliases = {
        '1 2 3': '123 tv',
        '1 2 3 tv': '123 tv',
        '123': '123 tv',
        '3 sat': '3sat',
        'sat 1': 'sat1',
        'sat 1 gold': 'sat1 gold',
        'sat 1 emotions': 'sat1 emotions',
        'kabel 1': 'kabel eins',
        'kabeleins': 'kabel eins',
        'pro 7': 'prosieben',
        'pro sieben': 'prosieben',
        'pro7 maxx': 'prosieben maxx',
        'pro sieben maxx': 'prosieben maxx',
        'rtl 2': 'rtl zwei',
        'rtl ii': 'rtl zwei',
        'rtlzwei': 'rtl zwei',
        'rtl nitro': 'nitro',
        'n tv': 'ntv',
        'superrtl': 'super rtl',
        'ard': 'das erste',
        'ard das erste': 'das erste',
        'zdf info': 'zdfinfo',
        'zdf neo': 'zdfneo',
        'welt n24': 'welt',
        'dw': 'deutsche welle',
        'dw deutsch': 'deutsche welle',
        'deutsche welle deutsch': 'deutsche welle',
        'auto moto sport': 'auto motor sport',
        'auto motor und sport': 'auto motor sport',
        'auto motor und sport channel': 'auto motor sport',
        '13th street universal': '13th street',
        'bon gusto': 'bongusto',
        'fashiontv': 'fashion tv',
        'edge sport': 'edgesport',
        'film gold': 'filmgold',
        'heimat kanal': 'heimatkanal',
        'kino welt': 'kinowelt',
        'kinowelt': 'kinowelttv',
        'br': 'br fernsehen',
        'br tv': 'br fernsehen',
        'hr': 'hr fernsehen',
        'mdr': 'mdr fernsehen',
        'ndr': 'ndr fernsehen',
        'swr': 'swr fernsehen',
        'rbb': 'rbb berlin',
        'allgau': 'allgaeu tv',
        'allgaeu': 'allgaeu tv',
        'muenchen': 'muenchen tv',
        'sachseneins': 'sachsen eins',
        's sport': 'sky sport',
        's sport bundesliga': 'sky sport bundesliga'
    }
    text = aliases.get(text, text)
    text = re.sub(r'^sky bundesliga([0-9]+)$', r'sky sport bundesliga \1', text)
    text = re.sub(r'^sky bundesliga(?: |$)', 'sky sport bundesliga ', text).strip()
    if re.match(r'^lg(?: |[0-9]|$)', text):
        text = 'lg kanaele'
    if re.match(r'^magenta (?:sport|fussball)(?: [0-9]+)?$', text):
        text = 'magenta sport'
    text = re.sub(r'^dazn bar ([0-9]+)$', r'dazn \1', text)
    text = re.sub(r'^dazn ([0-9]+) bar$', r'dazn \1', text)
    if text.startswith('s sport '):
        text = 'sky sport ' + text[8:]
    _KEY_CACHE[cache_key] = text
    return text


def _natural_key(text):
    parts = re.split(r'([0-9]+)', _name_key(text))
    return [(0, int(part)) if part.isdigit() else (1, part) for part in parts]


def _parse_numbered_list(text):
    sections = {}
    current = 'MASTER'
    sections[current] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('==='):
            current = line.strip('= ').strip() or current
            sections.setdefault(current, [])
            continue
        match = re.match(r'^\d+\.\s*(.+)$', line)
        if match:
            sections.setdefault(current, []).append(match.group(1).strip())
    return sections


def _preferred_name(names):
    for name in names:
        if not re.search(r'\b(?:HD|UHD|FHD|4K)\b', name, flags=re.I):
            return name
    return names[0] if names else ''


def _fallback_display_name(key, raw_name):
    match = re.match(r'^dazn ([0-9]+)$', key)
    if match:
        return 'DAZN %s' % match.group(1)
    match = re.match(r'^dazn events? ([0-9]+)$', key)
    if match:
        return 'DAZN Events %s' % match.group(1)
    if key == 'dazn fast plus':
        return 'DAZN FAST+'
    if key == 'dazn rise':
        return 'DAZN Rise'
    if key == 'magenta sport':
        return 'Magenta Sport'
    if key == 'lg kanaele':
        return 'LG-Kanaele'
    match = re.match(r'^sky sport bundesliga(?: ([0-9]+))?$', key)
    if match:
        return 'Sky Sport Bundesliga%s' % ((' ' + match.group(1)) if match.group(1) else '')
    match = re.match(r'^sky sport ([0-9]+)$', key)
    if match:
        return 'Sky Sport %s' % match.group(1)
    if key.startswith('sky sport '):
        return 'Sky Sport ' + key[10:].title()
    return _clean_label(raw_name)


def _reference_data():
    global _REF_CACHE
    if _REF_CACHE is not None:
        return _REF_CACHE
    text = _read_text(REFERENCE_FILE)
    sections = _parse_numbered_list(text)
    simple = _parse_numbered_list(_read_text(SIMPLE_LIST_FILE)).get('MASTER', [])
    if simple:
        sections.setdefault('MASTER', [])
        sections['MASTER'].extend(simple)

    by_key = {}
    for section_names in sections.values():
        for name in section_names:
            by_key.setdefault(_name_key(name), []).append(name)

    canonical = dict((key, _preferred_name(names)) for key, names in by_key.items())
    section_keys = {}
    for section, names in sections.items():
        section_keys[section] = set(_name_key(name) for name in names)

    _REF_CACHE = {
        'canonical': canonical,
        'section_keys': section_keys,
        'popular_keys': set(_name_key(name) for name in POPULAR_NAMES)
    }
    return _REF_CACHE


def _load_json(path):
    try:
        real_path = _translate_path(path)
        if not os.path.exists(real_path):
            return {}
        with open(real_path, 'r') as handle:
            return json.load(handle)
    except Exception:
        return {}


def _save_json(path, data):
    try:
        real_path = _translate_path(path)
        directory = os.path.dirname(real_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(real_path, 'w') as handle:
            json.dump(data, handle)
        return True
    except Exception:
        return False


def _source_mtime():
    try:
        real_path = _translate_path(CHANNELS_CACHE_FILE)
        if os.path.exists(real_path):
            return os.path.getmtime(real_path)
    except Exception:
        pass
    return None


def _contains_key_word(key, words):
    haystack = ' %s ' % key
    for word in words:
        if ' %s ' % _name_key(word) in haystack:
            return True
    return False


def _category_flags(key):
    refs = _reference_data()
    section_keys = refs.get('section_keys', {})
    flags = set()

    if key in refs.get('popular_keys', set()):
        flags.add('popular')
    if key in section_keys.get('HD PLUS / PRIVATE', set()):
        flags.add('private')
    if key in section_keys.get('ENTERTAINMENT', set()):
        flags.add('entertainment')
    if key in section_keys.get('FUSSBALL', set()):
        flags.add('football')
    if key in section_keys.get('DOKU', set()):
        flags.add('doku')

    if key.startswith('dazn '):
        flags.add('dazn')
        flags.add('football')
    if key.startswith('sky sport bundesliga') or key.startswith('sky bundesliga'):
        flags.add('sky_bundesliga')
        flags.add('football')
    elif key.startswith('sky sport '):
        flags.add('sky_sport')
        flags.add('football')
    elif key.startswith('sky '):
        flags.add('sky')

    if key == 'lg kanaele' or key.startswith('lg ') or re.match(r'^lg[0-9]+(?: |$)', key):
        flags.add('entertainment')
        flags.add('other')
    if key == 'magenta sport' or key.startswith('magenta sport ') or key.startswith('magentasport '):
        flags.add('football')
        flags.add('events')
    if _is_event_key(key):
        flags.add('events')
        flags.add('football')

    if _contains_key_word(key, SPORT_WORDS):
        flags.add('sport')

    if _contains_key_word(key, MOVIE_WORDS):
        flags.add('movies')
    if not flags:
        flags.add('other')
    return flags


def _is_event_key(key):
    if _contains_key_word(key, EVENT_WORDS):
        return True
    if re.match(r'^dazn (?:[3-9]|1[0-9]|2[0-9])$', key):
        return True
    if re.match(r'^dazn events? [0-9]+$', key):
        return True
    if re.match(r'^rtl plus (?:sport )?event [0-9]+$', key):
        return True
    if re.match(r'^sky select(?: |$)', key) or re.match(r'^sky popcorn select(?: |$)', key):
        return True
    if key == 'magenta sport':
        return True
    if re.match(r'^(?:magenta sport|magentasport) (?:[2-9]|1[0-9]|2[0-9])$', key):
        return True
    return False


def _stream_url(stream, label):
    url = dns_bypass.prepare_url_for_kodi(stream.get('url', ''))
    return _plugin_url({
        'action': 'play_kool_live',
        'url': url,
        'label': label
    })


def _build_group_data():
    cache = _load_json(CHANNELS_CACHE_FILE)
    germany = cache.get('groups', {}).get('Germany', {})
    if not germany:
        return {}

    refs = _reference_data()
    canonical = refs.get('canonical', {})
    groups = {}
    order = []

    for raw_name, streams in germany.items():
        key = _name_key(raw_name)
        if key in ('lg kanaele', 'magenta sport'):
            label = _fallback_display_name(key, raw_name)
        else:
            label = canonical.get(key) or _fallback_display_name(key, raw_name)
        if key not in groups:
            groups[key] = {
                'label': label,
                'items': [],
                'show_item_labels': key in ('lg kanaele', 'magenta sport')
            }
            order.append(key)
        for stream in streams or []:
            url = stream.get('url')
            if not url:
                continue
            groups[key]['items'].append({
                'url': _stream_url(stream, stream.get('name') or raw_name),
                'label': stream.get('name') or raw_name
            })

    categories = dict((category_id, []) for category_id, label in CATEGORY_ORDER)
    for key in order:
        group = groups.get(key, {})
        if not group.get('items'):
            continue
        categories['az'].append(key)
        for category_id in _category_flags(key):
            if category_id != 'az':
                categories[category_id].append(key)

    for keys in categories.values():
        keys.sort(key=lambda key: _natural_key(groups.get(key, {}).get('label') or key))

    data = {
        'version': STREAM_CACHE_VERSION,
        'source_mtime': _source_mtime(),
        'groups': groups,
        'categories': categories
    }
    _save_json(STREAM_GROUPS_FILE, data)
    return data


def _load_group_data():
    data = _load_json(STREAM_GROUPS_FILE)
    if (
        data.get('version') == STREAM_CACHE_VERSION and
        data.get('groups') and
        data.get('categories') and
        data.get('source_mtime') == _source_mtime()
    ):
        return data
    return _build_group_data()


def _country_storage_key(country):
    return _name_key(country or '')


def _country_group_key(country, raw_name):
    return '%s::%s' % (_country_storage_key(country), raw_name)


def _country_category_flags(raw_name):
    key = _name_key(raw_name)
    flags = set()
    if _contains_key_word(key, NEWS_WORDS):
        flags.add('news')
    if _contains_key_word(key, SPORT_WORDS):
        flags.add('sport')
    if _contains_key_word(key, ENTERTAINMENT_WORDS):
        flags.add('entertainment')
    return flags


def _build_country_group_data(country):
    cache = _load_json(CHANNELS_CACHE_FILE)
    channels = cache.get('groups', {}).get(country, {})
    if not channels:
        return {}

    groups = {}
    order = []
    categories = dict((category_id, []) for category_id, label in COUNTRY_CATEGORY_ORDER)
    for raw_name, streams in channels.items():
        group_id = _name_key(raw_name)
        if not group_id:
            continue
        key = _country_group_key(country, group_id)
        if key not in groups:
            groups[key] = {
                'label': _clean_label(raw_name),
                'items': [],
                '_flags': set()
            }
            order.append(key)
        for stream in streams or []:
            url = stream.get('url')
            if not url:
                continue
            label = stream.get('name') or raw_name
            groups[key]['items'].append({
                'url': _stream_url(stream, label),
                'label': label
            })
        groups[key].setdefault('_flags', set()).update(_country_category_flags(raw_name))

    for key in order:
        group = groups.get(key, {})
        if not group.get('items'):
            continue
        categories['az'].append(key)
        for category_id in group.pop('_flags', set()):
            categories[category_id].append(key)

    for category_id, keys in categories.items():
        if category_id == 'az':
            continue
        keys.sort(key=lambda key: _natural_key(groups.get(key, {}).get('label') or key))

    return {
        'version': STREAM_CACHE_VERSION,
        'source_mtime': _source_mtime(),
        'country': country,
        'groups': groups,
        'categories': categories
    }


def _load_all_country_data():
    data = _load_json(COUNTRY_GROUPS_FILE)
    if data.get('version') != STREAM_CACHE_VERSION or data.get('source_mtime') != _source_mtime():
        return {'version': STREAM_CACHE_VERSION, 'source_mtime': _source_mtime(), 'countries': {}}
    if 'countries' not in data:
        data['countries'] = {}
    return data


def _load_country_data(country):
    all_data = _load_all_country_data()
    country_key = _country_storage_key(country)
    data = all_data.get('countries', {}).get(country_key)
    if data and data.get('country') == country and data.get('groups') and data.get('categories'):
        return data
    data = _build_country_group_data(country)
    if data:
        all_data.setdefault('countries', {})[country_key] = data
        _save_json(COUNTRY_GROUPS_FILE, all_data)
    return data


def _add_category_folders(handle, categories):
    for category_id, category_label in CATEGORY_ORDER:
        keys = categories.get(category_id, [])
        if not keys:
            continue
        item = _folder_item('%s (%s)' % (category_label, len(keys)))
        _orig_addDirectoryItem(
            handle,
            _plugin_url({'action': 'codex_de_category', 'category': category_id}),
            item,
            True
        )


def _add_country_category_folders(handle, country, categories):
    for category_id, category_label in COUNTRY_CATEGORY_ORDER:
        keys = categories.get(category_id, [])
        if not keys:
            continue
        item = _folder_item('%s (%s)' % (category_label, len(keys)))
        _orig_addDirectoryItem(
            handle,
            _plugin_url({'action': 'codex_country_category', 'country': country, 'category': category_id}),
            item,
            True
        )


def _add_group_item(handle, key, group, action='codex_de_group', country=None):
    items = group.get('items', [])
    if not items:
        return
    label = group.get('label') or key
    if len(items) == 1:
        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        _apply_fanart(item)
        xbmcplugin.addDirectoryItem(handle, items[0].get('url', ''), item, False)
        return
    item = _folder_item('%s (%s Streams)' % (label, len(items)))
    params = {'action': action, 'group': key}
    if country is not None:
        params['country'] = country
    xbmcplugin.addDirectoryItem(handle, _plugin_url(params), item, True)


def _show_live_germany():
    handle = int(sys.argv[1])
    data = _load_group_data()
    if data.get('groups') and data.get('categories'):
        _add_category_folders(handle, data.get('categories', {}))
        try:
            xbmcplugin.setContent(handle, 'files')
        except Exception:
            pass
        xbmcplugin.endOfDirectory(handle)
        return
    default.router('action=kool_live_channels&country=Germany&sort=name')


def _show_category():
    handle = int(sys.argv[1])
    data = _load_group_data()
    groups = data.get('groups', {})
    keys = data.get('categories', {}).get(CURRENT_PARAMS.get('category'), [])
    for key in keys:
        group = groups.get(key)
        if group:
            _add_group_item(handle, key, group)
    try:
        xbmcplugin.setContent(handle, 'videos')
    except Exception:
        pass
    xbmcplugin.endOfDirectory(handle)


def _show_group():
    handle = int(sys.argv[1])
    data = _load_group_data()
    group = data.get('groups', {}).get(CURRENT_PARAMS.get('group'), {})
    for index, stream in enumerate(group.get('items', []), 1):
        label = _clean_label(stream.get('label')) if group.get('show_item_labels') else 'Stream %s' % index
        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        _apply_fanart(item)
        xbmcplugin.addDirectoryItem(handle, stream.get('url', ''), item, False)
    try:
        xbmcplugin.setContent(handle, 'videos')
    except Exception:
        pass
    xbmcplugin.endOfDirectory(handle)


def _query_from_plugin_url(url):
    if not isinstance(url, str):
        return ''
    return url.partition('?')[2]


def _play_group_stream(data, group_key, storage_key, display_label=None):
    handle = int(sys.argv[1])
    group = data.get('groups', {}).get(group_key, {})
    items = group.get('items') or []
    if not items:
        try:
            xbmcgui.Dialog().notification('VodKool', 'Keine Streams gefunden', xbmcgui.NOTIFICATION_WARNING, 2500)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        except Exception:
            pass
        return

    rotation = _load_json(STREAM_ROTATION_FILE)
    if not isinstance(rotation, dict):
        rotation = {}
    stored_index = rotation.get(storage_key, -1)
    last_index = int(stored_index if stored_index is not None else -1)
    index = (last_index + 1) % len(items)
    rotation[storage_key] = index
    _save_json(STREAM_ROTATION_FILE, rotation)

    group_label = display_label or group.get('label') or group_key
    stream_label = items[index].get('label') or group_label
    try:
        xbmcgui.Dialog().notification(
            group_label,
            'Stream %s von %s: %s' % (index + 1, len(items), _clean_label(stream_label)),
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
    except Exception:
        pass
    xbmc.log('[vodkool] Gruppenrotation %s: Stream %s von %s (%s)' % (
        group_label, index + 1, len(items), stream_label
    ), xbmc.LOGINFO)

    query = _query_from_plugin_url(items[index].get('url', ''))
    if query:
        default.router(query)
    else:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_de_group():
    data = _load_group_data()
    group_key = CURRENT_PARAMS.get('group') or ''
    label = CURRENT_PARAMS.get('label') or ''
    _play_group_stream(data, group_key, 'de::%s' % group_key, label)


def _play_country_group():
    country = CURRENT_PARAMS.get('country') or ''
    data = _load_country_data(country)
    group_key = CURRENT_PARAMS.get('group') or ''
    label = CURRENT_PARAMS.get('label') or ''
    _play_group_stream(data, group_key, 'country::%s::%s' % (country, group_key), label)


def _show_country_live():
    handle = int(sys.argv[1])
    country = CURRENT_PARAMS.get('country') or ''
    data = _load_country_data(country)
    if data.get('groups') and data.get('categories'):
        _add_country_category_folders(handle, country, data.get('categories', {}))
        try:
            xbmcplugin.setContent(handle, 'files')
        except Exception:
            pass
        xbmcplugin.endOfDirectory(handle)
        return
    default.router(urlencode({'action': 'kool_live_channels', 'country': country, 'sort': 'name'}))


def _show_country_category():
    handle = int(sys.argv[1])
    country = CURRENT_PARAMS.get('country') or ''
    data = _load_country_data(country)
    groups = data.get('groups', {})
    keys = data.get('categories', {}).get(CURRENT_PARAMS.get('category'), [])
    for key in keys:
        group = groups.get(key)
        if group:
            _add_group_item(handle, key, group, 'codex_country_group', country)
    try:
        xbmcplugin.setContent(handle, 'videos')
    except Exception:
        pass
    xbmcplugin.endOfDirectory(handle)


def _show_country_group():
    handle = int(sys.argv[1])
    country = CURRENT_PARAMS.get('country') or ''
    data = _load_country_data(country)
    group = data.get('groups', {}).get(CURRENT_PARAMS.get('group'), {})
    for index, stream in enumerate(group.get('items', []), 1):
        item = xbmcgui.ListItem(label='Stream %s' % index)
        item.setProperty('IsPlayable', 'true')
        _apply_fanart(item)
        xbmcplugin.addDirectoryItem(handle, stream.get('url', ''), item, False)
    try:
        xbmcplugin.setContent(handle, 'videos')
    except Exception:
        pass
    xbmcplugin.endOfDirectory(handle)


def _folder_item(label):
    item = xbmcgui.ListItem(label=label)
    _apply_fanart(item)
    return item


def _add_live_shortcuts_root(handle):
    item = _folder_item('Live TV')
    url = _plugin_url({'action': 'codex_live_tv_shortcuts'})
    return _orig_addDirectoryItem(handle, url, item, True)


def _show_live_shortcuts():
    handle = int(sys.argv[1])
    xbmcplugin.addDirectoryItem(
        handle,
        _plugin_url({'action': 'codex_de_live'}),
        _folder_item('Live TV Deutschland'),
        True
    )
    xbmcplugin.addDirectoryItem(
        handle,
        _plugin_url({'action': 'kool_live_countries'}),
        _folder_item('Live TV Europa'),
        True
    )
    try:
        xbmcplugin.setContent(handle, 'files')
    except Exception:
        pass
    xbmcplugin.endOfDirectory(handle)


def _rewrite_kool_live_country_url(url):
    if not isinstance(url, str):
        return url
    base, separator, query = url.partition('?')
    if not separator:
        return url
    params = _params_from_query(query)
    if params.get('action') != 'kool_live_sort' or not params.get('country'):
        return url
    if params.get('country') == 'Germany':
        params = {'action': 'codex_de_live'}
    else:
        params = {'action': 'codex_country_live', 'country': params.get('country')}
    return base + '?' + urlencode(params)


def _disable_live_timeshift(listitem):
    try:
        listitem.setProperty('inputstream', 'inputstream.ffmpegdirect')
        listitem.setProperty('inputstreamaddon', 'inputstream.ffmpegdirect')
        listitem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        listitem.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        listitem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        listitem.setProperty('inputstream.ffmpegdirect.stream_mode', '')
        listitem.setProperty('inputstream.ffmpegdirect.playback_as_live', 'true')
        listitem.setProperty('inputstream.ffmpegdirect.protocol_whitelist', 'http,https,tcp,tls,crypto')
        listitem.setProperty('inputstream.ffmpegdirect.stream_opts', ':'.join([
            'http_persistent=1',
            'multiple_requests=1',
            'reconnect=1',
            'reconnect_streamed=1',
            'reconnect_delay_max=2',
            'timeout=15000000',
        ]))
        listitem.setProperty('inputstream.ffmpegdirect.user_agent', 'libmpv')
        xbmc.log('[vodkool] LiveTV Timeshift deaktiviert: normaler FFmpeg/RAM-Stream ohne Disk-Puffer', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[vodkool] LiveTV Timeshift konnte nicht deaktiviert werden: %s' % exc, xbmc.LOGWARNING)
    return listitem


def _setResolvedUrl(handle, succeeded, listitem):
    if CURRENT_PARAMS.get('action') in ('play_kool_live', 'codex_de_play_group', 'codex_country_play_group') and succeeded and listitem:
        listitem = _disable_live_timeshift(listitem)
    return _orig_setResolvedUrl(handle, succeeded, listitem)


def _clean_choice_title(title):
    title = _strip_kodi_tags(title or '')
    title = re.sub(r'\[[^\]]+\]', ' ', title)
    title = re.sub(r'\([^\)]*(?:1080|720|2160|4k|uhd|hd|sd|sub|dub|german|deutsch)[^\)]*\)', ' ', title, flags=re.I)
    title = re.sub(r'\b(?:1080p?|720p?|2160p?|4k|uhd|fhd|hd|sd|german|deutsch|sub|dub|stream|online)\b', ' ', title, flags=re.I)
    title = re.sub(r'\s+', ' ', title).strip(' -:|')
    return title or 'Trailer'


def _walk_video_renderers(data):
    if isinstance(data, dict):
        if 'videoRenderer' in data:
            yield data['videoRenderer']
        for value in data.values():
            for item in _walk_video_renderers(value):
                yield item
    elif isinstance(data, list):
        for value in data:
            for item in _walk_video_renderers(value):
                yield item


def _text_from_runs(data):
    if isinstance(data, str):
        return data
    if not isinstance(data, dict):
        return ''
    if data.get('simpleText'):
        return data.get('simpleText')
    return ''.join((run or {}).get('text', '') for run in data.get('runs') or [])


def _duration_seconds(renderer):
    text = _text_from_runs((renderer or {}).get('lengthText'))
    if not text:
        return 0
    try:
        parts = [int(part) for part in text.strip().split(':')]
    except Exception:
        return 0
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return parts[0] if parts else 0


def _find_youtube_trailer_id(title, year=''):
    base_title = _clean_choice_title(title)
    query_parts = [base_title]
    if year:
        query_parts.append(str(year))
    base_query = ' '.join(part for part in query_parts if part).strip()
    if not base_query:
        return ''

    reject_words = ('review', 'kritik', 'analyse', 'erklaert', 'erklärt', 'reaction',
                    'recap', 'zusammenfassung', 'ranking', 'theorie', 'erklaerung',
                    'erklärung', 'komplett', 'ganze folge')
    search_queries = (
        (base_query + ' KinoCheck Deutsch Trailer', True),
        (base_query + ' Offizieller Deutsch Trailer', False),
    )
    for query, require_kinocheck in search_queries:
        payload = json.dumps({
            'context': {'client': {'clientName': 'WEB', 'clientVersion': '2.20240506.01.00'}},
            'query': query
        }).encode('utf-8')
        request = Request(
            'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
            data=payload,
            headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0'}
        )
        with urlopen(request, timeout=8) as response:
            data = json.loads(response.read().decode('utf-8', 'ignore'))
        best = None
        for index, video in enumerate(_walk_video_renderers(data)):
            video_id = video.get('videoId')
            if not video_id:
                continue
            title_text = _text_from_runs(video.get('title'))
            video_title = title_text.lower()
            channel_text = ' '.join(
                _text_from_runs(video.get(key))
                for key in ('ownerText', 'longBylineText', 'shortBylineText')
            ).lower()
            is_kinocheck = 'kinocheck' in video_title or 'kinocheck' in channel_text
            has_german_marker = 'deutsch' in video_title or 'german' in video_title
            has_english_marker = 'english' in video_title or 'englisch' in video_title
            duration = _duration_seconds(video)
            if require_kinocheck and not is_kinocheck:
                continue
            if require_kinocheck and not has_german_marker:
                continue
            if has_english_marker and not has_german_marker:
                continue
            if 'trailer' not in video_title:
                continue
            if any(word in video_title for word in reject_words):
                continue
            if duration and duration > 600:
                continue
            score = 10 if is_kinocheck else 0
            if 'offiziell' in video_title or 'official' in video_title:
                score += 3
            if has_german_marker:
                score += 2
            if duration and 45 <= duration <= 300:
                score += 1
            candidate = (score, -index, video_id)
            if best is None or candidate > best:
                best = candidate
        if best:
            return best[2]
    return ''


def _play_youtube_trailer_deferred(video_id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % video_id
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.sleep(250)
        xbmc.executebuiltin('PlayMedia(%s)' % url)
    except Exception:
        pass


def _get_label(listitem):
    try:
        return listitem.getLabel() or ''
    except Exception:
        return ''


def _get_year(listitem):
    try:
        year = listitem.getVideoInfoTag().getYear()
        if year:
            return str(year)
    except Exception:
        pass
    for key in ('year', 'premiered', 'aired'):
        try:
            value = listitem.getProperty(key)
            if value:
                return str(value)[:4]
        except Exception:
            pass
    return ''


def _get_media_type(listitem, url=''):
    try:
        media_type = listitem.getVideoInfoTag().getMediaType()
        if media_type in ('movie', 'tvshow'):
            return media_type
    except Exception:
        pass
    for key in ('mediatype', 'mediaType', 'MediaType', 'dbtype'):
        try:
            media_type = (listitem.getProperty(key) or '').strip().lower()
            if media_type in ('movie', 'film'):
                return 'movie'
            if media_type in ('tvshow', 'series', 'serie', 'show'):
                return 'tvshow'
        except Exception:
            pass
    params = _params_from_query((url or '').partition('?')[2])
    media_type = (params.get('mediatype') or params.get('media_type') or params.get('type') or '').strip().lower()
    if media_type in ('movie', 'film'):
        return 'movie'
    if media_type in ('tvshow', 'series', 'serie', 'show'):
        return 'tvshow'
    if media_type in ('season', 'staffel'):
        return 'season'
    if media_type in ('episode', 'folge'):
        return 'episode'
    return ''


def _is_live_url(url):
    params = _params_from_query((url or '').partition('?')[2])
    action = (params.get('action') or '').lower()
    return 'live' in action or action in ('play_kool_live', 'kool_live_channels', 'kool_live_countries', 'kool_live_sort')


def _is_generic_choice_label(label):
    l = (label or '').strip().lower()
    if not l:
        return True
    return any(word in l for word in (
        'live', 'tv', 'iptv', 'suche', 'search', 'genre', 'genres', 'kategorie',
        'category', 'filme', 'movies', 'serien', 'series',
        'weiter', 'next', 'seite', 'page', 'settings', 'einstellungen'
    ))


def _build_trailer_choice_url(title, media_type, original_url, original_is_folder, year=''):
    return _plugin_url({
        'action': 'nova_trailer_choice',
        'choice_title': _clean_choice_title(title),
        'choice_media_type': media_type,
        'choice_url': original_url or '',
        'choice_is_folder': '1' if original_is_folder else '0',
        'choice_year': year or ''
    })


def _maybe_wrap_trailer_choice(url, listitem, isFolder):
    if not isinstance(url, str) or 'nova_trailer_choice' in url or _is_live_url(url):
        return url, isFolder
    label = _get_label(listitem)
    if _is_generic_choice_label(label):
        return url, isFolder
    media_type = _get_media_type(listitem, url)
    params = _params_from_query((url or '').partition('?')[2])
    action = (params.get('action') or '').lower()
    if isFolder and media_type == '' and (
        action in ('season', 'seasons', 'episodes', 'show_episodes', 'showepisodes')
        or 'staffel' in label.lower() or 'season' in label.lower()
    ):
        media_type = 'season'
    if isFolder and media_type == 'tvshow':
        return url, isFolder
    if media_type == 'episode':
        return url, isFolder
    if media_type not in ('movie', 'season'):
        return url, isFolder
    return _build_trailer_choice_url(label, media_type, url, isFolder, _get_year(listitem)), False


def _handle_trailer_choice():
    if CURRENT_PARAMS.get('action') != 'nova_trailer_choice':
        return False
    title = CURRENT_PARAMS.get('choice_title', '')
    media_type = CURRENT_PARAMS.get('choice_media_type', 'movie')
    original_url = CURRENT_PARAMS.get('choice_url', '')
    original_is_folder = CURRENT_PARAMS.get('choice_is_folder') == '1'
    year = CURRENT_PARAMS.get('choice_year', '')
    play_label = 'Serie wiedergeben' if media_type == 'tvshow' else 'Film wiedergeben'
    choice = xbmcgui.Dialog().select(_clean_choice_title(title), [play_label, 'Trailer abspielen', 'Informationen'])
    if choice == 0 and original_url:
        command = 'Container.Update(%s)' if original_is_folder else 'PlayMedia(%s)'
        xbmc.executebuiltin(command % original_url)
    elif choice == 1:
        try:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            video_id = _find_youtube_trailer_id(title, year)
            if video_id:
                try:
                    xbmcplugin.endOfDirectory(int(sys.argv[1]), False)
                except Exception:
                    pass
                _play_youtube_trailer_deferred(video_id)
                return True
            else:
                xbmcgui.Dialog().notification('Trailer', 'Kein Trailer gefunden', xbmcgui.NOTIFICATION_INFO, 2500)
        except Exception:
            xbmcgui.Dialog().notification('Trailer', 'Trailer konnte nicht geladen werden', xbmcgui.NOTIFICATION_ERROR, 3000)
    elif choice == 2:
        xbmc.executebuiltin('Action(Info)')
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), False)
    except Exception:
        pass
    return True


def _apply_fanart(listitem):
    if listitem is None:
        return
    try:
        art = listitem.getArt() or {}
    except Exception:
        art = {}
    if not art.get('fanart'):
        art['fanart'] = FANART
    if not art.get('thumb') and art.get('icon'):
        art['thumb'] = art.get('icon')
    try:
        listitem.setArt(art)
    except Exception:
        pass
    try:
        listitem.setProperty('fanart_image', FANART)
    except Exception:
        pass


def _addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
    _apply_fanart(listitem)
    url = _rewrite_kool_live_country_url(url)
    url, isFolder = _maybe_wrap_trailer_choice(url, listitem, isFolder)
    return _orig_addDirectoryItem(handle, url, listitem, isFolder, totalItems)


def _addDirectoryItems(handle, items, totalItems=0):
    patched_items = []
    for item in items:
        try:
            url, listitem, isFolder = item[:3]
            _apply_fanart(listitem)
            url = _rewrite_kool_live_country_url(url)
            url, isFolder = _maybe_wrap_trailer_choice(url, listitem, isFolder)
            item = (url, listitem, isFolder) + tuple(item[3:])
        except Exception:
            pass
        patched_items.append(item)
    return _orig_addDirectoryItems(handle, patched_items, totalItems)


def _endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
    if _is_main_menu() and succeeded:
        try:
            _add_live_shortcuts_root(handle)
        except Exception:
            pass
    if _is_kool_live_channels():
        try:
            xbmcplugin.setContent(handle, 'videos')
        except Exception:
            pass
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except Exception:
            pass
    return _orig_endOfDirectory(handle, succeeded, updateListing, cacheToDisc)


xbmcplugin.addDirectoryItem = _addDirectoryItem
xbmcplugin.addDirectoryItems = _addDirectoryItems
xbmcplugin.endOfDirectory = _endOfDirectory
xbmcplugin.setResolvedUrl = _setResolvedUrl

import default

if __name__ == "__main__":
    if _handle_trailer_choice():
        pass
    elif CURRENT_PARAMS.get('action') == 'codex_live_tv_shortcuts':
        _show_live_shortcuts()
    elif _is_live_germany():
        _show_live_germany()
    elif _is_stream_category():
        _show_category()
    elif _is_stream_group():
        _show_group()
    elif CURRENT_PARAMS.get('action') == 'codex_de_play_group':
        _play_de_group()
    elif CURRENT_PARAMS.get('action') == 'codex_country_play_group':
        _play_country_group()
    elif _is_country_live():
        _show_country_live()
    elif _is_country_category():
        _show_country_category()
    elif _is_country_group():
        _show_country_group()
    elif len(sys.argv) > 2:
        default.router(sys.argv[2][1:])
    else:
        default.main_menu()
