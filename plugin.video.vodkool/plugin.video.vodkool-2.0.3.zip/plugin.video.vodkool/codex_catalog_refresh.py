"""Explicit VODKOOL catalog refresh. No playback probes or automatic retries."""
import json
import os
import tempfile
import time


class RefreshCancelled(Exception):
    pass


def atomic_json(path, data):
    directory = os.path.dirname(path)
    os.makedirs(directory, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.vodkool-refresh-', suffix='.tmp', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def read_cache(path):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def stream_index(groups):
    # Use the original channel name and opaque provider URL, never artwork or
    # a numeric position in the list. URLs are NOT copied into the report.
    return {(country, name): {s['url'] for s in streams if isinstance(s, dict) and s.get('url')}
            for country, channels in groups.items()
            for name, streams in channels.items()}


def compare_catalogs(old_groups, new_groups):
    old = stream_index(old_groups)
    new = stream_index(new_groups)
    changes = []
    for key in sorted(old.keys() | new.keys()):
        if old.get(key, set()) == new.get(key, set()):
            continue
        changes.append({'country': key[0], 'name': key[1],
                        'status': 'new' if key not in old else 'removed' if key not in new else 'changed',
                        'old_streams': len(old.get(key, set())), 'new_streams': len(new.get(key, set()))})
    return {'added_channels': len(new.keys() - old.keys()),
            'removed_channels': len(old.keys() - new.keys()),
            'changed_channels': sum(old[k] != new[k] for k in old.keys() & new.keys()),
            'countries': len(new_groups), 'channels': len(new),
            'streams': sum(len(streams) for streams in new.values()), 'changes': changes}


def refresh_catalog(provider, cache_path, report_path, progress, cancelled, wait):
    """Fetch each catalog page once using the addon's existing authenticated API.

    The previous cache is retained on errors, cancellation, malformed responses
    or an empty result. No token reset, no M3U edit, no blind retry.
    """
    previous = read_cache(cache_path)
    groups = {}
    seen_streams = set()
    seen_cursors = set()
    cursor = 0
    pages = 0
    while True:
        if cancelled():
            raise RefreshCancelled()
        if cursor in seen_cursors or pages >= 200:
            raise ValueError('Ungueltige oder endlose Katalog-Paginierung')
        seen_cursors.add(cursor)
        progress(0, 'Senderliste wird neu geholt - Seite %s' % (pages + 1))
        data = provider._kool_live_request(provider._KOOL_CATALOG_URL, {
            'language': 'de', 'region': 'AT', 'catalogId': 'iptv', 'id': 'iptv',
            'adult': False, 'search': '', 'sort': '', 'filter': {'group': None},
            'cursor': cursor, 'clientVersion': '3.0.3',
        })
        pages += 1
        if not isinstance(data, dict) or not isinstance(data.get('items'), list):
            raise ValueError('Der Anbieter hat keine gueltige Senderliste geliefert')
        if not data['items']:
            # Some APIs end pagination with a separate empty terminal page.
            # An empty FIRST page or an empty page with a continuation is not
            # a complete valid catalog and must never erase the old cache.
            if groups and data.get('nextCursor') in (None, ''):
                break
            raise ValueError('Leere Katalogseite - bisherige Senderliste bleibt erhalten')
        for stream in data['items']:
            if not isinstance(stream, dict) or not isinstance(stream.get('name'), str) or not stream['name'].strip():
                raise ValueError('Unvollstaendiger Sendereintrag im Katalog')
            if not isinstance(stream.get('url'), str) or not stream['url'].startswith(('http://', 'https://')):
                raise ValueError('Ungueltige Senderadresse im Katalog')
            country = stream.get('group') or 'Other'
            if not isinstance(country, str):
                raise ValueError('Ungueltige Laendergruppe im Katalog')
            key = (country, stream['name'], stream['url'])
            if key not in seen_streams:
                groups.setdefault(country, {}).setdefault(stream['name'], []).append(stream)
                seen_streams.add(key)
        next_cursor = data.get('nextCursor')
        if next_cursor is None or next_cursor == '':
            break
        # Same semantics as the original API, but malformed/repeated cursors
        # must not silently commit a partial catalog or loop indefinitely.
        if isinstance(next_cursor, bool):
            raise ValueError('Ungueltiger Folge-Cursor')
        try:
            cursor = int(next_cursor)
        except (TypeError, ValueError):
            raise ValueError('Ungueltiger Folge-Cursor')
        if cursor < 0 or cursor in seen_cursors:
            raise ValueError('Wiederholter oder ungueltiger Folge-Cursor')
        # Two seconds BETWEEN pages, not a global playback cooldown.
        for unused in range(20):
            if cancelled():
                raise RefreshCancelled()
            wait(100)
    if cancelled():
        raise RefreshCancelled()
    progress(90, 'Sender und Streamadressen werden verglichen')
    report = compare_catalogs(previous.get('groups', {}), groups)
    report.update({'schema': 1, 'ts': time.time(), 'pages': pages})
    progress(95, 'Aktuelle Zuordnungen werden gespeichert')
    # Only a complete successful catalog replaces the provider cache.
    atomic_json(cache_path, {'ts': report['ts'], 'groups': groups})
    try:
        atomic_json(report_path, report)
    except OSError:
        # The valid catalog has already been committed; report failure must
        # not misrepresent that as a failed refresh.
        report['report_saved'] = False
    else:
        report['report_saved'] = True
    progress(100, 'Senderabgleich abgeschlossen')
    return report
