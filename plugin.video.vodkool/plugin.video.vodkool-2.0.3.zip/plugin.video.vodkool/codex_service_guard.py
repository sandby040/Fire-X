"""Keep complete catalogs on background request failure; no token changes."""
import time
import types
from codex_catalog_refresh import atomic_json


def guarded_fetch(native_fetch, wait):
    """Reuse native pagination, but don't return its partial result on error.

    The legacy function catches request errors, logs them, and returns the
    already fetched pages. ensure_channels then treats those as a full catalog.
    A private globals copy keeps this fix scoped to this single function.
    """
    def fetch(signature):
        failed = []
        calls = [0]
        namespace = dict(native_fetch.__globals__)
        original_request = namespace['urllib'].request
        original_log = namespace['_log']

        def log(message, *args, **kwargs):
            if 'Catalog-Request fehlgeschlagen' in message:
                failed.append(True)
            return original_log(message, *args, **kwargs)

        def urlopen(*args, **kwargs):
            if calls[0]:
                # The same two-second page spacing as the manual catalog scan.
                if wait(2):
                    failed.append(True)
                    raise OSError('Catalog refresh aborted')
            calls[0] += 1
            try:
                return original_request.urlopen(*args, **kwargs)
            except Exception:
                failed.append(True)
                raise

        namespace['_log'] = log
        namespace['urllib'] = types.SimpleNamespace(request=types.SimpleNamespace(
            Request=original_request.Request, urlopen=urlopen))
        function = types.FunctionType(native_fetch.__code__, namespace,
                                      native_fetch.__name__, native_fetch.__defaults__, native_fetch.__closure__)
        groups = function(signature)
        if failed or not groups:
            return None
        return groups
    return fetch


def install(service, wait, translate, manual_running):
    fetch = guarded_fetch(service._fetch_channels, wait)
    last_attempt = [None]

    def ensure_channels(signature):
        if manual_running() or service._channel_cache_age() < service._CHANNEL_TTL:
            return
        now = time.monotonic()
        if last_attempt[0] is not None and now - last_attempt[0] < service._CHANNEL_TTL:
            return
        # Failure must not turn the native 30-second poll into repeated full
        # scans. This is ONLY a background scan interval, not a player cooldown.
        last_attempt[0] = now
        service._log('Lade vollstaendige Kanalliste im Hintergrund mit Seitenschutz')
        try:
            groups = fetch(signature)
            if groups is None:
                service._log('CATALOG-GUARD: unvollstaendigen Abruf verworfen; bisheriger Cache bleibt erhalten')
                return
            atomic_json(translate(service._CHANNEL_FILE), {'ts': time.time(), 'groups': groups})
            count = sum(len(streams) for channels in groups.values() for streams in channels.values())
            service._log('CATALOG-GUARD: vollstaendiger Cache gespeichert: %s Gruppen, %s Streams' % (len(groups), count))
        except Exception as exc:
            # Never expose signatures or signed URLs in new diagnostic logs.
            service._log('CATALOG-GUARD: Cache nicht ersetzt (%s)' % type(exc).__name__)

    service.ensure_channels = ensure_channels
