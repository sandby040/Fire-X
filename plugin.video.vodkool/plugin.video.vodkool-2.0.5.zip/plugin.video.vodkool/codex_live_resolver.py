"""Preserve MediaHubMX playback headers, as the VYPN client does.

Only the existing provider request is used. No token acquisition, automatic
source fallback, recursive resolveAgain or extra stream probe is performed.
"""
import re
from urllib.parse import quote, unquote, urlsplit

CLIENT_VERSION = '3.1.0'
_HEADER_NAME = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")


def playback_url(response):
    """Normalize the first resolved source and append its HTTP headers safely."""
    if isinstance(response, list):
        if not response:
            raise ValueError('Keine Streamquelle vom Anbieter erhalten')
        source = response[0]
    else:
        source = response
    if isinstance(source, str):
        source = {'url': source}
    if not isinstance(source, dict) or source.get('resolveAgain'):
        raise ValueError('Keine direkt abspielbare Streamquelle erhalten')
    url = source.get('url')
    if not isinstance(url, str):
        raise ValueError('Streamadresse fehlt')
    base, _, options = url.partition('|')
    parsed = urlsplit(base)
    if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
        raise ValueError('Ungueltige Streamadresse')
    headers = source.get('headers') or {}
    if not isinstance(headers, dict):
        raise ValueError('Ungueltige Stream-Header')
    # Match header names case-insensitively; upstream headers take precedence
    # over any same-name URL option. Do not decode/re-encode the signed base URL.
    additions = {}
    for name, value in headers.items():
        if not isinstance(name, str) or not _HEADER_NAME.fullmatch(name):
            raise ValueError('Ungueltiger Stream-Headername')
        if not isinstance(value, str) or any(c in value for c in '\r\n\x00'):
            raise ValueError('Ungueltiger Stream-Headerwert')
        if name.lower() == 'referrer':
            name = 'Referer'
        additions[name.lower()] = (name, value)
    existing = [part for part in options.split('&') if part and
                unquote(part.split('=', 1)[0]).lower() not in additions]
    existing.extend(quote(name, safe='') + '=' + quote(value, safe='')
                    for name, value in additions.values())
    return base + ('|' + '&'.join(existing) if existing else '')


def install(provider, log):
    def geturl(channel_url):
        response = provider._kool_live_request(provider._KOOL_RESOLVE_URL, {
            'language': 'de', 'region': 'AT', 'url': channel_url,
            'clientVersion': CLIENT_VERSION,
        })
        result = playback_url(response)
        source = response[0] if isinstance(response, list) and response else response
        count = len(source.get('headers') or {}) if isinstance(source, dict) else 0
        log('[vodkool] VYPN-COMPAT: resolve=1; clientVersion=%s; Stream-Header=%d' %
            (CLIENT_VERSION, count))
        return result
    provider._kool_live_geturl = geturl
