import dns_bypass
import service
import xbmc
import xbmcgui
import xbmcvfs
import codex_service_guard
import codex_token_session

dns_bypass.enable_dns_bypass()
codex_token_session.install_service(service, lambda message: xbmc.log(message, xbmc.LOGINFO))
codex_service_guard.install(service, xbmc.Monitor().waitForAbort, xbmcvfs.translatePath,
                            lambda: xbmcgui.Window(10000).getProperty('VodkoolCatalogRefreshRunning') == '1')

if __name__ == "__main__":
    service.VodkoolService().run()
