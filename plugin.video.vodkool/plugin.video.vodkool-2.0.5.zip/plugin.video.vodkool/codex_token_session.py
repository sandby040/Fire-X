"""One expiry-aware signature file for foreground and background service.

Only native server-issued signatures are used. This module never generates,
alters, signs or extends credentials, nor changes native login parameters.
"""
import base64
import builtins
from contextlib import contextmanager
import importlib.util
import json
import math
import os
import sys
import tempfile
import threading
import time
import types

MARGIN_SECONDS = 30


def expires_at(raw):
    """Decode expiry for local freshness checks, not cryptographic validation."""
    try:
        if not isinstance(raw, str) or not raw.strip():
            return 0
        raw = raw.strip()
        if raw.count('.') == 2:
            payload = raw.split('.')[1]
            data = json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4)))
            value = data['exp']
            scale = 1
        else:
            envelope = json.loads(base64.b64decode(raw + '=' * (-len(raw) % 4), validate=True))
            if not envelope.get('signature'):
                return 0
            data = envelope['data']
            data = json.loads(data) if isinstance(data, str) else data
            value = data['validUntil']
            scale = 1000
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return 0
        expiry = value / scale
        return expiry if math.isfinite(expiry) and expiry > 0 else 0
    except (ValueError, TypeError, KeyError, AttributeError):
        return 0


class SignatureStore:
    def __init__(self, path, fetch, log=lambda message: None, clock=time.time):
        self.path, self.fetch, self.log, self.clock = os.fspath(path), fetch, log, clock
        self.failed = False  # no duplicate fetch in one foreground invocation

    def valid(self, raw):
        return expires_at(raw) > self.clock() + MARGIN_SECONDS

    def read(self):
        try:
            with open(self.path, encoding='utf-8') as handle:
                return handle.read().strip()
        except (OSError, UnicodeError):
            return ''

    @contextmanager
    def locked(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        lockpath = self.path + '.codex-lock'
        deadline = time.monotonic() + 2
        owned = False
        try:
            while True:
                try:
                    fd = os.open(lockpath, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    os.close(fd)
                    owned = True
                    break
                except FileExistsError:
                    # Recover only our own abandoned lock after a crashed app.
                    try:
                        if self.clock() - os.stat(lockpath).st_mtime > 120:
                            os.unlink(lockpath)
                            continue
                    except FileNotFoundError:
                        continue
                    if time.monotonic() >= deadline:
                        break
                    time.sleep(0.1)
            yield owned
        finally:
            if owned:
                try:
                    os.unlink(lockpath)
                except FileNotFoundError:
                    pass

    def _write(self, raw):
        fd, temporary = tempfile.mkstemp(prefix='.codex-signature-', suffix='.tmp',
                                          dir=os.path.dirname(self.path))
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def save(self, raw):
        if not self.valid(raw):
            return False
        with self.locked() as owned:
            if not owned:
                return False
            current = self.read()
            if self.valid(current) and expires_at(current) > expires_at(raw):
                self.log('[vodkool] TOKEN-SESSION: aeltere Signatur nicht zurueckgeschrieben')
                return False
            self._write(raw)
            return True

    def get(self):
        raw = self.read()
        if self.valid(raw):
            return raw
        if self.failed:
            return ''
        with self.locked() as owned:
            # Another interpreter/service may have refreshed while we waited.
            raw = self.read()
            if self.valid(raw):
                return raw
            if not owned:
                self.failed = True
                self.log('[vodkool] TOKEN-SESSION: Erneuerung bereits aktiv; kein Parallelversuch')
                return ''
            self.log('[vodkool] TOKEN-SESSION: fehlt/abgelaufen; genau eine native Erneuerung')
            try:
                fresh = self.fetch()
                if not self.valid(fresh):
                    raise ValueError('Keine frische Signatur erhalten')
                self._write(fresh)
                self.log('[vodkool] TOKEN-SESSION: frische Serversignatur atomar gespeichert')
                return fresh
            except Exception as exc:
                self.failed = True
                # Exception messages may contain private URLs/credentials.
                self.log('[vodkool] TOKEN-SESSION: Erneuerung fehlgeschlagen (%s); kein Zweitversuch' %
                         type(exc).__name__)
                return ''


def install_handler(module, log):
    if getattr(module, '_codex_token_session_installed', False):
        return
    klass = module.SignatureHandler
    original_fetch = klass.get_new_signature
    module._is_sig_valid = lambda raw: expires_at(raw) > time.time() + MARGIN_SECONDS

    def store(handler):
        if not hasattr(handler, '_codex_store'):
            def fetch():
                handler._tok = None  # native fetch must not return stale RAM state
                return original_fetch(handler)
            handler._codex_store = SignatureStore(handler.path, fetch, log)
        return handler._codex_store

    def read_signature(handler):
        raw = store(handler).get()
        handler._tok = raw or None
        return handler._parse(raw) if raw else None

    def get_new_signature(handler):
        raw = store(handler).get()
        handler._tok = raw or None
        return raw or None

    def save_signature(handler, raw):
        store(handler).save(raw)
        handler._tok = store(handler).read() or None

    klass.read_signature = read_signature
    klass.get_new_signature = get_new_signature
    klass.save_signature = save_signature
    module._codex_token_session_installed = True


def private_threading(log):
    """Disable only the legacy per-import validator, never global threading."""
    proxy = types.ModuleType('threading')
    proxy.__dict__.update(vars(threading))
    def Thread(*args, **kwargs):
        target = kwargs.get('target', args[1] if len(args) > 1 else None)
        if (getattr(target, '__module__', None) == 'default' and
                getattr(target, '__name__', None) == '_validate_token'):
            class NoLegacyValidation:
                def start(self):
                    log('[vodkool] TOKEN-SESSION: Ablaufdatum lokal geprueft; kein Legacy-Validierungsrequest')
            return NoLegacyValidation()
        return threading.Thread(*args, **kwargs)
    proxy.Thread = Thread
    return proxy


def load_native_default(log):
    from resources.lib import signaturehandler
    install_handler(signaturehandler, log)
    if 'default' in sys.modules:
        module = sys.modules['default']
    else:
        spec = importlib.util.find_spec('default')
        if spec is None or not hasattr(spec.loader, 'get_code'):
            raise ImportError('Originales VODKOOL-Programm fehlt')
        module = importlib.util.module_from_spec(spec)
        original_import = builtins.__import__
        proxy = private_threading(log)
        def local_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name == 'threading' and level == 0:
                return proxy
            return original_import(name, globals, locals, fromlist, level)
        module.__dict__['__builtins__'] = dict(vars(builtins), __import__=local_import)
        sys.modules['default'] = module
        try:
            exec(spec.loader.get_code('default'), module.__dict__)
        except BaseException:
            sys.modules.pop('default', None)
            raise
    def current_token():
        parsed = module.sig_handler.read_signature()
        raw = (parsed or {}).get('mediahubmx-raw', '')
        module._token_cache.update(token=raw, time=time.time())
        return raw
    module._get_cached_token = current_token
    return module


def install_service(service, log):
    store = SignatureStore(service._SIG_FILE, service._fetch_signature, log)
    def ensure_signature():
        store.failed = False  # native service poll spacing remains unchanged
        return store.get()
    service.ensure_signature = ensure_signature
