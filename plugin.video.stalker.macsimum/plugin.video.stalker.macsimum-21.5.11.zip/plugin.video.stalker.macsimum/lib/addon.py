# -*- coding: utf-8 -*-
# Token-refresh + header-refresh + DE-sort wrapper
# - when create_link gets 403, do a real handshake, extract a fresh token,
#   update Authorization header, refresh profile, and retry create_link once.
# - reorder directory listings: keep search first, then labels starting with DE.
import os, time, threading, json, hashlib, importlib.util, importlib.machinery, urllib.parse, urllib.request, urllib.error, re, sys, sqlite3, unicodedata, base64

try:
    import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
except Exception:
    xbmc = xbmcplugin = xbmcgui = xbmcaddon = xbmcvfs = None

ADDON_ID = "plugin.video.stalker.macsimum"

_REQ_LOCK = threading.Lock()
_LAST_REQUEST_TS = 0.0
MIN_REQUEST_GAP = 0.0
RETRY_REQUEST_GAP = 0.15
_TMDB_API_KEY = "86dd18b04874d9c94afadde7993d94e3"
_TMDB_CACHE = {}
_TMDB_LOOKUP_COUNT = 0
_TMDB_LOOKUP_LIMIT = 0
_MEDIA_META = {}
DEFAULT_FANART = "special://home/addons/plugin.video.stalker.macsimum/resources/fanart.jpg"
NEXT_PAGE_ART = "special://home/addons/plugin.video.stalker.macsimum/resources/next_page.png"
FAVORITES_ART = "special://home/addons/plugin.video.stalker.macsimum/resources/media/gold_star.png"
_CURRENT_CONTENT = ""
_META_APPLY_LOG_COUNT = 0
_TMDB_GENRES = {
    12: "Abenteuer", 14: "Fantasy", 16: "Animation", 18: "Drama",
    27: "Horror", 28: "Action", 35: "Komödie", 36: "Historie",
    37: "Western", 53: "Thriller", 80: "Krimi", 99: "Dokumentation",
    878: "Science-Fiction", 9648: "Mystery", 10402: "Musik",
    10749: "Romanze", 10751: "Familie", 10752: "Kriegsfilm",
    10759: "Action & Abenteuer", 10762: "Kinder", 10763: "News",
    10764: "Reality", 10765: "Sci-Fi & Fantasy", 10766: "Soap",
    10767: "Talk", 10768: "Politik & Krieg", 10770: "TV-Film",
}
MAC_SESSION_FILE = "mac_session.json"
# Es gibt nur noch eine kurze aktuelle Session-MAC.
# Keine Bewertungslisten, keine stundenlangen Pins, keine Sperrlisten.
# Fuer laufende Live-TV-/Portal-Nutzung darf current_mac kurz wiederverwendet
# werden, damit nicht jeder Kanalstart eine neue Auth ausloest.
# Eine MAC wird erst nach echtem, erfolgreichem Bereichs-Warm-up gespeichert.
# Danach bleibt sie ohne starre Uhrzeit-Grenze erhalten. Normale Portal-,
# Netzwerk- oder Wiedergabefehler duerfen sie nicht mehr automatisch loeschen.
# Nur ein bewusst gestarteter manueller Handshake rotiert die gemeinsame MAC.
MAC_CURRENT_TTL = None
CATEGORY_NAV_CACHE_FILE = "category_nav_cache.json"
MACSIMUM_FAVORITES_FILE = "macsimum_favorites.json"
CATEGORY_NAV_CACHE_TTL = 10 * 60
MAX_PORTAL_ATTEMPTS = 1
PORTAL_TIMEOUT = 15
RATE_LIMIT_COOLDOWN = 10 * 60
LIVE_SAME_CHANNEL_GUARD_SECONDS = 4
MAX_LOCAL_MAC_PICK_ATTEMPTS = 25
MAX_LOCAL_MAC_PICK_SECONDS = 7
_CURRENT_REQUEST_MAC = None

# per-handle buffered directory entries for custom sort
_DIR_BUFFER = {}

def _log(msg, level=None):
    try:
        if xbmc:
            xbmc.log("[stalkerportal:tokenfix+desort] " + msg, level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _rewrite_url(url):
    # Keine Host-Umleitung mehr: URLs bleiben im Originalzustand.
    return url

def _force_added_sort_for_portal_listing(url, kwargs):
    """Keep Stalker VOD/series title listings on newest-first portal order."""
    try:
        params = kwargs.get("params")
        if isinstance(params, dict):
            p_action = str(params.get("action") or "").lower()
            p_type = str(params.get("type") or "").lower()
            if p_action == "get_ordered_list" and p_type in ("vod", "series"):
                params = dict(params)
                params["sortby"] = "added"
                params["orderby"] = "added"
                params["order"] = "desc"
                params["sort_order"] = "desc"
                kwargs["params"] = params
        if not isinstance(url, str) or "portal.php" not in url or "get_ordered_list" not in url:
            return url, kwargs
        parsed = urllib.parse.urlsplit(url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if (qs.get("action") or [""])[0].lower() == "get_ordered_list" and (qs.get("type") or [""])[0].lower() in ("vod", "series"):
            qs["sortby"] = ["added"]
            qs["orderby"] = ["added"]
            qs["order"] = ["desc"]
            qs["sort_order"] = ["desc"]
            new_query = urllib.parse.urlencode(qs, doseq=True)
            url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, new_query, parsed.fragment))
    except Exception:
        pass
    return url, kwargs


def _tmdb_image_size(url, size):
    url = str(url or "")
    if "image.tmdb.org/t/p/" not in url:
        return url
    parts = url.split("/t/p/", 1)
    if len(parts) != 2 or "/" not in parts[1]:
        return url
    return parts[0] + "/t/p/" + size + "/" + parts[1].split("/", 1)[1]


def _normalize_art_dict(art):
    if not isinstance(art, dict):
        return art
    normalized = dict(art)
    for key in ("icon", "thumb", "poster"):
        if normalized.get(key):
            normalized[key] = _tmdb_image_size(normalized.get(key), "w185")
    if normalized.get("fanart"):
        normalized["fanart"] = _tmdb_image_size(normalized.get("fanart"), "w300")
    return normalized


def _normalize_listitem_art(listitem):
    try:
        art = listitem.getArt() or {}
    except Exception:
        return
    try:
        listitem.setArt(_normalize_art_dict(art))
    except Exception:
        pass


def _normalize_tmdb_item_images(item):
    if not isinstance(item, dict):
        return item
    for key, value in list(item.items()):
        if not isinstance(value, str) or "image.tmdb.org/t/p/" not in value:
            continue
        key_name = str(key or "").lower()
        if any(name in key_name for name in ("fanart", "backdrop", "background", "landscape")):
            item[key] = _tmdb_image_size(value, "w300")
        else:
            item[key] = _tmdb_image_size(value, "w185")
    return item


def _addon_profile_dir():
    try:
        profile = xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile")
        if xbmcvfs:
            profile = xbmcvfs.translatePath(profile)
        elif xbmc:
            profile = xbmc.translatePath(profile)
        os.makedirs(profile, exist_ok=True)
        return profile
    except Exception:
        profile = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "..", "userdata", "addon_data", ADDON_ID)
        try:
            os.makedirs(profile, exist_ok=True)
        except Exception:
            pass
        return profile

def _mac_state_path():
    return os.path.join(_addon_profile_dir(), MAC_SESSION_FILE)

def _category_nav_cache_path():
    return os.path.join(_addon_profile_dir(), CATEGORY_NAV_CACHE_FILE)

def _macsimum_favorites_path():
    return os.path.join(_addon_profile_dir(), MACSIMUM_FAVORITES_FILE)

def _load_mac_state():
    try:
        with open(_mac_state_path(), "r", encoding="utf-8") as fh:
            state = json.load(fh)
            return state if isinstance(state, dict) else {}
    except Exception:
        return {}

def _save_mac_state(state):
    try:
        with open(_mac_state_path(), "w", encoding="utf-8") as fh:
            json.dump(state, fh, ensure_ascii=True, indent=2, sort_keys=True)
    except Exception as exc:
        _log("Could not save MAC session state: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _cooldown_remaining():
    state = _load_mac_state()
    try:
        until = float(state.get("cooldown_until", 0))
    except Exception:
        until = 0
    remaining = int(until - time.time())
    return remaining if remaining > 0 else 0

def _set_rate_limit_cooldown(reason=""):
    state = _load_mac_state()
    state["cooldown_until"] = time.time() + RATE_LIMIT_COOLDOWN
    _save_mac_state(state)
    _log("Portal rate limit cooldown active for %d seconds%s" % (RATE_LIMIT_COOLDOWN, (": " + reason) if reason else ""), xbmc.LOGWARNING if xbmc else None)

def _set_portal_timeout_cooldown(reason="", seconds=None):
    # Ein einzelner Portal-/Netzwerk-Timeout darf nicht alle Sender global
    # sperren. Der globale Cooldown bleibt ausschliesslich echten HTTP-429-
    # Rate-Limits vorbehalten. Gegen Doppelklicks schuetzt stattdessen der
    # senderbezogene Vier-Sekunden-Guard weiter unten.
    _log(
        "Portal timeout observed; global cooldown disabled%s" % (
            (": " + _redact_macs_in_text(reason)) if reason else ""
        ),
        xbmc.LOGWARNING if xbmc else None,
    )

def _live_same_channel_guard(label, cmd):
    """Block only a repeated click on the identical channel for four seconds."""
    try:
        key_source = "%s\n%s" % (str(label or "").strip().lower(), str(cmd or "").strip())
        key = hashlib.sha1(key_source.encode("utf-8", "ignore")).hexdigest()
        now = time.time()
        state = _load_mac_state()
        previous_key = str(state.get("live_channel_guard_key", "") or "")
        try:
            previous_until = float(state.get("live_channel_guard_until", 0) or 0)
        except Exception:
            previous_until = 0.0
        if previous_key == key and previous_until > now:
            return True, max(1, int(previous_until - now + 0.999))
        state["live_channel_guard_key"] = key
        state["live_channel_guard_until"] = now + LIVE_SAME_CHANNEL_GUARD_SECONDS
        _save_mac_state(state)
        return False, 0
    except Exception as exc:
        _log("Live same-channel guard failed open: %s" % exc, xbmc.LOGWARNING if xbmc else None)
        return False, 0

def _normalize_mac(mac):
    if not isinstance(mac, str):
        return ""
    match = re.search(r"(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b", mac)
    return match.group(0).upper() if match else ""

def _redact_mac(mac):
    mac = _normalize_mac(mac)
    return "****" + mac[-5:] if mac else "<none>"

def _redact_macs_in_text(text):
    try:
        return re.sub(
            r"(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b",
            lambda match: "****" + match.group(0).upper()[-5:],
            str(text or ""),
        )
    except Exception:
        return str(text or "")

def _mac_analytics_log(event, before="", after="", reason=""):
    try:
        current = ""
        try:
            current = _current_module_mac()
        except Exception:
            current = _CURRENT_REQUEST_MAC or ""
        _log(
            "[CODEX-MAC-ANALYTICS][Portal1/addon] %s reason=%s before=%s after=%s current=%s" % (
                event,
                reason or "-",
                _redact_mac(before),
                _redact_mac(after),
                _redact_mac(current),
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
    except Exception:
        pass

def _extract_mac_from_text(text):
    if isinstance(text, bytes):
        try:
            text = text.decode("utf-8", "ignore")
        except Exception:
            text = ""
    return _normalize_mac(text or "")

def _extract_mac_from_headers(headers):
    try:
        items = headers.items()
    except Exception:
        return ""
    for key, value in items:
        if str(key).lower() == "cookie":
            return _extract_mac_from_text(value)
    return ""

def _mac_scope_from_query(action="", query=None):
    action = (action or "").strip().lower()
    query = query or {}
    if action == "codex_macsimum_handshake":
        scope = ((query.get("scope") or ["root"])[0] or "").strip().lower()
        if scope in ("live", "tv", "livetv"):
            return "live"
        if scope in ("series", "serien"):
            return "series"
        return "vod"
    if action in ("tv", "live", "tv_listing", "codex_macsimum_bridge_play",
                  "codex_macsimum_scope_scan", "codex_macsimum_all_scan",
                  "codex_macsimum_gap_scan", "codex_macsimum_missing_m3u_repair"):
        return "live"
    if action in ("series", "ser_listing", "seasons", "season", "episodes",
                  "episode", "codex_macsimum_episode_play", "search_series"):
        return "series"
    if action in ("vod", "listing", "search", "play", "create_link",
                  "codex_macsimum_vod_play", "nova_trailer_choice"):
        return "vod"
    return ""

def _current_mac_scope():
    try:
        qs = urllib.parse.parse_qs((sys.argv[2] or "").lstrip("?"))
        action = ((qs.get("action") or [""])[0] or "").strip().lower()
        return _mac_scope_from_query(action, qs)
    except Exception:
        return ""

def _normalize_mac_scope(scope):
    scope = (scope or "").strip().lower()
    if scope in ("favorites", "favourites", "favoriten"):
        return "vod"
    if scope in ("tv", "livetv"):
        return "live"
    if scope in ("serien",):
        return "series"
    if scope in ("vod", "series", "live"):
        return scope
    return ""

def _mac_state_current_tuple(state):
    if not isinstance(state, dict):
        return "", 0.0, ""
    mac = _normalize_mac(state.get("current_mac", ""))
    scope = _normalize_mac_scope(state.get("current_scope", ""))
    try:
        at = float(state.get("current_at", 0) or 0)
    except Exception:
        at = 0.0
    return mac, at, scope

def _mac_state_verified_scopes(state):
    scopes = {}
    if isinstance(state, dict):
        raw = state.get("verified_scopes")
        if isinstance(raw, dict):
            for raw_scope, raw_entry in raw.items():
                scope = _normalize_mac_scope(raw_scope)
                if not scope:
                    continue
                if isinstance(raw_entry, dict):
                    mac = _normalize_mac(raw_entry.get("mac", "") or raw_entry.get("current_mac", ""))
                    try:
                        at = float(raw_entry.get("at", raw_entry.get("current_at", 0)) or 0)
                    except Exception:
                        at = 0.0
                else:
                    mac = _normalize_mac(str(raw_entry or ""))
                    at = 0.0
                if mac and at:
                    scopes[scope] = {"mac": mac, "at": at}
        current, current_at, current_scope = _mac_state_current_tuple(state)
        if current and current_at and current_scope and current_scope not in scopes:
            scopes[current_scope] = {"mac": current, "at": current_at}
    return scopes

def _mac_state_scope_failure_matches(state, scope, mac):
    scope = _normalize_mac_scope(scope)
    mac = _normalize_mac(mac)
    if not scope or not mac or not isinstance(state, dict):
        return False
    raw = state.get("scope_failures")
    if not isinstance(raw, dict):
        return False
    entry = raw.get(scope)
    if not isinstance(entry, dict):
        return False
    return _normalize_mac(entry.get("mac", "")) == mac

def _mac_state_set_scope_failure(state, scope, mac):
    scope = _normalize_mac_scope(scope)
    mac = _normalize_mac(mac)
    if not scope or not mac or not isinstance(state, dict):
        return False
    raw = state.get("scope_failures")
    if not isinstance(raw, dict):
        raw = {}
    raw[scope] = {"mac": mac, "at": time.time()}
    state["scope_failures"] = raw
    return True

def _mac_state_clear_scope_failure(state, scope=None, mac=None):
    if not isinstance(state, dict):
        return False
    raw = state.get("scope_failures")
    if not isinstance(raw, dict):
        return False
    changed = False
    scope = _normalize_mac_scope(scope)
    mac = _normalize_mac(mac)
    if scope:
        entry = raw.get(scope)
        if entry is not None and (not mac or _normalize_mac(entry.get("mac", "") if isinstance(entry, dict) else str(entry)) == mac):
            raw.pop(scope, None)
            changed = True
    elif mac:
        for key in list(raw.keys()):
            entry = raw.get(key)
            entry_mac = _normalize_mac(entry.get("mac", "") if isinstance(entry, dict) else str(entry))
            if entry_mac == mac:
                raw.pop(key, None)
                changed = True
    else:
        raw.clear()
        changed = True
    if raw:
        state["scope_failures"] = raw
    else:
        state.pop("scope_failures", None)
    return changed

def _mac_state_latest_scope(scopes):
    best_scope = ""
    best_mac = ""
    best_at = 0.0
    for scope, entry in (scopes or {}).items():
        try:
            at = float(entry.get("at", 0) or 0)
        except Exception:
            at = 0.0
        mac = _normalize_mac(entry.get("mac", ""))
        if mac and at and at >= best_at:
            best_scope, best_mac, best_at = scope, mac, at
    return best_mac, best_at, best_scope

def _mac_state_write_current(state, mac, at=None, scope=None):
    mac = _normalize_mac(mac)
    if not mac or not isinstance(state, dict):
        return False
    state["current_mac"] = mac
    state["current_at"] = float(at or time.time())
    scope = _normalize_mac_scope(scope)
    if scope:
        state["current_scope"] = scope
    else:
        state.pop("current_scope", None)
    return True

def _clear_current_mac_from_state(reason="", scope=None, hard=False):
    try:
        state = _load_mac_state()
        removed, _removed_at, removed_scope = _mac_state_current_tuple(state)
        requested_scope = _normalize_mac_scope(scope or _current_mac_scope())
        if not requested_scope:
            requested_scope = removed_scope
        if not hard:
            # Die MAC ist benutzerverwaltet: Ein normaler Fehler darf die
            # gespeicherte, zuvor verifizierte MAC nicht stillschweigend
            # verwerfen. Rotation/Loeschung erfolgt nur durch den expliziten
            # manuellen Handshake, der seinen Reset direkt ausfuehrt.
            _mac_analytics_log(
                "session-mac-preserved",
                after=removed,
                reason="automatic clear suppressed: %s scope=%s" % (reason, requested_scope or "-"),
            )
            return
        changed = False
        if hard or not requested_scope:
            for key in ("current_mac", "current_at", "current_scope", "verified_scopes", "scope_failures"):
                if key in state:
                    state.pop(key, None)
                    changed = True
        else:
            scopes = _mac_state_verified_scopes(state)
            if requested_scope in scopes:
                scopes.pop(requested_scope, None)
                changed = True
            if removed:
                changed = _mac_state_set_scope_failure(state, requested_scope, removed) or changed
            if scopes:
                state["verified_scopes"] = scopes
                latest_mac, latest_at, latest_scope = _mac_state_latest_scope(scopes)
                if latest_mac:
                    changed = _mac_state_write_current(state, latest_mac, latest_at, latest_scope) or changed
            else:
                state.pop("verified_scopes", None)
                for key in ("current_mac", "current_at", "current_scope"):
                    if key in state:
                        state.pop(key, None)
                        changed = True
        if changed:
            _save_mac_state(state)
        _mac_analytics_log("session-mac-cleared", before=removed, reason="%s scope=%s hard=%s" % (reason, requested_scope or "-", "1" if hard else "0"))
    except Exception as exc:
        _mac_analytics_log("session-mac-clear-error", reason="%s: %s" % (reason, exc))

def _preferred_mac_from_state():
    try:
        qs = urllib.parse.parse_qs((sys.argv[2] or "").lstrip("?"))
        action = ((qs.get("action") or [""])[0] or "").strip().lower()
        invocation_mac = _normalize_mac((qs.get("source_mac") or qs.get("choice_source_mac") or [""])[0])
        from_favorites = (
            (qs.get("from_favorites") or qs.get("choice_from_favorites") or [""])[0]
            .strip()
            .lower()
            in ("1", "true", "yes")
        )
        if from_favorites and invocation_mac:
            fav_state = _load_mac_state()
            fav_scopes = _mac_state_verified_scopes(fav_state)
            fav_entry = fav_scopes.get("vod") or {}
            fav_current = _normalize_mac(fav_entry.get("mac", ""))
            fav_current_at = float(fav_entry.get("at", 0) or 0)
            if fav_current and fav_current_at:
                _mac_analytics_log(
                    "session-favorite-current-overrides-one-shot",
                    before=invocation_mac,
                    after=fav_current,
                    reason="favorite uses fresh current session",
                )
                return fav_current
            fav_current, fav_current_at, fav_scope = _mac_state_current_tuple(fav_state)
            if fav_current and fav_current_at:
                _mac_analytics_log(
                    "session-favorite-latest-current-overrides-one-shot",
                    before=invocation_mac,
                    after=fav_current,
                    reason="favorite ignores stored source_mac and uses current scope=%s" % (fav_scope or "-"),
                )
                return fav_current
            latest_mac, latest_at, latest_scope = _mac_state_latest_scope(fav_scopes)
            if latest_mac and latest_at:
                _mac_analytics_log(
                    "session-favorite-latest-verified-overrides-one-shot",
                    before=invocation_mac,
                    after=latest_mac,
                    reason="favorite ignores stored source_mac and uses latest verified scope=%s" % (latest_scope or "-"),
                )
                return latest_mac
            _mac_analytics_log(
                "session-favorite-stale-one-shot-ignored",
                before=invocation_mac,
                reason="favorite has no fresh current session",
            )
            invocation_mac = ""
        if invocation_mac and action in ("episodes", "episode", "codex_macsimum_vod_play", "codex_macsimum_episode_play"):
            playback_state = _load_mac_state()
            wanted_scope = "series" if action in ("episodes", "episode", "codex_macsimum_episode_play") else "vod"
            playback_scopes = _mac_state_verified_scopes(playback_state)
            playback_entry = playback_scopes.get(wanted_scope) or {}
            playback_current = _normalize_mac(playback_entry.get("mac", ""))
            playback_current_at = float(playback_entry.get("at", 0) or 0)
            if (
                playback_current
                and playback_current_at
                and playback_current != invocation_mac
            ):
                _mac_analytics_log(
                    "session-playback-current-overrides-one-shot",
                    before=invocation_mac,
                    after=playback_current,
                    reason="action=%s uses fresh current session" % action,
                )
                return playback_current
        if invocation_mac:
            _mac_analytics_log("session-mac-one-shot", after=invocation_mac, reason="plugin-url")
            return invocation_mac
    except Exception:
        pass
    state = _load_mac_state()
    changed = False
    current, current_at, current_scope = _mac_state_current_tuple(state)
    requested_scope = _normalize_mac_scope(_current_mac_scope())
    verified_scopes = _mac_state_verified_scopes(state)
    if requested_scope:
        entry = verified_scopes.get(requested_scope) or {}
        scope_mac = _normalize_mac(entry.get("mac", ""))
        try:
            scope_at = float(entry.get("at", 0) or 0)
        except Exception:
            scope_at = 0.0
        if scope_mac and scope_at:
            if scope_mac != current or current_scope != requested_scope:
                _mac_state_write_current(state, scope_mac, scope_at, requested_scope)
                state["verified_scopes"] = verified_scopes
                changed = True
            if changed:
                _save_mac_state(state)
            _mac_analytics_log("session-current-reuse", after=scope_mac, reason="verified-scope-session scope=%s" % requested_scope)
            return scope_mac
    if current and current_at:
        if requested_scope and current_scope != requested_scope:
            if _mac_state_scope_failure_matches(state, requested_scope, current):
                _mac_analytics_log(
                    "session-current-scope-failed-skip",
                    after=current,
                    reason="wanted=%s stored=%s" % (requested_scope, current_scope or "legacy"),
                )
                return ""
            _mac_analytics_log(
                "session-current-cross-scope-tentative",
                after=current,
                reason="wanted=%s stored=%s" % (requested_scope, current_scope or "legacy"),
            )
            return current
        if changed:
            _save_mac_state(state)
        _mac_analytics_log("session-current-reuse", after=current, reason="verified-current-session scope=%s" % (current_scope or "-"))
        return current
    if current:
        for key in ("current_mac", "current_at", "current_scope"):
            if key in state:
                state.pop(key, None)
                changed = True
        _mac_analytics_log("session-current-invalid-cleared", before=current, reason="missing verification timestamp")
    if changed:
        _save_mac_state(state)
    return ""

def _remember_current_mac(mac, scope=None):
    mac = _normalize_mac(mac)
    if not mac:
        return
    try:
        scope = _normalize_mac_scope(scope or _current_mac_scope())
        now = time.time()
        state = _load_mac_state()
        scopes = _mac_state_verified_scopes(state)
        if scope:
            scopes[scope] = {"mac": mac, "at": now}
            state["verified_scopes"] = scopes
            _mac_state_clear_scope_failure(state, scope=scope, mac=mac)
        _mac_state_write_current(state, mac, now, scope)
        if scope:
            state["current_scope"] = scope
        else:
            state.pop("current_scope", None)
        _save_mac_state(state)
        _mac_analytics_log("session-current-saved-short", after=mac, reason="successful portal auth/warmup scope=%s verified_scopes=%s" % (scope or "-", ",".join(sorted(scopes.keys())) if scopes else "-"))
    except Exception as exc:
        _mac_analytics_log("session-current-save-error", after=mac, reason=str(exc))

def _current_error_reason(exc):
    name = exc.__class__.__name__.lower()
    text = str(exc).lower()
    try:
        if isinstance(exc, urllib.error.HTTPError):
            code = getattr(exc, "code", None)
            if code == 429:
                return "rate_limit"
            if code == 512:
                return "portal_response"
    except Exception:
        pass
    if "too many requests" in text or "http error 429" in text:
        return "rate_limit"
    if (
        "connecttimeout" in name or
        "readtimeout" in name or
        "timeout" in name or
        "timed out" in text or
        "read timed out" in text or
        "connect timeout" in text or
        "max retries exceeded" in text
    ):
        return "portal_timeout"
    if (
        "jsondecodeerror" in name or
        "expecting value" in text or
        "http error 512" in text or
        "http 512" in text or
        "nonetype" in text or
        "object is not iterable" in text or
        "urlerror" in name
    ):
        return "portal_response"
    return ""

def _replace_mac_in_text(text, mac):
    mac = _normalize_mac(mac)
    if not mac or not isinstance(text, str):
        return text
    return re.sub(r"(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b", mac, text)

def _is_portal_request_url(url):
    if not isinstance(url, str):
        return False
    lowered = url.lower()
    return "portal.php" in lowered or "stalker_portal" in lowered

def _cookie_for_mac(cookie, mac):
    mac = _normalize_mac(mac)
    if not mac:
        return cookie
    cookie = cookie if isinstance(cookie, str) else ""
    if re.search(r"(?i)\bmac\s*=", cookie):
        return _replace_mac_in_text(cookie, mac)
    prefix = "mac=%s; stb_lang=de; timezone=Europe/Berlin" % mac
    return prefix + (("; " + cookie.lstrip("; ")) if cookie else "")

def _set_request_header(req, key, value):
    try:
        req.add_header(key, value)
    except Exception:
        pass
    for store_name in ("headers", "unredirected_hdrs"):
        try:
            store = getattr(req, store_name)
            for existing in list(store.keys()):
                if str(existing).lower() == key.lower():
                    store[existing] = value
        except Exception:
            pass

def _apply_mac_to_urllib_request(req, pinned_mac, url=""):
    global _CURRENT_REQUEST_MAC
    request_mac = ""
    try:
        headers = getattr(req, "headers", {}) or {}
        unredirected = getattr(req, "unredirected_hdrs", {}) or {}
        request_mac = _extract_mac_from_headers(headers) or _extract_mac_from_headers(unredirected)
        if pinned_mac:
            saw_cookie = False
            for key, value in list(headers.items()) + list(unredirected.items()):
                if str(key).lower() == "cookie":
                    saw_cookie = True
                    _set_request_header(req, key, _cookie_for_mac(value, pinned_mac))
                    request_mac = pinned_mac
            if not saw_cookie and _is_portal_request_url(url):
                _set_request_header(req, "Cookie", _cookie_for_mac("", pinned_mac))
                request_mac = pinned_mac
            try:
                data = getattr(req, "data", None)
                if isinstance(data, bytes):
                    replaced = _replace_mac_in_text(data.decode("utf-8", "ignore"), pinned_mac).encode("utf-8")
                    req.data = replaced
            except Exception:
                pass
    except Exception:
        pass
    _CURRENT_REQUEST_MAC = _normalize_mac(pinned_mac or request_mac)
    return req

def _current_module_token():
    for _module_name, module in list(sys.modules.items()):
        if module is None:
            continue
        try:
            portal = getattr(module, "stalker_portal", None)
            token = getattr(portal, "token", "") if portal is not None else ""
            if token:
                return str(token)
        except Exception:
            pass
    return ""

def _action_needs_portal_token(action=None):
    action = (action or _current_plugin_action() or "").strip().lower()
    return action in (
        "vod", "series", "listing", "ser_listing", "search", "search_series",
        "tv", "live", "tv_listing",
        "seasons", "season", "episodes", "episode", "play", "create_link",
        "codex_macsimum_vod_play", "codex_macsimum_episode_play",
        "codex_macsimum_bridge_play", "codex_macsimum_handshake",
        "codex_macsimum_scope_scan", "codex_macsimum_all_scan", "codex_macsimum_gap_scan",
        "codex_macsimum_missing_m3u_repair",
    )

def _prepare_usable_impl():
    pinned_mac = _preferred_mac_from_state()
    _mac_analytics_log("prepare-usable-start", after=pinned_mac, reason="preferred-state")
    action = _current_plugin_action()
    if pinned_mac:
        mod = _impl()
        _apply_session_mac_to_modules()
        if _action_needs_portal_token(action) and not _current_module_token():
            last_initial_error = getattr(mod, "_codex_last_initial_error", None)
            if last_initial_error is not None and _current_error_reason(last_initial_error) == "portal_timeout":
                # A temporary portal/network timeout is not proof that a MAC
                # which was already verified for this scope has become bad.
                # Keep the verified session in mac_session.json so the next
                # sender can immediately retry the same good MAC. There is no
                # global timeout cooldown; only identical rapid double-clicks
                # are guarded at the bridge entry point.
                _mac_analytics_log(
                    "prepare-usable-tokenless-timeout-preserve",
                    after=pinned_mac,
                    reason=action or "-",
                )
                _reset_impl_for_retry()
                return None, pinned_mac
            _mac_analytics_log("prepare-usable-tokenless-one-shot-failed", after=pinned_mac, reason=action or "-")
            _clear_current_mac_from_state("tokenless one-shot failed without reload: %s" % (action or "-"))
            _reset_impl_for_retry()
            return None, pinned_mac
        _mac_analytics_log("prepare-usable-pinned", after=pinned_mac)
        return mod, pinned_mac

    mod = _impl()
    if _action_needs_portal_token(action) and not _current_module_token():
        before = _current_module_mac()
        if action in ("codex_macsimum_bridge_play", "codex_macsimum_handshake"):
            # Live-TV-3 wird pro Kanal als einzelne Plugin-URL gestartet.
            # Wenn die erste Authentifizierung schon keinen vollwertigen Token
            # liefert, darf dieser Fehler nicht sofort eine zweite MAC/Handshake-
            # Kette ausloesen. Sonst verliert das Portal nach einem defekten
            # Sender sehr schnell den Zugang fuer Filme/Serien.
            last_initial_error = getattr(mod, "_codex_last_initial_error", None)
            if last_initial_error is not None and _current_error_reason(last_initial_error) == "portal_timeout":
                _set_portal_timeout_cooldown("%s initial auth timeout: %s" % (action or "portal", last_initial_error))
            event_name = "prepare-usable-bridge-tokenless-abort" if action == "codex_macsimum_bridge_play" else "prepare-usable-handshake-tokenless-abort"
            _mac_analytics_log(event_name, before=before, reason=action or "-")
            _clear_current_mac_from_state("tokenless abort: %s" % (action or "-"))
            _reset_impl_for_retry()
            return None, ""
        _mac_analytics_log("prepare-usable-tokenless-reload-once", before=before, reason=action or "-")
        last_initial_error = getattr(mod, "_codex_last_initial_error", None)
        if last_initial_error is not None and _current_error_reason(last_initial_error) == "portal_timeout":
            _set_portal_timeout_cooldown("%s initial auth timeout: %s" % (action or "portal", last_initial_error))
        _clear_current_mac_from_state("tokenless reload once: %s" % (action or "-"))
        _reset_impl_for_retry()
        retry_mod = _impl()
        if _action_needs_portal_token(action) and not _current_module_token():
            retry_before = _current_module_mac()
            _mac_analytics_log("prepare-usable-tokenless-reload-failed", before=retry_before, reason=action or "-")
            _clear_current_mac_from_state("tokenless reload failed: %s" % (action or "-"))
            _reset_impl_for_retry()
            return None, ""
        retry_current = _current_module_mac()
        if retry_current:
            try:
                _remember_current_mac(retry_current)
            except Exception:
                pass
        _mac_analytics_log("prepare-usable-tokenless-reload-ok", after=retry_current, reason=action or "-")
        return retry_mod, ""
    elif not _current_module_token() and _current_module_mac():
        # Eine beim Modulimport fehlgeschlagene Auth darf nicht als aktuelle
        # Session weiterlaufen. Root darf trotzdem das statische Startmenue
        # zeigen; erst echte Portalbereiche wie Filme/Serien/Live TV brechen
        # ohne Token sauber ab.
        before = _current_module_mac()
        _mac_analytics_log("prepare-usable-tokenless-current-cleared", before=before, reason=action or "root")
        _clear_current_mac_from_state("tokenless current after import: %s" % (action or "root"))
        if action:
            _reset_impl_for_retry()
            return None, ""
        _mac_analytics_log("prepare-usable-tokenless-root-menu", before=before, reason="root")
        return mod, ""
    try:
        current_mac = _current_module_mac()
        if _current_module_token() and current_mac:
            # Root/Auth allein reicht beim Portal nicht als Stabilitaetsbeweis:
            # einzelne MACs liefern zwar einen Token, geben danach aber fuer
            # VOD/Serien leere Kategorien zurueck. Deshalb erst nach einem
            # erfolgreichen Bereichs-Warm-up oder einer echten Liste pinnen.
            _mac_analytics_log("prepare-usable-current-tentative", after=current_mac, reason=action or "root")
    except Exception as remember_exc:
        _mac_analytics_log("prepare-usable-current-tentative-error", reason=str(remember_exc))
    _mac_analytics_log("prepare-usable-current", after=_current_module_mac(), reason="short-current-session-tentative")
    return mod, ""

def _apply_session_mac_to_modules():
    pinned_mac = _preferred_mac_from_state()
    if not pinned_mac:
        return ""
    for _module_name, module in list(sys.modules.items()):
        if module is None or not hasattr(module, "G"):
            continue
        G = getattr(module, "G", None)
        portal_config = getattr(G, "portal_config", None) if G is not None else None
        if portal_config is None:
            continue
        try:
            portal_config.mac = pinned_mac
        except Exception:
            pass
        try:
            portal_config.mac_cookie = _replace_mac_in_text(getattr(portal_config, "mac_cookie", "") or ("mac=" + pinned_mac), pinned_mac)
        except Exception:
            pass
    return pinned_mac

def _current_module_mac():
    for _module_name, module in list(sys.modules.items()):
        if module is None or not hasattr(module, "G"):
            continue
        G = getattr(module, "G", None)
        portal_config = getattr(G, "portal_config", None) if G is not None else None
        mac = _normalize_mac(getattr(portal_config, "mac", "")) if portal_config is not None else ""
        if mac:
            return mac
    return _CURRENT_REQUEST_MAC or ""

def _current_plugin_action():
    return _get_action(_current_plugin_url())

def _content_for_action(action=None):
    action = (action or _current_plugin_action() or "").strip().lower()
    if action in ("search",):
        return "movies"
    if action in ("ser_listing",):
        return "tvshows"
    if action in ("seasons", "season"):
        return "seasons"
    if action in ("episodes", "episode", "play_episode", "epiplay"):
        return "episodes"
    return ""

def _media_type_for_action(action=None):
    content = _content_for_action(action)
    if content == "movies":
        return "movie"
    if content == "tvshows":
        return "tvshow"
    if content == "seasons":
        return "season"
    if content == "episodes":
        return "episode"
    return ""

def _media_type_for_playable_action(action=None):
    action = (action or "").strip().lower()
    if action in ("play", "create_link", "vod_play", "movie", "movies"):
        return "movie"
    return ""

def _meta_has_title_identity(meta):
    if not isinstance(meta, dict):
        return False
    return bool(
        _clean_meta_value(meta.get("tmdb_id")) or
        _clean_meta_value(meta.get("imdb_id")) or
        _clean_meta_value(meta.get("plot")) or
        _clean_meta_value(meta.get("year")) or
        _format_rating_text(_first_non_empty(meta.get("tmdb_rating"), meta.get("rating"), meta.get("trakt_rating")))
    )

def _can_remember_current_mac_for_current_view(items):
    action = _current_plugin_action()
    if action not in ("vod", "series", "listing", "seasons", "episodes", "search", "ser_listing"):
        return False
    visible = 0
    labels = []
    for entry in items or []:
        try:
            url, li, _isFolder, _totalItems = entry
        except Exception:
            continue
        if _should_hide_item(url, _get_label(li), _isFolder):
            continue
        label = _get_label(li).strip()
        if label and not _is_next_page_label(label):
            visible += 1
            labels.append(label)
        if visible >= 2 and action not in ("vod", "series"):
            return True
    if action in ("vod", "series"):
        if visible < 8:
            _mac_analytics_log(
                "session-current-save-skipped-small-menu",
                after=_current_module_mac(),
                reason="action=%s visible=%d labels=%s" % (action, visible, " / ".join(labels[:8])),
            )
            return False
        if visible <= 12 and not any((value or "").lower().startswith("de") or "deutsch" in (value or "").lower() for value in labels):
            _mac_analytics_log(
                "session-current-save-skipped-no-de-menu",
                after=_current_module_mac(),
                reason="action=%s visible=%d labels=%s" % (action, visible, " / ".join(labels[:8])),
            )
            return False
        return True
    return False

def _pace(delay=None):
    global _LAST_REQUEST_TS
    if delay is None:
        delay = MIN_REQUEST_GAP
    if delay <= 0:
        _LAST_REQUEST_TS = time.time()
        return
    now = time.time()
    wait = delay - (now - _LAST_REQUEST_TS)
    if wait > 0:
        time.sleep(wait)
    _LAST_REQUEST_TS = time.time()

def _is_create_link(url):
    return isinstance(url, str) and "action=create_link" in url.lower()

def _portal_base(url):
    sp = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit((sp.scheme, sp.netloc, "/portal.php", "", ""))

def _make_url(base, q):
    return base + ("&" if "?" in base else "?") + q


def _is_tokenish_url(url):
    if not isinstance(url, str):
        return False
    lowered = url.lower()
    return (
        "portal.php" in lowered and
        (
            "action=handshake" in lowered or
            "action=get_profile" in lowered or
            "action=get_main_info" in lowered
        )
    )

def _extract_token(text):
    try:
        obj = json.loads(text)
    except Exception:
        return None
    for path in [
        ("js", "token"),
        ("js", "id"),
        ("token",),
        ("id",),
    ]:
        cur = obj
        ok = True
        for k in path:
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
            else:
                ok = False
                break
        if ok and isinstance(cur, str) and cur:
            return cur
    return None


def _clean_meta_value(value):
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def _first_non_empty(*values):
    for value in values:
        if value is None:
            continue
        if isinstance(value, (list, tuple)):
            cleaned = []
            for item in value:
                text = _clean_meta_value(item)
                if text:
                    cleaned.append(text)
            if cleaned:
                return " / ".join(cleaned)
            continue
        text = _clean_meta_value(value)
        if text:
            return text
    return ""


def _clean_search_title(title):
    text = _clean_meta_value(title)
    text = text.replace("┃", " ").replace("|", " ")
    text = re.sub(r"\[[^\]]*\]", " ", text)
    text = re.sub(r"\([^)]*\)", " ", text)
    text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
    text = re.sub(r"\b(?:1080p?|720p?|2160p?|4k|uhd|fhd|hd|hq|sd|german|deutsch|multi|sub|dub|stream|online|neu|new)\b", " ", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _title_lookup_variants(title):
    raw = _clean_meta_value(title)
    variants = []
    for value in (
        raw,
        raw.replace("┃", " ").replace("|", " "),
        _clean_choice_title(raw),
        _clean_search_title(raw),
    ):
        value = _clean_meta_value(value)
        if value and value not in variants:
            variants.append(value)
    return variants


def _extract_year_text(value):
    text = _clean_meta_value(value)
    match = re.search(r"(19|20)\d{2}", text)
    if not match:
        return ""
    return match.group(0)


def _parse_rating_float(value):
    text = _clean_meta_value(value).replace(",", ".")
    match = re.search(r"\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except Exception:
        return None


def _format_rating_text(value):
    rating_value = _parse_rating_float(value)
    if rating_value is None:
        return ""
    return "%.1f" % rating_value


def _parse_votes_int(value):
    text = _clean_meta_value(value).replace(".", "").replace(",", "")
    match = re.search(r"\d+", text)
    if not match:
        return None
    try:
        return int(match.group(0))
    except Exception:
        return None


def _tmdb_request(endpoint, params):
    query = urllib.parse.urlencode(params)
    url = "https://api.themoviedb.org/3/%s?%s" % (endpoint, query)
    request = urllib.request.Request(url, headers={"User-Agent": "Kodi-Stalker-Metadata/1.0"})
    with urllib.request.urlopen(request, timeout=4) as response:
        return json.loads(response.read().decode("utf-8"))


def _tmdb_lookup(title, year="", media_type="", force=False):
    global _TMDB_LOOKUP_COUNT

    if _TMDB_LOOKUP_LIMIT <= 0 and not force:
        return {}

    clean_year = _extract_year_text(year) or _extract_year_text(title)
    clean_title = _clean_search_title(title)
    media_hint = _clean_meta_value(media_type).lower()
    if not clean_title:
        return {}

    cache_key = (clean_title.lower(), clean_year, media_hint)
    if cache_key in _TMDB_CACHE:
        return _TMDB_CACHE[cache_key]
    if _TMDB_LOOKUP_COUNT >= _TMDB_LOOKUP_LIMIT and not force:
        return {}

    if not force:
        _TMDB_LOOKUP_COUNT += 1

    if media_hint in ("tvshow", "season", "episode", "tv"):
        searches = [
            ("search/tv", {"query": clean_title, "language": "de-DE", "include_adult": "false", "api_key": _TMDB_API_KEY}),
            ("search/movie", {"query": clean_title, "language": "de-DE", "include_adult": "false", "api_key": _TMDB_API_KEY}),
        ]
    else:
        searches = [
            ("search/movie", {"query": clean_title, "language": "de-DE", "include_adult": "false", "api_key": _TMDB_API_KEY}),
            ("search/tv", {"query": clean_title, "language": "de-DE", "include_adult": "false", "api_key": _TMDB_API_KEY}),
        ]

    if clean_year:
        updated = []
        for endpoint, params in searches:
            params = dict(params)
            if endpoint == "search/movie":
                params["year"] = clean_year
            else:
                params["first_air_date_year"] = clean_year
            updated.append((endpoint, params))
        searches = updated

    meta = {}
    for endpoint, params in searches:
        try:
            data = _tmdb_request(endpoint, params)
        except Exception:
            continue
        for result in data.get("results") or []:
            rating = result.get("vote_average")
            votes = result.get("vote_count")
            if rating in (None, "", 0, 0.0) and votes in (None, "", 0, 0.0):
                continue
            release_date = result.get("release_date") or result.get("first_air_date") or ""
            meta = {
                "rating": _format_rating_text(rating),
                "votes": _clean_meta_value(votes),
                "year": _extract_year_text(release_date) or clean_year,
                "tmdb_id": _clean_meta_value(result.get("id")),
                "plot": _clean_meta_value(result.get("overview")),
                "genre": " / ".join(
                    _TMDB_GENRES.get(gid, "")
                    for gid in (result.get("genre_ids") or [])
                    if _TMDB_GENRES.get(gid, "")
                ),
                "tmdb_type": "tv" if endpoint == "search/tv" else "movie",
            }
            break
        if meta:
            break

    if force and meta.get("tmdb_id"):
        meta = _tmdb_enrich_details(meta)

    _TMDB_CACHE[cache_key] = meta
    return meta


def _format_money(value):
    try:
        amount = int(value or 0)
    except Exception:
        amount = 0
    if amount <= 0:
        return ""
    return "{:,} $".format(amount).replace(",", ".")


def _tmdb_enrich_details(meta):
    tmdb_id = _clean_meta_value(meta.get("tmdb_id"))
    tmdb_type = meta.get("tmdb_type") or "movie"
    if not tmdb_id:
        return meta
    try:
        details = _tmdb_request(
            "%s/%s" % (tmdb_type, tmdb_id),
            {
                "language": "de-DE",
                "api_key": _TMDB_API_KEY,
                "append_to_response": "external_ids,credits,videos,content_ratings,release_dates",
            },
        )
    except Exception:
        return meta
    if not details:
        return meta

    enriched = dict(meta)
    release_date = details.get("release_date") or details.get("first_air_date") or ""
    genres = details.get("genres") or []
    director = []
    writer = []
    cast = []
    for person in ((details.get("credits") or {}).get("crew") or []):
        name = person.get("name") or ""
        job = person.get("job") or ""
        department = person.get("department") or ""
        if not name:
            continue
        if job == "Director" and name not in director:
            director.append(name)
        elif department == "Writing" and name not in writer:
            writer.append("%s: %s" % (job, name) if job else name)
    for person in ((details.get("credits") or {}).get("cast") or [])[:20]:
        name = person.get("name") or ""
        role = person.get("character") or ""
        image = ""
        if person.get("profile_path"):
            image = "https://image.tmdb.org/t/p/w300%s" % person.get("profile_path")
        if name:
            cast.append((name, role, image))

    runtime = details.get("runtime")
    if not runtime and details.get("episode_run_time"):
        try:
            runtime = details.get("episode_run_time")[0]
        except Exception:
            runtime = ""

    enriched.update({
        "title": _clean_meta_value(details.get("title") or details.get("name") or meta.get("title")),
        "plot": _first_non_empty(details.get("overview"), meta.get("plot")),
        "rating": _format_rating_text(_first_non_empty(details.get("vote_average"), meta.get("rating"))),
        "votes": _clean_meta_value(_first_non_empty(details.get("vote_count"), meta.get("votes"))),
        "year": _extract_year_text(release_date) or meta.get("year", ""),
        "premiered": _clean_meta_value(release_date),
        "genre": " / ".join(g.get("name", "") for g in genres if g.get("name")) or meta.get("genre", ""),
        "imdb_id": _clean_meta_value((details.get("external_ids") or {}).get("imdb_id") or details.get("imdb_id")),
        "director": " / ".join(director),
        "writer": " / ".join(writer),
        "runtime": _clean_meta_value(runtime),
        "budget": _format_money(details.get("budget")),
        "revenue": _format_money(details.get("revenue")),
        "poster": "https://image.tmdb.org/t/p/w185%s" % details.get("poster_path") if details.get("poster_path") else "",
        "fanart": "https://image.tmdb.org/t/p/w300%s" % details.get("backdrop_path") if details.get("backdrop_path") else "",
        "cast": cast,
    })
    return enriched


def _build_rating_line(rating="", votes="", year="", genre=""):
    parts = []
    rating_text = _format_rating_text(rating)
    if rating_text:
        parts.append("Bewertung: %s" % rating_text)

    votes_value = _parse_votes_int(votes)
    if votes_value:
        parts.append("Stimmen: %s" % votes_value)

    year_text = _extract_year_text(year) or _clean_meta_value(year)
    if year_text:
        parts.append(year_text)

    genre_text = _clean_meta_value(genre)
    if genre_text:
        parts.append(genre_text)

    return " | ".join(parts)


def _build_meta_plot(plot="", year="", genre="", rating="", votes=""):
    plot_text = _clean_meta_value(plot)
    rating_line = _build_rating_line(rating=rating, votes=votes, year=year, genre=genre)
    if not rating_line:
        return plot_text

    colored_line = "[COLOR blue]%s[/COLOR]" % rating_line
    if colored_line in plot_text or rating_line in plot_text:
        return plot_text
    if plot_text:
        return "%s[CR]%s" % (colored_line, plot_text)
    return colored_line


def _looks_like_media_item(item):
    if not isinstance(item, dict):
        return False
    media_keys = (
        "name", "title", "description", "plot", "genres_str", "genre", "year",
        "rating_imdb", "vote_average", "tmdb_rating", "TMDb_Rating",
        "rating_trakt", "trakt_rating", "Trakt_Rating",
        "tmdb", "tmdb_id", "tmdbid", "imdb_id",
        "screenshot_uri", "logo", "poster", "cmd", "category_id", "series"
    )
    return any(key in item for key in media_keys)


def _build_media_meta_keys(title="", year="", media_type=""):
    clean_year = _extract_year_text(year)
    media_hint = _clean_meta_value(media_type).lower()
    keys = []
    for clean_title in _title_lookup_variants(title):
        lowered = _clean_search_title(clean_title).lower()
        if not lowered:
            continue
        for key in (
            "%s|%s|%s" % (lowered, clean_year, media_hint) if clean_year and media_hint else "",
            "%s|%s" % (lowered, clean_year) if clean_year else "",
            "%s||%s" % (lowered, media_hint) if media_hint else "",
            lowered,
        ):
            if key and key not in keys:
                keys.append(key)
    return keys


def _remember_media_meta(title="", year="", media_type="", rating="", tmdb_rating="", trakt_rating="", votes="", tmdb_id="", imdb_id="", plot="", genre=""):
    meta = {
        "rating": _format_rating_text(rating),
        "tmdb_rating": _format_rating_text(tmdb_rating),
        "trakt_rating": _format_rating_text(trakt_rating),
        "votes": _clean_meta_value(votes),
        "tmdb_id": _clean_meta_value(tmdb_id),
        "imdb_id": _clean_meta_value(imdb_id),
        "year": _extract_year_text(year) or _clean_meta_value(year),
        "plot": _clean_meta_value(plot),
        "genre": _clean_meta_value(genre),
        "media_type": _clean_meta_value(media_type).lower(),
    }
    for key in _build_media_meta_keys(title=title, year=year, media_type=media_type):
        _MEDIA_META[key] = dict(meta)
    tmdb_id_text = meta.get("tmdb_id")
    if tmdb_id_text:
        _MEDIA_META["tmdb:%s" % tmdb_id_text] = dict(meta)


def _meta_keys_from_url(url):
    if not isinstance(url, str):
        return []
    try:
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    except Exception:
        return []

    keys = []
    for name in ("title", "name", "movie", "show", "label"):
        for value in query.get(name) or []:
            keys.extend(_build_media_meta_keys(title=value))
    for name in ("tmdb", "tmdb_id", "tmdbid"):
        for value in query.get(name) or []:
            tmdb_id = _clean_meta_value(value)
            if tmdb_id:
                keys.append("tmdb:%s" % tmdb_id)
    return keys


def _find_media_meta(listitem, url=""):
    keys = []
    label = _get_label(listitem)
    keys.extend(_build_media_meta_keys(title=label))
    try:
        tag_title = listitem.getVideoInfoTag().getTitle()
        if tag_title:
            keys.extend(_build_media_meta_keys(title=tag_title, year=_get_year(listitem)))
    except Exception:
        pass
    for prop in ("title", "name", "Title", "Name", "originaltitle"):
        try:
            value = listitem.getProperty(prop)
            if value:
                keys.extend(_build_media_meta_keys(title=value, year=_get_year(listitem)))
        except Exception:
            pass
    keys.extend(_meta_keys_from_url(url))
    seen = set()
    for key in keys:
        if not key or key in seen:
            continue
        seen.add(key)
        if key in _MEDIA_META:
            return _MEDIA_META[key]
    return None


def _apply_default_fanart(listitem):
    if listitem is None:
        return
    try:
        art = listitem.getArt() or {}
    except Exception:
        art = {}
    if not art.get("fanart"):
        art["fanart"] = DEFAULT_FANART
    if not art.get("thumb") and art.get("icon"):
        art["thumb"] = art.get("icon")
    art = _normalize_art_dict(art)
    try:
        listitem.setArt(art)
    except Exception:
        pass
    try:
        listitem.setProperty("fanart_image", DEFAULT_FANART)
    except Exception:
        pass


def _is_next_page_label(label):
    text = (label or "").lower()
    return "nächste" in text or "naechste" in text or "next" in text or "weiter" in text or ">>>" in text


def _apply_next_page_art(listitem):
    if listitem is None:
        return
    try:
        listitem.setArt({"icon": NEXT_PAGE_ART, "thumb": NEXT_PAGE_ART, "poster": NEXT_PAGE_ART, "fanart": DEFAULT_FANART})
        listitem.setProperty("fanart_image", DEFAULT_FANART)
    except Exception:
        pass


def _apply_listitem_metadata(listitem, url="", isFolder=False):
    global _META_APPLY_LOG_COUNT
    if listitem is None:
        return
    _apply_default_fanart(listitem)
    title_text = _get_label(listitem)

    meta = _find_media_meta(listitem, url=url)
    if not meta:
        return

    tmdb_rating_text = _format_rating_text(_first_non_empty(meta.get("tmdb_rating"), meta.get("rating")))
    trakt_rating_text = _format_rating_text(meta.get("trakt_rating"))
    display_rating_text = _format_rating_text(_first_non_empty(meta.get("rating"), meta.get("tmdb_rating"), meta.get("trakt_rating")))
    votes_value = _parse_votes_int(meta.get("votes")) or 0
    tmdb_id = _clean_meta_value(meta.get("tmdb_id"))
    imdb_id = _clean_meta_value(meta.get("imdb_id"))
    plot_text = _clean_meta_value(meta.get("plot"))
    genre_text = _clean_meta_value(meta.get("genre"))
    year_text = _extract_year_text(meta.get("year")) or _clean_meta_value(meta.get("year"))
    media_type = _clean_meta_value(meta.get("media_type")).lower()
    if media_type not in ("movie", "tvshow", "season", "episode") and (not isFolder or _meta_has_title_identity(meta)):
        media_type = _media_type_for_action(_get_action(url) or _current_plugin_action())
    if media_type not in ("movie", "tvshow", "season", "episode") and not isFolder:
        media_type = _media_type_for_playable_action(_get_action(url))

    info_labels = {"title": _clean_search_title(title_text) or title_text}
    meta_plot = _build_meta_plot(
        plot=plot_text,
        year=year_text,
        genre=genre_text,
        rating=_first_non_empty(tmdb_rating_text, display_rating_text),
        votes=meta.get("votes"),
    )
    if meta_plot:
        info_labels["plot"] = meta_plot
    if genre_text:
        info_labels["genre"] = genre_text
    year_value = _parse_votes_int(year_text)
    if year_value and 1900 <= year_value <= 2100:
        info_labels["year"] = year_value
    if media_type in ("movie", "tvshow", "season", "episode"):
        info_labels["mediatype"] = media_type
    rating_for_info = _parse_rating_float(_first_non_empty(tmdb_rating_text, display_rating_text))
    if rating_for_info is not None:
        info_labels["rating"] = rating_for_info
    if votes_value:
        info_labels["votes"] = str(votes_value)
    try:
        listitem.setInfo(type="Video", infoLabels=info_labels)
    except Exception:
        pass
    if media_type:
        try:
            listitem.setProperty("mediatype", media_type)
            listitem.setProperty("dbtype", media_type)
        except Exception:
            pass

    try:
        vtag = listitem.getVideoInfoTag()
    except Exception:
        vtag = None

    if vtag:
        if media_type in ("movie", "tvshow", "season", "episode"):
            try:
                vtag.setMediaType(media_type)
            except Exception:
                pass
        if meta_plot:
            try:
                vtag.setPlot(meta_plot)
            except Exception:
                pass
        if genre_text:
            try:
                vtag.setGenres([g.strip() for g in re.split(r"[/,|]", genre_text) if g.strip()])
            except Exception:
                pass
        if year_value and 1900 <= year_value <= 2100:
            try:
                vtag.setYear(year_value)
            except Exception:
                pass

    if tmdb_id:
        try:
            listitem.setUniqueIDs({"tmdb": tmdb_id})
        except Exception:
            pass
        try:
            listitem.setProperty("tmdb_id", tmdb_id)
            listitem.setProperty("TmdbId", tmdb_id)
            if media_type:
                listitem.setProperty("mediatype", media_type)
                listitem.setProperty("dbtype", media_type)
        except Exception:
            pass
        if vtag:
            try:
                vtag.setUniqueID(tmdb_id, "tmdb")
            except Exception:
                pass
            try:
                vtag.setUniqueIDs({"tmdb": tmdb_id})
            except Exception:
                pass
    if imdb_id and imdb_id.startswith("tt"):
        try:
            listitem.setUniqueIDs({"tmdb": tmdb_id, "imdb": imdb_id} if tmdb_id else {"imdb": imdb_id})
        except Exception:
            pass
        try:
            listitem.setProperty("imdb_id", imdb_id)
        except Exception:
            pass
        if vtag:
            try:
                vtag.setUniqueID(imdb_id, "imdb")
            except Exception:
                pass
            try:
                vtag.setUniqueIDs({"tmdb": tmdb_id, "imdb": imdb_id} if tmdb_id else {"imdb": imdb_id})
            except Exception:
                pass

    if tmdb_rating_text:
        try:
            listitem.setProperty("TMDb_Rating", tmdb_rating_text)
        except Exception:
            pass
        tmdb_rating_value = _parse_rating_float(tmdb_rating_text)
        if tmdb_rating_value is not None:
            for provider in ("themoviedb", "tmdb"):
                try:
                    listitem.setRating(provider, tmdb_rating_value, votes_value, False)
                except Exception:
                    pass
                if vtag:
                    try:
                        vtag.setRating(tmdb_rating_value, votes_value, provider, False)
                    except Exception:
                        pass

    if trakt_rating_text:
        try:
            listitem.setProperty("Trakt_Rating", trakt_rating_text)
        except Exception:
            pass
        trakt_rating_value = _parse_rating_float(trakt_rating_text)
        if trakt_rating_value is not None:
            try:
                listitem.setRating("trakt", trakt_rating_value, votes_value, False)
            except Exception:
                pass
            if vtag:
                try:
                    vtag.setRating(trakt_rating_value, votes_value, "trakt", False)
                except Exception:
                    pass
    if display_rating_text:
        try:
            listitem.setProperty("Rating", display_rating_text)
            listitem.setProperty("RatingAndVotes", _build_rating_line(rating=display_rating_text, votes=meta.get("votes"), year=year_text, genre=genre_text))
            listitem.setLabel2(display_rating_text)
        except Exception:
            pass
    if _META_APPLY_LOG_COUNT < 8 and (tmdb_id or tmdb_rating_text or trakt_rating_text):
        _META_APPLY_LOG_COUNT += 1
        _log(
            "metadata applied label=%r content=%r media=%r action=%r tmdb_id=%r tmdb=%r trakt=%r" % (
                title_text, _CURRENT_CONTENT, media_type, _get_action(url) or _current_plugin_action(),
                tmdb_id, tmdb_rating_text, trakt_rating_text
            )
        )


def _enrich_media_item(item):
    if not _looks_like_media_item(item):
        return item
    _normalize_tmdb_item_images(item)

    title = _first_non_empty(item.get("name"), item.get("title"), item.get("original_name"))
    plot = _first_non_empty(item.get("description"), item.get("plot"))
    year = _first_non_empty(item.get("year"), item.get("release_date"), item.get("first_air_date"))
    genre = _first_non_empty(item.get("genres_str"), item.get("genre"), item.get("genres"))
    imdb_rating = _first_non_empty(item.get("rating_imdb"), item.get("imdb"), item.get("IMDbRating"), item.get("IMDb_Rating"))
    tmdb_rating = _first_non_empty(item.get("vote_average"), item.get("tmdb_rating"), item.get("TMDb_Rating"), item.get("themoviedb"))
    trakt_rating = _first_non_empty(item.get("rating_trakt"), item.get("trakt_rating"), item.get("Trakt_Rating"))
    votes = _first_non_empty(item.get("votes"), item.get("vote_count"))
    media_type = _first_non_empty(item.get("media_type"), item.get("mediatype"))
    tmdb_id = _first_non_empty(item.get("tmdb_id"), item.get("tmdb"), item.get("tmdbid"))
    imdb_id = _first_non_empty(item.get("imdb_id"), item.get("imdbid"))

    current_rating = _first_non_empty(imdb_rating, tmdb_rating, item.get("rating"))

    if title and not current_rating and not plot:
        tmdb_meta = _tmdb_lookup(title, year=year, media_type=media_type)
        tmdb_rating = _first_non_empty(tmdb_rating, tmdb_meta.get("rating"))
        votes = _first_non_empty(votes, tmdb_meta.get("votes"))
        year = _first_non_empty(year, tmdb_meta.get("year"))
        tmdb_id = _first_non_empty(tmdb_id, tmdb_meta.get("tmdb_id"))
        plot = _first_non_empty(plot, tmdb_meta.get("plot"))
        genre = _first_non_empty(genre, tmdb_meta.get("genre"))

    rating = _first_non_empty(imdb_rating, tmdb_rating, item.get("rating"))
    rating_text = _format_rating_text(rating)
    tmdb_rating_text = _format_rating_text(tmdb_rating)
    trakt_rating_text = _format_rating_text(trakt_rating)

    if rating_text:
        item["rating_imdb"] = rating_text
        item["rating"] = rating_text
        item["imdb"] = rating_text
        item["IMDbRating"] = rating_text
        item["IMDb_Rating"] = rating_text
    if tmdb_rating_text:
        item["vote_average"] = tmdb_rating_text
        item["tmdb_rating"] = tmdb_rating_text
        item["TMDb_Rating"] = tmdb_rating_text
        item["themoviedb"] = tmdb_rating_text
    if trakt_rating_text:
        item["rating_trakt"] = trakt_rating_text
        item["trakt_rating"] = trakt_rating_text
        item["Trakt_Rating"] = trakt_rating_text
    if votes:
        item["votes"] = _clean_meta_value(votes)
        item["vote_count"] = _clean_meta_value(votes)
    if tmdb_id:
        item["tmdb_id"] = _clean_meta_value(tmdb_id)
        item["tmdb"] = _clean_meta_value(tmdb_id)
        item["tmdbid"] = _clean_meta_value(tmdb_id)
    if imdb_id and _clean_meta_value(imdb_id).startswith("tt"):
        item["imdb_id"] = _clean_meta_value(imdb_id)

    meta_plot = _build_meta_plot(plot=plot, year=year, genre=genre, rating=rating_text, votes=votes)
    if meta_plot:
        if "description" in item or plot:
            item["description"] = meta_plot
        if "plot" in item or plot:
            item["plot"] = meta_plot

    _remember_media_meta(
        title=title,
        year=year,
        media_type=media_type,
        rating=rating_text,
        tmdb_rating=tmdb_rating_text,
        trakt_rating=trakt_rating_text,
        votes=votes,
        tmdb_id=tmdb_id,
        imdb_id=imdb_id,
        plot=plot,
        genre=genre,
    )

    return item


def _enrich_json_value(value):
    if isinstance(value, list):
        for idx, item in enumerate(value):
            value[idx] = _enrich_json_value(item)
        return value

    if not isinstance(value, dict):
        return value

    if _looks_like_media_item(value):
        _enrich_media_item(value)

    js_data = value.get("js")
    if isinstance(js_data, dict):
        _enrich_json_value(js_data)

    data_list = value.get("data")
    if isinstance(data_list, list):
        _enrich_json_value(data_list)

    for key, nested in list(value.items()):
        if isinstance(nested, list):
            if key == "series" and nested and not isinstance(nested[0], dict):
                continue
            _enrich_json_value(nested)
        elif isinstance(nested, dict):
            _enrich_json_value(nested)

    return value


def _patch_json_metadata():
    try:
        if getattr(json, "_stalker_meta_patched", False):
            return

        _orig_loads = json.loads
        _orig_load = json.load

        def _loads(s, *args, **kwargs):
            data = _orig_loads(s, *args, **kwargs)
            try:
                return _enrich_json_value(data)
            except Exception:
                return data

        def _load(fp, *args, **kwargs):
            data = _orig_load(fp, *args, **kwargs)
            try:
                return _enrich_json_value(data)
            except Exception:
                return data

        json.loads = _loads
        json.load = _load
        json._stalker_meta_patched = True
    except Exception as e:
        _log(f"json metadata patch failed: {e}", xbmc.LOGWARNING if xbmc else None)

def _patch_socket_dns():
    try:
        import socket
        try:
            socket.setdefaulttimeout(PORTAL_TIMEOUT)
        except Exception:
            pass
    except Exception as e:
        _log(f"socket patch failed: {e}", xbmc.LOGERROR if xbmc else None)

def _refresh_session_with_token(session, failed_url, kwargs):
    base = _portal_base(failed_url)
    hs = _make_url(base, "type=stb&action=handshake&JsHttpRequest=1-xml")
    gp = _make_url(base, "type=stb&action=get_profile&JsHttpRequest=1-xml")
    mi = _make_url(base, "type=stb&action=get_main_info&JsHttpRequest=1-xml")

    headers = dict(kwargs.get("headers") or {})
    timeout = kwargs.get("timeout", PORTAL_TIMEOUT)

    hs = _rewrite_url(hs)
    gp = _rewrite_url(gp)
    mi = _rewrite_url(mi)

    _log("create_link 403 -> handshake for fresh token")
    _pace(RETRY_REQUEST_GAP)
    r = session.get(hs, headers=headers, timeout=timeout, allow_redirects=True)
    _log(f"handshake -> HTTP {getattr(r, 'status_code', None)}")
    token = None
    try:
        token = _extract_token(getattr(r, "text", "") or "")
    except Exception:
        token = None

    if token:
        headers["Authorization"] = "Bearer " + token
        _log("fresh token extracted and Authorization header updated")
    else:
        _log("handshake returned no parseable token", xbmc.LOGWARNING if xbmc else None)

    for u in (gp, mi):
        try:
            _pace(RETRY_REQUEST_GAP)
            rr = session.get(u, headers=headers, timeout=timeout, allow_redirects=True)
            _log(f"refresh step {u!r} -> HTTP {getattr(rr, 'status_code', None)}")
        except Exception as e:
            _log(f"refresh step failed for {u!r}: {e}", xbmc.LOGWARNING if xbmc else None)

    return headers

def _patch_requests():
    try:
        import requests
        _orig = requests.sessions.Session.request
        _orig_response_json = requests.models.Response.json

        def _response_json(self, *args, **kwargs):
            data = _orig_response_json(self, *args, **kwargs)
            try:
                return _enrich_json_value(data)
            except Exception:
                return data

        requests.models.Response.json = _response_json

        def _request(self, method, url, *args, **kwargs):
            if isinstance(url, str):
                url = _rewrite_url(url)
            url, kwargs = _force_added_sort_for_portal_listing(url, kwargs)
            pinned_mac = _preferred_mac_from_state()
            if pinned_mac:
                headers = dict(kwargs.get("headers") or {})
                saw_cookie = False
                for key, value in list(headers.items()):
                    if str(key).lower() == "cookie":
                        saw_cookie = True
                        headers[key] = _cookie_for_mac(value, pinned_mac)
                if not saw_cookie and _is_portal_request_url(url):
                    headers["Cookie"] = _cookie_for_mac("", pinned_mac)
                kwargs["headers"] = headers
            if kwargs.get("timeout") is None:
                kwargs["timeout"] = PORTAL_TIMEOUT
            else:
                try:
                    timeout = kwargs.get("timeout")
                    if isinstance(timeout, (tuple, list)):
                        kwargs["timeout"] = tuple(min(float(v), PORTAL_TIMEOUT) for v in timeout)
                    elif float(timeout) > PORTAL_TIMEOUT:
                        kwargs["timeout"] = PORTAL_TIMEOUT
                except Exception:
                    kwargs["timeout"] = PORTAL_TIMEOUT

            resp = _orig(self, method, url, *args, **kwargs)

            if _is_create_link(url) and getattr(resp, "status_code", None) == 403:
                try:
                    with _REQ_LOCK:
                        new_headers = _refresh_session_with_token(self, url, kwargs)
                        new_kwargs = dict(kwargs)
                        new_kwargs["headers"] = new_headers
                        _pace(RETRY_REQUEST_GAP)
                        retry_resp = _orig(self, method, url, *args, **new_kwargs)
                    _log(f"retry create_link after token refresh -> HTTP {getattr(retry_resp, 'status_code', None)}")
                    return retry_resp
                except Exception as e:
                    _log(f"token refresh retry failed: {e}", xbmc.LOGERROR if xbmc else None)
            if getattr(resp, "status_code", None) == 429:
                _set_rate_limit_cooldown("HTTP 429")
            return resp

        requests.sessions.Session.request = _request
    except Exception as e:
        _log(f"requests patch failed: {e}", xbmc.LOGWARNING if xbmc else None)

def _patch_urllib():
    try:
        import urllib.request as _ur
        _orig = _ur.urlopen
        _orig_opener_open = _ur.OpenerDirector.open

        def _cap_timeout_args(args, kwargs):
            args = tuple(args)
            if len(args) > 0:
                try:
                    first = args[0]
                    if first is None or float(first) > PORTAL_TIMEOUT:
                        args = (PORTAL_TIMEOUT,) + tuple(args[1:])
                except Exception:
                    args = (PORTAL_TIMEOUT,) + tuple(args[1:])
            if "timeout" not in kwargs and len(args) == 0:
                kwargs["timeout"] = PORTAL_TIMEOUT
            elif "timeout" in kwargs:
                try:
                    if kwargs["timeout"] is None or float(kwargs["timeout"]) > PORTAL_TIMEOUT:
                        kwargs["timeout"] = PORTAL_TIMEOUT
                except Exception:
                    kwargs["timeout"] = PORTAL_TIMEOUT
            return args, kwargs

        def _urlopen(req, *args, **kwargs):
            args, kwargs = _cap_timeout_args(args, kwargs)
            url = None
            try:
                url = getattr(req, "full_url", None) or (req.get_full_url() if hasattr(req, "get_full_url") else None)
                if not url and isinstance(req, str):
                    url = req
            except Exception:
                pass
            pinned_mac = _preferred_mac_from_state()
            if not isinstance(req, str):
                req = _apply_mac_to_urllib_request(req, pinned_mac, url=url or "")
            if isinstance(url, str):
                new_url = _rewrite_url(url)
                if new_url != url:
                    _log(f"urllib rewrite: {url!r} -> {new_url!r}")
                    url = new_url
                    if isinstance(req, str):
                        req = url
            if isinstance(req, str) and pinned_mac and _is_portal_request_url(url):
                req = _ur.Request(req, headers={"Cookie": _cookie_for_mac("", pinned_mac)})
            try:
                return _orig(req, *args, **kwargs)
            except urllib.error.HTTPError as e:
                if getattr(e, "code", None) == 429:
                    _set_rate_limit_cooldown("HTTP 429")
                raise

        def _opener_open(self, fullurl, data=None, timeout=_ur.socket._GLOBAL_DEFAULT_TIMEOUT):
            pinned_mac = _preferred_mac_from_state()
            url = None
            try:
                url = getattr(fullurl, "full_url", None) or (fullurl.get_full_url() if hasattr(fullurl, "get_full_url") else None)
                if not url and isinstance(fullurl, str):
                    url = fullurl
            except Exception:
                pass
            if pinned_mac and not isinstance(fullurl, str):
                fullurl = _apply_mac_to_urllib_request(fullurl, pinned_mac, url=url or "")
            elif pinned_mac and isinstance(fullurl, str) and _is_portal_request_url(fullurl):
                fullurl = _ur.Request(fullurl, data=data, headers={"Cookie": _cookie_for_mac("", pinned_mac)})
                data = None
            try:
                if timeout is _ur.socket._GLOBAL_DEFAULT_TIMEOUT or timeout is None or float(timeout) > PORTAL_TIMEOUT:
                    timeout = PORTAL_TIMEOUT
            except Exception:
                timeout = PORTAL_TIMEOUT
            return _orig_opener_open(self, fullurl, data, timeout)

        _ur.urlopen = _urlopen
        _ur.OpenerDirector.open = _opener_open
    except Exception as e:
        _log(f"urllib patch failed: {e}", xbmc.LOGERROR if xbmc else None)

def _get_label(listitem):
    try:
        return listitem.getLabel() or ""
    except Exception:
        try:
            return listitem.getlabel() or ""
        except Exception:
            return ""

def _get_action(url):
    if not isinstance(url, str):
        return ""
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        return (qs.get("action") or [""])[0].strip().lower()
    except Exception:
        return ""

def _query_value(url, *names):
    if not isinstance(url, str):
        return ""
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    except Exception:
        return ""
    for name in names:
        value = (qs.get(name) or qs.get(name.lower()) or [""])[0]
        if value:
            return str(value)
    return ""

def _clean_choice_title(title):
    title = re.sub(r"\[[^\]]+\]", " ", title or "")
    title = re.sub(r"\([^\)]*(?:1080|720|2160|4k|uhd|fhd|hd|hq|sd|sub|dub|german|deutsch|multi)[^\)]*\)", " ", title, flags=re.I)
    title = re.sub(r"\b(?:1080p?|720p?|2160p?|4k|uhd|fhd|hd|hq|sd|german|deutsch|multi|sub|dub|stream|online|neu|new)\b", " ", title, flags=re.I)
    title = re.sub(r"\bS\d{1,2}E\d{1,3}\b", " ", title, flags=re.I)
    title = re.sub(r"\b\d{1,2}x\d{1,3}\b", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", title).strip(" -:|")
    return title or "Trailer"

def _text_from_runs(data):
    if isinstance(data, str):
        return data
    if not isinstance(data, dict):
        return ""
    if data.get("simpleText"):
        return data.get("simpleText")
    return "".join((run or {}).get("text", "") for run in data.get("runs") or [])

def _walk_video_renderers(data):
    if isinstance(data, dict):
        if "videoRenderer" in data:
            yield data["videoRenderer"]
        for value in data.values():
            yield from _walk_video_renderers(value)
    elif isinstance(data, list):
        for value in data:
            yield from _walk_video_renderers(value)

def _duration_seconds(renderer):
    text = _text_from_runs((renderer or {}).get("lengthText"))
    if not text:
        return 0
    try:
        parts = [int(part) for part in text.strip().split(":")]
    except Exception:
        return 0
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return parts[0] if parts else 0

def _find_youtube_trailer_id(title, year=""):
    base_title = _clean_choice_title(title)
    query_parts = [base_title]
    if year:
        query_parts.append(str(year))
    base_query = " ".join(part for part in query_parts if part).strip()
    if not base_query:
        return ""

    reject_words = ("review", "kritik", "analyse", "erklaert", "erklärt", "reaction",
                    "recap", "zusammenfassung", "ranking", "theorie", "erklaerung",
                    "erklärung", "komplett", "ganze folge")
    search_queries = (
        (base_query + " KinoCheck Deutsch Trailer", True),
        (base_query + " Offizieller Deutsch Trailer", False),
    )
    for query, require_kinocheck in search_queries:
        payload = json.dumps({
            "context": {"client": {"clientName": "WEB", "clientVersion": "2.20240506.01.00"}},
            "query": query
        }).encode("utf-8")
        request = urllib.request.Request(
            "https://www.youtube.com/youtubei/v1/search?prettyPrint=false",
            data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(request, timeout=8) as response:
            data = json.loads(response.read().decode("utf-8", "ignore"))
        best = None
        for index, video in enumerate(_walk_video_renderers(data)):
            video_id = video.get("videoId")
            if not video_id:
                continue
            title_text = _text_from_runs(video.get("title"))
            video_title = title_text.lower()
            channel_text = " ".join(
                _text_from_runs(video.get(key))
                for key in ("ownerText", "longBylineText", "shortBylineText")
            ).lower()
            is_kinocheck = "kinocheck" in video_title or "kinocheck" in channel_text
            has_german_marker = "deutsch" in video_title or "german" in video_title
            has_english_marker = "english" in video_title or "englisch" in video_title
            duration = _duration_seconds(video)
            if require_kinocheck and not is_kinocheck:
                continue
            if require_kinocheck and not has_german_marker:
                continue
            if has_english_marker and not has_german_marker:
                continue
            if "trailer" not in video_title:
                continue
            if any(word in video_title for word in reject_words):
                continue
            if duration and duration > 600:
                continue
            score = 10 if is_kinocheck else 0
            if "offiziell" in video_title or "official" in video_title:
                score += 3
            if has_german_marker:
                score += 2
            if duration and 45 <= duration <= 300:
                score += 1
            candidate = (score, -index, video_id)
            if best is None or candidate > best:
                best = candidate
        if best:
            return best[2]
    return ""

def _normalize_trailer_title(title):
    text = str(title or "").replace("\u00df", "ss").replace("\u1e9e", "ss")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[\[\]\(\)\{\}:|,._+!?/\\-]+", " ", text.lower())
    return re.sub(r"\s+", " ", text).strip()

def _without_leading_articles(title):
    return re.sub(r"^(the|der|die|das|ein|eine)\s+", "", _normalize_trailer_title(title)).strip()

def _meaningful_trailer_tokens(title):
    ignored = set(["der", "die", "das", "the", "ein", "eine", "und", "oder", "of", "and", "a",
                   "trailer", "official", "offiziell", "deutsch", "german", "english", "hd",
                   "film", "movie", "kino", "kinocheck"])
    return [token for token in _normalize_trailer_title(title).split() if len(token) > 1 and token not in ignored]

def _youtube_title_matches_request(request_title, result_title, year=""):
    request_year = str(year or "")[:4]
    if not request_year:
        year_match = re.search(r"\b(?:19|20)\d{2}\b", str(request_title or ""))
        request_year = year_match.group(0) if year_match else ""
    request_tokens = [
        token for token in _meaningful_trailer_tokens(request_title)
        if not re.match(r"^(?:19|20)\d{2}$", token)
    ]
    result_tokens = set(_meaningful_trailer_tokens(result_title))
    if not request_tokens:
        return True
    if len(request_tokens) == 1:
        token = request_tokens[0]
        result_norm = _normalize_trailer_title(result_title)
        compact_initialisms = [re.sub(r"\s+", "", match) for match in re.findall(r"(?:\b[a-z0-9]\b\s*){2,}", result_norm)]
        if request_year:
            result_years = re.findall(r"\b(?:19|20)\d{2}\b", str(result_title))
            if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
                return False
        if token in compact_initialisms:
            return True
        result_tokens_clean = [
            item for item in _meaningful_trailer_tokens(result_title)
            if not re.match(r"^#?\d+$", item)
            and not re.match(r"^(?:19|20)\d{2}$", item)
        ]
        return result_tokens_clean == [token]
    missing = [token for token in request_tokens if token not in result_tokens]
    if request_year:
        result_years = re.findall(r"\b(?:19|20)\d{2}\b", str(result_title))
        if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
            return False
    return len(missing) <= max(0, len(request_tokens) // 4)

def _tmdb_title_matches(item, lookup_title):
    lookup_norm = _normalize_trailer_title(lookup_title)
    lookup_article = _without_leading_articles(lookup_title)
    for key in ("title", "name", "original_title", "original_name"):
        candidate = item.get(key) or ""
        if _normalize_trailer_title(candidate) == lookup_norm:
            return True
        if _normalize_trailer_title(candidate).replace(" ", "") == lookup_norm.replace(" ", ""):
            return True
        if _without_leading_articles(candidate) == lookup_article:
            return True
    return False

def _tmdb_year(item, media_type):
    value = item.get("release_date") if media_type == "movie" else item.get("first_air_date")
    return str(value or "")[:4]

def _year_close(expected, actual):
    try:
        return not expected or not actual or abs(int(str(expected)[:4]) - int(str(actual)[:4])) <= 1
    except Exception:
        return True

def _find_tmdb_trailer_id(title, media_type="movie", year="", preferred_language="de"):
    try:
        lookup_title = _clean_choice_title(title)
        clean_year = _extract_year_text(year) or _extract_year_text(lookup_title)
        lookup_title = re.sub(r"\(?\b(?:19|20)\d{2}\b\)?", " ", lookup_title)
        lookup_title = re.sub(r"\s+", " ", lookup_title).strip(" -:|")
        if not lookup_title:
            return ""
        lookup_type = "tv" if media_type in ("tvshow", "season", "episode", "tv") else "movie"
        search_endpoint = "search/tv" if lookup_type == "tv" else "search/movie"
        year_key = "first_air_date_year" if lookup_type == "tv" else "primary_release_year"
        params = {"query": lookup_title, "language": "de-DE", "include_adult": "false", "api_key": _TMDB_API_KEY}
        if clean_year:
            params[year_key] = clean_year
        results = (_tmdb_request(search_endpoint, params).get("results") or [])
        if not results and clean_year:
            params.pop(year_key, None)
            results = (_tmdb_request(search_endpoint, params).get("results") or [])
        tmdb_id = ""
        for item in results:
            if _year_close(clean_year, _tmdb_year(item, lookup_type)) and _tmdb_title_matches(item, lookup_title):
                tmdb_id = str(item.get("id") or "")
                break
        if not tmdb_id and results and _year_close(clean_year, _tmdb_year(results[0], lookup_type)):
            tmdb_id = str(results[0].get("id") or "")
        if not tmdb_id:
            return ""
        lang_code = "de" if preferred_language == "de" else "en"
        data = _tmdb_request("%s/%s" % (lookup_type, tmdb_id), {
            "language": "de-DE" if preferred_language == "de" else "en-US",
            "append_to_response": "videos",
            "include_video_language": lang_code,
            "api_key": _TMDB_API_KEY,
        })
        best = None
        for index, video in enumerate((data.get("videos") or {}).get("results") or []):
            if (video.get("site") or "").lower() != "youtube":
                continue
            if (video.get("iso_639_1") or "").lower() != lang_code:
                continue
            video_type = (video.get("type") or "").lower()
            name = video.get("name") or ""
            if video_type != "trailer" and "trailer" not in name.lower():
                continue
            score = (10 if video.get("official") else 0) + (3 if video_type == "trailer" else 0) - index
            candidate = (score, video.get("key"), name)
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best and best[1]:
            _log("TMDB trailer found (%s): %s - %s" % (preferred_language, best[1], best[2]), xbmc.LOGINFO if xbmc else None)
            return best[1]
    except Exception as exc:
        _log("TMDB trailer failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return ""

def _find_youtube_trailer_id_language(title, year="", preferred_language="de", strict_german_marker=True):
    base_title = _clean_choice_title(title)
    base_query = " ".join(part for part in (base_title, str(year) if year and str(year) not in base_title else "") if part).strip()
    if not base_query:
        return ""
    reject_words = ("review", "kritik", "analyse", "erklaert", "erklärt", "reaction",
                    "recap", "zusammenfassung", "ranking", "theorie", "erklaerung",
                    "erklärung", "komplett", "ganze folge")
    if preferred_language == "kinocheck":
        search_queries = ((base_query + " KinoCheck Deutsch Trailer", True),)
        hl, gl = "de", "DE"
    elif preferred_language == "de":
        if strict_german_marker:
            search_queries = ((base_query + " KinoCheck Deutsch Trailer", True), (base_query + " Offizieller Deutsch Trailer", False))
        else:
            search_queries = ((base_query + " Trailer Deutsch", False), (base_query + " Offizieller Deutsch Trailer", False))
        hl, gl = "de", "DE"
    else:
        search_queries = ((base_query + " Official Trailer", False), (base_query + " Trailer", False))
        hl, gl = "en", "US"
    for query, require_kinocheck in search_queries:
        payload = json.dumps({
            "context": {"client": {"clientName": "WEB", "clientVersion": "2.20250925.01.00", "hl": hl, "gl": gl}},
            "query": query
        }).encode("utf-8")
        request = urllib.request.Request(
            "https://www.youtube.com/youtubei/v1/search?prettyPrint=false",
            data=payload,
            headers={"Content-Type": "application/json", "Origin": "https://www.youtube.com", "User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(request, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8", "ignore"))
        best = None
        for index, video in enumerate(_walk_video_renderers(data)):
            video_id = video.get("videoId")
            if not video_id:
                continue
            title_text = _text_from_runs(video.get("title"))
            video_title = title_text.lower()
            channel_text = " ".join(_text_from_runs(video.get(key)) for key in ("ownerText", "longBylineText", "shortBylineText")).lower()
            is_kinocheck = "kinocheck" in video_title or "kinocheck" in channel_text
            has_german_marker = "deutsch" in video_title or "german" in video_title
            if require_kinocheck and (not is_kinocheck or not has_german_marker):
                continue
            if strict_german_marker and preferred_language in ("de", "kinocheck") and not has_german_marker:
                continue
            if preferred_language == "en" and has_german_marker:
                continue
            if "trailer" not in video_title or any(word in video_title for word in reject_words):
                continue
            duration = _duration_seconds(video)
            if duration and duration > 600:
                continue
            if not _youtube_title_matches_request(base_title, title_text, year):
                continue
            score = (10 if is_kinocheck else 0) + (3 if "offiziell" in video_title or "official" in video_title else 0) + (2 if has_german_marker else 0) + (1 if duration and 45 <= duration <= 300 else 0)
            candidate = (score, -index, video_id, title_text)
            if best is None or candidate[:3] > best[:3]:
                best = candidate
        if best:
            _log("YouTube trailer found (%s): %s - %s" % (preferred_language, best[2], best[3]), xbmc.LOGINFO if xbmc else None)
            return best[2]
    return ""

def _trailer_search_title(title, media_type, tvshow_title="", season=""):
    base = _clean_choice_title(tvshow_title or title)
    if media_type == "season" and season:
        return "%s Staffel %s" % (base, season)
    return _clean_choice_title(title or base)

def _find_best_trailer_id(title, media_type="movie", year=""):
    return (
        _find_youtube_trailer_id_language(title, year, "kinocheck")
        or _find_tmdb_trailer_id(title, media_type, year, "de")
        or _find_youtube_trailer_id_language(title, year, "de")
        or _find_tmdb_trailer_id(title, media_type, year, "en")
        or _find_youtube_trailer_id_language(title, year, "en")
        or _find_youtube_trailer_id_language(title, year, "de", False)
    )

def _play_youtube_trailer_deferred(video_id):
    url = "plugin://plugin.video.youtube/play/?video_id=%s&codex_trailer=1" % video_id
    try:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmc.sleep(250)
        xbmc.executebuiltin("PlayMedia(%s)" % url)
        for _ in range(24):
            xbmc.sleep(250)
            if xbmc.Player().isPlayingVideo():
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                xbmc.sleep(250)
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                break
    except Exception as exc:
        _log("Trailer starter failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _get_year(listitem):
    try:
        year = listitem.getVideoInfoTag().getYear()
        if year:
            return str(year)
    except Exception:
        pass
    for key in ("year", "premiered", "aired"):
        try:
            value = listitem.getProperty(key)
            if value:
                return str(value)[:4]
        except Exception:
            pass
    return ""

def _get_plot(listitem):
    try:
        plot = listitem.getVideoInfoTag().getPlot()
        if plot:
            return str(plot)
    except Exception:
        pass
    for key in ("plot", "description", "Plot", "Description"):
        try:
            value = listitem.getProperty(key)
            if value:
                return str(value)
        except Exception:
            pass
    return ""

def _get_genre(listitem):
    try:
        genre = listitem.getVideoInfoTag().getGenres()
        if isinstance(genre, (list, tuple)) and genre:
            return " / ".join(str(g) for g in genre if g)
        if genre:
            return str(genre)
    except Exception:
        pass
    for key in ("genre", "Genre", "genres", "genres_str"):
        try:
            value = listitem.getProperty(key)
            if value:
                return str(value)
        except Exception:
            pass
    return ""

def _get_rating_text(listitem):
    for key in ("TMDb_Rating", "Trakt_Rating", "IMDb_Rating", "Rating"):
        try:
            value = listitem.getProperty(key)
            if value:
                return _format_rating_text(value)
        except Exception:
            pass
    try:
        rating = listitem.getVideoInfoTag().getRating()
        if rating:
            return _format_rating_text(rating)
    except Exception:
        pass
    return ""

def _get_media_type(listitem, url=""):
    try:
        media_type = listitem.getVideoInfoTag().getMediaType()
        if media_type in ("movie", "tvshow", "season", "episode"):
            return media_type
    except Exception:
        pass
    for key in ("mediatype", "mediaType", "MediaType", "dbtype"):
        try:
            media_type = (listitem.getProperty(key) or "").strip().lower()
            if media_type in ("movie", "film"):
                return "movie"
            if media_type in ("tvshow", "series", "serie", "show"):
                return "tvshow"
            if media_type in ("season", "staffel"):
                return "season"
            if media_type in ("episode", "folge"):
                return "episode"
        except Exception:
            pass
    meta = _find_media_meta(listitem, url=url)
    if meta:
        media_type = (meta.get("media_type") or "").strip().lower()
        if media_type in ("movie", "film"):
            return "movie"
        if media_type in ("tvshow", "series", "serie", "show", "tv"):
            return "tvshow"
    media_type = _query_value(url, "mediatype", "media_type", "type", "content").strip().lower()
    if media_type in ("movie", "film"):
        return "movie"
    if media_type in ("tvshow", "series", "serie", "show", "tv"):
        return "tvshow"
    return ""

def _current_plugin_url():
    try:
        return sys.argv[0] + (sys.argv[2] or "")
    except Exception:
        try:
            return "plugin://%s/" % ADDON_ID
        except Exception:
            return ""

def _latest_myvideos_db():
    try:
        db_dir = _translate_path("special://database")
    except Exception:
        db_dir = ""
    try:
        candidates = []
        for name in os.listdir(db_dir):
            if re.match(r"^MyVideos\d+\.db$", name or ""):
                path = os.path.join(db_dir, name)
                candidates.append((os.path.getmtime(path), path))
        if candidates:
            return sorted(candidates, reverse=True)[0][1]
    except Exception:
        pass
    return ""

def _resume_point_for_url(url):
    if not url:
        return 0.0, 0.0
    db_path = _latest_myvideos_db()
    if not db_path or not os.path.exists(db_path):
        return 0.0, 0.0
    try:
        conn = sqlite3.connect("file:%s?mode=ro" % db_path.replace("\\", "/"), uri=True, timeout=0.25)
        try:
            row = conn.execute(
                """
                SELECT b.timeInSeconds, b.totalTimeInSeconds
                FROM bookmark b
                JOIN files f ON f.idFile = b.idFile
                LEFT JOIN path p ON p.idPath = f.idPath
                WHERE b.type = 1
                  AND (
                    f.strFilename = ?
                    OR (IFNULL(p.strPath, '') || IFNULL(f.strFilename, '')) = ?
                  )
                ORDER BY b.idBookmark DESC
                LIMIT 1
                """,
                (url, url),
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return 0.0, 0.0
        resume = float(row[0] or 0)
        total = float(row[1] or 0)
        if resume > 30 and (not total or resume < max(0, total - 30)):
            return resume, total
    except Exception as exc:
        _log("Resume lookup failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return 0.0, 0.0

def _apply_resume_offset(listitem, resolved_url=""):
    if listitem is None:
        return
    try:
        qs = urllib.parse.parse_qs((sys.argv[2] or "").lstrip("?"))
        force_resume = (qs.get("codex_force_resume") or ["0"])[0] == "1"
    except Exception:
        force_resume = False
    if not force_resume:
        return
    plugin_url = _current_plugin_url()
    resume, total = _resume_point_for_url(plugin_url)
    if not resume and resolved_url:
        resume, total = _resume_point_for_url(resolved_url)
    if not resume:
        return
    try:
        listitem.setProperty("StartOffset", str(int(resume)))
        listitem.setProperty("resumetime", str(float(resume)))
        if total:
            listitem.setProperty("totaltime", str(float(total)))
        _log("Applied resume offset %.1fs for %r" % (resume, plugin_url or resolved_url))
    except Exception as exc:
        _log("Could not apply resume offset: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _translate_path(path):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        if xbmc:
            return xbmc.translatePath(path)
    except Exception:
        pass
    return path

def _view_db_path():
    try:
        db_dir = _translate_path("special://database/")
        candidates = [n for n in os.listdir(db_dir) if n.lower().startswith("viewmodes") and n.lower().endswith(".db")]
        if candidates:
            candidates.sort()
            return os.path.join(db_dir, candidates[-1])
        return os.path.join(db_dir, "ViewModes6.db")
    except Exception:
        return ""

def _view_prefs_path():
    try:
        profile = ""
        if xbmcaddon:
            profile = _translate_path(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
        if not profile:
            profile = _translate_path("special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, "view_prefs.json")
    except Exception:
        return ""

def _is_live_listing_path(path):
    try:
        text = urllib.parse.unquote(path or "").lower()
    except Exception:
        text = (path or "").lower()
    live_words = (
        "live", "livetv", "live-tv", " iptv", "| iptv", "channels", "channel",
        "sender", "fernsehen", "radio", "epg"
    )
    return any(word in text for word in live_words)

def _is_title_listing_path(path):
    return False

def _is_title_listing(items):
    current = _current_plugin_url()
    if _is_title_listing_path(current):
        return True
    if _is_live_listing_path(current):
        return False
    media_count = 0
    for url, li, _isFolder, _totalItems in items or []:
        if _get_media_type(li, url) in ("movie", "tvshow"):
            media_count += 1
            if media_count >= 3:
                return True
    if _CURRENT_CONTENT not in ("movies", "tvshows"):
        return False
    return False

def _content_for_items(items):
    if _is_live_listing_path(_current_plugin_url()):
        return ""
    counts = {"movie": 0, "tvshow": 0, "season": 0, "episode": 0}
    for url, li, _isFolder, _totalItems in items or []:
        if _should_hide_item(url, _get_label(li), _isFolder) or _is_next_page_label(_get_label(li)):
            continue
        media_type = _get_media_type(li, url)
        if not media_type and not _isFolder:
            media_type = _media_type_for_playable_action(_get_action(url))
        if media_type in counts:
            counts[media_type] += 1
    if counts["movie"] >= 2:
        return "movies"
    if counts["tvshow"] >= 2:
        return "tvshows"
    if counts["season"] >= 1:
        return "seasons"
    if counts["episode"] >= 1:
        return "episodes"
    return ""

def _load_view_prefs():
    try:
        path = _view_prefs_path()
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def _save_view_prefs(prefs):
    try:
        path = _view_prefs_path()
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(prefs, f, sort_keys=True)
    except Exception:
        pass

def _row_from_pref():
    try:
        data = _load_view_prefs().get("video_titles")
        if data and int(data.get("viewMode") or 0):
            return (
                0,
                int(data.get("viewMode") or 0),
                int(data.get("sortMethod") or 0),
                int(data.get("sortOrder") or 1),
                int(data.get("sortAttributes") or 0),
                data.get("skin") or "skin.aeon.nox.silvo",
            )
    except Exception:
        pass
    return None

def _remember_view_row(row):
    try:
        view_mode = int(row[1] or 0)
        if not view_mode:
            return
        prefs = _load_view_prefs()
        prefs["video_titles"] = {
            "viewMode": view_mode,
            "sortMethod": int(row[2] or 0),
            "sortOrder": int(row[3] or 1),
            "sortAttributes": int(row[4] or 0),
            "skin": row[5] or "skin.aeon.nox.silvo",
        }
        _save_view_prefs(prefs)
    except Exception:
        pass

def _get_view_row(con, path):
    try:
        return con.execute(
            "select idView, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path=?",
            (10025, path)
        ).fetchone()
    except Exception:
        return None

def _latest_title_view_row(con):
    pref = _row_from_pref()
    if pref:
        return pref
    try:
        rows = con.execute(
            "select idView, path, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path like ? and viewMode<>0 order by idView desc limit 500",
            (10025, "plugin://%s%%" % ADDON_ID)
        ).fetchall()
        if rows:
            row = rows[0]
            return (row[0], row[2], row[3], row[4], row[5], row[6])
    except Exception:
        pass
    return None

def _set_view_row(con, path, source_row):
    if not source_row or not int(source_row[1] or 0):
        return
    view_mode = int(source_row[1] or 0)
    sort_method = int(source_row[2] or 0)
    sort_order = int(source_row[3] or 1)
    sort_attributes = int(source_row[4] or 0)
    skin = source_row[5] or "skin.aeon.nox.silvo"
    existing = _get_view_row(con, path)
    if existing:
        con.execute(
            "update view set viewMode=?, sortMethod=?, sortOrder=?, sortAttributes=?, skin=? where idView=?",
            (view_mode, sort_method, sort_order, sort_attributes, skin, existing[0])
        )
    else:
        next_id = con.execute("select coalesce(max(idView), 0) + 1 from view").fetchone()[0]
        con.execute(
            "insert into view (idView, window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) values (?, ?, ?, ?, ?, ?, ?, ?)",
            (next_id, 10025, path, view_mode, sort_method, sort_order, sort_attributes, skin)
        )

def _sync_title_view_before_end(items):
    if not _is_title_listing(items):
        return
    db_path = _view_db_path()
    if not db_path or not os.path.exists(db_path):
        return
    current = _current_plugin_url()
    try:
        con = sqlite3.connect(db_path, timeout=0.5)
        try:
            row = _get_view_row(con, current)
            if row and int(row[1] or 0):
                _remember_view_row(row)
                return
            source = _latest_title_view_row(con)
            if source:
                _set_view_row(con, current, source)
                _remember_view_row(source)
                con.commit()
        finally:
            con.close()
    except Exception as e:
        _log(f"view sync failed: {e}", xbmc.LOGWARNING if xbmc else None)

def _is_generic_choice_label(label):
    l = (label or "").strip().lower()
    if not l:
        return True
    generic = (
        "live", "tv", "iptv", "cache", "suche", "search", "genre", "genres",
        "category", "kategorie", "jahr", "years", "weiter", "next", "seite",
        "page", "settings", "einstellungen", "vod", "filme", "movies", "serien",
        "series", "top", "popular", "trending",
        "mac wechseln"
    )
    return any(word in l for word in generic)

def _extract_season_number(title):
    try:
        match = re.search(r"(?:staffel|season)\s*(\d+)", title or "", re.I)
        if match:
            return match.group(1)
        match = re.search(r"(?:^|[\s._-])s(?:eason)?\s*0*(\d+)(?:$|[\s._-])", title or "", re.I)
        if match:
            return match.group(1)
    except Exception:
        pass
    return ""

def _season_number_from_url(url, label=""):
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(str(url or "")).query)
    except Exception:
        qs = {}
    for key in ("season", "season_id"):
        value = (qs.get(key) or [""])[0]
        match = re.search(r"(\d+)", str(value or ""))
        if match:
            return match.group(1)
    value = (qs.get("video_id") or [""])[0]
    if ":" in str(value or ""):
        tail = str(value).split(":", 1)[1]
        match = re.search(r"(\d+)", tail)
        if match:
            return match.group(1)
    return _extract_season_number(label)

def _normalize_season_listitem_label(listitem, url, isFolder=False):
    if not isFolder or listitem is None:
        return
    try:
        action = _get_action(url)
        if action not in ("episodes", "episode"):
            return
        number = _season_number_from_url(url, _get_label(listitem))
        if not number:
            return
        new_label = "Season %s" % number
        try:
            listitem.setLabel(new_label)
        except Exception:
            try:
                listitem.setLabel2(new_label)
            except Exception:
                pass
        try:
            tag = listitem.getVideoInfoTag()
            if tag:
                try:
                    tag.setTitle(new_label)
                except Exception:
                    pass
                try:
                    tag.setSeason(int(number))
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass

def _current_context_title():
    try:
        query = urllib.parse.parse_qs((sys.argv[2] or "").lstrip("?"))
    except Exception:
        query = {}
    for name in ("tvshow_title", "TVShowTitle", "sName", "title", "name", "show", "series", "series_name"):
        value = (query.get(name) or query.get(name.lower()) or [""])[0]
        if value:
            value = _clean_choice_title(str(value))
            if value and not _is_generic_choice_label(value):
                return value
    return ""

def _build_trailer_choice_url(title, media_type, original_url, original_is_folder, year="", plot="", genre="", rating="", votes="", tvshow_title="", season="", art=None, source_mac="", from_favorites=False, fav_id=""):
    art = art if isinstance(art, dict) else {}
    params = {
        "action": "nova_trailer_choice",
        "choice_title": _clean_choice_title(title),
        "choice_media_type": media_type,
        "choice_url": original_url or "",
        "choice_is_folder": "1" if original_is_folder else "0",
        "choice_year": year or "",
        "choice_plot": plot or "",
        "choice_genre": genre or "",
        "choice_rating": rating or "",
        "choice_votes": votes or "",
        "choice_tvshow_title": tvshow_title or "",
        "choice_season": season or "",
        "choice_art": json.dumps(art, ensure_ascii=False, sort_keys=True) if art else "",
        "choice_source_mac": _normalize_mac(source_mac),
        "choice_from_favorites": "1" if from_favorites else "",
        "choice_fav_id": fav_id or "",
    }
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))

def _with_one_shot_source_mac(url, source_mac):
    source_mac = _normalize_mac(source_mac)
    if not source_mac or not isinstance(url, str) or not url:
        return url
    try:
        split = urllib.parse.urlsplit(url)
        qs = urllib.parse.parse_qs(split.query, keep_blank_values=True)
        qs["source_mac"] = [source_mac]
        query = urllib.parse.urlencode(qs, doseq=True)
        return urllib.parse.urlunsplit((split.scheme, split.netloc, split.path, query, split.fragment))
    except Exception:
        return url

def _favorite_id(title, media_type, original_url):
    raw = "%s|%s|%s" % (_clean_choice_title(title), media_type or "", original_url or "")
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:16]

def _art_from_listitem(listitem):
    art = {}
    try:
        raw = listitem.getArt() or {}
        if isinstance(raw, dict):
            art.update({str(k): str(v) for k, v in raw.items() if v})
    except Exception:
        pass
    for prop, key in (
        ("icon", "icon"),
        ("thumb", "thumb"),
        ("poster", "poster"),
        ("fanart", "fanart"),
        ("logo", "icon"),
    ):
        try:
            value = listitem.getProperty(prop)
            if value and not art.get(key):
                art[key] = str(value)
        except Exception:
            pass
    return art

def _best_art_for_favorite(fav):
    art = {}
    raw = fav.get("art")
    if isinstance(raw, dict):
        art.update({str(k): str(v) for k, v in raw.items() if v})
    for key in ("icon", "thumb", "poster", "fanart"):
        value = fav.get(key)
        if value and not art.get(key):
            art[key] = str(value)
    if not (art.get("thumb") or art.get("poster") or art.get("icon")):
        try:
            tmdb_meta = _tmdb_lookup(fav.get("title") or "", year=fav.get("year") or "", media_type=fav.get("media_type") or "", force=True)
            if tmdb_meta.get("poster"):
                poster = _tmdb_image_size(tmdb_meta.get("poster"), "w185")
                art.update({"icon": poster, "thumb": poster, "poster": poster})
            if tmdb_meta.get("fanart"):
                art["fanart"] = _tmdb_image_size(tmdb_meta.get("fanart"), "w300")
        except Exception:
            pass
    if not art.get("icon"):
        art["icon"] = art.get("thumb") or art.get("poster") or FAVORITES_ART
    if not art.get("thumb"):
        art["thumb"] = art.get("poster") or art.get("icon") or FAVORITES_ART
    return art

def _load_macsimum_favorites():
    try:
        path = _macsimum_favorites_path()
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8-sig") as fh:
                data = json.load(fh)
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
    except Exception as exc:
        _log("Favoriten konnten nicht gelesen werden: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return []

def _save_macsimum_favorites(items):
    try:
        path = _macsimum_favorites_path()
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(items or [], fh, ensure_ascii=False, indent=2, sort_keys=True)
        return True
    except Exception as exc:
        _log("Favoriten konnten nicht gespeichert werden: %s" % exc, xbmc.LOGERROR if xbmc else None)
    return False

def _add_macsimum_favorite(title, media_type, original_url, original_is_folder, year="", plot="", genre="", rating="", votes="", tvshow_title="", season="", art=None, source_mac=""):
    clean_title = _clean_choice_title(title)
    art = art if isinstance(art, dict) else {}
    fav = {
        "id": _favorite_id(clean_title, media_type, original_url),
        "title": clean_title,
        "media_type": media_type or "movie",
        "original_url": original_url or "",
        "original_is_folder": bool(original_is_folder),
        "year": year or "",
        "plot": plot or "",
        "genre": genre or "",
        "rating": rating or "",
        "votes": votes or "",
        "tvshow_title": tvshow_title or "",
        "season": season or "",
        "art": art,
        "icon": art.get("icon") or art.get("thumb") or art.get("poster") or "",
        "thumb": art.get("thumb") or art.get("poster") or art.get("icon") or "",
        "poster": art.get("poster") or art.get("thumb") or "",
        "fanart": art.get("fanart") or "",
        "source_mac": _normalize_mac(source_mac) or _normalize_mac(_current_module_mac()),
        "added_at": int(time.time()),
    }
    items = _load_macsimum_favorites()
    items = [item for item in items if item.get("id") != fav["id"]]
    items.insert(0, fav)
    if _save_macsimum_favorites(items):
        return fav
    return None

def _remove_macsimum_favorite(fav_id):
    fav_id = str(fav_id or "").strip()
    if not fav_id:
        return False
    items = _load_macsimum_favorites()
    new_items = [item for item in items if str(item.get("id") or "") != fav_id]
    if len(new_items) == len(items):
        return False
    return _save_macsimum_favorites(new_items)

def _clear_macsimum_favorites():
    return _save_macsimum_favorites([])

def _update_macsimum_favorite_source_mac(fav_id="", title="", source_mac=""):
    mac = _normalize_mac(source_mac)
    if not mac:
        return False
    clean_title = _clean_choice_title(title)
    items = _load_macsimum_favorites()
    changed = False
    for fav in items:
        if not isinstance(fav, dict):
            continue
        if fav_id and str(fav.get("id") or "") == str(fav_id):
            fav["source_mac"] = mac
            changed = True
            break
        if clean_title and _clean_choice_title(fav.get("title") or "") == clean_title:
            fav["source_mac"] = mac
            changed = True
            break
    if changed:
        return _save_macsimum_favorites(items)
    return False

def _update_all_macsimum_favorites_source_mac(source_mac=""):
    mac = _normalize_mac(source_mac)
    if not mac:
        return 0
    items = _load_macsimum_favorites()
    changed = 0
    for fav in items:
        if not isinstance(fav, dict):
            continue
        if _normalize_mac(fav.get("source_mac") or "") != mac:
            fav["source_mac"] = mac
            changed += 1
    if changed:
        _save_macsimum_favorites(items)
    return changed

def _build_macsimum_favorites_url():
    return "plugin://%s/?action=codex_macsimum_favorites" % ADDON_ID

def _build_macsimum_remove_favorite_url(fav_id):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({
        "action": "codex_macsimum_remove_favorite",
        "fav_id": fav_id or "",
    }))

def _build_macsimum_clear_favorites_url():
    return "plugin://%s/?action=codex_macsimum_clear_favorites" % ADDON_ID

def _favorite_to_choice_url(fav):
    return _build_trailer_choice_url(
        fav.get("title") or "Favorit",
        fav.get("media_type") or "movie",
        fav.get("original_url") or "",
        bool(fav.get("original_is_folder")),
        fav.get("year") or "",
        fav.get("plot") or "",
        fav.get("genre") or "",
        fav.get("rating") or "",
        fav.get("votes") or "",
        fav.get("tvshow_title") or "",
        fav.get("season") or "",
        _best_art_for_favorite(fav),
        "",
        True,
        fav.get("id") or "",
    )

def _make_macsimum_favorites_root_item(source_listitem=None):
    item = xbmcgui.ListItem("Favoriten")
    try:
        item.setArt({"icon": FAVORITES_ART, "thumb": FAVORITES_ART})
        _apply_default_fanart(item)
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _dispatch_original_folder_url(original_url, argv):
    try:
        split = urllib.parse.urlsplit(original_url or "")
        query = ("?" + split.query) if split.query else ""
        if not query:
            raise Exception("Originale Ordner-URL ohne Query")
        new_argv = [argv[0], argv[1], query]
        old_argv = list(sys.argv)
        try:
            sys.argv = list(new_argv)
            _log("Trailer choice direct folder dispatch: %r" % original_url)
            mod, _pinned_mac = _prepare_usable_impl()
            if mod is None:
                _finish_failed_directory(new_argv)
                return True
            return mod.run(new_argv)
        finally:
            sys.argv = old_argv
    except Exception as exc:
        _log("Trailer choice direct folder dispatch failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        try:
            _finish_failed_directory(argv)
        except Exception:
            pass
        return True

def _compact_folder_update_url(original_url):
    if not isinstance(original_url, str):
        return original_url
    try:
        split = urllib.parse.urlsplit(original_url)
        qs = urllib.parse.parse_qs(split.query, keep_blank_values=True)
        action = ((qs.get("action") or [""])[0] or "").strip().lower()
        if action not in ("episodes", "episode"):
            return original_url
        keep = (
            "type", "action", "video_id", "cmd", "start", "end", "season",
            "title", "logo", "plot", "fanart", "actors", "genre_tuple",
            "category_id", "page", "update_listing"
        )
        safe_defaults = {
            "plot": "N/A",
            "actors": "[]",
            "genre_tuple": "()",
        }
        compact = []
        for key in keep:
            if key in qs:
                for value in qs.get(key) or [""]:
                    if key == "actors":
                        value = "[]"
                    elif key == "genre_tuple":
                        value = "()"
                    elif key == "plot":
                        value = (value or "N/A")[:240]
                    compact.append((key, value))
            elif key in safe_defaults:
                compact.append((key, safe_defaults[key]))
        if not any(key == "action" for key, _value in compact):
            compact.insert(0, ("action", action or "episodes"))
        query = urllib.parse.urlencode(compact)
        return urllib.parse.urlunsplit((split.scheme, split.netloc, split.path, query, split.fragment))
    except Exception as exc:
        _log("Compact folder update url failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
        return original_url

def _maybe_wrap_trailer_choice(url, listitem, isFolder):
    if not isinstance(url, str) or "nova_trailer_choice" in url:
        return url, isFolder
    action = _get_action(url)
    if action in ("tv", "live", "manual_mac_switch", "codex_macsimum_clear_favorites", "codex_macsimum_remove_favorite"):
        return url, isFolder
    if not isFolder and action in ("episode", "episodes", "play_episode", "epiplay"):
        return url, isFolder
    label = _get_label(listitem)
    if _is_generic_choice_label(label):
        return url, isFolder
    if isFolder and action in ("seasons", "season"):
        media_type = "tvshow"
    elif isFolder and action in ("episodes", "episode"):
        media_type = "season"
    else:
        media_type = _get_media_type(listitem, url)
    if media_type not in ("movie", "tvshow", "season", "episode"):
        if not isFolder and action not in ("", "tv", "live"):
            media_type = "movie"
        elif isFolder and action in ("seasons", "season"):
            media_type = "tvshow"
        elif isFolder and (action in ("episodes", "episode") or "staffel" in label.lower() or "season" in label.lower()):
            media_type = "season"
    if media_type not in ("movie", "tvshow", "season"):
        return url, isFolder
    try:
        listitem.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return _build_trailer_choice_url(
        label,
        media_type,
        url,
        isFolder,
        _get_year(listitem),
        _get_plot(listitem),
        _get_genre(listitem),
        _get_rating_text(listitem),
        "",
        _current_context_title() if media_type == "season" else "",
        _extract_season_number(label) if media_type == "season" else "",
        _art_from_listitem(listitem),
        _current_module_mac(),
    ), False

def _is_root_media_listing(items):
    actions = set()
    for url, _li, _isFolder, _totalItems in items:
        action = _get_action(url)
        if action:
            actions.add(action)
    return "series" in actions and ("vod" in actions or "tv" in actions)

def _is_root_live_tv_entry(url, listitem, isFolder):
    try:
        action = _get_action(url)
        label = _get_label(listitem).strip().lower()
        if action in ("tv", "live", "livetv"):
            return True
        if isFolder and label in ("live tv", "live-tv", "livetv"):
            return True
    except Exception:
        pass
    return False

def _hide_root_live_tv_entry(items):
    # CODEX: Stalker-Portal-Root "Live TV" bewusst nur unsichtbar.
    # Wieder sichtbar machen: diese Filterzeile in _inject_manual_switch_item
    # entfernen/auskommentieren. Die eigentliche Live-TV-Mechanik bleibt
    # unverändert im Add-on erhalten, damit Live TV 3 nicht beschädigt wird.
    filtered = []
    hidden = 0
    for url, li, isFolder, totalItems in list(items or []):
        if _is_root_live_tv_entry(url, li, isFolder):
            hidden += 1
            continue
        filtered.append((url, li, isFolder, totalItems))
    if hidden:
        try:
            _log("Root Live TV entry hidden by Codex flag: %d" % hidden)
        except Exception:
            pass
    return filtered

def _build_manual_switch_url():
    return "plugin://%s/?action=manual_mac_switch" % ADDON_ID

def _build_all_live_scan_url():
    return "plugin://%s/?action=codex_macsimum_all_scan" % ADDON_ID

def _build_gap_live_scan_url():
    return "plugin://%s/?action=codex_macsimum_gap_scan" % ADDON_ID

def _build_missing_m3u_repair_url():
    return "plugin://%s/?action=codex_macsimum_missing_m3u_repair" % ADDON_ID

def _build_scope_scan_url(scope):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({
        "action": "codex_macsimum_scope_scan",
        "scope": str(scope or "").strip().lower(),
    }))

def _codex_scope_display_name(scope):
    names = {
        "de": "Deutschland",
        "international_sport": "International Sport / VIP / PPV",
        "at": "Österreich",
        "ch": "Schweiz",
        "nl": "Niederlande",
        "be": "Belgien",
        "england": "England / UK",
        "us": "USA",
        "ca": "Kanada",
        "fr": "Frankreich",
        "it": "Italien",
        "es": "Spanien",
        "pt": "Portugal",
        "pl": "Polen",
        "al": "Albanien",
        "rs": "Serbien",
        "me": "Montenegro",
        "hr": "Kroatien",
        "si": "Slowenien",
        "mk": "Mazedonien",
        "ba": "Bosnien",
        "exyu_allgemein": "Ex-Yu allgemein",
        "gr": "Griechenland",
        "ro": "Rumänien",
        "bg": "Bulgarien",
        "hu": "Ungarn",
        "cz": "Tschechien",
        "sk": "Slowakei",
        "dk": "Dänemark",
        "se": "Schweden",
        "no": "Norwegen",
        "fi": "Finnland",
        "ru": "Russland",
        "ua": "Ukraine",
        "ge": "Georgien",
        "az": "Aserbaidschan",
        "am": "Armenien",
        "au": "Australien",
        "br": "Brasilien",
        "co": "Kolumbien",
        "pe": "Peru",
        "arabic_general": "Arabisch allgemein",
        "ma": "Marokko",
        "dz": "Algerien",
        "sa": "Saudi-Arabien",
        "lb": "Libanon",
        "tn": "Tunesien",
        "kw": "Kuwait",
        "sd": "Sudan",
        "eg": "Ägypten",
        "ps": "Palästina",
        "ae": "VAE",
        "bh": "Bahrain",
        "iq": "Irak",
        "jo": "Jordanien",
        "qa": "Katar",
        "sy": "Syrien",
        "kurdish": "Kurdisch",
        "suryoyo": "Suryoyo",
        "ir": "Iran",
        "in": "Indien",
        "pk": "Pakistan",
        "africa": "Afrika",
        "dstv": "DStv",
        "th": "Thailand",
        "adult": "Adult",
    }
    return names.get(str(scope or "").strip().lower(), str(scope or "").strip() or "Unbekannt")

def _make_manual_switch_item(source_listitem=None):
    item = xbmcgui.ListItem("[B]MAC WECHSELN[/B]")
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _make_all_live_scan_item(source_listitem=None):
    item = xbmcgui.ListItem("[B]Senderlisten aktualisieren[/B]")
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _build_saved_live_category_url(title, cid):
    query = urllib.parse.urlencode({
        "action": "tv_listing",
        "category": str(title or ""),
        "category_id": str(cid or ""),
        "page": "1",
        "update_listing": "False",
    })
    return "plugin://%s/?%s" % (ADDON_ID, query)

def _make_saved_live_category_item(title, source_listitem=None):
    item = xbmcgui.ListItem(str(title or ""))
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    try:
        _apply_default_fanart(item)
    except Exception:
        pass
    return item

def _make_gap_live_scan_item(source_listitem=None):
    item = xbmcgui.ListItem("[B]Leere Ordner nachscannen[/B]")
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _make_missing_m3u_repair_item(source_listitem=None):
    item = xbmcgui.ListItem("[B]Fehlende Sender zuordnen[/B]")
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _make_scope_scan_item(scope, missing_count=0, total_count=0, source_listitem=None):
    label = "[B]Gezielt zuordnen: %s[/B]" % _codex_scope_display_name(scope)
    if total_count:
        label += "  [COLOR FFCCAA00](offen: %s/%s)[/COLOR]" % (missing_count, total_count)
    item = xbmcgui.ListItem(label)
    try:
        if source_listitem is not None:
            art = source_listitem.getArt() or {}
            if art:
                item.setArt(art)
    except Exception:
        pass
    try:
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    return item

def _codex_live_scan_category_is_247(cat):
    try:
        title = str((cat or {}).get("title") or (cat or {}).get("name") or "").strip()
    except Exception:
        title = ""
    norm = _codex_ascii_norm(title)
    return "24 7" in norm or "247" in norm

def _codex_open_scope_scan_rows():
    try:
        snapshot = _codex_load_all_live_scan_snapshot()
        scanned = snapshot.get("seen") if isinstance(snapshot, dict) else []
        summary = _codex_m3u_missing_summary(_codex_all_m3u_refresh_scopes(), scanned or [])
        rows = []
        for scope in _codex_all_m3u_refresh_scopes():
            row = summary.get(scope) or {}
            missing = row.get("missing") or []
            total = int(row.get("total") or 0)
            if missing and total:
                rows.append((scope, len(missing), total))
        return rows
    except Exception as exc:
        _log("Could not build open scope scan rows: %s" % exc, xbmc.LOGWARNING if xbmc else None)
        return []

def _augment_live_category_items(items):
    if _current_plugin_action() not in ("tv", "live"):
        return items
    items = list(items or [])
    if not items:
        return items
    try:
        existing_ids = set()
        for url, _li, _isFolder, _totalItems in items:
            cid = _codex_category_id_from_url(url)
            if cid:
                existing_ids.add(str(cid).lower())
        source = items[0][1] if items else None
        added = 0
        for cat in _codex_saved_full_live_categories():
            cid = str(cat.get("id") or "").strip()
            title = str(cat.get("title") or "").strip()
            if not cid or not title or cid.lower() in existing_ids:
                continue
            url = _build_saved_live_category_url(title, cid)
            items.append((url, _make_saved_live_category_item(title, source), True, 0))
            existing_ids.add(cid.lower())
            added += 1
        if added:
            _log("Live TV categories augmented from saved snapshot: +%d (total=%d)" % (added, len(items)))
    except Exception as exc:
        _log("Could not augment live TV categories: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return items

def _inject_manual_switch_item(items):
    try:
        if _current_plugin_action() in ("tv", "live"):
            items = _augment_live_category_items(items)
            has_folder = any(bool(isFolder) for _url, _li, isFolder, _totalItems in items)
            if has_folder and not any(_get_action(url) == "codex_macsimum_all_scan" for url, _li, _isFolder, _totalItems in items):
                source = items[0][1] if items else None
                items.insert(0, (_build_all_live_scan_url(), _make_all_live_scan_item(source), False, 0))
            if has_folder and not any(_get_action(url) == "codex_macsimum_gap_scan" for url, _li, _isFolder, _totalItems in items):
                source = items[0][1] if items else None
                insert_at = 1 if any(_get_action(url) == "codex_macsimum_all_scan" for url, _li, _isFolder, _totalItems in items) else 0
                items.insert(insert_at, (_build_gap_live_scan_url(), _make_gap_live_scan_item(source), False, 0))
            if has_folder and not any(_get_action(url) == "codex_macsimum_missing_m3u_repair" for url, _li, _isFolder, _totalItems in items):
                source = items[0][1] if items else None
                insert_at = 2
                items.insert(insert_at, (_build_missing_m3u_repair_url(), _make_missing_m3u_repair_item(source), False, 0))
            try:
                source = items[0][1] if items else None
                existing_scope_scans = set()
                for url, _li, _isFolder, _totalItems in items:
                    if _get_action(url) != "codex_macsimum_scope_scan":
                        continue
                    try:
                        q = urllib.parse.parse_qs(urllib.parse.urlsplit(str(url or "")).query)
                        existing_scope_scans.add((q.get("scope") or [""])[0].strip().lower())
                    except Exception:
                        pass
                insert_at = 3
                added_scopes = 0
                for scope, missing_count, total_count in _codex_open_scope_scan_rows():
                    if scope in existing_scope_scans:
                        continue
                    items.insert(insert_at + added_scopes, (
                        _build_scope_scan_url(scope),
                        _make_scope_scan_item(scope, missing_count, total_count, source),
                        False,
                        0,
                    ))
                    existing_scope_scans.add(scope)
                    added_scopes += 1
                if added_scopes:
                    _log("Live TV added targeted scope scan entries: %s" % added_scopes)
            except Exception as scope_exc:
                _log("Could not inject targeted scope scan entries: %s" % scope_exc, xbmc.LOGWARNING if xbmc else None)
            return items
        if _is_root_media_listing(items):
            source = items[0][1] if items else None
            items = list(items)
            items = _hide_root_live_tv_entry(items)
            if not any(_get_action(url) == "codex_macsimum_favorites" for url, _li, _isFolder, _totalItems in items):
                items.append((_build_macsimum_favorites_url(), _make_macsimum_favorites_root_item(source), True, 0))
            return items
    except Exception as exc:
        _log("Could not inject favorites item: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return items

def _is_cacheable_category_nav(items):
    action = _current_plugin_action()
    if action in ("tv", "live", "seasons", "episodes", "episode", "play", "create_link", "nova_trailer_choice", "manual_mac_switch"):
        return False
    if _is_live_listing_path(_current_plugin_url()):
        return False
    if _is_root_media_listing(items):
        # CODEX: Root-Menü niemals als kleinen Kategorie-Cache speichern.
        # Nach dem Ausblenden von "Live TV" besteht der Root aus nur noch
        # Filme/Serien/Favoriten und darf nicht als Film-/Serien-Kategorie
        # wiederverwendet werden.
        _log("Category nav cache skipped: root media listing")
        return False
    visible = []
    folder_count = 0
    play_count = 0
    media_count = 0
    for url, li, isFolder, _totalItems in items or []:
        label = _get_label(li).strip()
        if not label or _should_hide_item(url, label, isFolder) or _is_next_page_label(label):
            continue
        child_action = _get_action(url)
        media_type = _get_media_type(li, url)
        visible.append((url, li, isFolder, child_action, media_type))
        if isFolder:
            folder_count += 1
        if child_action in ("play", "create_link", "vod_play", "movie", "movies"):
            play_count += 1
        if media_type in ("movie", "tvshow", "season", "episode"):
            media_count += 1
    if len(visible) < 3 or folder_count < 3:
        _log("Category nav cache skipped: visible=%d folders=%d action=%r" % (len(visible), folder_count, action))
        return False
    if play_count or media_count:
        _log("Category nav cache skipped: play=%d media=%d action=%r" % (play_count, media_count, action))
        return False
    for url, li, isFolder, child_action, _media_type in visible:
        label = _get_label(li).strip()
        if not isFolder and label.lower() not in ("all", "alle") and not _is_search_entry(label, child_action):
            _log("Category nav cache skipped: non-folder %r action=%r" % (_get_label(li), child_action))
            return False
        child_action = _get_action(url)
        if child_action in ("play", "create_link", "episode", "episodes", "seasons"):
            return False
    return True

def _load_category_nav_cache(path):
    # CODEX: Kategorie-Navigationscache deaktiviert; siehe _save_category_nav_cache.
    return None
    try:
        cache_path = _category_nav_cache_path()
        if not os.path.exists(cache_path):
            return None
        with open(cache_path, "r", encoding="utf-8-sig") as fh:
            data = json.load(fh)
        entry = data.get("entry")
        if not isinstance(entry, dict):
            return None
        if entry.get("path") != path:
            return None
        if time.time() - float(entry.get("ts") or 0) > CATEGORY_NAV_CACHE_TTL:
            return None
        items = entry.get("items")
        return items if isinstance(items, list) and items else None
    except Exception:
        return None

def _save_category_nav_cache(path, items):
    # CODEX: Kategorie-Navigationscache deaktiviert.
    # Grund: Nach Root-/Live-TV-UI-Anpassungen konnte ein unvollständiges
    # Filme-Menü ("FILM_SUCHE", "ALLE FILME", wenige EU/MULTI-Ordner)
    # gespeichert und später statt der echten DE-Kategorien angezeigt werden.
    # Korrektheit ist hier wichtiger als der kleine Speed-Vorteil.
    if not path or not _is_cacheable_category_nav(items):
        return
    return
    packed = []
    for url, li, isFolder, totalItems in items:
        try:
            art = li.getArt() or {}
        except Exception:
            art = {}
        packed.append({
            "label": _get_label(li),
            "url": url,
            "isFolder": bool(isFolder),
            "totalItems": int(totalItems or 0),
            "art": art,
        })
    try:
        cache_path = _category_nav_cache_path()
        with open(cache_path, "w", encoding="utf-8") as fh:
            json.dump({"entry": {"path": path, "ts": time.time(), "items": packed}}, fh, ensure_ascii=True, separators=(",", ":"))
        _log("Stored small category navigation cache with %d entries" % len(packed))
    except Exception as exc:
        _log("Could not store category navigation cache: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _clear_category_nav_cache(reason=""):
    try:
        cache_path = _category_nav_cache_path()
        if os.path.exists(cache_path):
            os.remove(cache_path)
            _log("Cleared category navigation cache%s" % ((": " + reason) if reason else ""))
    except Exception:
        pass

def _serve_category_nav_cache(argv):
    if not xbmcplugin or not xbmcgui or not isinstance(argv, (list, tuple)) or len(argv) < 3:
        return False
    path = _current_plugin_url()
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
        if qs.get("codex_force_refresh"):
            _log("Category nav cache bypassed for force refresh: %r" % path)
            return False
    except Exception:
        pass
    cached_items = _load_category_nav_cache(path)
    if not cached_items:
        return False
    try:
        handle = int(argv[1])
    except Exception:
        return False
    try:
        xbmcplugin.setContent(handle, "files")
    except Exception:
        pass
    for entry in cached_items:
        try:
            if _should_hide_item(entry.get("url") or "", entry.get("label") or "", bool(entry.get("isFolder"))):
                continue
            li = xbmcgui.ListItem(entry.get("label") or "")
            art = entry.get("art") if isinstance(entry.get("art"), dict) else {}
            if art:
                li.setArt(art)
            li.setProperty("IsPlayable", "false")
            _apply_default_fanart(li)
            xbmcplugin.addDirectoryItem(handle, entry.get("url") or "", li, bool(entry.get("isFolder")), int(entry.get("totalItems") or 0))
        except Exception:
            continue
    xbmcplugin.endOfDirectory(handle, True, False, True)
    _log("Served small category navigation cache for %r" % path)
    return True

def _is_macsimum_adult_movie_category(label):
    return (label or "").strip().upper().startswith("XXX")

def _should_hide_item(url, label="", is_folder=False):
    action = (_get_action(url) or "").strip().lower()
    if action in ("codex_macsimum_all_scan", "codex_macsimum_gap_scan") and _current_plugin_action() not in ("tv", "live"):
        return True
    if _current_plugin_action() == "vod" and is_folder and _is_macsimum_adult_movie_category(label):
        return True
    return False

def _is_search_label(label):
    if not isinstance(label, str):
        return False
    l = label.strip().lower()
    return ("search" in l) or ("suche" in l)

def _is_search_entry(label, action=""):
    action = (action or "").strip().lower()
    label = (label or "").strip().lower()
    return action.startswith("search") or "search" in label or "suche" in label


def _is_de_label(label):
    if not isinstance(label, str):
        return False
    l = label.strip().upper()
    return (
        l.startswith("DE") or
        l.startswith("DE-") or
        l.startswith("DE|") or
        l.startswith("GER") or
        l.startswith("DEUTSCH")
    )

def _is_prev_page_label(label):
    text = (label or "").lower()
    return "vorher" in text or "vorige" in text or "zurück" in text or "zurueck" in text or "previous" in text or "<<<" in text

def _query_from_url(url):
    try:
        return urllib.parse.parse_qs(urllib.parse.urlsplit(url or "").query, keep_blank_values=True)
    except Exception:
        return {}

def _first_int_from_text(value):
    try:
        match = re.search(r"\d+", str(value or ""))
        if match:
            return int(match.group(0))
    except Exception:
        pass
    return 0

def _decode_cmd_json_from_url(url):
    try:
        raw = (_query_from_url(url).get("cmd") or [""])[0]
        if not raw:
            return {}
        raw = urllib.parse.unquote(raw)
        padded = raw + ("=" * ((4 - len(raw) % 4) % 4))
        decoded = base64.b64decode(padded).decode("utf-8", "ignore")
        data = json.loads(decoded)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _stalker_numeric_id_from_entry(entry):
    try:
        url, li, _isFolder, _totalItems = entry
    except Exception:
        return 0
    qs = _query_from_url(url)
    for key in ("stream_id", "movie_id", "series_id", "video_id", "id", "episode_id", "episod_id"):
        number = _first_int_from_text((qs.get(key) or [""])[0])
        if number:
            return number
    cmd = _decode_cmd_json_from_url(url)
    for key in ("stream_id", "movie_id", "series_id", "video_id", "id", "episode_id", "episod_id"):
        number = _first_int_from_text(cmd.get(key))
        if number:
            return number
    try:
        for key in ("stream_id", "movie_id", "series_id", "video_id", "id", "episode_id", "episod_id"):
            number = _first_int_from_text(li.getProperty(key))
            if number:
                return number
    except Exception:
        pass
    return 0

def _sort_title_listing_newest_first(items):
    if _current_plugin_action() not in ("listing", "ser_listing"):
        return None
    if _content_for_items(items) not in ("movies", "tvshows"):
        return None

    prev_items = []
    next_items = []
    sortable = []
    unsorted_items = []
    for idx, entry in enumerate(items):
        try:
            label = _get_label(entry[1])
        except Exception:
            label = ""
        if _is_prev_page_label(label):
            prev_items.append(entry)
            continue
        if _is_next_page_label(label):
            next_items.append(entry)
            continue
        numeric_id = _stalker_numeric_id_from_entry(entry)
        if numeric_id:
            sortable.append((numeric_id, idx, entry))
        else:
            unsorted_items.append((idx, entry))

    if len(sortable) < 2:
        return None
    sortable.sort(key=lambda row: (-row[0], row[1]))
    return prev_items + [entry for _num, _idx, entry in sortable] + [entry for _idx, entry in unsorted_items] + next_items


def _sort_buffer(items):
    if _current_plugin_action() == "codex_macsimum_favorites":
        clear_items = []
        favorite_items = []
        for entry in items:
            try:
                url, _li, _isFolder, _totalItems = entry
                if _get_action(url) == "codex_macsimum_clear_favorites":
                    clear_items.append(entry)
                else:
                    favorite_items.append(entry)
            except Exception:
                favorite_items.append(entry)
        return clear_items + favorite_items

    # Reihenfolge gemäß Vorgabe:
    # 1) erster Search/Suche-Eintrag
    # 2) alle DE-/GER-/DEUTSCH-Kategorien
    # 3) alle übrigen Kategorien
    # Innerhalb der Gruppen bleibt die ursprüngliche Reihenfolge erhalten.
    search_item = None
    de_items = []
    other_items = []

    for entry in items:
        url, li, isFolder, totalItems = entry
        label = _get_label(li)

        if search_item is None and _is_search_label(label):
            search_item = entry
        elif _is_de_label(label):
            de_items.append(entry)
        else:
            other_items.append(entry)

    ordered = de_items + other_items
    if search_item is not None:
        return [search_item] + ordered
    return ordered

def _patch_kodi_url_handoffs():
    if not xbmcplugin:
        return
    try:
        _orig_setResolvedUrl = xbmcplugin.setResolvedUrl
        def _setResolvedUrl(handle, succeeded, listitem):
            try:
                resolved_path = ""
                if listitem is not None:
                    try:
                        resolved_path = listitem.getPath() or ""
                    except Exception:
                        resolved_path = ""
                    if resolved_path:
                        rewritten_path = _rewrite_url(resolved_path)
                        if rewritten_path != resolved_path:
                            _log(f"Rewrite playback URL: {resolved_path!r} -> {rewritten_path!r}")
                            try:
                                listitem.setPath(rewritten_path)
                            except Exception:
                                li = xbmcgui.ListItem(label=getattr(listitem, "getLabel", lambda: "")())
                                li.setPath(rewritten_path)
                                listitem = li
                            resolved_path = rewritten_path
                    _apply_resume_offset(listitem, resolved_path)
            except Exception as e:
                _log(f"setResolvedUrl patch error: {e}", xbmc.LOGWARNING if xbmc else None)
            return _orig_setResolvedUrl(handle, succeeded, listitem)
        xbmcplugin.setResolvedUrl = _setResolvedUrl
    except Exception as e:
        _log(f"Failed to patch setResolvedUrl: {e}", xbmc.LOGERROR if xbmc else None)

    try:
        _orig_setContent = xbmcplugin.setContent
        _orig_addDirectoryItem = xbmcplugin.addDirectoryItem
        _orig_addDirectoryItems = xbmcplugin.addDirectoryItems
        _orig_endOfDirectory = xbmcplugin.endOfDirectory

        def _setContent(handle, content):
            global _CURRENT_CONTENT
            try:
                _CURRENT_CONTENT = str(content or "").lower()
            except Exception:
                _CURRENT_CONTENT = ""
            return _orig_setContent(handle, content)

        def _addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
            if isinstance(url, str):
                url = _rewrite_url(url)
            if _should_hide_item(url, _get_label(listitem), isFolder):
                _log(f"Hide menu item: {_get_label(listitem)!r} -> {url!r}")
                return True
            _apply_listitem_metadata(listitem, url=url, isFolder=isFolder)
            try:
                action = _get_action(url)
                if action in ("seasons", "season", "episodes", "episode"):
                    _log("Series navigation item: label=%r folder=%s action=%r url=%r" % (_get_label(listitem), isFolder, action, url))
            except Exception:
                pass
            _normalize_season_listitem_label(listitem, url, isFolder)
            if _is_next_page_label(_get_label(listitem)):
                _apply_next_page_art(listitem)
            url, isFolder = _maybe_wrap_trailer_choice(url, listitem, isFolder)
            _DIR_BUFFER.setdefault(int(handle), []).append((url, listitem, isFolder, totalItems))
            return True

        def _addDirectoryItems(handle, items, totalItems=0):
            buf = _DIR_BUFFER.setdefault(int(handle), [])
            for item in items:
                try:
                    url, li, isFolder = item
                except Exception:
                    continue
                if isinstance(url, str):
                    url = _rewrite_url(url)
                if _should_hide_item(url, _get_label(li), isFolder):
                    _log(f"Hide menu item: {_get_label(li)!r} -> {url!r}")
                    continue
                _apply_listitem_metadata(li, url=url, isFolder=isFolder)
                try:
                    action = _get_action(url)
                    if action in ("seasons", "season", "episodes", "episode"):
                        _log("Series navigation item: label=%r folder=%s action=%r url=%r" % (_get_label(li), isFolder, action, url))
                except Exception:
                    pass
                _normalize_season_listitem_label(li, url, isFolder)
                if _is_next_page_label(_get_label(li)):
                    _apply_next_page_art(li)
                url, isFolder = _maybe_wrap_trailer_choice(url, li, isFolder)
                buf.append((url, li, isFolder, totalItems))
            return True

        def _endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
            global _CURRENT_CONTENT
            h = int(handle)
            items = _DIR_BUFFER.pop(h, None)
            if items:
                try:
                    inferred = _content_for_items(items)
                    if inferred and _CURRENT_CONTENT not in ("movies", "tvshows", "seasons", "episodes"):
                        _orig_setContent(h, inferred)
                        _CURRENT_CONTENT = inferred
                except Exception:
                    pass
                if succeeded and _can_remember_current_mac_for_current_view(items):
                    _remember_current_mac(_current_module_mac())
                _sync_title_view_before_end(items)
                sorted_items = _sort_buffer(items)
                sorted_items = _inject_manual_switch_item(sorted_items)
                _save_category_nav_cache(_current_plugin_url(), sorted_items)
                for url, li, isFolder, totalItems in sorted_items:
                    _orig_addDirectoryItem(h, url, li, isFolder, totalItems)
            elif succeeded and _current_plugin_action() == "tv_listing":
                try:
                    if _add_live_scan_fallback_directory(h, _orig_addDirectoryItem):
                        cacheToDisc = True
                except Exception as exc:
                    _log("Live TV category fallback failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            elif succeeded and _current_plugin_action() in ("vod", "series", "listing", "seasons", "episodes", "search", "ser_listing"):
                _log("Empty Macsimum listing finished without cache so the next open can retry", xbmc.LOGWARNING if xbmc else None)
                cacheToDisc = False
            return _orig_endOfDirectory(h, succeeded, updateListing, cacheToDisc)

        xbmcplugin.setContent = _setContent
        xbmcplugin.addDirectoryItem = _addDirectoryItem
        xbmcplugin.addDirectoryItems = _addDirectoryItems
        xbmcplugin.endOfDirectory = _endOfDirectory
    except Exception as e:
        _log(f"Failed to patch directory sorting: {e}", xbmc.LOGERROR if xbmc else None)

_patch_json_metadata()
_patch_socket_dns()
_patch_requests()
_patch_urllib()
_patch_kodi_url_handoffs()

_DIR = os.path.dirname(__file__)
_PYC = os.path.join(_DIR, "addon.pyc")

def _load_impl():
    loader = importlib.machinery.SourcelessFileLoader("lib._addon_impl", _PYC)
    spec = importlib.util.spec_from_loader(loader.name, loader)
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    return mod

_IMPL = None
def _impl():
    global _IMPL
    if _IMPL is None:
        _IMPL = _load_impl()
    return _IMPL

def _reset_impl_for_retry():
    global _IMPL, _DIR_BUFFER, _CURRENT_REQUEST_MAC
    _IMPL = None
    _CURRENT_REQUEST_MAC = ""
    _DIR_BUFFER.clear()
    for name in (
        "lib._addon_impl",
        "lib.service",
        "lib.config",
        "lib.stalker_net",
        "lib.tmdb",
        "lib.utils",
    ):
        try:
            sys.modules.pop(name, None)
        except Exception:
            pass

def _macsimum_native_service(prefix=""):
    try:
        mod, _pinned_mac = _prepare_usable_impl()
        if mod is None and _action_needs_portal_token():
            raise Exception("Keine nutzbare Portal-Session")
        import lib.service as native_service
        return native_service
    except Exception as exc:
        _log("%s native service unavailable: %s" % (prefix, exc), xbmc.LOGWARNING if xbmc else None)
        raise

def _macsimum_reload_native(prefix=""):
    try:
        _reset_impl_for_retry()
        _prepare_usable_impl()
        import lib.service as native_service
        _log("%s reloaded Macsimum native session" % prefix, xbmc.LOGWARNING if xbmc else None)
        return native_service
    except Exception as exc:
        _log("%s reload failed: %s" % (prefix, exc), xbmc.LOGWARNING if xbmc else None)
        raise

def _macsimum_extract_category_list(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        js = payload.get("js")
        if isinstance(js, list):
            return js
        if isinstance(js, dict):
            for key in ("data", "items", "categories", "genres"):
                value = js.get(key)
                if isinstance(value, list):
                    return value
        for key in ("data", "items", "categories", "genres"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
    return []

def _macsimum_category_label(cat):
    try:
        if isinstance(cat, dict):
            for key in ("title", "name", "category_name", "genre", "label"):
                value = cat.get(key)
                if value:
                    return str(value)
            return json.dumps(cat, ensure_ascii=False, sort_keys=True)
        return str(cat or "")
    except Exception:
        return ""

def _macsimum_categories_look_complete(label, cats):
    label_key = (label or "").strip().lower()
    if label_key not in ("vod", "series"):
        return True
    count = len(cats or [])
    labels = [_macsimum_category_label(cat) for cat in (cats or [])]
    visible = [value.strip() for value in labels if value and value.strip()]
    joined = " | ".join(visible).lower()
    if count < 8:
        _log(
            "CODEX-MACSIMUM-%s warmup rejects suspicious tiny category set: %d labels=%s" % (
                label_key.upper(),
                count,
                " / ".join(visible[:8]),
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
        return False
    if count <= 12 and not any(value.lower().startswith("de") or "de " in value.lower() or "deutsch" in value.lower() for value in visible):
        _log(
            "CODEX-MACSIMUM-%s warmup rejects category set without DE folders: %d labels=%s" % (
                label_key.upper(),
                count,
                " / ".join(visible[:8]),
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
        return False
    if count <= 12 and ("amazon" in joined or "disney" in joined or "netflix" in joined) and "de" not in joined:
        _log(
            "CODEX-MACSIMUM-%s warmup rejects streaming-only mini menu: %d labels=%s" % (
                label_key.upper(),
                count,
                " / ".join(visible[:8]),
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
        return False
    return True

def _macsimum_extract_channel_page(payload):
    if isinstance(payload, list):
        return payload, 0, 0
    if isinstance(payload, dict):
        src = payload.get("js") if isinstance(payload.get("js"), dict) else payload
        data = []
        for key in ("data", "items", "episodes", "series", "channels"):
            value = src.get(key) if isinstance(src, dict) else None
            if isinstance(value, list):
                data = value
                break
        try:
            total = int(src.get("total_items") or src.get("total") or 0) if isinstance(src, dict) else 0
        except Exception:
            total = 0
        try:
            page_items = int(src.get("max_page_items") or src.get("page_items") or 0) if isinstance(src, dict) else 0
        except Exception:
            page_items = 0
        return data, total, page_items
    return [], 0, 0

def _macsimum_has_payload(result):
    if isinstance(result, str):
        return bool(result.strip())
    if isinstance(result, list):
        return bool(result)
    if isinstance(result, dict):
        data, _total, _page_items = _macsimum_extract_channel_page(result)
        if data:
            return True
        cats = _macsimum_extract_category_list(result)
        if cats:
            return True
        return bool(result)
    return bool(result)

def _macsimum_rotate_native(native_service, reason):
    try:
        before = _current_module_mac()
        _mac_analytics_log("native-rotate-call", before=before, reason=reason)
        rotator = getattr(native_service, "rotate_mac_now", None)
        if callable(rotator):
            rotator(reason)
            _mac_analytics_log("native-rotate-return", before=before, after=_current_module_mac(), reason=reason)
            return True
    except Exception as exc:
        _mac_analytics_log("native-rotate-error", reason="%s: %s" % (reason, exc))
        _log("MAC rotation failed (%s): %s" % (reason, exc), xbmc.LOGWARNING if xbmc else None)
    return False

def _macsimum_warmup_native(prefix="MACSIMUM-WARMUP", rotate_on_empty=True, max_attempts=3, targets=None):
    native_service = _macsimum_native_service(prefix)
    if targets == "vod":
        warmup_targets = (("VOD", "get_categories"),)
    elif targets == "series":
        warmup_targets = (("series", "get_ser_categories"),)
    elif targets == "live":
        warmup_targets = (("LIVE", "get_tv_genres"),)
    else:
        warmup_targets = (("VOD", "get_categories"), ("series", "get_ser_categories"))
    for label, getter_name in warmup_targets:
        getter = getattr(native_service, getter_name, None)
        if not callable(getter):
            continue
        attempts = max(1, int(max_attempts or 1))
        for attempt in range(1, attempts + 1):
            try:
                warm = getter()
                cats = _macsimum_extract_category_list(warm)
                if cats:
                    if not _macsimum_categories_look_complete(label, cats):
                        cats = []
                    else:
                        scope = "series" if label.lower() == "series" else ("live" if label.lower() == "live" else "vod")
                        _log("%s %s warmup ok: %d categories" % (prefix, label, len(cats)))
                        _remember_current_mac(_current_module_mac(), scope=scope)
                        return True
                _log("%s %s warmup empty (%d/%d)" % (prefix, label, attempt, attempts), xbmc.LOGWARNING if xbmc else None)
            except Exception as exc:
                _log("%s %s warmup failed (%d/%d): %s" % (prefix, label, attempt, attempts, exc), xbmc.LOGWARNING if xbmc else None)
            if attempt < attempts and rotate_on_empty:
                _macsimum_rotate_native(native_service, "%s %s warmup retry %d" % (prefix, label, attempt))
                try:
                    time.sleep(0.65 + (0.20 * attempt))
                except Exception:
                    pass
    return False

def _macsimum_retry_call(func_factory, prefix, outer_attempts=6, inner_attempts=2):
    last_exc = None
    native_service = _macsimum_native_service(prefix)
    for outer in range(1, int(outer_attempts) + 1):
        for inner in range(1, int(inner_attempts) + 1):
            try:
                func = func_factory(native_service)
                result = func()
                if _macsimum_has_payload(result):
                    if outer > 1 or inner > 1:
                        _log("%s recovered on attempt %s.%s" % (prefix, outer, inner), xbmc.LOGWARNING if xbmc else None)
                    return result
                _log("%s empty result on attempt %s.%s" % (prefix, outer, inner), xbmc.LOGWARNING if xbmc else None)
            except Exception as exc:
                last_exc = exc
                _log("%s failed on attempt %s.%s: %s" % (prefix, outer, inner, exc), xbmc.LOGWARNING if xbmc else None)
            if inner < int(inner_attempts):
                try:
                    time.sleep(0.25 + (0.08 * inner))
                except Exception:
                    pass
        if outer < int(outer_attempts):
            _macsimum_rotate_native(native_service, "%s retry %s/%s" % (prefix, outer, outer_attempts))
            native_service = _macsimum_reload_native(prefix)
            _macsimum_warmup_native(prefix, rotate_on_empty=False)
            try:
                time.sleep(0.35 + (0.12 * outer))
            except Exception:
                pass
    if last_exc:
        raise last_exc
    return {}

def _macsimum_mac_from_stream_url(stream_url):
    try:
        parsed = urllib.parse.urlsplit(str(stream_url or "").split("|", 1)[0])
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        mac = (qs.get("mac") or [""])[0]
        if mac:
            return mac.strip()
    except Exception:
        pass
    return ""

def _macsimum_stream_headers_from_native(native_service, stream_url=""):
    headers = {}
    preferred_stream_mac = _macsimum_mac_from_stream_url(stream_url) or _preferred_mac_from_state()
    try:
        candidates = [native_service]
        for module_name in ("lib.service", "resources.lib.service", "service"):
            module = sys.modules.get(module_name)
            if module is not None and module not in candidates:
                candidates.append(module)
        for candidate in list(sys.modules.values()):
            try:
                if getattr(candidate, "stalker_portal", None) is not None and candidate not in candidates:
                    candidates.append(candidate)
            except Exception:
                pass
        for candidate in candidates:
            portal = getattr(candidate, "stalker_portal", None)
            if portal is None:
                continue
            for method_name in ("headers", "headers_2", "get_headers"):
                try:
                    method = getattr(portal, method_name, None)
                    if callable(method):
                        got = method() or {}
                        if isinstance(got, dict):
                            headers.update(got)
                except Exception:
                    pass
            try:
                mac = preferred_stream_mac or getattr(portal, "mac", "") or ""
                if mac:
                    for existing_key in list(headers.keys()):
                        if str(existing_key).lower() == "cookie":
                            headers.pop(existing_key, None)
                    headers["Cookie"] = "mac=%s; stb_lang=en; timezone=Europe/Amsterdam" % mac
            except Exception:
                pass
            try:
                referer = getattr(portal, "org_url", "") or getattr(portal, "url", "") or ""
                if referer and not any(str(k).lower() == "referer" for k in headers.keys()):
                    headers["Referer"] = referer
            except Exception:
                pass
            break
    except Exception:
        pass
    if not any(str(k).lower() == "user-agent" for k in headers.keys()):
        headers["User-Agent"] = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
    if not any(str(k).lower() == "x-user-agent" for k in headers.keys()):
        headers["X-User-Agent"] = "Model: MAG250; Link: WiFi"
    clean = {}
    allowed = {"user-agent", "referer", "cookie", "x-user-agent", "accept", "connection"}
    for key, value in (headers or {}).items():
        if str(key).lower() in allowed and value:
            clean[str(key)] = str(value)
    return clean

def _macsimum_with_stream_headers(stream_url, native_service):
    if not stream_url or "|" in stream_url:
        return stream_url
    try:
        headers = _macsimum_stream_headers_from_native(native_service, stream_url)
        if headers:
            return stream_url + "|" + urllib.parse.urlencode(headers)
    except Exception:
        pass
    return stream_url

def _macsimum_live_stream_rejected(stream_url, native_service, prefix="CODEX-MACSIMUM-TV-PLAY"):
    if not stream_url:
        return True
    try:
        check_url = stream_url.split("|", 1)[0]
        headers = _macsimum_stream_headers_from_native(native_service, check_url)
        headers["Range"] = "bytes=0-0"
        req = urllib.request.Request(check_url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=2.2) as response:
            code = int(getattr(response, "status", 0) or getattr(response, "code", 0) or 0)
            if code >= 400:
                _log("%s quick stream check rejected HTTP %s" % (prefix, code), xbmc.LOGWARNING if xbmc else None)
                return True
            return False
    except urllib.error.HTTPError as exc:
        code = int(getattr(exc, "code", 0) or 0)
        if code in (401, 403, 404, 409, 410, 451, 500, 502, 503, 504, 509):
            _log("%s quick stream check rejected HTTP %s" % (prefix, code), xbmc.LOGWARNING if xbmc else None)
            return True
        _log("%s quick stream check HTTP %s allowed to Kodi" % (prefix, code), xbmc.LOGWARNING if xbmc else None)
        return False
    except Exception as exc:
        # Timeouts or servers that dislike byte-range probing are not treated as
        # dead. Kodi may still be able to open them, so do not burn MACs here.
        _log("%s quick stream check inconclusive: %s" % (prefix, exc), xbmc.LOGWARNING if xbmc else None)
        return False

def _macsimum_resolve_vod_stream(cmd):
    if not cmd:
        return ""
    _macsimum_warmup_native("CODEX-MACSIMUM-VOD-PLAY-PRE", rotate_on_empty=False, max_attempts=1, targets="vod")
    def _factory(native_service):
        def _play():
            portal = getattr(native_service, "stalker_portal", None)
            if portal is not None and hasattr(portal, "get_stream_link"):
                try:
                    direct = portal.get_stream_link(cmd, content_type="vod")
                    if direct:
                        return _macsimum_with_stream_headers(direct, native_service)
                except Exception as direct_exc:
                    _log("CODEX-MACSIMUM-VOD-PLAY direct portal failed: %s" % direct_exc, xbmc.LOGWARNING if xbmc else None)
            stream = native_service.get_vod_stream_url(cmd, max_attempts=1)
            return _macsimum_with_stream_headers(stream, native_service)
        return _play
    return _macsimum_retry_call(_factory, "CODEX-MACSIMUM-VOD-PLAY", outer_attempts=1, inner_attempts=1)

def _macsimum_norm_lookup_title(value):
    try:
        text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii")
    except Exception:
        text = str(value or "")
    text = re.sub(r"\[[^\]]+\]|\([^\)]*\)", " ", text)
    text = re.sub(r"[^a-zA-Z0-9]+", " ", text).strip().lower()
    return re.sub(r"\s+", " ", text)

def _macsimum_item_title(item):
    if not isinstance(item, dict):
        return ""
    for key in ("name", "title", "o_name", "original_name", "movie_title"):
        value = item.get(key)
        if value:
            return str(value).strip()
    return ""

def _macsimum_year_from_item(item):
    if not isinstance(item, dict):
        return ""
    for key in ("year", "released", "release_date", "added"):
        match = re.search(r"\b(19|20)\d{2}\b", str(item.get(key) or ""))
        if match:
            return match.group(0)
    return ""

def _macsimum_build_vod_cmd_from_item(item, old_cmd=""):
    if not isinstance(item, dict):
        return ""
    for key in ("cmd", "mc_cmd", "command"):
        value = item.get(key)
        if value:
            return str(value)
    old_payload = {}
    try:
        padded = str(old_cmd or "") + ("=" * ((4 - len(str(old_cmd or "")) % 4) % 4))
        old_payload = json.loads(base64.b64decode(padded).decode("utf-8", "ignore"))
        if not isinstance(old_payload, dict):
            old_payload = {}
    except Exception:
        old_payload = {}
    stream_id = ""
    for key in ("stream_id", "id", "movie_id", "video_id"):
        value = item.get(key)
        if value not in (None, "", [], {}):
            stream_id = str(value).split(":", 1)[0].strip()
            break
    if not stream_id:
        return ""
    stream_source = item.get("stream_source")
    if stream_source in ("", [], {}):
        stream_source = None
    target_container = item.get("target_container")
    if target_container in (None, "", [], {}):
        target_container = old_payload.get("target_container") or "[\"mkv\"]"
    payload = {
        "type": "movie",
        "stream_id": stream_id,
        "stream_source": stream_source,
        "target_container": target_container,
    }
    try:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return base64.b64encode(raw).decode("ascii").rstrip("=")
    except Exception:
        return ""

def _macsimum_fresh_vod_cmd_for_favorite(title, year="", old_cmd=""):
    clean_title = _clean_choice_title(title)
    lookup = _macsimum_norm_lookup_title(clean_title)
    if not lookup:
        return ""
    wanted_year = ""
    match = re.search(r"\b(19|20)\d{2}\b", str(year or ""))
    if match:
        wanted_year = match.group(0)
    try:
        _macsimum_warmup_native("CODEX-MACSIMUM-FAVORITES-VOD-LOOKUP", rotate_on_empty=False, max_attempts=1, targets="vod")
        import lib.service as native_service
        categories = []
        try:
            categories = native_service.get_categories() or []
        except Exception as cat_exc:
            _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup categories failed: %s" % cat_exc, xbmc.LOGWARNING if xbmc else None)
        search_targets = [("", "global")]
        for cat in categories or []:
            if not isinstance(cat, dict):
                continue
            cid = str(cat.get("id") or cat.get("category_id") or "").strip()
            cname = str(cat.get("title") or cat.get("name") or cid).strip()
            if cid:
                search_targets.append((cid, cname))
        best_item = None
        best_score = -1
        request_count = 0
        tokens = [token for token in lookup.split() if len(token) > 1]
        for cid, cname in search_targets[:45]:
            try:
                if request_count:
                    time.sleep(0.08)
                request_count += 1
                result = native_service.get_videos(cid, 1, clean_title)
                data = result.get("data") if isinstance(result, dict) else []
            except Exception as search_exc:
                _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup search failed category=%s: %s" % (cname, search_exc), xbmc.LOGWARNING if xbmc else None)
                continue
            for item in data or []:
                item_title = _macsimum_item_title(item)
                item_norm = _macsimum_norm_lookup_title(item_title)
                if not item_norm:
                    continue
                score = 0
                if item_norm == lookup:
                    score += 100
                elif lookup in item_norm:
                    score += 50
                elif all(token in item_norm.split() for token in tokens):
                    score += 35
                else:
                    continue
                item_year = _macsimum_year_from_item(item)
                if wanted_year and item_year == wanted_year:
                    score += 25
                elif wanted_year and item_year and item_year != wanted_year:
                    score -= 15
                if score > best_score:
                    best_score = score
                    best_item = item
                if score >= 125:
                    fresh_cmd = _macsimum_build_vod_cmd_from_item(item, old_cmd)
                    if fresh_cmd:
                        _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup exact: title=%r category=%r requests=%d stream_id=%s" % (
                            clean_title,
                            cname,
                            request_count,
                            str(item.get("stream_id") or item.get("id") or "")[:24],
                        ), xbmc.LOGWARNING if xbmc else None)
                        return fresh_cmd
            if best_score >= 100 and best_item is not None:
                fresh_cmd = _macsimum_build_vod_cmd_from_item(best_item, old_cmd)
                if fresh_cmd:
                    _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup best: title=%r category=%r requests=%d score=%d stream_id=%s" % (
                        clean_title,
                        cname,
                        request_count,
                        best_score,
                        str(best_item.get("stream_id") or best_item.get("id") or "")[:24],
                    ), xbmc.LOGWARNING if xbmc else None)
                    return fresh_cmd
        if best_item is not None:
            fresh_cmd = _macsimum_build_vod_cmd_from_item(best_item, old_cmd)
            if fresh_cmd:
                _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup loose: title=%r requests=%d score=%d stream_id=%s" % (
                    clean_title,
                    request_count,
                    best_score,
                    str(best_item.get("stream_id") or best_item.get("id") or "")[:24],
                ), xbmc.LOGWARNING if xbmc else None)
                return fresh_cmd
        _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup no match: title=%r requests=%d" % (clean_title, request_count), xbmc.LOGWARNING if xbmc else None)
    except Exception as exc:
        _log("CODEX-MACSIMUM-FAVORITES-VOD fresh lookup failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return ""

def _macsimum_resolve_episode_stream(video_id, series, cmd=""):
    if not video_id and not cmd:
        return ""
    _macsimum_warmup_native("CODEX-MACSIMUM-SERIES-EP-PLAY-PRE", rotate_on_empty=False, max_attempts=1, targets="series")
    def _factory(native_service):
        def _play():
            portal = getattr(native_service, "stalker_portal", None)
            tried_cmds = set()
            if portal is not None and hasattr(portal, "get_stream_link"):
                try:
                    for candidate in (cmd, video_id):
                        candidate = str(candidate or "").strip()
                        if not candidate or candidate in tried_cmds:
                            continue
                        tried_cmds.add(candidate)
                        direct = portal.get_stream_link(candidate, content_type="series", ep_id=series or video_id)
                        if direct:
                            return _macsimum_with_stream_headers(direct, native_service)
                except Exception as direct_exc:
                    _log("CODEX-MACSIMUM-SERIES-EP-PLAY direct portal failed: %s" % direct_exc, xbmc.LOGWARNING if xbmc else None)
            if not video_id:
                return ""
            fallback_cmd = "/media/%s.mpg" % str(video_id or "").strip()
            if fallback_cmd in tried_cmds:
                return ""
            stream = native_service.get_episode_stream_url(video_id, series or video_id, max_attempts=1)
            return _macsimum_with_stream_headers(stream, native_service)
        return _play
    native_service = _macsimum_native_service("CODEX-MACSIMUM-SERIES-EP-PLAY")
    last_exc = None
    for attempt in range(1, 3):
        if attempt > 1:
            before = _current_module_mac()
            _log(
                "CODEX-MACSIMUM-SERIES-EP-PLAY empty create_link; rotate once for same episode before=%s" % _redact_mac(before),
                xbmc.LOGWARNING if xbmc else None,
            )
            if not _macsimum_rotate_native(native_service, "CODEX-MACSIMUM-SERIES-EP-PLAY playable episode retry"):
                break
            after = _current_module_mac()
            if after:
                try:
                    _remember_current_mac(after)
                except Exception:
                    pass
            if not _current_module_token():
                _log(
                    "CODEX-MACSIMUM-SERIES-EP-PLAY retry stopped: rotated session has no token after=%s" % _redact_mac(after),
                    xbmc.LOGWARNING if xbmc else None,
                )
                break
            try:
                getter = getattr(native_service, "get_ser_categories", None)
                if callable(getter):
                    warm = getter() or []
                    count = len(warm) if isinstance(warm, list) else 0
                    _log(
                        "CODEX-MACSIMUM-SERIES-EP-PLAY retry series warmup ok: %s categories after=%s" % (count, _redact_mac(after)),
                        xbmc.LOGWARNING if xbmc else None,
                    )
            except Exception as warm_exc:
                _log("CODEX-MACSIMUM-SERIES-EP-PLAY retry series warmup failed: %s" % warm_exc, xbmc.LOGWARNING if xbmc else None)
        try:
            result = _factory(native_service)()
            if _macsimum_has_payload(result):
                if attempt > 1:
                    _log("CODEX-MACSIMUM-SERIES-EP-PLAY recovered on controlled MAC retry", xbmc.LOGWARNING if xbmc else None)
                return result
            _log("CODEX-MACSIMUM-SERIES-EP-PLAY empty result on controlled attempt %s/2" % attempt, xbmc.LOGWARNING if xbmc else None)
        except Exception as exc:
            last_exc = exc
            _log("CODEX-MACSIMUM-SERIES-EP-PLAY failed on controlled attempt %s/2: %s" % (attempt, exc), xbmc.LOGWARNING if xbmc else None)
    if last_exc:
        raise last_exc
    return {}

def _codex_live_variant_rank(name, preferred=""):
    norm = " " + _codex_ascii_norm(name) + " "
    preferred_norm = " " + _codex_ascii_norm(preferred) + " "

    def has_quality(text, *tokens):
        return any((" " + token + " ") in text for token in tokens)

    quality_groups = (
        ("FHD", ("FHD", "FULLHD")),
        ("HD", ("HD",)),
        ("HEVC", ("HEVC",)),
        ("RAW", ("RAW",)),
        ("UHD", ("UHD", "4K")),
        ("2K", ("2K",)),
        ("SD", ("SD",)),
    )
    preferred_quality = ""
    for quality, tokens in quality_groups:
        if has_quality(preferred_norm, *tokens):
            preferred_quality = quality
            break
    own_quality = ""
    for quality, tokens in quality_groups:
        if has_quality(norm, *tokens):
            own_quality = quality
            break
    if preferred_quality and own_quality == preferred_quality:
        return 0
    order = {"FHD": 1, "HD": 2, "HEVC": 3, "UHD": 4, "2K": 5, "RAW": 6, "SD": 7, "": 8}
    return order.get(own_quality, 9)

def _codex_live_fallback_cmds(label, current_cmd, limit=3):
    cmds = []
    seen_cmds = set()
    current_cmd = str(current_cmd or "").strip()
    if current_cmd:
        cmds.append(current_cmd)
        seen_cmds.add(current_cmd)
    base_key = _codex_channel_match_key(label)
    if not base_key:
        return cmds
    payload = _codex_load_all_live_scan_snapshot()
    raw = payload.get("seen") if isinstance(payload, dict) else []
    if not isinstance(raw, list):
        return cmds
    candidates = []
    for row in raw:
        if not isinstance(row, dict):
            continue
        name = _codex_channel_title(row)
        row_cmd = _codex_channel_cmd(row)
        if not name or not row_cmd or row_cmd in seen_cmds:
            continue
        if _codex_channel_match_key(name) != base_key:
            continue
        candidates.append((_codex_live_variant_rank(name, label), _codex_ascii_norm(name), name, row_cmd))
    candidates.sort()
    for _rank, _norm_name, name, row_cmd in candidates:
        if row_cmd in seen_cmds:
            continue
        cmds.append(row_cmd)
        seen_cmds.add(row_cmd)
        _log("CODEX-MACSIMUM-TV-PLAY sibling fallback candidate: %s -> %s" % (label or "-", name), xbmc.LOGWARNING if xbmc else None)
        if len(cmds) >= max(1, int(limit or 3)):
            break
    return cmds

def _macsimum_resolve_tv_stream(cmd, label=""):
    if not cmd:
        return ""
    # Live-TV-3/PlaylistLoader-Bridge: einfacher Juli/9-Abspielweg, aber ohne
    # MAC-Rotation bei einem einzelnen toten/nicht freigegebenen Sender.
    # Wichtig: Wenn create_link fuer einen Kanal nur {} liefert, ist das ein
    # Sender-Fehler, kein Grund die komplette Portal-Session zu verbrennen.
    live_warmup_ok = _macsimum_warmup_native(
        "CODEX-MACSIMUM-TV-PLAY-PRE",
        rotate_on_empty=False,
        max_attempts=1,
        targets="live",
    )
    if not live_warmup_ok:
        _log(
            "CODEX-MACSIMUM-TV-PLAY-PRE live warmup not ready; continuing with current token only, no MAC rotation",
            xbmc.LOGWARNING if xbmc else None,
        )

    try:
        native_service = _macsimum_native_service("CODEX-MACSIMUM-TV-PLAY")
    except Exception as svc_exc:
        _log("CODEX-MACSIMUM-TV-PLAY service unavailable: %s" % svc_exc, xbmc.LOGWARNING if xbmc else None)
        _clear_current_mac_from_state("live bridge service unavailable: %s" % svc_exc)
        return ""

    portal = getattr(native_service, "stalker_portal", None)
    if portal is not None and hasattr(portal, "get_stream_link"):
        try:
            direct = portal.get_stream_link(cmd, content_type="itv")
            if direct:
                _remember_current_mac(_current_module_mac())
                return _macsimum_with_stream_headers(direct, native_service)
            _log(
                "CODEX-MACSIMUM-TV-PLAY no stream for channel %s cmd=%s; abort immediately without fallback/MAC rotation and keep current MAC" % (label or "-", cmd),
                xbmc.LOGWARNING if xbmc else None,
            )
            return ""
        except Exception as direct_exc:
            _log(
                "CODEX-MACSIMUM-TV-PLAY direct portal failed without fallback/MAC rotation cmd=%s: %s" % (cmd, direct_exc),
                xbmc.LOGWARNING if xbmc else None,
            )
            _clear_current_mac_from_state("live bridge direct failed: %s" % direct_exc)
            return ""

    try:
        stream = native_service.get_tv_stream_url(cmd, max_attempts=1)
        if stream:
            _remember_current_mac(_current_module_mac())
            return _macsimum_with_stream_headers(stream, native_service)
    except Exception as fallback_exc:
        _log(
            "CODEX-MACSIMUM-TV-PLAY fallback failed without auto-rotation: %s" % fallback_exc,
            xbmc.LOGWARNING if xbmc else None,
        )
        _clear_current_mac_from_state("live bridge fallback failed: %s" % fallback_exc)
    return ""

def _is_transient_portal_error(exc):
    return _current_error_reason(exc) in ("bad_mac", "rate_limit", "portal_timeout")

def _finish_failed_directory(argv):
    try:
        _clear_category_nav_cache("portal request failed")
    except Exception:
        pass
    try:
        if xbmc:
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
    except Exception:
        pass
    try:
        if xbmcplugin and isinstance(argv, (list, tuple)) and len(argv) > 1:
            xbmcplugin.endOfDirectory(int(argv[1]), False, False, False)
    except Exception:
        pass

def _macsimum_abort_playback_busy_state(reason=""):
    try:
        _log("CODEX-MACSIMUM-PLAY-ABORT cleanup: %s" % (reason or "-"), xbmc.LOGWARNING if xbmc else None)
    except Exception:
        pass
    try:
        if xbmc:
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
    except Exception:
        pass
    try:
        if xbmc and xbmc.Player().isPlaying():
            xbmc.executebuiltin("PlayerControl(Stop)")
    except Exception:
        pass
    try:
        if xbmc:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass

def _macsimum_prestop_live_player_before_bridge(label="", keep_busy=False):
    """Stop a still-running/hanging Kodi live stream before a fresh Live-TV bridge auth.

    Kodi can keep probing the previous Stalker live URL for many seconds after the
    user starts another channel. For Portal 1 this is risky: the old stream keeps
    hitting /play/live.php while the new channel starts a fresh handshake. Keep the
    bridge single-shot, but make sure the previous player attempt is really stopped
    before warm-up/create_link starts.
    """
    try:
        if not xbmc:
            return
        if not keep_busy:
            try:
                xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            except Exception:
                pass
        player = xbmc.Player()
        was_playing = False
        try:
            was_playing = bool(player.isPlaying())
        except Exception:
            was_playing = False
        _log(
            "CODEX-MACSIMUM-TV-PLAY pre-stop Kodi player before bridge: %s active=%s" % (
                label or "-",
                "1" if was_playing else "0",
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
        try:
            # Nicht xbmc.Player().stop() verwenden: das kann bei einem haengenden
            # HTTP-Live-Stream blockieren, bis Kodis alter InputStream in den
            # Timeout laeuft. PlayerControl(Stop) ist leichter und laesst den
            # Bridge-Start nicht an CVideoPlayer::CloseFile festkleben.
            xbmc.executebuiltin("PlayerControl(Stop)")
        except Exception:
            pass
        try:
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        except Exception:
            pass
        # Wait briefly so the old CFileCache/OpenInputStream does not overlap
        # the new Stalker handshake. Keep it very short; duplicate clicks are
        # handled by the bridge lock, not by waiting here.
        for _idx in range(8):
            try:
                if not xbmc.Player().isPlaying():
                    break
            except Exception:
                break
            try:
                xbmc.sleep(100)
            except Exception:
                time.sleep(0.1)
        if not keep_busy:
            try:
                xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            except Exception:
                pass
    except Exception as exc:
        _log("CODEX-MACSIMUM-TV-PLAY pre-stop skipped: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _macsimum_live_loading_progress(label="", percent=10, message="Sender wird geladen"):
    if not xbmc:
        return None
    try:
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        return True
    except Exception as exc:
        _log("CODEX-MACSIMUM-TV-PLAY loading spinner skipped: %s" % exc, xbmc.LOGWARNING if xbmc else None)
        return None

def _macsimum_live_loading_update(progress, percent=50, label="", message="Sender wird geladen"):
    if not progress:
        return
    try:
        # Leicht halten: keine DialogProgress-Updates und keine oberen
        # Dauer-Notifications. Nur Kodis normales Busy-Drehsymbol in der Mitte
        # plus eine sehr kurze Ende-/Fehlermeldung.
        current = int(percent or 0)
        if current in (15, 35):
            try:
                if xbmc:
                    xbmc.executebuiltin("ActivateWindow(busydialog)")
            except Exception:
                pass
            return
        if current == 95 and xbmcgui:
            xbmcgui.Dialog().notification(
                "[B][COLOR FFB8860B]Kanal wird gestartet[/COLOR][/B]",
                "",
                xbmcgui.NOTIFICATION_INFO,
                1500,
            )
            return
        if current == 100 and xbmcgui:
            xbmcgui.Dialog().notification(
                "[B][COLOR FFB8860B]Kanal nicht erreichbar[/COLOR][/B]",
                "",
                xbmcgui.NOTIFICATION_ERROR,
                2200,
            )
            return
    except Exception:
        pass

def _macsimum_live_loading_close(progress):
    try:
        if xbmc:
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
    except Exception:
        pass
    return

def _macsimum_add_query_params(url, pairs):
    if not url:
        return url
    try:
        split = urllib.parse.urlsplit(url)
        query_pairs = urllib.parse.parse_qsl(split.query, keep_blank_values=True)
        replace_keys = set(k for k, _v in pairs)
        query_pairs = [(k, v) for k, v in query_pairs if k not in replace_keys]
        query_pairs.extend([(k, str(v)) for k, v in pairs])
        return urllib.parse.urlunsplit((split.scheme, split.netloc, split.path, urllib.parse.urlencode(query_pairs), split.fragment))
    except Exception:
        try:
            sep = "&" if "?" in url else "?"
            return url + sep + urllib.parse.urlencode([(k, str(v)) for k, v in pairs])
        except Exception:
            return url

def _macsimum_refresh_target_from_args(argv):
    def _looks_like_media_refresh_target(value):
        if not value:
            return False
        if not value.startswith("plugin://%s/" % ADDON_ID):
            return False
        if value.startswith("plugin://plugin.video.stalker.macsimum.talker3"):
            return False
        action = (_get_action(value) or "").strip().lower()
        return action in ("listing", "ser_listing", "seasons", "season", "episodes", "episode", "search", "search_series")

    def _stored_target():
        value = ""
        if xbmcgui:
            try:
                value = xbmcgui.Window(10000).getProperty("StalkerMacsimumRefreshTarget") or ""
            except Exception:
                value = ""
        if (not value) and xbmc:
            try:
                value = xbmc.getInfoLabel("Container.FolderPath") or ""
            except Exception:
                value = ""
        return value

    try:
        raw = (argv[2] or "").lstrip("?")
        pairs = urllib.parse.parse_qsl(raw, keep_blank_values=True)
    except Exception:
        pairs = []
    target = ""
    passthrough = []
    seen_target = False
    for key, value in pairs:
        if key == "target" and not seen_target:
            target = value or ""
            seen_target = True
            continue
        if key in ("action", "target"):
            continue
        if seen_target:
            passthrough.append((key, value))
    if not target:
        target = _current_plugin_url()
    if not _looks_like_media_refresh_target(target):
        fallback = _stored_target()
        if _looks_like_media_refresh_target(fallback):
            target = fallback
    if passthrough and target.startswith("plugin://%s/" % ADDON_ID):
        target = _macsimum_add_query_params(target, passthrough)
    return target

def _is_macsimum_force_refresh_target(url):
    if not url:
        return False
    if not url.startswith("plugin://%s/" % ADDON_ID):
        return False
    if url.startswith("plugin://plugin.video.stalker.macsimum.talker3"):
        return False
    action = (_get_action(url) or "").strip().lower()
    return action in ("listing", "ser_listing", "seasons", "season", "episodes", "episode", "search", "search_series")

def _handle_macsimum_force_refresh(argv):
    if not xbmc or not xbmcplugin or not isinstance(argv, (list, tuple)) or len(argv) < 3:
        return False
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_force_refresh":
        return False
    target = _macsimum_refresh_target_from_args(argv)
    if not _is_macsimum_force_refresh_target(target):
        _log("CODEX-MACSIMUM-FORCE-REFRESH refused unsafe target: %r" % target, xbmc.LOGWARNING if xbmc else None)
        try:
            xbmcgui.Dialog().notification("Stalker Portal", "Diese Seite kann hier nicht neu geladen werden", xbmcgui.NOTIFICATION_WARNING, 2200)
        except Exception:
            pass
        try:
            xbmcplugin.endOfDirectory(int(argv[1]), True, False, False)
        except Exception:
            pass
        return True
    _clear_category_nav_cache("force media page refresh")
    refresh_url = _macsimum_add_query_params(target, [
        ("codex_force_refresh", int(time.time() * 1000)),
    ])
    _log("CODEX-MACSIMUM-FORCE-REFRESH update target=%r refresh=%r" % (target, refresh_url))
    try:
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
        xbmc.executebuiltin("Container.Update(%s,replace)" % refresh_url)
    except Exception as exc:
        _log("CODEX-MACSIMUM-FORCE-REFRESH failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
    try:
        xbmcplugin.endOfDirectory(int(argv[1]), True, False, False)
    except Exception:
        pass
    return True

def _handle_manual_switch(argv):
    if not xbmc:
        return False
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False

    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "manual_mac_switch":
        return False

    _log("Manual MAC switch requested -> reopen addon root")
    try:
        xbmc.executebuiltin("Container.Update(plugin://%s/,replace)" % ADDON_ID)
    except Exception as exc:
        _log("Manual MAC switch failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
    return True

def _set_tag_value(tag, method, value):
    if value in (None, "", []):
        return
    try:
        func = getattr(tag, method, None)
        if func:
            func(value)
    except Exception:
        pass

def _show_information_dialog(title, media_type="", year="", plot="", genre="", rating="", votes="", tvshow_title="", season=""):
    clean_title = _clean_choice_title(title)
    lookup_title = _clean_choice_title(tvshow_title) if media_type in ("tvshow", "season", "episode") and tvshow_title else clean_title
    tmdb_meta = _tmdb_lookup(lookup_title, year=year, media_type=media_type, force=True)
    try:
        _log("Rich info lookup title=%r lookup=%r type=%r year=%r tmdb=%r plot=%r director=%r budget=%r" % (
            clean_title, lookup_title, media_type, year, tmdb_meta.get("tmdb_id", ""), bool(tmdb_meta.get("plot")), bool(tmdb_meta.get("director")), bool(tmdb_meta.get("budget"))
        ))
    except Exception:
        pass
    try:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    except Exception:
        pass
    if not tmdb_meta:
        fallback_item = xbmcgui.ListItem(label=clean_title)
        fallback_labels = {
            "title": clean_title,
            "plot": plot,
            "genre": genre,
            "mediatype": "tvshow" if media_type in ("tvshow", "season", "episode") else "movie",
            "year": _parse_votes_int(year) or 0,
            "rating": _parse_rating_float(rating) or 0,
            "votes": _parse_votes_int(votes) or 0,
        }
        try:
            fallback_item.setInfo(type="Video", infoLabels={k: v for k, v in fallback_labels.items() if v not in (None, "", 0, [])})
            xbmcgui.Dialog().info(fallback_item)
        except Exception:
            xbmcgui.Dialog().notification("MacSimum", "Keine Informationen gefunden", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    label = ("Staffel %s" % season) if media_type == "season" and season else _first_non_empty(tmdb_meta.get("title"), clean_title)
    item = xbmcgui.ListItem(label=label)
    dbtype = "tvshow" if media_type in ("tvshow", "season", "episode") or tmdb_meta.get("tmdb_type") == "tv" else "movie"
    if media_type in ("season", "episode"):
        dbtype = media_type

    plot_text = _first_non_empty(tmdb_meta.get("plot"), plot)
    genre_text = _first_non_empty(tmdb_meta.get("genre"), genre)
    rating_text = _first_non_empty(tmdb_meta.get("rating"), rating)
    votes_text = _first_non_empty(tmdb_meta.get("votes"), votes)
    year_text = _first_non_empty(tmdb_meta.get("year"), year)
    duration = _parse_votes_int(tmdb_meta.get("runtime")) or 0
    rating_value = _parse_rating_float(rating_text)
    votes_value = _parse_votes_int(votes_text) or 0

    info_labels = {
        "title": label,
        "plot": plot_text,
        "genre": genre_text,
        "mediatype": dbtype,
        "director": tmdb_meta.get("director", ""),
        "writer": tmdb_meta.get("writer", ""),
        "premiered": tmdb_meta.get("premiered", ""),
        "year": _parse_votes_int(year_text) or 0,
        "duration": duration * 60,
        "rating": rating_value or 0,
        "votes": votes_value,
    }
    try:
        item.setInfo(type="Video", infoLabels={k: v for k, v in info_labels.items() if v not in (None, "", 0, [])})
    except Exception:
        pass

    try:
        tag = item.getVideoInfoTag()
        _set_tag_value(tag, "setMediaType", dbtype)
        _set_tag_value(tag, "setTitle", label)
        _set_tag_value(tag, "setPlot", plot_text)
        _set_tag_value(tag, "setGenres", [g.strip() for g in re.split(r"[/,|]", genre_text) if g.strip()])
        _set_tag_value(tag, "setDirectors", [d.strip() for d in tmdb_meta.get("director", "").split("/") if d.strip()])
        _set_tag_value(tag, "setWriters", [w.strip() for w in tmdb_meta.get("writer", "").split("/") if w.strip()])
        _set_tag_value(tag, "setPremiered", tmdb_meta.get("premiered", ""))
        year_value = _parse_votes_int(year_text)
        if year_value:
            _set_tag_value(tag, "setYear", year_value)
        if duration:
            _set_tag_value(tag, "setDuration", duration * 60)
        if rating_value is not None:
            try:
                tag.setRating(rating_value, votes_value, "tmdb", True)
            except Exception:
                pass
        if tmdb_meta.get("tmdb_id"):
            try:
                tag.setUniqueID(str(tmdb_meta.get("tmdb_id")), "tmdb")
            except Exception:
                pass
        if tmdb_meta.get("imdb_id"):
            try:
                tag.setUniqueID(str(tmdb_meta.get("imdb_id")), "imdb")
            except Exception:
                pass
    except Exception:
        pass

    art = {}
    if tmdb_meta.get("poster"):
        poster = _tmdb_image_size(tmdb_meta.get("poster"), "w185")
        art.update({"icon": poster, "thumb": poster, "poster": poster})
    if tmdb_meta.get("fanart"):
        art["fanart"] = _tmdb_image_size(tmdb_meta.get("fanart"), "w300")
    if art:
        try:
            item.setArt(art)
        except Exception:
            pass

    for key, value in {
        "TmdbId": tmdb_meta.get("tmdb_id", ""),
        "tmdb_id": tmdb_meta.get("tmdb_id", ""),
        "imdb_id": tmdb_meta.get("imdb_id", ""),
        "Budget": tmdb_meta.get("budget", ""),
        "Revenue": tmdb_meta.get("revenue", ""),
        "TMDb_Rating": rating_text,
        "Trakt_Rating": "",
    }.items():
        if value:
            try:
                item.setProperty(key, str(value))
            except Exception:
                pass
    try:
        ids = {}
        if tmdb_meta.get("tmdb_id"):
            ids["tmdb"] = str(tmdb_meta.get("tmdb_id"))
        if tmdb_meta.get("imdb_id"):
            ids["imdb"] = str(tmdb_meta.get("imdb_id"))
        if ids:
            item.setUniqueIDs(ids)
    except Exception:
        pass
    try:
        xbmcgui.Dialog().info(item)
    except Exception:
        xbmc.executebuiltin("Action(Info)")

def _handle_macsimum_favorites(argv):
    if not xbmcplugin or not xbmcgui:
        return False
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action == "codex_macsimum_remove_favorite":
        fav_id = (qs.get("fav_id") or [""])[0]
        ok = _remove_macsimum_favorite(fav_id)
        try:
            xbmcgui.Dialog().notification("Favoriten", "Favorit entfernt" if ok else "Favorit nicht gefunden", xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 2200)
            xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
        return True
    if action == "codex_macsimum_clear_favorites":
        try:
            confirmed = xbmcgui.Dialog().yesno("Favoriten", "Alle Stalker Maximum Favoriten löschen?")
        except Exception:
            confirmed = True
        if confirmed:
            ok = _clear_macsimum_favorites()
            try:
                xbmcgui.Dialog().notification("Favoriten", "Alle Favoriten gelöscht" if ok else "Favoriten konnten nicht gelöscht werden", xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 2500)
                xbmc.executebuiltin("Container.Refresh")
            except Exception:
                pass
        return True
    if action != "codex_macsimum_favorites":
        return False

    try:
        handle = int(argv[1])
    except Exception:
        handle = -1
    favorites = _load_macsimum_favorites()
    try:
        xbmcplugin.setContent(handle, "movies")
    except Exception:
        pass
    if not favorites:
        li = xbmcgui.ListItem("Keine Favoriten gespeichert")
        try:
            li.setArt({"icon": FAVORITES_ART, "thumb": FAVORITES_ART})
            li.setProperty("IsPlayable", "false")
            _apply_default_fanart(li)
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, "", li, False)
        xbmcplugin.endOfDirectory(handle, True, False, False)
        return True

    clear_li = xbmcgui.ListItem("Alle Favoriten löschen")
    try:
        clear_li.setArt({"icon": FAVORITES_ART, "thumb": FAVORITES_ART})
        clear_li.setProperty("IsPlayable", "false")
        _apply_default_fanart(clear_li)
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(handle, _build_macsimum_clear_favorites_url(), clear_li, False)

    for fav in favorites:
        try:
            label = fav.get("title") or "Favorit"
            media_type = fav.get("media_type") or "movie"
            li = xbmcgui.ListItem(label)
            art = _best_art_for_favorite(fav)
            if media_type in ("movie", "tvshow", "season", "episode"):
                try:
                    li.setInfo(type="Video", infoLabels={
                        "title": label,
                        "plot": fav.get("plot") or "",
                        "year": _parse_votes_int(fav.get("year")) or 0,
                        "genre": fav.get("genre") or "",
                        "rating": _parse_rating_float(fav.get("rating")) or 0,
                        "mediatype": "tvshow" if media_type == "tvshow" else ("season" if media_type == "season" else ("episode" if media_type == "episode" else "movie")),
                    })
                except Exception:
                    pass
            li.setArt(art)
            li.setProperty("IsPlayable", "false")
            _apply_default_fanart(li)
            try:
                li.addContextMenuItems([
                    ("Aus Stalker Maximum Favoriten entfernen", "RunPlugin(%s)" % _build_macsimum_remove_favorite_url(fav.get("id") or "")),
                ])
            except Exception:
                pass
            xbmcplugin.addDirectoryItem(handle, _favorite_to_choice_url(fav), li, False)
        except Exception as exc:
            _log("Favorit konnte nicht gelistet werden: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    xbmcplugin.endOfDirectory(handle, True, False, True)
    return True

def _handle_trailer_choice(argv):
    if not xbmc or not xbmcgui:
        return False
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False

    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "nova_trailer_choice":
        return False

    title = (qs.get("choice_title") or [""])[0]
    media_type = (qs.get("choice_media_type") or ["movie"])[0]
    original_url = (qs.get("choice_url") or [""])[0]
    original_is_folder = (qs.get("choice_is_folder") or ["0"])[0] == "1"
    year = (qs.get("choice_year") or [""])[0]
    plot = (qs.get("choice_plot") or [""])[0]
    genre = (qs.get("choice_genre") or [""])[0]
    rating = (qs.get("choice_rating") or [""])[0]
    votes = (qs.get("choice_votes") or [""])[0]
    tvshow_title = (qs.get("choice_tvshow_title") or [""])[0]
    season = (qs.get("choice_season") or [""])[0]
    source_mac = _normalize_mac((qs.get("choice_source_mac") or [""])[0])
    from_favorites = (qs.get("choice_from_favorites") or [""])[0].strip().lower() in ("1", "true", "yes")
    fav_id = (qs.get("choice_fav_id") or [""])[0]
    if from_favorites and source_mac:
        _mac_analytics_log(
            "favorite-choice-source-mac-ignored",
            before=source_mac,
            reason="favorite playback must use current Stalker session",
        )
        source_mac = ""
    try:
        choice_art = json.loads((qs.get("choice_art") or ["{}"])[0] or "{}")
        if not isinstance(choice_art, dict):
            choice_art = {}
    except Exception:
        choice_art = {}
    if media_type == "season":
        play_label = "Staffel wiedergeben"
    elif media_type == "episode":
        play_label = "Episode wiedergeben"
    elif media_type == "tvshow":
        play_label = "Serie wiedergeben"
    else:
        play_label = "Film wiedergeben"
    choice = xbmcgui.Dialog().select(_clean_choice_title(title), [play_label, "Trailer abspielen", "Informationen", "zu Favoriten hinzufügen"])
    if choice == 0 and original_url:
        try:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        except Exception:
            pass
        if original_is_folder:
            try:
                update_url = _compact_folder_update_url(original_url)
                update_url = _with_one_shot_source_mac(update_url, source_mac)
                _log("Trailer choice folder update: media=%r url=%r" % (media_type, _redact_macs_in_text(update_url)))
            except Exception:
                update_url = _with_one_shot_source_mac(original_url, source_mac)
            try:
                xbmcplugin.endOfDirectory(int(argv[1]), True, False, False)
            except Exception:
                pass
            xbmc.executebuiltin("Container.Update(%s,replace)" % update_url)
            return True
        try:
            xbmcplugin.endOfDirectory(int(argv[1]), True, False, False)
        except Exception:
            pass
        try:
            _log("Trailer choice passthrough: media=%r folder=%s url=%r" % (media_type, original_is_folder, original_url))
        except Exception:
            pass
        play_url = original_url
        try:
            parsed_original = urllib.parse.urlsplit(original_url)
            original_qs = urllib.parse.parse_qs(parsed_original.query, keep_blank_values=True)
            original_action = (original_qs.get("action") or [""])[0].strip().lower()
            original_cmd = (original_qs.get("cmd") or [""])[0]
            if media_type == "movie" and original_cmd and original_action in ("play", "vod_play", "movie_play"):
                play_url = "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({
                    "action": "codex_macsimum_vod_play",
                    "label": title or "Film",
                    "cmd": original_cmd,
                    "icon": choice_art.get("icon") or choice_art.get("thumb") or choice_art.get("poster") or "",
                    "year": year or "",
                    "source_mac": source_mac,
                    "from_favorites": "1" if from_favorites else "",
                    "fav_id": fav_id,
                }))
                _log("Trailer choice routed through Macsimum warm VOD resolver: %r" % _redact_macs_in_text(play_url))
        except Exception as exc:
            _log("Trailer choice warm VOD routing skipped: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            play_url = original_url
        xbmc.executebuiltin("PlayMedia(%s)" % play_url)
        return True
    elif choice == 1:
        try:
            trailer_title = _trailer_search_title(title, media_type, tvshow_title, season)
            video_id = _find_best_trailer_id(trailer_title, media_type, year)
            if video_id:
                _play_youtube_trailer_deferred(video_id)
                return True
            xbmcgui.Dialog().notification("Stalker Portal", "Kein Trailer gefunden", xbmcgui.NOTIFICATION_INFO, 2500)
        except Exception as exc:
            _log("Trailer failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
            xbmcgui.Dialog().notification("Stalker Portal", "Trailer konnte nicht gestartet werden", xbmcgui.NOTIFICATION_ERROR, 2500)
    elif choice == 2:
        _show_information_dialog(title, media_type=media_type, year=year, plot=plot, genre=genre, rating=rating, votes=votes, tvshow_title=tvshow_title, season=season)
    elif choice == 3:
        fav = _add_macsimum_favorite(
            title, media_type, original_url, original_is_folder,
            year=year, plot=plot, genre=genre, rating=rating, votes=votes,
            tvshow_title=tvshow_title, season=season, art=choice_art,
            source_mac=source_mac or _current_module_mac()
        )
        try:
            if fav:
                xbmcgui.Dialog().notification("Favoriten", "zu Stalker Portal 1 Favoriten hinzugefügt", xbmcgui.NOTIFICATION_INFO, 2500)
            elif False and fav:
                xbmcgui.Dialog().notification("Favoriten", "Zu Stalker Maximum Favoriten hinzugefügt", xbmcgui.NOTIFICATION_INFO, 2500)
            else:
                xbmcgui.Dialog().notification("Favoriten", "Favorit konnte nicht gespeichert werden", xbmcgui.NOTIFICATION_ERROR, 3000)
        except Exception:
            pass
    try:
        xbmcplugin.endOfDirectory(int(argv[1]), False)
    except Exception:
        pass
    return True

def _codex_genre_id(genre):
    for key in ("id", "gid", "category_id", "genre_id"):
        value = (genre or {}).get(key) if isinstance(genre, dict) else None
        if value not in (None, ""):
            return str(value).strip()
    return ""

def _codex_valid_genre_id(value):
    value = str(value or "").strip()
    return value == "*" or value.isdigit()

def _codex_is_all_live_category(title, cid=""):
    title = str(title or "").strip().upper()
    cid = str(cid or "").strip()
    return cid == "*" or title in ("ALL", "ALLE", "ALLE TV SENDER", "ALL TV", "ALL TV SENDER", "ALLE SENDER")

def _codex_category_id_from_url(url):
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(str(url or "")).query)
    except Exception:
        return ""
    for key in ("category_id", "genre", "id"):
        value = (qs.get(key) or [""])[0]
        value = str(value or "").strip()
        if value:
            return value
    return ""

def _codex_saved_full_live_categories():
    path = os.path.join(_addon_profile_dir(), "codex_macsimum_all_categories.json")
    try:
        with open(path, "r", encoding="utf-8-sig") as fh:
            payload = json.load(fh)
    except Exception:
        return []
    raw = payload.get("all") or payload.get("categories") or []
    result = []
    seen = set()
    for cat in raw:
        if not isinstance(cat, dict):
            continue
        title = str(cat.get("title") or cat.get("name") or cat.get("label") or "").strip()
        cid = _codex_category_id_from_url(cat.get("url") or "")
        if not cid:
            cid = _codex_genre_id(cat)
        if _codex_is_all_live_category(title, cid):
            continue
        if not title or not _codex_valid_genre_id(cid):
            continue
        key = cid.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append({"id": cid, "title": title})
    return result

def _codex_merge_live_categories(primary):
    merged = []
    seen = set()
    for cat in list(primary or []) + _codex_saved_full_live_categories():
        if not isinstance(cat, dict):
            continue
        title = str(cat.get("title") or cat.get("name") or "").strip()
        cid = _codex_genre_id(cat)
        if _codex_is_all_live_category(title, cid):
            continue
        if not title or not _codex_valid_genre_id(cid):
            continue
        key = cid.lower()
        if key in seen:
            continue
        seen.add(key)
        merged.append({"id": cid, "title": title})
    return merged

def _codex_channel_title(item):
    if not isinstance(item, dict):
        return ""
    for key in ("name", "title", "display_name", "fname"):
        value = item.get(key)
        if value:
            return str(value).strip()
    return ""

def _codex_channel_cmd(item):
    if not isinstance(item, dict):
        return ""
    for key in ("cmd", "url", "stream_url", "command"):
        value = item.get(key)
        if value:
            return str(value).strip()
    return ""

def _codex_channel_icon(item):
    if not isinstance(item, dict):
        return ""
    for key in ("logo", "logo_url", "icon", "icon_url", "screenshot_uri", "tv_genre_logo"):
        value = item.get(key)
        if value:
            return str(value).strip()
    return ""

def _codex_extract_tv_page(payload):
    if isinstance(payload, dict) and ("data" in payload or "channels" in payload or "items" in payload):
        data = payload.get("data") or payload.get("channels") or payload.get("items") or []
        try:
            total = int(payload.get("total_items") or payload.get("total") or 0)
        except Exception:
            total = 0
        return data if isinstance(data, list) else [], total
    js = payload.get("js") if isinstance(payload, dict) else payload
    if isinstance(js, dict):
        data = js.get("data") or js.get("channels") or js.get("items") or []
        try:
            total = int(js.get("total_items") or js.get("total") or 0)
        except Exception:
            total = 0
        return data if isinstance(data, list) else [], total
    if isinstance(js, list):
        return js, 0
    return [], 0

def _codex_scan_report_paths(scope):
    base = "codex_macsimum_%s_live_scan_seen" % scope
    return (
        os.path.join(_addon_profile_dir(), base + ".json"),
        os.path.join(_addon_profile_dir(), base + "_names.txt"),
    )

def _codex_all_live_scan_seen_items_for_category(cid):
    cid = str(cid or "").strip()
    if not cid:
        return []
    payload = _codex_load_all_live_scan_snapshot()
    if not isinstance(payload, dict):
        return []
    raw = payload.get("seen") if isinstance(payload, dict) else []
    if not isinstance(raw, list):
        return []
    items = []
    seen = set()
    for row in raw:
        if not isinstance(row, dict):
            continue
        if str(row.get("category_id") or "").strip() != cid:
            continue
        name = _codex_channel_title(row)
        cmd = _codex_channel_cmd(row)
        if not name or not cmd:
            continue
        key = (name, cmd)
        if key in seen:
            continue
        seen.add(key)
        items.append(row)
    return items

def _codex_load_all_live_scan_snapshot():
    path = os.path.join(_addon_profile_dir(), "codex_macsimum_all_live_scan_seen.json")
    try:
        with open(path, "r", encoding="utf-8-sig") as fh:
            payload = json.load(fh)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}

def _codex_previous_live_seen_by_category():
    payload = _codex_load_all_live_scan_snapshot()
    raw = payload.get("seen") if isinstance(payload, dict) else []
    if not isinstance(raw, list):
        return {}
    rows_by_category = {}
    seen = set()
    for row in raw:
        if not isinstance(row, dict):
            continue
        cid = str(row.get("category_id") or "").strip()
        name = _codex_channel_title(row)
        cmd = _codex_channel_cmd(row)
        if not cid or not name or not cmd:
            continue
        key = (cid, name, cmd)
        if key in seen:
            continue
        seen.add(key)
        rows_by_category.setdefault(cid, []).append(row)
    return rows_by_category

def _codex_snapshot_zero_category_ids(snapshot=None):
    snapshot = snapshot if isinstance(snapshot, dict) else _codex_load_all_live_scan_snapshot()
    raw = snapshot.get("categories") if isinstance(snapshot, dict) else []
    result = set()
    if not isinstance(raw, list):
        return result
    for cat in raw:
        if not isinstance(cat, dict):
            continue
        cid = str(cat.get("id") or "").strip()
        if not cid:
            continue
        try:
            seen_count = int(cat.get("seen") or 0)
        except Exception:
            seen_count = 0
        if seen_count <= 0:
            result.add(cid)
    return result

def _codex_merge_live_scan_rows(old_rows, new_rows):
    merged = []
    seen = set()
    for row in list(old_rows or []):
        if not isinstance(row, dict):
            continue
        cid = str(row.get("category_id") or "").strip()
        name = _codex_channel_title(row)
        cmd = _codex_channel_cmd(row)
        if not cid or not name or not cmd:
            continue
        key = (cid, name, cmd)
        seen.add(key)
        merged.append(row)
    for row in list(new_rows or []):
        if not isinstance(row, dict):
            continue
        cid = str(row.get("category_id") or "").strip()
        name = _codex_channel_title(row)
        cmd = _codex_channel_cmd(row)
        if not cid or not name or not cmd:
            continue
        key = (cid, name, cmd)
        if key in seen:
            continue
        seen.add(key)
        merged.append(row)
    return merged

def _codex_merge_live_scan_categories(old_categories, current_categories, merged_rows):
    result = []
    seen = set()
    row_counts = {}
    for row in merged_rows or []:
        cid = str(row.get("category_id") or "").strip()
        if cid:
            row_counts[cid] = row_counts.get(cid, 0) + 1
    for cat in list(old_categories or []) + list(current_categories or []):
        if not isinstance(cat, dict):
            continue
        cid = str(cat.get("id") or _codex_genre_id(cat) or "").strip()
        title = str(cat.get("title") or cat.get("name") or "").strip()
        if not cid or not title or cid in seen:
            continue
        seen.add(cid)
        result.append({"id": cid, "title": title, "seen": row_counts.get(cid, 0)})
    return result

def _codex_backup_all_live_scan_snapshot(reason):
    path = os.path.join(_addon_profile_dir(), "codex_macsimum_all_live_scan_seen.json")
    if not os.path.exists(path):
        return ""
    backup = path + ".bak_%s_%s" % (re.sub(r"[^A-Za-z0-9_]+", "_", str(reason or "scan")), time.strftime("%Y%m%d_%H%M%S"))
    try:
        with open(path, "r", encoding="utf-8-sig", errors="replace") as src:
            data = src.read()
        with open(backup, "w", encoding="utf-8") as dst:
            dst.write(data)
        return backup
    except Exception as exc:
        _log("Macsimum scan snapshot backup failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return ""

def _codex_get_tv_channels_scan_page(native_service, gid, page, title, progress=None, previous_rows=None, retry_delay=None):
    payload = native_service.get_tv_channels(gid, str(page))
    data, total_items = _codex_extract_tv_page(payload)
    if data or str(page) != "1":
        return payload, data, total_items, 0
    try:
        payload_keys = ",".join(sorted(payload.keys())) if isinstance(payload, dict) else type(payload).__name__
        _log("Macsimum ALL scan empty category: id=%s title=%s payload=%s total=%s" % (gid, title, payload_keys, total_items), xbmc.LOGWARNING if xbmc else None)
    except Exception:
        pass
    # Manche Portal-Kategorien antworten beim ersten Zugriff leer, liefern aber
    # nach einer kurzen Pause Daten. Genau ein ruhiger Retry, keine MAC-Rotation.
    try:
        delay = retry_delay if retry_delay is not None else (1.35 if previous_rows else 1.15)
        time.sleep(float(delay))
    except Exception:
        pass
    retry_payload = native_service.get_tv_channels(gid, str(page))
    retry_data, retry_total = _codex_extract_tv_page(retry_payload)
    if retry_data:
        _log("Macsimum ALL scan empty category recovered after retry: id=%s title=%s rows=%s total=%s" % (gid, title, len(retry_data), retry_total), xbmc.LOGWARNING if xbmc else None)
        return retry_payload, retry_data, retry_total, 1
    try:
        retry_keys = ",".join(sorted(retry_payload.keys())) if isinstance(retry_payload, dict) else type(retry_payload).__name__
        _log("Macsimum ALL scan empty category after retry: id=%s title=%s payload=%s total=%s" % (gid, title, retry_keys, retry_total), xbmc.LOGWARNING if xbmc else None)
    except Exception:
        pass
    return retry_payload, retry_data, retry_total, 1

def _codex_live_scan_bridge_url(row):
    name = _codex_channel_title(row)
    params = {
        "action": "codex_macsimum_bridge_play",
        "label": name,
        "cmd": _codex_channel_cmd(row),
        "icon": _codex_channel_icon(row),
    }
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))

def _add_live_scan_fallback_directory(handle, add_directory_item=None):
    if _current_plugin_action() != "tv_listing":
        return False
    cid = _codex_category_id_from_url(_current_plugin_url())
    rows = _codex_all_live_scan_seen_items_for_category(cid)
    if not rows:
        return False
    try:
        if xbmcplugin:
            xbmcplugin.setContent(handle, "videos")
    except Exception:
        pass
    adder = add_directory_item or xbmcplugin.addDirectoryItem
    added = 0
    for row in rows:
        try:
            name = _codex_channel_title(row)
            icon = _codex_channel_icon(row)
            li = xbmcgui.ListItem(label=name)
            li.setProperty("IsPlayable", "true")
            if icon:
                li.setArt({"icon": icon, "thumb": icon})
            try:
                li.setInfo(type="Video", infoLabels={"mediatype": "movie", "title": name})
            except Exception:
                pass
            _apply_default_fanart(li)
            adder(handle, _codex_live_scan_bridge_url(row), li, False, 0)
            added += 1
        except Exception:
            continue
    if added:
        _log("Live TV category fallback filled cid=%s with %d scan channels" % (cid, added))
        return True
    return False

def _handle_macsimum_live_scan_navigation(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action not in ("tv", "live", "tv_listing"):
        return False
    try:
        handle = int(argv[1])
    except Exception:
        return False

    if action in ("tv", "live"):
        categories = _codex_saved_full_live_categories()
        if not categories:
            return False
        try:
            xbmcplugin.setContent(handle, "files")
        except Exception:
            pass
        try:
            xbmcplugin.addDirectoryItem(handle, _build_all_live_scan_url(), _make_all_live_scan_item(), False, 0)
        except Exception:
            pass
        try:
            xbmcplugin.addDirectoryItem(handle, _build_gap_live_scan_url(), _make_gap_live_scan_item(), False, 0)
        except Exception:
            pass
        try:
            xbmcplugin.addDirectoryItem(handle, _build_missing_m3u_repair_url(), _make_missing_m3u_repair_item(), False, 0)
        except Exception:
            pass
        for cat in categories:
            try:
                cid = str(cat.get("id") or "").strip()
                title = str(cat.get("title") or "").strip()
                if not cid or not title:
                    continue
                li = _make_saved_live_category_item(title)
                xbmcplugin.addDirectoryItem(handle, _build_saved_live_category_url(title, cid), li, True, 0)
            except Exception:
                continue
        xbmcplugin.endOfDirectory(handle, True, False, True)
        _log("Served Live TV category root from saved scan snapshot: %d categories" % len(categories))
        return True

    rows = _codex_all_live_scan_seen_items_for_category(_codex_category_id_from_url(_current_plugin_url()))
    if not rows:
        return False
    try:
        xbmcplugin.setContent(handle, "videos")
    except Exception:
        pass
    for row in rows:
        try:
            name = _codex_channel_title(row)
            icon = _codex_channel_icon(row)
            li = xbmcgui.ListItem(label=name)
            li.setProperty("IsPlayable", "true")
            if icon:
                li.setArt({"icon": icon, "thumb": icon})
            try:
                li.setInfo(type="Video", infoLabels={"mediatype": "movie", "title": name})
            except Exception:
                pass
            _apply_default_fanart(li)
            xbmcplugin.addDirectoryItem(handle, _codex_live_scan_bridge_url(row), li, False, 0)
        except Exception:
            continue
    xbmcplugin.endOfDirectory(handle, True, False, True)
    _log("Served Live TV category listing from saved scan snapshot: cid=%s channels=%d" % (_codex_category_id_from_url(_current_plugin_url()), len(rows)))
    return True

def _codex_playlistloader_profile_dir():
    try:
        profile = xbmcaddon.Addon("plugin.video.playlistloader.macsimum").getAddonInfo("profile")
        if xbmcvfs:
            profile = xbmcvfs.translatePath(profile)
        elif xbmc:
            profile = xbmc.translatePath(profile)
        return profile
    except Exception:
        return os.path.join(_addon_profile_dir(), "..", "plugin.video.playlistloader.macsimum")

def _codex_scope_m3u_path(scope):
    scope = (scope or "de").strip().lower().replace("-", "_")
    aliases = {
        "uk": "england", "gb": "england", "balkan_exyu": "exyu_allgemein", "czsk": "cz",
        "skandinavien": "se", "ru_ua_kaukasus": "ru", "lateinamerika": "br",
        "arabisch_nahost": "arabic_general", "indien_pakistan": "in", "afrika": "africa",
    }
    scope = aliases.get(scope, scope)
    names = {
        "de": "stalker_macsimum_live_tv.m3u",
        "international_sport": "stalker_macsimum_international_sport.m3u",
        "at": "stalker_macsimum_at.m3u", "ch": "stalker_macsimum_ch.m3u", "nl": "stalker_macsimum_nl.m3u",
        "be": "stalker_macsimum_be.m3u", "england": "stalker_macsimum_england.m3u",
        "us": "stalker_macsimum_us.m3u", "ca": "stalker_macsimum_ca.m3u", "fr": "stalker_macsimum_fr.m3u",
        "it": "stalker_macsimum_it.m3u", "es": "stalker_macsimum_es.m3u", "pt": "stalker_macsimum_pt.m3u",
        "pl": "stalker_macsimum_pl.m3u", "al": "stalker_macsimum_al.m3u", "rs": "stalker_macsimum_rs.m3u",
        "me": "stalker_macsimum_me.m3u", "hr": "stalker_macsimum_hr.m3u", "si": "stalker_macsimum_si.m3u",
        "mk": "stalker_macsimum_mk.m3u", "ba": "stalker_macsimum_ba.m3u",
        "exyu_allgemein": "stalker_macsimum_exyu_allgemein.m3u", "gr": "stalker_macsimum_gr.m3u",
        "ro": "stalker_macsimum_ro.m3u", "bg": "stalker_macsimum_bg.m3u", "hu": "stalker_macsimum_hu.m3u",
        "cz": "stalker_macsimum_cz.m3u", "sk": "stalker_macsimum_sk.m3u", "dk": "stalker_macsimum_dk.m3u",
        "se": "stalker_macsimum_se.m3u", "no": "stalker_macsimum_no.m3u", "fi": "stalker_macsimum_fi.m3u",
        "ru": "stalker_macsimum_ru.m3u", "ua": "stalker_macsimum_ua.m3u", "ge": "stalker_macsimum_ge.m3u",
        "az": "stalker_macsimum_az.m3u", "am": "stalker_macsimum_am.m3u", "au": "stalker_macsimum_au.m3u",
        "br": "stalker_macsimum_br.m3u", "co": "stalker_macsimum_co.m3u", "pe": "stalker_macsimum_pe.m3u",
        "arabic_general": "stalker_macsimum_arabic_general.m3u", "ma": "stalker_macsimum_ma.m3u",
        "dz": "stalker_macsimum_dz.m3u", "sa": "stalker_macsimum_sa.m3u", "lb": "stalker_macsimum_lb.m3u",
        "tn": "stalker_macsimum_tn.m3u", "kw": "stalker_macsimum_kw.m3u", "sd": "stalker_macsimum_sd.m3u",
        "eg": "stalker_macsimum_eg.m3u", "ps": "stalker_macsimum_ps.m3u", "ae": "stalker_macsimum_ae.m3u",
        "bh": "stalker_macsimum_bh.m3u", "iq": "stalker_macsimum_iq.m3u", "jo": "stalker_macsimum_jo.m3u",
        "qa": "stalker_macsimum_qa.m3u", "sy": "stalker_macsimum_sy.m3u", "kurdish": "stalker_macsimum_kurdish.m3u",
        "suryoyo": "stalker_macsimum_suryoyo.m3u", "ir": "stalker_macsimum_ir.m3u",
        "in": "stalker_macsimum_in.m3u", "pk": "stalker_macsimum_pk.m3u", "africa": "stalker_macsimum_africa.m3u",
        "dstv": "stalker_macsimum_dstv.m3u", "th": "stalker_macsimum_thailand.m3u", "thailand": "stalker_macsimum_thailand.m3u",
        "adult": "stalker_macsimum_adult.m3u",
    }
    filename = names.get(scope) or names.get("de")
    return os.path.join(_codex_playlistloader_profile_dir(), "playlists", filename)

def _codex_ascii_norm(value):
    small_caps = {
        0x1D00: "A", 0x0299: "B", 0x1D04: "C", 0x1D05: "D", 0x1D07: "E", 0xA730: "F", 0x0262: "G", 0x029C: "H",
        0x026A: "I", 0x1D0A: "J", 0x1D0B: "K", 0x029F: "L", 0x1D0D: "M", 0x0274: "N", 0x1D0F: "O", 0x1D18: "P",
        0x01EB: "Q", 0xA7AF: "Q", 0x0280: "R", 0xA731: "S", 0x1D1B: "T", 0x1D1C: "U", 0x1D20: "V", 0x1D21: "W", 0x028F: "Y", 0x1D22: "Z",
        0x1D43: "A", 0x1D47: "B", 0x1D9C: "C", 0x1D48: "D", 0x1D49: "E", 0x1DA0: "F", 0x1D4D: "G", 0x02B0: "H",
        0x1DA6: "I", 0x02B2: "J", 0x1D4F: "K", 0x02E1: "L", 0x1D50: "M", 0x207F: "N", 0x1D52: "O", 0x1D56: "P",
        0x02B3: "R", 0x02E2: "S", 0x1D57: "T", 0x1D58: "U", 0x1D5B: "V", 0x02B7: "W", 0x02B8: "Y", 0x1DBB: "Z",
    }
    text = "".join(small_caps.get(ord(ch), ch) for ch in str(value or ""))
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.replace("\u00df", "SS").replace("\u1e9e", "SS").replace("\u00d8", "O").replace("\u00f8", "O")
    text = re.sub(r"[^A-Za-z0-9]+", " ", text).upper()
    return re.sub(r"\s+", " ", text).strip()

def _codex_channel_match_key(value):
    text = _codex_ascii_norm(value)
    text = re.sub(r"\bSPORTS\b", "SPORT", text)
    text = re.sub(r"\b(FULLHD|FHD|HEVC|RAW|UHD|QHD|HD|SD|HDR|4K|2K)\b", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def _codex_channel_match_keys(value):
    raw = str(value or "")
    variants = [raw]
    if "|" in raw:
        variants.append(raw.split("|", 1)[1])
    if ":" in raw:
        variants.append(raw.split(":", 1)[1])
    keys = []
    seen = set()
    country_prefixes = set("DE AT CH NL BE UK GB US USA CA FR IT ES PT PL GR RO BG HU CZ SK NO SE DK FI RU UA AU BR MX AR AE SA IN PK AF ZA TH EXYU YU HR SR RS BA BIH BH MK ME MNE AL SLO SI SU AM ARM AZ GE IL IQ IR EG LB KW QA OM JO SY".split())
    def add(key):
        key = str(key or "").strip()
        if key and key not in seen:
            seen.add(key)
            keys.append(key)
    def add_compact(key):
        compact_key = re.sub(r"\s+", "", str(key or "").strip())
        if len(compact_key) >= 4:
            add(compact_key)
    def add_aliases(key):
        key = str(key or "").strip()
        if not key:
            return
        variants = [key]
        replacements = (
            ("CINE 34", "CINE34"),
            ("SPORT ITALIA", "SPORTITALIA"),
            ("SUPER TENNIS", "SUPERTENNIS"),
            ("LAZIO STYLE", "LAZIOSTYLE"),
        )
        for old, new in replacements:
            if old in key:
                variants.append(key.replace(old, new))
            if new in key:
                variants.append(key.replace(new, old))
        for alias in variants:
            add(alias)
            add_compact(alias)
    for variant in variants:
        normalized = _codex_ascii_norm(variant)
        if normalized:
            add_aliases(normalized)
            parts = normalized.split()
            if len(parts) > 1 and parts[0] in country_prefixes:
                add_aliases(" ".join(parts[1:]))
    for variant in variants:
        base = _codex_channel_match_key(variant)
        if base:
            add_aliases(base)
            parts = base.split()
            if len(parts) > 1 and parts[0] in country_prefixes:
                add_aliases(" ".join(parts[1:]))
    return keys

def _codex_category_scope(cat):
    title = str((cat or {}).get("title") or (cat or {}).get("name") or "").strip()
    cid = _codex_genre_id(cat)
    norm = _codex_ascii_norm(title)
    compact = norm.replace(" ", "")
    scopes = set()
    if _codex_is_all_live_category(title, cid):
        return scopes
    scope_ids = {
        "international_sport": {"755","759","757","171","357","504","498","500"},
        "at": {"39","721"}, "ch": {"65","686","716"}, "nl": {"738","739","40","509","41","740","42","43","44","45","737"},
        "be": {"47"}, "england": {"58","329","651","330","331","649","763","764"},
        "us": {"59","322","415","321","324","323","414","634","635","636","637","638","639","640","641","657","642","643","644","645","646"},
        "ca": {"444","647"}, "fr": {"46","179","703","676","176","177","180","178"},
        "it": {"687","60","491","111","232","231","299","112","490"}, "es": {"61","398","399","551","552","714"},
        "pt": {"64","395","396","400","397"}, "pl": {"633","57","95","97","98","100","99"},
        "al": {"56","688","130","102","96","103"}, "rs": {"133","358"}, "me": {"412"}, "hr": {"49"},
        "si": {"72"}, "mk": {"50"}, "ba": {"51"}, "exyu_allgemein": {"758","475","401","515","480","479"},
        "gr": {"53","537","374","138","139"}, "ro": {"55","248","247","244","246","628"},
        "bg": {"54","337","338","339","684","685"}, "hu": {"70"},
        "cz": {"71","524","525","527","526","528","529","530","531","532","533"}, "sk": {"73"},
        "dk": {"67"}, "se": {"66"}, "no": {"68"}, "fi": {"69"},
        "ru": {"327","183","380","379","712","340","711","630"}, "ua": {"336"}, "ge": {"708"}, "az": {"52"}, "am": {"164"},
        "au": {"74"}, "br": {"75"}, "co": {"413"}, "pe": {"416"},
        "arabic_general": {"78","167","302","406","488","405","404","304","408","538","539","540","541"},
        "ma": {"750"}, "dz": {"542"}, "sa": {"543"}, "lb": {"546"}, "tn": {"547"}, "kw": {"548"}, "sd": {"555"},
        "eg": {"741"}, "ps": {"742"}, "ae": {"743"}, "bh": {"752"}, "iq": {"753"}, "jo": {"754"}, "qa": {"751"}, "sy": {"749"},
        "kurdish": {"79"}, "suryoyo": {"695"}, "ir": {"83"}, "in": {"81","691","692"}, "pk": {"80"},
        "africa": {"82"}, "dstv": {"352"}, "th": {"85"}, "adult": {"86","632","700","701"},
        "de": {"736","760","222","221","709","650","536","225","503","706","659","223","249","262","224","629","226","697","438","696","523","228","702","227","698","699","626","683","682","229","446","332","505","673","506","512","519"},
    }
    for scope, ids in scope_ids.items():
        if str(cid) in ids:
            scopes.add(scope)
    def has(*tokens):
        return any(token in norm for token in tokens)
    def starts(*tokens):
        return any(norm.startswith(token + " ") or compact.startswith(token) for token in tokens)
    if not scopes:
        if starts("AT") or has("AUSTRIA"): scopes.add("at")
        elif starts("CH") or has("SWISS", "BLUE SPORT"): scopes.add("ch")
        elif starts("NL") or has("NETHERLAND", "HOLLAND", "VIAPLAY"): scopes.add("nl")
        elif starts("BE") or has("BELGIUM"): scopes.add("be")
        elif starts("UK", "GB", "EN") or has("UNITED KINGDOM", "ENGLAND", "BRITAIN"): scopes.add("england")
        elif starts("US", "USA") or has("UNITED STATES"): scopes.add("us")
        elif starts("CA") or has("CANADA"): scopes.add("ca")
        elif starts("FR") or has("FRANCE", "FRENCH"): scopes.add("fr")
        elif starts("IT") or has("ITALY", "ITALIA"): scopes.add("it")
        elif starts("ES") or has("SPAIN", "ESPANA"): scopes.add("es")
        elif starts("PT") or has("PORTUGAL"): scopes.add("pt")
        elif starts("PL") or has("POLAND", "POLSKA"): scopes.add("pl")
        elif starts("AL", "ALB") or has("ALBANIA", "ALBANIEN"): scopes.add("al")
        elif starts("RS", "SR") or has("SERBIA", "SERBIEN"): scopes.add("rs")
        elif starts("ME", "MNE") or has("MONTENEGRO", "CRNA GORA"): scopes.add("me")
        elif starts("HR", "CRO") or has("CROATIA", "KROATIEN"): scopes.add("hr")
        elif starts("SI", "SLO") or has("SLOVENIA", "SLOWENIEN"): scopes.add("si")
        elif starts("MK") or has("MACEDONIA", "MAZEDONIEN"): scopes.add("mk")
        elif starts("BA", "BIH", "BH") or has("BOSNIA", "BOSNIEN"): scopes.add("ba")
        elif starts("GR") or has("GREECE", "HELLAS"): scopes.add("gr")
        elif starts("RO") or has("ROMANIA"): scopes.add("ro")
        elif starts("BG") or has("BULGARIA"): scopes.add("bg")
        elif starts("HU") or has("HUNGARY"): scopes.add("hu")
        elif starts("CZ") or has("CZECH"): scopes.add("cz")
        elif starts("SK") or has("SLOVAK"): scopes.add("sk")
        elif starts("DK") or has("DENMARK"): scopes.add("dk")
        elif starts("SE") or has("SWEDEN"): scopes.add("se")
        elif starts("NO") or has("NORWAY"): scopes.add("no")
        elif starts("FI") or has("FINLAND"): scopes.add("fi")
        elif starts("RU") or has("RUSSIA"): scopes.add("ru")
        elif starts("UA") or has("UKRAINE"): scopes.add("ua")
        elif starts("GE") or has("GEORGIA"): scopes.add("ge")
        elif starts("AZ") or has("AZERBAIJAN", "AZERBAYCAN"): scopes.add("az")
        elif starts("AM", "ARM") or has("ARMENIA", "ARMENIEN"): scopes.add("am")
        elif starts("AU") or has("AUSTRALIA"): scopes.add("au")
        elif starts("BR") or has("BRAZIL"): scopes.add("br")
        elif starts("COL", "CO") or has("COLOMBIA"): scopes.add("co")
        elif starts("PE") or has("PERU"): scopes.add("pe")
        elif starts("MA") or has("MOROCCO"): scopes.add("ma")
        elif starts("DZ") or has("ALGERIA"): scopes.add("dz")
        elif starts("SA") or has("SAUDI"): scopes.add("sa")
        elif starts("LB") or has("LEBANON"): scopes.add("lb")
        elif starts("TN") or has("TUNISIE", "TUNISIA"): scopes.add("tn")
        elif starts("KW") or has("KUWAIT"): scopes.add("kw")
        elif starts("SD") or has("SUDAN"): scopes.add("sd")
        elif starts("EG") or has("EGYPT"): scopes.add("eg")
        elif starts("PS") or has("PALASTINE", "PALESTINE"): scopes.add("ps")
        elif starts("AE") or has("UAE"): scopes.add("ae")
        elif starts("BH") or has("BAHRAIN"): scopes.add("bh")
        elif starts("IQ") or has("IRAQ"): scopes.add("iq")
        elif starts("JO") or has("JORDAN"): scopes.add("jo")
        elif starts("QA") or has("QATAR"): scopes.add("qa")
        elif starts("SY") or has("SYRIA"): scopes.add("sy")
        elif starts("IR") or has("IRAN"): scopes.add("ir")
        elif starts("IN") or has("INDIA"): scopes.add("in")
        elif starts("PK") or has("PAKISTAN"): scopes.add("pk")
        elif starts("TH") or has("THAILAND", "THAI"): scopes.add("th")
        elif has("KURD", "KURDISTAN"): scopes.add("kurdish")
        elif has("SURY", "ASSYR"): scopes.add("suryoyo")
        elif starts("AF") or has("AFRICA"): scopes.add("africa")
    return scopes

def _codex_categories_for_scope(scope, categories):
    scope = (scope or "de").strip().lower().replace("-", "_")
    aliases = {
        "uk": "england", "gb": "england", "balkan_exyu": "exyu_allgemein", "czsk": "cz",
        "skandinavien": "se", "ru_ua_kaukasus": "ru", "lateinamerika": "br",
        "arabisch_nahost": "arabic_general", "indien_pakistan": "in", "afrika": "africa", "thailand": "th",
    }
    scope = aliases.get(scope, scope)
    selected = []
    for cat in categories or []:
        if scope in _codex_category_scope(cat):
            selected.append(cat)
    return selected

def _codex_m3u_extinf_name(line):
    try:
        return line.rsplit(",", 1)[1].strip()
    except Exception:
        return ""

def _codex_m3u_name_is_relevant_channel(name):
    raw = str(name or "").strip()
    if not raw:
        return False
    # M3U-Trenner wie "★☆★ NEWS ★☆★" sind keine Sender und duerfen
    # die Lueckenstatistik nicht aufblasen.
    if "★" in raw or "☆" in raw:
        return False
    normalized = _codex_ascii_norm(raw)
    if not normalized:
        return False
    # 24/7-Pseudo-Ordner/-Kanaele sind fuer die Live-TV-3-Bruecke nicht
    # wichtig. "24x7" bleibt bewusst erlaubt, weil das echte Sendernamen
    # wie NDTV 24x7 treffen kann.
    if re.search(r"\b24\s*/\s*7\b", raw, re.IGNORECASE):
        return False
    return True

def _codex_plugin_url_has_bridge_cmd(url):
    try:
        parsed = urllib.parse.urlsplit(str(url or ""))
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        action = (qs.get("action") or [""])[0].strip().lower()
        cmd = (qs.get("cmd") or [""])[0].strip()
        return action == "codex_macsimum_bridge_play" and bool(cmd)
    except Exception:
        return False

def _codex_update_plugin_url(url, name, match):
    parsed = urllib.parse.urlsplit(str(url or ""))
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs["action"] = ["codex_macsimum_bridge_play"]
    qs["label"] = [name or match.get("name") or ""]
    qs["cmd"] = [match.get("cmd") or ""]
    qs["icon"] = [match.get("icon") or ""]
    query = urllib.parse.urlencode({k: v[-1] if isinstance(v, list) else v for k, v in qs.items()})
    return urllib.parse.urlunsplit(("plugin", "plugin.video.stalker.macsimum", "/", query, ""))

def _codex_first(item, *keys):
    if not isinstance(item, dict):
        return ""
    for key in keys:
        value = item.get(key)
        if value not in (None, "", []):
            return str(value).strip()
    return ""

def _codex_extract_listing_items(payload):
    if isinstance(payload, dict):
        js = payload.get("js")
        if isinstance(js, dict):
            for key in ("data", "items", "episodes", "series"):
                value = js.get(key)
                if isinstance(value, list):
                    return value
        for key in ("data", "items", "episodes", "series"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
    if isinstance(payload, list):
        return payload
    return []

def _codex_clean_series_id(value):
    value = str(value or "").strip()
    return value.split(":", 1)[0] if ":" in value else value

def _codex_clean_season_id(video_id, season):
    raw = str(season or "").strip()
    if not raw and ":" in str(video_id or ""):
        raw = str(video_id or "").split(":", 1)[1]
    match = re.search(r"(\d+)", raw)
    return match.group(1) if match else raw

def _codex_episode_label(item, fallback_index=0):
    label = _codex_first(item, "name", "title", "episode_name", "fname", "original_title")
    if label:
        return label
    number = _codex_first(item, "episode", "episode_number", "series_number", "number")
    if number:
        return "Episode %s" % number
    return "Episode %s" % fallback_index

def _codex_parse_episode_numbers(value):
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value or "").strip()
    if not text:
        return []
    try:
        parsed = json.loads(text)
        if isinstance(parsed, (list, tuple)):
            return [str(v).strip() for v in parsed if str(v).strip()]
    except Exception:
        pass
    return re.findall(r"\d+", text)

def _codex_expand_season_rows_to_episodes(rows, wanted_season=""):
    expanded = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        label = _codex_episode_label(row, len(expanded) + 1)
        lower_label = label.lower()
        numbers = _codex_parse_episode_numbers(row.get("series"))
        cmd = _codex_first(row, "cmd", "url", "stream_url", "command")
        looks_like_season_row = bool(numbers and cmd and ("season" in lower_label or "staffel" in lower_label))
        if not looks_like_season_row:
            expanded.append(row)
            continue
        season_no = _codex_clean_season_id("", label) or str(wanted_season or "").strip()
        for ep_no in numbers:
            item = dict(row)
            item["name"] = "S%s E%s" % (season_no or "?", ep_no)
            item["episode_number"] = ep_no
            item["series"] = ep_no
            item["video_id"] = ep_no
            item["is_codex_expanded_episode"] = True
            expanded.append(item)
    return expanded

def _handle_macsimum_episode_listing(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action not in ("episodes", "episode"):
        return False
    handle = -1
    try:
        handle = int(argv[1])
    except Exception:
        pass
    video_id = (qs.get("video_id") or qs.get("series_id") or [""])[0]
    series_id = _codex_clean_series_id(video_id)
    season_id = _codex_clean_season_id(video_id, (qs.get("season") or [""])[0])
    title = (qs.get("title") or qs.get("tvshow_title") or ["Serie"])[0]
    poster = (qs.get("logo") or qs.get("icon") or [""])[0]
    fanart = (qs.get("fanart") or [""])[0]
    page = (qs.get("page") or ["1"])[0]
    source_mac = _normalize_mac((qs.get("source_mac") or qs.get("choice_source_mac") or [""])[0])
    try:
        _log("Direct series episode listing: series=%r season=%r title=%r" % (series_id, season_id, title))
        payload = _macsimum_retry_call(
            lambda native_service: (lambda: native_service.get_episodes(series_id, season_id, page)),
            "CODEX-MACSIMUM-SERIES-EP-LIST",
            outer_attempts=1,
            inner_attempts=1,
        )
        source_mac = _normalize_mac(_current_module_mac()) or source_mac
        episodes = _codex_extract_listing_items(payload)
        episodes = _codex_expand_season_rows_to_episodes(episodes, season_id)
        try:
            sample_keys = sorted(list(episodes[0].keys())) if episodes and isinstance(episodes[0], dict) else []
            _log("Direct series episode listing returned %s items keys=%r" % (len(episodes), sample_keys[:20]))
        except Exception:
            pass
        if xbmcplugin and handle >= 0:
            try:
                xbmcplugin.setContent(handle, "episodes")
            except Exception:
                pass
        for idx, ep in enumerate(episodes or [], 1):
            if not isinstance(ep, dict):
                continue
            label = _codex_episode_label(ep, idx)
            ep_id = _codex_first(ep, "id", "video_id", "episode_id", "series_id", "ch_id")
            cmd = _codex_first(ep, "cmd", "url", "stream_url", "command")
            ep_series = _codex_first(ep, "series", "series_id", "episode_series") or series_id
            icon = _codex_first(ep, "screenshot_uri", "logo", "logo_url", "icon", "icon_url") or poster
            plot = _codex_first(ep, "descr", "description", "plot", "info")
            duration = _codex_first(ep, "time", "duration")
            params = {
                "action": "codex_macsimum_episode_play",
                "label": label,
                "video_id": ep_id,
                "series": ep_series,
                "cmd": cmd,
                "icon": icon,
                "source_mac": source_mac,
            }
            url = "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))
            li = xbmcgui.ListItem(label=label) if xbmcgui else None
            if li is not None:
                try:
                    li.setProperty("IsPlayable", "true")
                except Exception:
                    pass
                art = {}
                if icon:
                    art.update({"icon": icon, "thumb": icon, "poster": icon})
                if fanart:
                    art["fanart"] = fanart
                if art:
                    try:
                        li.setArt(art)
                    except Exception:
                        pass
                try:
                    info = {"title": label, "mediatype": "episode", "tvshowtitle": title}
                    if plot:
                        info["plot"] = plot
                    if duration and str(duration).isdigit():
                        info["duration"] = int(duration)
                    li.setInfo(type="Video", infoLabels=info)
                except Exception:
                    pass
            if xbmcplugin and handle >= 0 and li is not None:
                xbmcplugin.addDirectoryItem(handle, url, li, False)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, False)
        return True
    except Exception as exc:
        _log("Direct series episode listing failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        if xbmcgui:
            xbmcgui.Dialog().notification("Serien", "Staffel konnte nicht geöffnet werden", xbmcgui.NOTIFICATION_ERROR, 3000)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, False, False, False)
        return True

def _handle_macsimum_vod_play(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_vod_play":
        return False
    label = (qs.get("label") or ["Film"])[0]
    cmd = (qs.get("cmd") or [""])[0]
    icon = (qs.get("icon") or [""])[0]
    year = (qs.get("year") or [""])[0]
    from_favorites = (qs.get("from_favorites") or [""])[0].strip().lower() in ("1", "true", "yes")
    fav_id = (qs.get("fav_id") or [""])[0]
    try:
        stream_url = _macsimum_resolve_vod_stream(cmd)
        if not stream_url and from_favorites:
            _log(
                "CODEX-MACSIMUM-FAVORITES-VOD stored cmd returned empty for %r; no broad lookup or MAC rotation during favorite playback" % label,
                xbmc.LOGWARNING if xbmc else None,
            )
        if not stream_url:
            raise Exception("Kein Stream-Link erhalten")
        if from_favorites:
            try:
                _update_macsimum_favorite_source_mac(fav_id, label, _current_module_mac())
            except Exception as fav_exc:
                _log("CODEX-MACSIMUM-FAVORITES source_mac update skipped: %s" % fav_exc, xbmc.LOGWARNING if xbmc else None)
        item = xbmcgui.ListItem(label=label, path=stream_url)
        item.setProperty("IsPlayable", "true")
        if icon:
            try:
                item.setArt({"icon": icon, "thumb": icon})
            except Exception:
                pass
        try:
            item.setInfo(type="Video", infoLabels={"mediatype": "movie", "title": label})
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(int(argv[1]), True, item)
    except Exception as exc:
        _log("Macsimum VOD play failed for %r: %s" % (label, exc), xbmc.LOGERROR if xbmc else None)
        if xbmcgui:
            xbmcgui.Dialog().notification("Film", "Film konnte nicht geladen werden", xbmcgui.NOTIFICATION_ERROR, 3000)
        try:
            xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
    return True

def _handle_macsimum_episode_play(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_episode_play":
        return False
    label = (qs.get("label") or ["Episode"])[0]
    video_id = (qs.get("video_id") or [""])[0]
    series = (qs.get("series") or [""])[0]
    cmd = (qs.get("cmd") or [""])[0]
    icon = (qs.get("icon") or [""])[0]
    try:
        stream_url = _macsimum_resolve_episode_stream(video_id, series, cmd)
        if not stream_url:
            raise Exception("Kein Stream-Link erhalten")
        item = xbmcgui.ListItem(label=label, path=stream_url)
        item.setProperty("IsPlayable", "true")
        if icon:
            try:
                item.setArt({"icon": icon, "thumb": icon})
            except Exception:
                pass
        try:
            item.setInfo(type="Video", infoLabels={"mediatype": "episode", "title": label})
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(int(argv[1]), True, item)
    except Exception as exc:
        _log("Macsimum episode play failed for %r: %s" % (label, exc), xbmc.LOGERROR if xbmc else None)
        if xbmcgui:
            xbmcgui.Dialog().notification("Episode", "Episode konnte nicht geladen werden", xbmcgui.NOTIFICATION_ERROR, 3000)
        try:
            xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
    return True

def _codex_scan_key_index(scanned, unique_only=False):
    by_key = {}
    duplicates = set()
    for item in scanned or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name") or ""
        cmd = item.get("cmd") or ""
        if not name or not cmd:
            continue
        for key in _codex_channel_match_keys(name):
            if not key:
                continue
            previous = by_key.get(key)
            if previous and (
                (previous.get("cmd") or "") != cmd
                or (previous.get("name") or "") != name
            ):
                duplicates.add(key)
                continue
            if key not in by_key:
                by_key[key] = item
    if unique_only and duplicates:
        for key in duplicates:
            by_key.pop(key, None)
    return by_key

def _codex_refresh_m3u_from_scan(scope, scanned, fallback_scanned=None):
    path = _codex_scope_m3u_path(scope)
    if not os.path.exists(path):
        return 0, 0, path
    by_key = _codex_scan_key_index(scanned, unique_only=False)
    # Zweite Stufe fuer Sammellisten und verschobene Kategorien:
    # Erst enger Länder-/Scope-Treffer, dann nur eindeutig global gefundene
    # Sender. Dadurch werden z.B. International-Sport-Eintraege aus AT/PL/BE
    # repariert, ohne riskante doppelte Namen quer zu verdrahten.
    fallback_by_key = _codex_scan_key_index(fallback_scanned, unique_only=True) if fallback_scanned else {}
    with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
        lines = fh.read().splitlines()
    matched = 0
    changed = 0
    total = 0
    missing = []
    current_name = ""
    out = []
    for line in lines:
        if line.startswith("#EXTINF"):
            current_name = _codex_m3u_extinf_name(line)
            out.append(line)
            continue
        if current_name and line.startswith("plugin://plugin.video.stalker.macsimum/"):
            if not _codex_m3u_name_is_relevant_channel(current_name):
                out.append(line)
                current_name = ""
                continue
            total += 1
            match = None
            for key in _codex_channel_match_keys(current_name):
                match = by_key.get(key)
                if not match:
                    match = fallback_by_key.get(key)
                if match:
                    break
            if match and match.get("cmd"):
                matched += 1
                new_line = _codex_update_plugin_url(line, current_name, match)
                if new_line != line:
                    changed += 1
                out.append(new_line)
            elif _codex_plugin_url_has_bridge_cmd(line):
                # Schon fertig verdrahtet: nicht als Luecke zaehlen, auch wenn
                # der aktuelle Scan-Snapshot den Namen nicht mehr enthaelt.
                matched += 1
                out.append(line)
            else:
                missing.append(current_name)
                out.append(line)
            current_name = ""
            continue
        out.append(line)
    if changed:
        backup = path + ".bak_scope_scan_%s" % time.strftime("%Y%m%d_%H%M%S")
        try:
            with open(backup, "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
        except Exception:
            pass
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(out) + "\n")
    try:
        miss_path = os.path.join(_addon_profile_dir(), "codex_macsimum_%s_live_scan_missing_m3u.txt" % ((scope or "de").strip().lower()))
        with open(miss_path, "w", encoding="utf-8") as fh:
            fh.write("Nicht zugeordnete M3U-Eintraege: %s von %s\n\n" % (len(missing), total))
            for name in missing:
                fh.write("- %s\n" % name)
    except Exception:
        pass
    return matched, total, changed, path

def _handle_macsimum_bridge_play(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_bridge_play":
        return False
    label = (qs.get("label") or ["Live TV"])[0]
    cmd = (qs.get("cmd") or [""])[0]
    icon = (qs.get("icon") or [""])[0]
    duplicate_click, guard_remaining = _live_same_channel_guard(label, cmd)
    if duplicate_click:
        _log(
            "CODEX-MACSIMUM-TV-PLAY same-channel click blocked (%ds left): %s" % (
                guard_remaining,
                label or "-",
            ),
            xbmc.LOGWARNING if xbmc else None,
        )
        try:
            xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
        return True
    cooldown = _cooldown_remaining()
    if cooldown:
        _log(
            "CODEX-MACSIMUM-TV-PLAY skip bridge while portal cooldown is active (%d seconds left): %s" % (cooldown, label or "-"),
            xbmc.LOGWARNING if xbmc else None,
        )
        try:
            if xbmcgui:
                xbmcgui.Dialog().notification(
                    "Live TV 3",
                    "Portal beruhigt sich kurz (%ds)" % cooldown,
                    xbmcgui.NOTIFICATION_WARNING,
                    1800,
                )
        except Exception:
            pass
        _macsimum_abort_playback_busy_state("bridge cooldown: %s" % label)
        try:
            xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
        return True
    progress = None
    try:
        progress = _macsimum_live_loading_progress(label, 8, "Sender wird geladen")
        _macsimum_live_loading_update(progress, 15, label, "Alten Stream sauber stoppen")
        _macsimum_prestop_live_player_before_bridge(label, keep_busy=True)
        _macsimum_live_loading_update(progress, 35, label, "Stream wird vorbereitet")
        stream_url = _macsimum_resolve_tv_stream(cmd, label)
        if not stream_url:
            raise Exception("Kein Stream-Link erhalten")
        _macsimum_live_loading_update(progress, 82, label, "Stream gefunden")
        item = xbmcgui.ListItem(label=label, path=stream_url)
        item.setProperty("IsPlayable", "true")
        try:
            if icon:
                item.setArt({"icon": icon, "thumb": icon})
        except Exception:
            pass
        try:
            item.setInfo(type="Video", infoLabels={"mediatype": "movie", "Title": label})
        except Exception:
            pass
        _macsimum_live_loading_update(progress, 95, label, "Wiedergabe startet")
        xbmcplugin.setResolvedUrl(int(argv[1]), True, item)
    except Exception as exc:
        _log("Macsimum bridge play failed for %r: %s" % (label, exc), xbmc.LOGERROR if xbmc else None)
        _macsimum_live_loading_update(progress, 100, label, "Kanal nicht erreichbar")
        _macsimum_abort_playback_busy_state("bridge failed: %s" % label)
        try:
            xbmcplugin.setResolvedUrl(int(argv[1]), False, xbmcgui.ListItem())
        except Exception:
            pass
        _macsimum_abort_playback_busy_state("bridge resolved false: %s" % label)
    finally:
        _macsimum_live_loading_close(progress)
    return True

def _codex_write_handshake_status_file(path, payload):
    try:
        if not path:
            return
        try:
            if xbmcvfs and str(path).startswith("special://"):
                path = xbmcvfs.translatePath(path)
        except Exception:
            pass
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except Exception:
                pass
        data = dict(payload or {})
        data["ts"] = time.time()
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, sort_keys=True)
    except Exception as exc:
        _log("CODEX-MACSIMUM-HANDSHAKE status file write failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)

def _codex_macsimum_verify_live_stream_link():
    """Verify that the current Live-TV session can build at least one real stream link."""
    candidates = (
        ("COMEDY CENTRAL RAW", "ffmpeg http://localhost/ch/160914_"),
        ("PROSIEBEN HD", "ffmpeg http://localhost/ch/95561_"),
        ("DMAX RAW", "ffmpeg http://localhost/ch/129769_"),
    )
    for label, cmd in candidates:
        try:
            stream = _macsimum_resolve_tv_stream(cmd, "VERIFY %s" % label)
            if stream:
                _log(
                    "CODEX-MACSIMUM-HANDSHAKE-LIVE verify stream ok: %s" % label,
                    xbmc.LOGWARNING if xbmc else None,
                )
                _mac_analytics_log("manual-handshake-live-verify-ok", reason=label)
                return True
            _log(
                "CODEX-MACSIMUM-HANDSHAKE-LIVE verify stream empty: %s" % label,
                xbmc.LOGWARNING if xbmc else None,
            )
        except Exception as exc:
            _log(
                "CODEX-MACSIMUM-HANDSHAKE-LIVE verify stream error %s: %s" % (label, exc),
                xbmc.LOGWARNING if xbmc else None,
            )
    _mac_analytics_log("manual-handshake-live-verify-failed", reason="no live stream link")
    return False

def _handle_macsimum_handshake(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_handshake":
        return False
    try:
        if xbmcgui:
            xbmcgui.Dialog().notification("Handshake", "Handshake läuft...", time=1500)
        _mac_analytics_log("manual-handshake-start")
        try:
            state = _load_mac_state()
            for key in ("current_mac", "current_at", "current_scope", "verified_scopes", "scope_failures"):
                state.pop(key, None)
            _save_mac_state(state)
            _mac_analytics_log("manual-handshake-session-cleared")
        except Exception:
            pass
        _reset_impl_for_retry()
        _mac_analytics_log("manual-handshake-after-reset")
        _macsimum_warmup_native("CODEX-MACSIMUM-HANDSHAKE", rotate_on_empty=False)
        _mac_analytics_log("manual-handshake-after-warmup")
        if xbmcgui:
            xbmcgui.Dialog().notification("Handshake", "Handshake erfolgreich", time=2500)
    except Exception as exc:
        _mac_analytics_log("manual-handshake-error", reason=str(exc))
        _log("Macsimum manual handshake failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        if xbmcgui:
            xbmcgui.Dialog().notification("Handshake", "Handshake fehlgeschlagen", xbmcgui.NOTIFICATION_ERROR, 3000)
    return True

# Portal-1-Handshake: letzte Definition ist absichtlich die aktive Variante.
# Sie ersetzt den alten Legacy-Block direkt darueber, damit nur noch der
# Portal-2-aehnliche Warm-up mit Ergebnispruefung benutzt wird.
def _handle_macsimum_handshake(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_handshake":
        return False

    quiet = (qs.get("quiet") or ["0"])[0].strip().lower() in ("1", "true", "yes")
    verify_live = (qs.get("verify_live") or qs.get("codex_verify_live") or ["0"])[0].strip().lower() in ("1", "true", "yes")
    status_file = (qs.get("codex_status_file") or qs.get("status_file") or [""])[0].strip()
    scope = (qs.get("scope") or ["root"])[0].strip().lower() or "root"
    favorite_scope = scope in ("favorites", "favourites", "favoriten")
    if favorite_scope:
        target = "vod"
    elif scope in ("series", "serien"):
        target = "series"
    elif scope in ("live", "tv", "livetv"):
        target = "live"
    else:
        target = "vod"
    log_scope = "favorites target=vod" if favorite_scope else target

    cooldown = _cooldown_remaining()
    if cooldown:
        _log(
            "CODEX-MACSIMUM-HANDSHAKE skip while portal cooldown is active (%d seconds left, scope=%s)" % (cooldown, target),
            xbmc.LOGWARNING if xbmc else None,
        )
        try:
            if xbmcgui and not quiet:
                xbmcgui.Dialog().notification(
                    "Handshake",
                    "Portal beruhigt sich kurz (%ds)" % cooldown,
                    xbmcgui.NOTIFICATION_WARNING,
                    2000,
                )
        except Exception:
            pass
        try:
            if status_file:
                _codex_write_handshake_status_file(status_file, {
                    "ok": False,
                    "addon": ADDON_ID,
                    "scope": target,
                    "error": "portal cooldown active",
                    "cooldown": cooldown,
                })
            if xbmcplugin and len(argv) > 1:
                xbmcplugin.endOfDirectory(int(argv[1]), False, False, False)
        except Exception:
            pass
        return True

    progress = None
    ok = False
    soft_live_ok = False
    last_error = None
    try:
        if xbmcgui and not quiet:
            progress = xbmcgui.DialogProgress()
            progress.create("Handshake", "Handshake laeuft...")
            progress.update(5, "Handshake laeuft...")

        _mac_analytics_log("manual-handshake-start", reason="scope=%s" % log_scope)
        try:
            if progress:
                progress.update(20, "Session wird vorbereitet...")
            state = _load_mac_state()
            for key in ("current_mac", "current_at", "current_scope", "verified_scopes", "scope_failures"):
                state.pop(key, None)
            _save_mac_state(state)
            _mac_analytics_log("manual-handshake-session-cleared", reason="scope=favorites-new-mac" if favorite_scope else "scope=%s" % target)
            try:
                _clear_category_nav_cache("manual handshake reset: %s" % log_scope)
            except Exception:
                pass
        except Exception as state_exc:
            _mac_analytics_log("manual-handshake-session-clear-error", reason=str(state_exc))

        _reset_impl_for_retry()
        _mac_analytics_log("manual-handshake-after-reset", reason="scope=%s" % log_scope)

        if target == "live":
            if progress:
                progress.update(35, "Alten Live-Stream stoppen...")
            try:
                _macsimum_prestop_live_player_before_bridge("Handshake Live", keep_busy=True)
            except Exception as stop_exc:
                _log(
                    "CODEX-MACSIMUM-HANDSHAKE-LIVE pre-stop failed: %s" % stop_exc,
                    xbmc.LOGWARNING if xbmc else None,
                )

        if progress:
            progress.update(45, "Warm-up...")
        try:
            ok = bool(_macsimum_warmup_native(
                "CODEX-MACSIMUM-HANDSHAKE-%s" % target.upper(),
                rotate_on_empty=(target != "live"),
                max_attempts=1,
                targets=target,
            ))
            if not ok and target == "live" and _current_module_token():
                _log(
                    "CODEX-MACSIMUM-HANDSHAKE-LIVE live warmup empty but token ok; accepting soft handshake without pinning current MAC",
                    xbmc.LOGWARNING if xbmc else None,
                )
                soft_live_ok = True
                ok = True
        except Exception as warm_exc:
            last_error = warm_exc
            ok = False

        _mac_analytics_log(
            "manual-handshake-after-warmup",
            reason=("ok scope=%s" % log_scope) if ok else ("failed scope=%s error=%s" % (log_scope, last_error or "")),
        )

        if ok and target == "live" and verify_live:
            if progress:
                progress.update(70, "Sender-Link wird geprueft...")
            if soft_live_ok:
                ok = False
                last_error = "live warmup empty; strict stream verify skipped"
                soft_live_ok = False
                _mac_analytics_log("manual-handshake-live-verify-failed", reason=last_error)
            elif not _codex_macsimum_verify_live_stream_link():
                ok = False
                last_error = "live stream verify failed"

        if ok:
            if soft_live_ok:
                try:
                    _clear_current_mac_from_state("live soft handshake had empty warmup; do not pin current MAC")
                except Exception:
                    pass
                _mac_analytics_log("manual-handshake-soft-ok-unpinned", reason="scope=%s" % log_scope)
            else:
                try:
                    _remember_current_mac(_current_module_mac())
                except Exception:
                    pass
                if favorite_scope:
                    try:
                        updated = _update_all_macsimum_favorites_source_mac(_current_module_mac())
                        _mac_analytics_log("manual-handshake-favorites-source-mac-updated", reason="updated=%d" % updated)
                    except Exception as fav_update_exc:
                        _mac_analytics_log("manual-handshake-favorites-source-mac-update-error", reason=str(fav_update_exc))
            if progress:
                progress.update(100, "Handshake erfolgreich")
                try:
                    xbmc.sleep(250)
                except Exception:
                    pass
            if xbmcgui and not quiet:
                xbmcgui.Dialog().notification("Handshake", "Handshake erfolgreich", time=1800)
            _mac_analytics_log("manual-handshake-finished-ok", reason="scope=%s" % log_scope)
            if target == "series":
                try:
                    _log(
                        "CODEX-MACSIMUM-HANDSHAKE-SERIES refresh current episode container after new MAC",
                        xbmc.LOGWARNING if xbmc else None,
                    )
                    if xbmc:
                        xbmc.executebuiltin("Container.Refresh")
                except Exception as refresh_exc:
                    _log(
                        "CODEX-MACSIMUM-HANDSHAKE-SERIES refresh failed: %s" % refresh_exc,
                        xbmc.LOGWARNING if xbmc else None,
                    )
        else:
            try:
                state = _load_mac_state()
                for key in ("current_mac", "current_at", "current_scope", "verified_scopes", "scope_failures"):
                    state.pop(key, None)
                _save_mac_state(state)
            except Exception:
                pass
            _reset_impl_for_retry()
            if progress:
                progress.update(100, "Handshake fehlgeschlagen")
                try:
                    xbmc.sleep(250)
                except Exception:
                    pass
            if xbmcgui and not quiet:
                xbmcgui.Dialog().notification("Handshake", "Handshake fehlgeschlagen", xbmcgui.NOTIFICATION_ERROR, 3000)
            _mac_analytics_log("manual-handshake-finished-failed", reason=str(last_error or "no categories"))
    except Exception as exc:
        last_error = exc
        _mac_analytics_log("manual-handshake-error", reason=str(exc))
        _log("Macsimum manual handshake failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        if progress:
            try:
                progress.update(100, "Handshake fehlgeschlagen")
                xbmc.sleep(250)
            except Exception:
                pass
        if xbmcgui and not quiet:
            xbmcgui.Dialog().notification("Handshake", "Handshake fehlgeschlagen", xbmcgui.NOTIFICATION_ERROR, 3000)
    finally:
        if progress:
            try:
                progress.close()
            except Exception:
                pass
        if status_file:
            _codex_write_handshake_status_file(status_file, {
                "ok": bool(ok),
                "addon": ADDON_ID,
                "scope": target,
                "soft_live_ok": bool(soft_live_ok),
                "verify_live": bool(verify_live),
                "mac": _redact_mac(_current_module_mac()),
                "error": "" if ok else str(last_error or "no categories"),
            })
        try:
            if xbmcplugin and len(argv) > 1:
                xbmcplugin.endOfDirectory(int(argv[1]), ok, False, False)
        except Exception:
            pass
    return True

def _handle_macsimum_scope_scan(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_scope_scan":
        return False
    scope = (qs.get("scope") or ["de"])[0].strip().lower() or "de"
    if scope == "ru_ua_kaukasus":
        scope = "ru"
    handle = -1
    try:
        handle = int(argv[1])
    except Exception:
        pass
    progress = None
    scanned = []
    selected = []
    request_count = 0
    empty_retry_count = 0
    empty_retry_recovered = 0
    fresh_scanned_count = 0
    try:
        if xbmcgui:
            progress = xbmcgui.DialogProgress()
            progress.create("Senderliste wird aktualisiert", "Portal-Session vorbereiten...")
            progress.update(1, "Portal-Session vorbereiten...")
        mod, _pinned_mac = _prepare_usable_impl()
        if mod is None:
            previous_snapshot = _codex_load_all_live_scan_snapshot()
            previous_rows = previous_snapshot.get("seen") if isinstance(previous_snapshot, dict) else []
            previous_categories = previous_snapshot.get("categories") if isinstance(previous_snapshot, dict) else []
            matched, total_items, changed, m3u_path = _codex_refresh_m3u_from_scan(scope, [], previous_rows)
            if progress:
                progress.update(100, "Portal nicht erreichbar - Speicher genutzt")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Aktualisiert", "Aus Speicher: %s von %s" % (matched, total_items), time=3500)
            _log("Macsimum scope scan used snapshot fallback: scope=%s matched=%s/%s changed=%s m3u=%s categories=%s" % (
                scope, matched, total_items, changed, m3u_path, len(previous_categories or [])
            ), xbmc.LOGWARNING if xbmc else None)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            return True
        import lib.service as native_service
        portal_categories = native_service.get_tv_genres() or []
        categories = _codex_merge_live_categories(portal_categories)
        categories = [g for g in categories if not _codex_live_scan_category_is_247(g)]
        selected = _codex_categories_for_scope(scope, categories)
        if not selected:
            raise Exception("Keine passenden Kategorien")
        previous_snapshot = _codex_load_all_live_scan_snapshot()
        previous_rows = previous_snapshot.get("seen") if isinstance(previous_snapshot, dict) else []
        previous_categories = previous_snapshot.get("categories") if isinstance(previous_snapshot, dict) else []
        previous_seen_by_category = _codex_previous_live_seen_by_category()
        total_categories = max(1, len(selected))
        _log("Macsimum scope scan starts: scope=%s categories=%s portal=%s" % (scope, len(selected), len(portal_categories)), xbmc.LOGWARNING if xbmc else None)
        for idx, genre in enumerate(selected, 1):
            title = str((genre or {}).get("title") or (genre or {}).get("name") or "").strip()
            gid = _codex_genre_id(genre)
            if not gid:
                continue
            if progress:
                try:
                    if progress.iscanceled():
                        break
                    progress.update(int(3 + (idx - 1) * 92 / total_categories), "%s / %s: %s" % (idx, total_categories, title))
                except Exception:
                    pass
            category_seen = 0
            for page in range(1, 21):
                try:
                    if request_count:
                        time.sleep(1.6)
                    request_count += 1
                except Exception:
                    pass
                payload, data, total_items, retry_used = _codex_get_tv_channels_scan_page(
                    native_service, gid, page, title, progress,
                    previous_seen_by_category.get(str(gid).strip()) or [],
                    retry_delay=2.2,
                )
                empty_retry_count += retry_used
                if retry_used and data:
                    empty_retry_recovered += 1
                if not data:
                    if page == 1:
                        _log("Macsimum scope scan empty category: scope=%s id=%s title=%s" % (scope, gid, title), xbmc.LOGWARNING if xbmc else None)
                    break
                for item in data:
                    name = _codex_channel_title(item)
                    cmd = _codex_channel_cmd(item)
                    icon = _codex_channel_icon(item)
                    if name and cmd:
                        category_seen += 1
                        fresh_scanned_count += 1
                        scanned.append({"name": name, "cmd": cmd, "icon": icon, "category": title, "category_id": gid, "page": page})
                if total_items and category_seen >= total_items:
                    break
                if not total_items:
                    break
            if category_seen == 0:
                previous_rows_for_category = previous_seen_by_category.get(str(gid).strip()) or []
                if previous_rows_for_category:
                    for row in previous_rows_for_category:
                        keep = dict(row)
                        keep.setdefault("category", title)
                        keep.setdefault("category_id", gid)
                        keep["stale_snapshot"] = "1"
                        scanned.append(keep)
        if fresh_scanned_count <= 0:
            if progress:
                progress.update(100, "Keine neuen Treffer - bestehende Liste bleibt")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Aktualisiert", "Keine neuen Treffer - Liste bleibt", time=3500)
            _log("Macsimum scope scan kept existing mapping: scope=%s categories=%s stale_rows=%s requests=%s empty_retry=%s recovered=%s" % (
                scope, len(selected), len(scanned), request_count, empty_retry_count, empty_retry_recovered
            ), xbmc.LOGWARNING if xbmc else None)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            return True
        json_path, txt_path = _codex_write_scan_report(scope, selected, scanned)
        snapshot_backup = _codex_backup_all_live_scan_snapshot("scope_scan_%s" % scope)
        merged_rows = _codex_merge_live_scan_rows(previous_rows, scanned)
        merged_categories = _codex_merge_live_scan_categories(previous_categories, categories, merged_rows)
        all_json_path, all_txt_path = _codex_write_scan_report("all", merged_categories, merged_rows)
        _codex_write_country_discovery_report(merged_categories, merged_rows)
        matched, total_items, changed, m3u_path = _codex_refresh_m3u_from_scan(scope, scanned, merged_rows)
        if progress:
            progress.update(100, "Aktualisiert: %s von %s" % (matched, total_items))
            time.sleep(0.35)
            progress.close()
        if xbmcgui:
            xbmcgui.Dialog().notification("Aktualisiert", "%s von %s | geaendert: %s" % (matched, total_items, changed), time=3500)
        _log("Macsimum scope scan done: scope=%s categories=%s scanned=%s matched=%s/%s changed=%s m3u=%s json=%s txt=%s" % (
            scope, len(selected), len(scanned), matched, total_items, changed, m3u_path, json_path, txt_path
        ), xbmc.LOGWARNING if xbmc else None)
        _log("Macsimum scope scan snapshot updated: scope=%s requests=%s empty_retry=%s recovered=%s backup=%s all_json=%s all_txt=%s" % (
            scope, request_count, empty_retry_count, empty_retry_recovered, snapshot_backup, all_json_path, all_txt_path
        ), xbmc.LOGWARNING if xbmc else None)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, False)
    except Exception as exc:
        _log("Macsimum scope scan failed: scope=%s error=%s" % (scope, exc), xbmc.LOGERROR if xbmc else None)
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        if xbmcgui:
            xbmcgui.Dialog().notification("Aktualisierung fehlgeschlagen", str(exc)[:80], xbmcgui.NOTIFICATION_ERROR, 3500)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, False, False, False)
    return True

def _codex_write_scan_report(scope, categories, scanned):
    json_path, txt_path = _codex_scan_report_paths(scope)
    cat_counts = {}
    for item in scanned:
        key = str(item.get("category_id") or item.get("category") or "").strip()
        cat_counts[key] = cat_counts.get(key, 0) + 1
    packed_categories = []
    for cat in categories or []:
        title = str((cat or {}).get("title") or (cat or {}).get("name") or "").strip()
        cid = _codex_genre_id(cat)
        packed_categories.append({"id": cid, "title": title, "seen": cat_counts.get(cid, 0) or cat_counts.get(title, 0)})
    payload = {
        "addon": ADDON_ID,
        "scope": scope,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "categories": packed_categories,
        "seen": scanned,
        "status": "ok",
    }
    try:
        with open(json_path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
    except Exception as exc:
        _log("Macsimum scan JSON report failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    try:
        with open(txt_path, "w", encoding="utf-8") as fh:
            fh.write("Macsimum Live Scan: %s\n" % scope)
            fh.write("Gruppen: %s | Sender: %s\n\n" % (len(packed_categories), len(scanned)))
            for cat in packed_categories:
                fh.write("## [%s] %s (%s)\n" % (cat.get("id") or "", cat.get("title") or "", cat.get("seen") or 0))
                for item in scanned:
                    if str(item.get("category_id") or "") == str(cat.get("id") or ""):
                        fh.write("- %s\n" % (item.get("name") or ""))
                fh.write("\n")
    except Exception as exc:
        _log("Macsimum scan TXT report failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return json_path, txt_path

def _codex_write_country_discovery_report(categories, scanned):
    path = os.path.join(_addon_profile_dir(), "codex_macsimum_country_discovery.txt")
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("Macsimum Kategorie-/Laenderuebersicht\n")
            fh.write("Gruppen: %s | Sender: %s\n\n" % (len(categories or []), len(scanned or [])))
            for cat in categories or []:
                cid = _codex_genre_id(cat)
                title = str((cat or {}).get("title") or (cat or {}).get("name") or "").strip()
                count = sum(1 for item in scanned or [] if str(item.get("category_id") or "") == str(cid))
                fh.write("[%s] %s => %s Sender\n" % (cid, title, count))
    except Exception as exc:
        _log("Macsimum country discovery report failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return path

def _codex_all_m3u_refresh_scopes():
    return [
        "de", "international_sport",
        "at", "ch", "nl", "be", "england", "us", "ca", "fr", "it", "es", "pt", "pl",
        "al", "rs", "me", "hr", "si", "mk", "ba", "exyu_allgemein", "gr", "ro", "bg", "hu", "cz", "sk",
        "dk", "se", "no", "fi", "ru", "ua", "ge", "az", "am", "au", "br", "co", "pe",
        "arabic_general", "ma", "dz", "sa", "lb", "tn", "kw", "sd", "eg", "ps", "ae", "bh", "iq", "jo", "qa", "sy",
        "kurdish", "suryoyo", "ir", "in", "pk", "africa", "dstv", "th", "adult",
    ]

def _codex_refresh_all_scope_m3us_from_scan(categories, scanned, progress=None):
    category_by_id = {}
    for cat in categories or []:
        cid = _codex_genre_id(cat)
        if cid:
            category_by_id[str(cid)] = cat
    scanned_by_scope = {}
    for item in scanned or []:
        cid = str(item.get("category_id") or "").strip()
        cat = category_by_id.get(cid) or {"id": cid, "title": item.get("category") or ""}
        scopes = _codex_category_scope(cat)
        for scope in scopes:
            scanned_by_scope.setdefault(scope, []).append(item)
    results = []
    scopes = _codex_all_m3u_refresh_scopes()
    total = max(1, len(scopes))
    for idx, scope in enumerate(scopes, 1):
        try:
            if progress:
                try:
                    progress.update(int(70 + (idx - 1) * 25 / total), "Aktualisiere M3U: %s" % scope)
                except Exception:
                    pass
            matched, total_items, changed, m3u_path = _codex_refresh_m3u_from_scan(scope, scanned_by_scope.get(scope, []), scanned)
            results.append({"scope": scope, "matched": matched, "total": total_items, "changed": changed, "path": m3u_path})
        except Exception as exc:
            results.append({"scope": scope, "matched": 0, "total": 0, "changed": 0, "error": str(exc)})
            _log("Macsimum all-scope M3U refresh failed for %s: %s" % (scope, exc), xbmc.LOGWARNING if xbmc else None)
    try:
        path = os.path.join(_addon_profile_dir(), "codex_macsimum_all_scope_m3u_refresh.txt")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("Macsimum M3U-Aktualisierung aus All-Live-Scan\n")
            fh.write("Zeit: %s\n\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
            for row in results:
                fh.write("%s: matched=%s/%s changed=%s%s\n" % (
                    row.get("scope") or "",
                    row.get("matched") or 0,
                    row.get("total") or 0,
                    row.get("changed") or 0,
                    (" error=" + row.get("error")) if row.get("error") else "",
                ))
    except Exception as exc:
        _log("Macsimum all-scope M3U refresh report failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return results

def _codex_refresh_all_scope_m3us_from_saved_snapshot(progress=None, reason=""):
    snapshot = _codex_load_all_live_scan_snapshot()
    categories = snapshot.get("categories") if isinstance(snapshot, dict) else []
    scanned = snapshot.get("seen") if isinstance(snapshot, dict) else []
    if not scanned:
        return None
    if progress:
        try:
            progress.update(80, "Portal nicht erreichbar - nutze gespeicherten Scan...")
        except Exception:
            pass
    refresh_results = _codex_refresh_all_scope_m3us_from_scan(categories or _codex_saved_full_live_categories(), scanned, progress)
    changed_total = sum(int(row.get("changed") or 0) for row in refresh_results)
    matched_total = sum(int(row.get("matched") or 0) for row in refresh_results)
    list_total = sum(int(row.get("total") or 0) for row in refresh_results)
    _log("Macsimum ALL live scan fallback from saved snapshot%s: categories=%s scanned=%s matched=%s/%s changed=%s" % (
        ((" (%s)" % reason) if reason else ""),
        len(categories or []), len(scanned or []), matched_total, list_total, changed_total
    ), xbmc.LOGWARNING if xbmc else None)
    return refresh_results, matched_total, list_total, changed_total

def _codex_m3u_missing_summary(scopes, scanned):
    by_key = {}
    for item in scanned or []:
        name = _codex_channel_title(item)
        cmd = _codex_channel_cmd(item)
        if not name or not cmd:
            continue
        for key in _codex_channel_match_keys(name):
            if key and key not in by_key:
                by_key[key] = item
    result = {}
    for scope in scopes or []:
        path = _codex_scope_m3u_path(scope)
        total = 0
        matched = 0
        missing = []
        if not os.path.exists(path):
            result[scope] = {"total": 0, "matched": 0, "missing": [], "path": path}
            continue
        current_name = ""
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith("#EXTINF"):
                        current_name = _codex_m3u_extinf_name(line)
                        continue
                    if current_name and line.startswith("plugin://plugin.video.stalker.macsimum/"):
                        if not _codex_m3u_name_is_relevant_channel(current_name):
                            current_name = ""
                            continue
                        total += 1
                        found = False
                        if _codex_plugin_url_has_bridge_cmd(line):
                            found = True
                        for key in _codex_channel_match_keys(current_name):
                            if key in by_key:
                                found = True
                                break
                        if found:
                            matched += 1
                        else:
                            missing.append(current_name)
                        current_name = ""
        except Exception as exc:
            _log("Macsimum missing M3U summary failed for %s: %s" % (scope, exc), xbmc.LOGWARNING if xbmc else None)
        result[scope] = {"total": total, "matched": matched, "missing": missing, "path": path}
    return result

def _codex_missing_summary_counts(summary):
    total = 0
    matched = 0
    missing = 0
    for row in (summary or {}).values():
        total += int(row.get("total") or 0)
        matched += int(row.get("matched") or 0)
        missing += len(row.get("missing") or [])
    return total, matched, missing

def _codex_write_missing_m3u_repair_report(before_summary, after_summary, candidates, scanned, refresh_results, details=None):
    path = os.path.join(_addon_profile_dir(), "codex_macsimum_missing_m3u_repair_report.txt")
    try:
        before_total, before_matched, before_missing = _codex_missing_summary_counts(before_summary)
        after_total, after_matched, after_missing = _codex_missing_summary_counts(after_summary)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("Macsimum Fehlende-M3U-Zuordnungen Reparatur\n")
            fh.write("Zeit: %s\n\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
            fh.write("Vorher:  matched=%s/%s missing=%s\n" % (before_matched, before_total, before_missing))
            fh.write("Nachher: matched=%s/%s missing=%s\n" % (after_matched, after_total, after_missing))
            fh.write("Gescannte Kategorien: %s | gelesene Zeilen: %s\n\n" % (len(candidates or []), len(scanned or [])))
            if details:
                for line in details:
                    fh.write("%s\n" % line)
                fh.write("\n")
            fh.write("M3U-Aktualisierung:\n")
            for row in refresh_results or []:
                fh.write("- %s: matched=%s/%s changed=%s%s\n" % (
                    row.get("scope") or "",
                    row.get("matched") or 0,
                    row.get("total") or 0,
                    row.get("changed") or 0,
                    (" error=" + row.get("error")) if row.get("error") else "",
                ))
            fh.write("\nNoch fehlend pro Liste:\n")
            for scope in sorted((after_summary or {}).keys()):
                row = after_summary.get(scope) or {}
                missing = row.get("missing") or []
                if not row.get("total") and not missing:
                    continue
                fh.write("\n## %s: missing=%s von %s\n" % (scope, len(missing), row.get("total") or 0))
                for name in missing[:250]:
                    fh.write("- %s\n" % name)
                if len(missing) > 250:
                    fh.write("- ... %s weitere\n" % (len(missing) - 250))
    except Exception as exc:
        _log("Macsimum missing M3U repair report failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)
    return path

def _handle_macsimum_missing_m3u_repair(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_missing_m3u_repair":
        return False
    handle = -1
    try:
        handle = int(argv[1])
    except Exception:
        pass

    progress = None
    scanned = []
    candidates = []
    details = []
    request_count = 0
    empty_retry_count = 0
    empty_retry_recovered = 0
    try:
        if xbmcgui:
            progress = xbmcgui.DialogProgress()
            progress.create("Fehlende Sender zuordnen", "Pruefe M3U-Luecken...")
            progress.update(1, "Pruefe M3U-Luecken...")

        snapshot = _codex_load_all_live_scan_snapshot()
        previous_rows = snapshot.get("seen") if isinstance(snapshot, dict) else []
        previous_categories = snapshot.get("categories") if isinstance(snapshot, dict) else []
        previous_seen_by_category = _codex_previous_live_seen_by_category()
        scopes = _codex_all_m3u_refresh_scopes()
        before_summary = _codex_m3u_missing_summary(scopes, previous_rows)
        affected_scopes = set(scope for scope, row in before_summary.items() if row.get("missing"))
        before_total, before_matched, before_missing = _codex_missing_summary_counts(before_summary)
        details.append("Betroffene Scopes: %s" % (", ".join(sorted(affected_scopes)) or "-"))
        details.append("Vorher matched=%s/%s missing=%s" % (before_matched, before_total, before_missing))

        if not affected_scopes:
            refresh_results = _codex_refresh_all_scope_m3us_from_scan(previous_categories or _codex_saved_full_live_categories(), previous_rows, progress)
            after_summary = _codex_m3u_missing_summary(scopes, previous_rows)
            report = _codex_write_missing_m3u_repair_report(before_summary, after_summary, [], [], refresh_results, details)
            if progress:
                progress.update(100, "Keine offenen M3U-Luecken gefunden")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Fehlende Sender", "Keine offenen Luecken", time=3500)
            _log("Macsimum missing M3U repair skipped: no gaps report=%s" % report, xbmc.LOGWARNING if xbmc else None)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            return True

        if progress:
            progress.update(4, "Portal-Session vorbereiten...")
        mod, _pinned_mac = _prepare_usable_impl()
        if mod is None:
            refresh_results = _codex_refresh_all_scope_m3us_from_scan(previous_categories or _codex_saved_full_live_categories(), previous_rows, progress)
            after_summary = _codex_m3u_missing_summary(scopes, previous_rows)
            report = _codex_write_missing_m3u_repair_report(before_summary, after_summary, [], [], refresh_results, details + ["Portal nicht erreichbar: nur Snapshot-Zuordnung erneuert."])
            if progress:
                progress.update(100, "Portal nicht erreichbar - Snapshot genutzt")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Fehlende Sender", "Aus Speicher aktualisiert", time=3500)
            _log("Macsimum missing M3U repair used snapshot fallback: report=%s" % report, xbmc.LOGWARNING if xbmc else None)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            return True

        import lib.service as native_service
        portal_categories = native_service.get_tv_genres() or []
        categories = _codex_merge_live_categories(portal_categories or previous_categories)
        categories = [g for g in categories if _codex_genre_id(g) and not _codex_live_scan_category_is_247(g)]
        if not categories:
            raise Exception("Keine Live-TV-Kategorien erhalten")

        for cat in categories:
            cat_scopes = _codex_category_scope(cat)
            if cat_scopes.intersection(affected_scopes):
                candidates.append(cat)
        if not candidates:
            candidates = categories
            details.append("Keine Scope-Kategorien gefunden; Vollscan als Fallback.")

        _log("Macsimum missing M3U repair starts: affected_scopes=%s candidates=%s previous_rows=%s" % (
            ",".join(sorted(affected_scopes)), len(candidates), len(previous_rows or [])
        ), xbmc.LOGWARNING if xbmc else None)

        total_candidates = max(1, len(candidates))
        for idx, genre in enumerate(candidates, 1):
            title = str((genre or {}).get("title") or (genre or {}).get("name") or "").strip()
            gid = _codex_genre_id(genre)
            if not gid:
                continue
            category_seen = 0
            if progress:
                try:
                    if progress.iscanceled():
                        details.append("Vom Benutzer abgebrochen bei Kategorie %s/%s." % (idx, total_candidates))
                        break
                    progress.update(int(6 + (idx - 1) * 82 / total_candidates), "Scanne %s/%s: %s" % (idx, total_candidates, title))
                except Exception:
                    pass
            for page in range(1, 21):
                try:
                    if request_count:
                        time.sleep(1.25)
                    request_count += 1
                except Exception:
                    pass
                previous_rows_for_category = previous_seen_by_category.get(str(gid).strip()) or []
                payload, data, total_items, retry_used = _codex_get_tv_channels_scan_page(
                    native_service, gid, page, title, progress,
                    previous_rows_for_category,
                    retry_delay=2.0,
                )
                empty_retry_count += retry_used
                if retry_used and data:
                    empty_retry_recovered += 1
                if not data:
                    break
                for item in data:
                    name = _codex_channel_title(item)
                    cmd = _codex_channel_cmd(item)
                    icon = _codex_channel_icon(item)
                    if name and cmd:
                        category_seen += 1
                        scanned.append({"name": name, "cmd": cmd, "icon": icon, "category": title, "category_id": gid, "page": page, "missing_m3u_repair": "1"})
                if total_items and category_seen >= total_items:
                    break
                if not total_items:
                    break
            if category_seen == 0:
                previous_rows_for_category = previous_seen_by_category.get(str(gid).strip()) or []
                if previous_rows_for_category:
                    for row in previous_rows_for_category:
                        keep = dict(row)
                        keep.setdefault("category", title)
                        keep.setdefault("category_id", gid)
                        keep["stale_snapshot"] = "1"
                        scanned.append(keep)
                    details.append("Kategorie leer, Snapshot behalten: [%s] %s (%s Sender)" % (gid, title, len(previous_rows_for_category)))
            _log("Macsimum missing M3U repair category scanned: id=%s title=%s rows=%s" % (gid, title, category_seen), xbmc.LOGWARNING if xbmc else None)

        snapshot_backup = _codex_backup_all_live_scan_snapshot("missing_m3u_repair")
        merged_rows = _codex_merge_live_scan_rows(previous_rows, scanned)
        merged_categories = _codex_merge_live_scan_categories(previous_categories, categories, merged_rows)
        json_path, txt_path = _codex_write_scan_report("all", merged_categories, merged_rows)
        country_path = _codex_write_country_discovery_report(merged_categories, merged_rows)
        refresh_results = _codex_refresh_all_scope_m3us_from_scan(merged_categories, merged_rows, progress)
        after_summary = _codex_m3u_missing_summary(scopes, merged_rows)
        after_total, after_matched, after_missing = _codex_missing_summary_counts(after_summary)
        changed_total = sum(int(row.get("changed") or 0) for row in refresh_results)
        report = _codex_write_missing_m3u_repair_report(before_summary, after_summary, candidates, scanned, refresh_results, details + [
            "Requests=%s empty_retry=%s recovered=%s" % (request_count, empty_retry_count, empty_retry_recovered),
            "Snapshot-Backup=%s" % snapshot_backup,
            "Snapshot=%s" % json_path,
            "Namen=%s" % txt_path,
            "Laender=%s" % country_path,
        ])
        if progress:
            progress.update(100, "Zuordnung: %s von %s | offen: %s" % (after_matched, after_total, after_missing))
            time.sleep(0.6)
            progress.close()
        if xbmcgui:
            xbmcgui.Dialog().notification("Fehlende Sender zugeordnet", "%s von %s | offen: %s" % (after_matched, after_total, after_missing), time=4500)
        _log("Macsimum missing M3U repair done: before=%s/%s missing=%s after=%s/%s missing=%s candidates=%s scanned=%s requests=%s empty_retry=%s recovered=%s changed=%s report=%s" % (
            before_matched, before_total, before_missing, after_matched, after_total, after_missing,
            len(candidates), len(scanned), request_count, empty_retry_count, empty_retry_recovered, changed_total, report
        ), xbmc.LOGWARNING if xbmc else None)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, False)
        return True
    except Exception as exc:
        _log("Macsimum missing M3U repair failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        if xbmcgui:
            xbmcgui.Dialog().notification("Zuordnung fehlgeschlagen", str(exc)[:80], xbmcgui.NOTIFICATION_ERROR, 3500)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, False, False, False)
    return True

def _handle_macsimum_all_scan(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_all_scan":
        return False
    handle = -1
    try:
        handle = int(argv[1])
    except Exception:
        pass
    progress = None
    scanned = []
    categories = []
    previous_seen_by_category = _codex_previous_live_seen_by_category()
    retained_snapshot_rows = 0
    empty_retry_count = 0
    empty_retry_recovered = 0
    try:
        if xbmcgui:
            progress = xbmcgui.DialogProgress()
            progress.create("Alle Live-Ordner scannen", "Authentifizierung vorbereiten...")
            progress.update(2, "Authentifizierung vorbereiten...")
        mod, _pinned_mac = _prepare_usable_impl()
        if mod is None:
            fallback = _codex_refresh_all_scope_m3us_from_saved_snapshot(progress, "no usable token")
            if fallback:
                _refresh_results, matched_total, list_total, changed_total = fallback
                if progress:
                    progress.update(100, "Aus Speicher aktualisiert: %s von %s" % (matched_total, list_total))
                    time.sleep(0.35)
                    progress.close()
                if xbmcgui:
                    xbmcgui.Dialog().notification("Senderlisten aktualisiert", "Aus Speicher: %s von %s" % (matched_total, list_total), time=3500)
                if xbmcplugin and handle >= 0:
                    xbmcplugin.endOfDirectory(handle, True, False, False)
                return True
            raise Exception("Keine nutzbare Portal-Session fuer Senderlisten-Aktualisierung")
        import lib.service as native_service
        portal_categories = native_service.get_tv_genres() or []
        if not portal_categories:
            fallback = _codex_refresh_all_scope_m3us_from_saved_snapshot(progress, "portal categories empty")
            if fallback:
                _refresh_results, matched_total, list_total, changed_total = fallback
                if progress:
                    progress.update(100, "Aus Speicher aktualisiert: %s von %s" % (matched_total, list_total))
                    time.sleep(0.35)
                    progress.close()
                if xbmcgui:
                    xbmcgui.Dialog().notification("Senderlisten aktualisiert", "Aus Speicher: %s von %s" % (matched_total, list_total), time=3500)
                if xbmcplugin and handle >= 0:
                    xbmcplugin.endOfDirectory(handle, True, False, False)
                return True
        categories = _codex_merge_live_categories(portal_categories)
        categories = [g for g in categories if _codex_genre_id(g) and not _codex_live_scan_category_is_247(g)]
        total = max(1, len(categories))
        if not categories:
            raise Exception("Keine Live-TV-Kategorien erhalten")
        _log("Macsimum ALL live scan starts: categories=%s portal=%s" % (len(categories), len(portal_categories)), xbmc.LOGWARNING if xbmc else None)
        for idx, genre in enumerate(categories, 1):
            title = str((genre or {}).get("title") or (genre or {}).get("name") or "").strip()
            gid = _codex_genre_id(genre)
            category_seen = 0
            if progress:
                try:
                    if progress.iscanceled():
                        break
                    progress.update(int(3 + (idx - 1) * 94 / total), "Scanne %s/%s: %s" % (idx, total, title))
                except Exception:
                    pass
            for page in range(1, 21):
                previous_rows = previous_seen_by_category.get(str(gid).strip()) or []
                payload, data, total_items, retry_used = _codex_get_tv_channels_scan_page(native_service, gid, page, title, progress, previous_rows)
                empty_retry_count += retry_used
                if retry_used and data:
                    empty_retry_recovered += 1
                if not data:
                    break
                for item in data:
                    name = _codex_channel_title(item)
                    cmd = _codex_channel_cmd(item)
                    icon = _codex_channel_icon(item)
                    if name and cmd:
                        category_seen += 1
                        scanned.append({"name": name, "cmd": cmd, "icon": icon, "category": title, "category_id": gid, "page": page})
                if total_items and category_seen >= total_items:
                    break
                if not total_items:
                    break
            if category_seen == 0:
                previous_rows = previous_seen_by_category.get(str(gid).strip()) or []
                if previous_rows:
                    for row in previous_rows:
                        keep = dict(row)
                        keep.setdefault("category", title)
                        keep.setdefault("category_id", gid)
                        keep["stale_snapshot"] = "1"
                        scanned.append(keep)
                    retained_snapshot_rows += len(previous_rows)
                    _log("Macsimum ALL scan retained previous snapshot category: id=%s title=%s rows=%s" % (gid, title, len(previous_rows)), xbmc.LOGWARNING if xbmc else None)
        json_path, txt_path = _codex_write_scan_report("all", categories, scanned)
        country_path = _codex_write_country_discovery_report(categories, scanned)
        refresh_results = _codex_refresh_all_scope_m3us_from_scan(categories, scanned, progress)
        changed_total = sum(int(row.get("changed") or 0) for row in refresh_results)
        matched_total = sum(int(row.get("matched") or 0) for row in refresh_results)
        list_total = sum(int(row.get("total") or 0) for row in refresh_results)
        if progress:
            progress.update(100, "Aktualisiert: %s von %s" % (matched_total, list_total))
            time.sleep(0.35)
            progress.close()
        if xbmcgui:
            xbmcgui.Dialog().notification("Senderlisten aktualisiert", "%s von %s | geaendert: %s" % (matched_total, list_total, changed_total), time=3500)
        _log("Macsimum ALL live scan done: categories=%s scanned=%s empty_retry=%s recovered=%s retained_snapshot=%s matched=%s/%s changed=%s json=%s txt=%s country=%s" % (len(categories), len(scanned), empty_retry_count, empty_retry_recovered, retained_snapshot_rows, matched_total, list_total, changed_total, json_path, txt_path, country_path), xbmc.LOGWARNING if xbmc else None)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, False)
        return True
    except Exception as exc:
        _log("Macsimum ALL live scan failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        try:
            fallback = _codex_refresh_all_scope_m3us_from_saved_snapshot(progress, "portal scan failed: %s" % exc)
            if fallback:
                _refresh_results, matched_total, list_total, _changed_total = fallback
                if progress:
                    progress.update(100, "Aus Speicher aktualisiert: %s von %s" % (matched_total, list_total))
                    time.sleep(0.35)
                    progress.close()
                if xbmcgui:
                    xbmcgui.Dialog().notification("Senderlisten aktualisiert", "Aus Speicher: %s von %s" % (matched_total, list_total), time=3500)
                if xbmcplugin and handle >= 0:
                    xbmcplugin.endOfDirectory(handle, True, False, False)
                return True
        except Exception as fallback_exc:
            _log("Macsimum ALL live scan saved-snapshot fallback failed: %s" % fallback_exc, xbmc.LOGWARNING if xbmc else None)
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        if xbmcgui:
            xbmcgui.Dialog().notification("Scan fehlgeschlagen", str(exc)[:80], xbmcgui.NOTIFICATION_ERROR, 3500)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, False, False, False)
    return True

def _handle_macsimum_gap_scan(argv):
    try:
        qs = urllib.parse.parse_qs((argv[2] or "").lstrip("?"))
    except Exception:
        return False
    action = (qs.get("action") or [""])[0].strip().lower()
    if action != "codex_macsimum_gap_scan":
        return False
    handle = -1
    try:
        handle = int(argv[1])
    except Exception:
        pass

    progress = None
    gap_scanned = []
    categories = []
    previous_snapshot = _codex_load_all_live_scan_snapshot()
    previous_rows = previous_snapshot.get("seen") if isinstance(previous_snapshot, dict) else []
    previous_categories = previous_snapshot.get("categories") if isinstance(previous_snapshot, dict) else []
    previous_seen_by_category = _codex_previous_live_seen_by_category()
    zero_ids = _codex_snapshot_zero_category_ids(previous_snapshot)
    request_count = 0
    empty_retry_count = 0
    empty_retry_recovered = 0
    snapshot_backup = ""
    try:
        if xbmcgui:
            progress = xbmcgui.DialogProgress()
            progress.create("Leere Live-Ordner nachscannen", "Authentifizierung vorbereiten...")
            progress.update(2, "Authentifizierung vorbereiten...")
        mod = _impl()
        if _action_needs_portal_token(action) and not _current_module_token():
            raise Exception("Keine nutzbare Portal-Session fuer Luecken-Scan")
        import lib.service as native_service
        portal_categories = native_service.get_tv_genres() or []
        categories_source = portal_categories or previous_categories or _codex_saved_full_live_categories()
        categories = _codex_merge_live_categories(categories_source)
        categories = [g for g in categories if _codex_genre_id(g)]
        if not categories:
            raise Exception("Keine Live-TV-Kategorien erhalten")

        candidates = []
        old_categories_by_id = {}
        for cat in previous_categories or []:
            if isinstance(cat, dict):
                cid = str(cat.get("id") or "").strip()
                if cid:
                    old_categories_by_id[cid] = cat
        for genre in categories:
            gid = _codex_genre_id(genre)
            if not gid:
                continue
            old_rows = previous_seen_by_category.get(str(gid).strip()) or []
            if gid in zero_ids or (not old_rows and gid in old_categories_by_id):
                candidates.append(genre)

        if not candidates:
            if progress:
                progress.update(100, "Keine leeren Ordner im Snapshot gefunden")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Luecken-Scan", "Keine leeren Ordner gefunden", time=3000)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            _log("Macsimum GAP live scan skipped: no zero categories")
            return True

        total = max(1, len(candidates))
        _log("Macsimum GAP live scan starts: zero_categories=%s previous_rows=%s" % (len(candidates), len(previous_rows or [])), xbmc.LOGWARNING if xbmc else None)
        for idx, genre in enumerate(candidates, 1):
            title = str((genre or {}).get("title") or (genre or {}).get("name") or "").strip()
            gid = _codex_genre_id(genre)
            if not gid:
                continue
            category_seen = 0
            if progress:
                try:
                    if progress.iscanceled():
                        break
                    progress.update(int(4 + (idx - 1) * 88 / total), "Nachscan %s/%s: %s" % (idx, total, title))
                except Exception:
                    pass
            for page in range(1, 21):
                try:
                    if request_count:
                        time.sleep(2.0)
                    request_count += 1
                except Exception:
                    pass
                payload, data, total_items, retry_used = _codex_get_tv_channels_scan_page(
                    native_service, gid, page, title, progress,
                    previous_seen_by_category.get(str(gid).strip()) or [],
                    retry_delay=2.0,
                )
                empty_retry_count += retry_used
                if retry_used and data:
                    empty_retry_recovered += 1
                if not data:
                    break
                for item in data:
                    name = _codex_channel_title(item)
                    cmd = _codex_channel_cmd(item)
                    icon = _codex_channel_icon(item)
                    if name and cmd:
                        category_seen += 1
                        gap_scanned.append({"name": name, "cmd": cmd, "icon": icon, "category": title, "category_id": gid, "page": page, "gap_scan": "1"})
                if total_items and category_seen >= total_items:
                    break
                if not total_items:
                    break
            _log("Macsimum GAP category scanned: id=%s title=%s rows=%s" % (gid, title, category_seen), xbmc.LOGWARNING if xbmc else None)

        _codex_write_scan_report("gap", candidates, gap_scanned)
        if not gap_scanned:
            if progress:
                progress.update(100, "Keine neuen Sender gefunden")
                time.sleep(0.35)
                progress.close()
            if xbmcgui:
                xbmcgui.Dialog().notification("Luecken-Scan fertig", "Keine neuen Sender gefunden", time=3500)
            _log("Macsimum GAP live scan done: candidates=%s new_rows=0 merged_skipped=1 requests=%s empty_retry=%s recovered=%s" % (
                len(candidates), request_count, empty_retry_count, empty_retry_recovered
            ), xbmc.LOGWARNING if xbmc else None)
            if xbmcplugin and handle >= 0:
                xbmcplugin.endOfDirectory(handle, True, False, False)
            return True
        snapshot_backup = _codex_backup_all_live_scan_snapshot("gap_scan")
        merged_rows = _codex_merge_live_scan_rows(previous_rows, gap_scanned)
        merged_categories = _codex_merge_live_scan_categories(previous_categories, categories, merged_rows)
        json_path, txt_path = _codex_write_scan_report("all", merged_categories, merged_rows)
        country_path = _codex_write_country_discovery_report(merged_categories, merged_rows)
        refresh_results = _codex_refresh_all_scope_m3us_from_scan(merged_categories, merged_rows, progress)
        changed_total = sum(int(row.get("changed") or 0) for row in refresh_results)
        matched_total = sum(int(row.get("matched") or 0) for row in refresh_results)
        list_total = sum(int(row.get("total") or 0) for row in refresh_results)
        added_total = max(0, len(merged_rows) - len(_codex_merge_live_scan_rows(previous_rows, [])))
        if progress:
            progress.update(100, "Ergaenzt: +%s | M3U: %s von %s" % (added_total, matched_total, list_total))
            time.sleep(0.35)
            progress.close()
        if xbmcgui:
            xbmcgui.Dialog().notification("Luecken-Scan fertig", "+%s Sender | M3U: %s von %s" % (added_total, matched_total, list_total), time=4000)
        _log("Macsimum GAP live scan done: candidates=%s new_rows=%s merged_rows=%s added=%s requests=%s empty_retry=%s recovered=%s matched=%s/%s changed=%s backup=%s json=%s txt=%s country=%s" % (
            len(candidates), len(gap_scanned), len(merged_rows), added_total, request_count,
            empty_retry_count, empty_retry_recovered, matched_total, list_total, changed_total,
            snapshot_backup, json_path, txt_path, country_path
        ), xbmc.LOGWARNING if xbmc else None)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, True, False, False)
        return True
    except Exception as exc:
        _log("Macsimum GAP live scan failed: %s" % exc, xbmc.LOGERROR if xbmc else None)
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        if xbmcgui:
            xbmcgui.Dialog().notification("Luecken-Scan fehlgeschlagen", str(exc)[:80], xbmcgui.NOTIFICATION_ERROR, 3500)
        if xbmcplugin and handle >= 0:
            xbmcplugin.endOfDirectory(handle, False, False, False)
    return True

def run(*args, **kwargs):
    argv = args[0] if args else None
    try:
        if isinstance(argv, (list, tuple)) and len(argv) >= 3:
            if not _current_plugin_action():
                _clear_category_nav_cache("addon root opened")
            if _handle_macsimum_force_refresh(argv):
                return None
            if _handle_manual_switch(argv):
                return None
            if _handle_macsimum_live_scan_navigation(argv):
                return None
            if _handle_macsimum_vod_play(argv):
                return None
            if _handle_macsimum_episode_play(argv):
                return None
            if _handle_macsimum_episode_listing(argv):
                return None
            if _handle_macsimum_bridge_play(argv):
                return None
            if _handle_macsimum_handshake(argv):
                return None
            if _handle_macsimum_scope_scan(argv):
                return None
            if _handle_macsimum_missing_m3u_repair(argv):
                return None
            if _handle_macsimum_gap_scan(argv):
                return None
            if _handle_macsimum_all_scan(argv):
                return None
            if _handle_macsimum_favorites(argv):
                return None
            if _handle_trailer_choice(argv):
                return None
            if _serve_category_nav_cache(argv):
                return None
    except Exception as exc:
        _log("Manual action dispatch failed: %s" % exc, xbmc.LOGWARNING if xbmc else None)

    last_exc = None
    cooldown = _cooldown_remaining()
    if cooldown:
        _log("Skip Macsimum portal request while portal cooldown is active (%d seconds left)" % cooldown, xbmc.LOGWARNING if xbmc else None)
        _finish_failed_directory(argv)
        return None

    for attempt in range(1, MAX_PORTAL_ATTEMPTS + 1):
        try:
            mod, pinned_mac = _prepare_usable_impl()
            if mod is None:
                _finish_failed_directory(argv)
                return None
            action = _current_plugin_action()
            if action in ("vod", "series", "listing", "ser_listing", "search", "search_series"):
                try:
                    warmup_target = "series" if action in ("series", "ser_listing", "search_series") else "vod"
                    warmup_ok = _macsimum_warmup_native(
                        "CODEX-MACSIMUM-RUN-%s" % action,
                        rotate_on_empty=False,
                        max_attempts=1,
                        targets=warmup_target,
                    )
                    if not warmup_ok:
                        _log("Warmup before native run returned empty for %s; clear tentative MAC and retry once" % action, xbmc.LOGWARNING if xbmc else None)
                        try:
                            _clear_current_mac_from_state("empty warmup before native run: %s" % action)
                        except Exception:
                            pass
                        _reset_impl_for_retry()
                        retry_mod, _retry_pinned = _prepare_usable_impl()
                        if retry_mod is None:
                            _finish_failed_directory(argv)
                            return None
                        try:
                            warmup_ok = _macsimum_warmup_native(
                                "CODEX-MACSIMUM-RUN-%s-RETRY" % action,
                                rotate_on_empty=False,
                                max_attempts=1,
                                targets=warmup_target,
                            )
                        except Exception as retry_warm_exc:
                            _log("Retry warmup before native run failed for %s: %s" % (action, retry_warm_exc), xbmc.LOGWARNING if xbmc else None)
                            warmup_ok = False
                        if not warmup_ok:
                            _log("Retry warmup before native run returned empty for %s; stop quiet to avoid auth flood" % action, xbmc.LOGWARNING if xbmc else None)
                            try:
                                _clear_current_mac_from_state("retry empty warmup before native run: %s" % action)
                            except Exception:
                                pass
                            _finish_failed_directory(argv)
                            return None
                        mod = retry_mod
                    try:
                        _remember_current_mac(_current_module_mac())
                    except Exception:
                        pass
                except Exception as warm_exc:
                    _log("Warmup before native run failed for %s: %s" % (action, warm_exc), xbmc.LOGWARNING if xbmc else None)
                    _finish_failed_directory(argv)
                    return None
            return mod.run(*args, **kwargs)
        except Exception as exc:
            last_exc = exc
            if not _is_transient_portal_error(exc):
                raise
            reason = _current_error_reason(exc)
            if reason == "rate_limit":
                _set_rate_limit_cooldown(str(exc))
            elif reason == "portal_timeout":
                _set_portal_timeout_cooldown(str(exc))
            else:
                _clear_current_mac_from_state("transient portal error: %s" % exc)
            _log("Transient Macsimum portal error on attempt %d/%d: %s" % (attempt, MAX_PORTAL_ATTEMPTS, exc), xbmc.LOGWARNING if xbmc else None)
            _reset_impl_for_retry()
            try:
                if xbmc:
                    xbmc.executebuiltin("Dialog.Close(busydialog)")
                    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            except Exception:
                pass
            time.sleep(0.25 * attempt)

    _log("Macsimum portal failed after guarded retries: %s" % last_exc, xbmc.LOGERROR if xbmc else None)
    _finish_failed_directory(argv)
    return None
