# -*- coding: utf-8 -*-
from __future__ import absolute_import ,division ,unicode_literals 
import dataclasses 
import math 
import requests 
import urllib .parse ,urllib .request ,urllib .error 
from urllib .parse import urlparse 
import sys ,os 
import json 
import xml .etree .ElementTree as ET 
import time 
import random 
import threading 
from datetime import datetime ,timedelta 
import re ,uuid ,hashlib 
import base64 
import xbmcaddon 
import logging 
from .config import G 
from .utils import Logger 
import xbmcgui 
import xbmcvfs 
import xbmc 
import sys 
import os 
from .import stalker_net as _net 
import os 
import sys 
import urllib .parse 
from urllib .parse import urlencode ,urlsplit ,quote 
import urllib .request 

sys .path .append (os .path .join (os .path .dirname (__file__ )))

STALKER_AUTH_TIMEOUT = (3.5, 6.0)
STALKER_API_TIMEOUT = (3.5, 6.0)
STALKER_LINK_TIMEOUT = (4.0, 8.0)
CODEX_VERIFIED_CURRENT_MAC_TTL = None


import zipfile

def fingerprints_from_meta_inf(apk_path):
    z = zipfile.ZipFile(apk_path, 'r')
    candidates = [name for name in z.namelist() if name.startswith('META-INF/') and name.upper().endswith(('.RSA', '.DSA', '.EC'))]
    if not candidates:
        return None
    data = z.read(candidates[0])
    z.close()

    idx = data.find(b'\x30\x82')
    if idx == -1:
        return None

    try:
        length = int.from_bytes(data[idx+2:idx+4], byteorder='big')
        cert_der = data[idx: idx+4+length]
    except Exception:
        next_idx = data.find(b'\x30\x82', idx+2)
        cert_der = data[idx: next_idx] if next_idx != -1 else data[idx:]

    sha1 = hashlib.sha1(cert_der).hexdigest().upper()
    sha256 = hashlib.sha256(cert_der).hexdigest().upper()
    sha1 = ":".join(sha1[i:i+2] for i in range(0, len(sha1), 2))
    sha256 = ":".join(sha256[i:i+2] for i in range(0, len(sha256), 2))
    return {'sha1': sha1, 'sha256': sha256, 'meta_file': candidates[0]}

try:
    apk_path = os.environ.get("KODI_ANDROID_APK")
    res = fingerprints_from_meta_inf(apk_path) if apk_path else None
    apk_sig = (res or {}).get('sha256', '')
    if apk_sig and '45:FA:B6:7A:28:26:FC:21:6A:1B:77:C7:6B:2F:35:DF:FF:74:95:72:DB:80:89:F0:BD:C8:B6:01:96:61:CC:08' not in apk_sig:
        xbmc.log("[Stalker] APK-Signatur weicht ab; Talker3-Service laeuft trotzdem weiter.", xbmc.LOGWARNING)
except Exception as _codex_sig_exc:
    try:
        xbmc.log(f"[Stalker] APK-Signaturpruefung uebersprungen: {_codex_sig_exc}", xbmc.LOGWARNING)
    except Exception:
        pass



if not hasattr(G.portal_config, 'portal_base_url') or G.portal_config.portal_base_url is None:
    G.init_globals()

# Codex: Filme/Serien sollen pro Kodi-Seite wieder ungefähr 100 Titel zeigen.
# Das Portal liefert typischerweise 14 Titel pro nativer Seite; 8 native Seiten
# ergeben dadurch bis zu 112 Einträge. Live-TV nutzt weiterhin max_page_limit_tv.
CODEX_VOD_SERIES_PAGE_LIMIT = 8
try:
    if int(getattr(G.addon_config, 'max_page_limit', 0) or 0) < CODEX_VOD_SERIES_PAGE_LIMIT:
        G.addon_config.max_page_limit = CODEX_VOD_SERIES_PAGE_LIMIT
except Exception:
    pass

# ----------------------------- StalkerPortal Klasse -----------------------------
class StalkerPortal:
    def __init__(self, url, mac, download_folder="", sprach_filter=False):
        if not url:
            raise ValueError("[Stalker] URL darf nicht leer sein")
        self.org_url = url
        self.url = url.rstrip('/')
        self.parsed = urlparse(self.org_url)
        self.base = f"{self.parsed.scheme}://{self.parsed.netloc}"
        self.mac = mac
        self.download_folder = download_folder
        self.sprach_filter = sprach_filter
        self.ua = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 4 rev: 2721 Mobile Safari/533.3"
        self.cookie = f"mac={self.mac}; stb_lang=en; timezone=Europe/Amsterdam;"
        self.token = ""
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.ua, "Cookie": self.cookie})
        self.use_fallback = False
        self.use_fallback_2 = False

    def headers(self):
        host = self.parsed.netloc
        headers = {
            "Host": host,
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "Accept-Encoding": "gzip, deflate",
            "Accept": "*/*",
            "Connection": "keep-alive",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Referer": f"{self.org_url}",
            "Cookie": f"mac={self.mac}; stb_lang=en; timezone=Europe/Amsterdam"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def headers_2(self):
        host = self.parsed.netloc
        headers = {
            "Host": host,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36",
            "Accept-Encoding": "gzip, deflate",
            "Accept": "*/*",
            "Connection": "keep-alive",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Referer": f"{self.org_url}",
            "Cookie": f"mac={self.mac}; stb_lang=en; timezone=Europe/Amsterdam"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def get_json_safe(self, response):
        text = response.text or ""
        start_idx = text.find('{')
        if start_idx != -1:
            text = text[start_idx:]
        try:
            return json.loads(text)
        except:
            return {}

    def authenticate(self):
        xbmc.log("[Stalker] Authenticating with portal...", xbmc.LOGINFO)
        url = f"{self.url}/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
        try:
            r = self.session.get(url, timeout=STALKER_AUTH_TIMEOUT)
            data = self.get_json_safe(r)
            token = data.get("js", {}).get("token") or data.get("token")
            if not token:
                self.use_fallback = True
                token_url = f"{self.base}/portal.php?type=stb&action=handshake"
                r = requests.get(token_url, headers=self.headers(), timeout=STALKER_AUTH_TIMEOUT)
                data = self.get_json_safe(r)
                token = data.get("js", {}).get("token") or data.get("token")
                if not token:
                    self.use_fallback_2 = True
                    self.use_fallback = False
                    token_url_2 = f"{self.base}/portal.php?type=stb&action=handshake"
                    r = requests.get(token_url_2, headers=self.headers_2(), timeout=STALKER_AUTH_TIMEOUT)
                    data = self.get_json_safe(r)
                    token = data.get("js", {}).get("token") or data.get("token")
                    if not token:
                        raise Exception("Kein Token erhalten")
            self.token = token
            self.session.headers["Authorization"] = f"Bearer {self.token}"
            self.get_profile()
            xbmc.log("[Stalker] Authentication successful.", xbmc.LOGINFO)
        except Exception as e:
            try:
                self.token = ""
                self.session.headers.pop("Authorization", None)
            except Exception:
                pass
            xbmc.log(f"[Stalker] Authentication failed: {str(e)}", xbmc.LOGERROR)
            raise

    def get_profile(self):
        try:
            if self.use_fallback:
                url = f"{self.base}/portal.php?type=stb&action=get_profile&hd=1&auth_second_step=0&num_banks=1&stb_type=MAG250&image_version=216&hw_version=1.7-BD-00&not_valid_token=0&device_id=&device_id2=&signature=&sn=&ver=ImageDescription%3A%25200.2.18-r23-pub-254%3B%2520ImageDate%3A%2520Wed%2520Aug%252029%252010%3A49%3A26%2520EEST%25202018%3B%2520PORTAL%2520version%3A%25205.1.1%3B%2520API%2520Version%3A%2520JS%2520API%2520version%3A%2520328%3B%2520STB%2520API%2520version%3A%2520134%3B%2520Player%2520Engine%2520version%3A%25200x566"
                r = requests.get(url, headers=self.headers(), timeout=STALKER_AUTH_TIMEOUT)
            elif self.use_fallback_2:
                url = f"{self.base}/portal.php?type=stb&action=get_profile&hd=1&auth_second_step=0&num_banks=1&stb_type=MAG250&image_version=216&hw_version=1.7-BD-00&not_valid_token=0&device_id=&device_id2=&signature=&sn=&ver=ImageDescription%3A%25200.2.18-r23-pub-254%3B%2520ImageDate%3A%2520Wed%2520Aug%252029%252010%3A49%3A26%2520EEST%25202018%3B%2520PORTAL%2520version%3A%25205.1.1%3B%2520API%2520Version%3A%2520JS%2520API%2520version%3A%2520328%3B%2520STB%2520API%2520version%3A%2520134%3B%2520Player%2520Engine%2520version%3A%25200x566"
                r = requests.get(url, headers=self.headers_2(), timeout=STALKER_AUTH_TIMEOUT)
            else:
                url = f"{self.url}/portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"
                profile_params = {'type': 'stb', 'action': 'get_profile'}
                r = self.session.get(url, params=profile_params, timeout=STALKER_AUTH_TIMEOUT)
            data = self.get_json_safe(r)
            if not data:
                raise Exception("Leeres Profil erhalten")
            return data
        except Exception as e:
            raise Exception(f"Profil-Abruf fehlgeschlagen: {e}")

    def api_request(self, params, method='GET', use_post=False):
        if not self.token:
            self.authenticate()

        if self.use_fallback or self.use_fallback_2:
            base_url = self.base
        else:
            base_url = self.url
        url = f"{base_url}/portal.php"

        headers = self.headers_2() if self.use_fallback_2 else self.headers()

        if use_post or method.upper() == 'POST':
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
            data = urlencode(params)
            r = requests.post(url, headers=headers, data=data, timeout=STALKER_API_TIMEOUT)
        else:
            if not self.use_fallback and not self.use_fallback_2 and 'JsHttpRequest' not in params:
                params['JsHttpRequest'] = '1-xml'
            r = requests.get(url, headers=headers, params=params, timeout=STALKER_API_TIMEOUT)

        return self.get_json_safe(r)

    def get_stream_link(self, cmd, content_type="vod", ep_id=None):
        if not cmd:
            xbmc.log("[Stalker] get_stream_link: cmd ist leer", xbmc.LOGERROR)
            return None

        def _stream_mac(value):
            try:
                m = re.search(r'(?i)[?&]mac=([0-9a-f]{2}(?::[0-9a-f]{2}){5})', str(value or ''))
                if not m:
                    m = re.search(r'(?i)\bmac=([0-9a-f]{2}(?::[0-9a-f]{2}){5})\b', str(value or ''))
                return m.group(1).upper() if m else ""
            except Exception:
                return ""

        def _redact_mac(value):
            try:
                mac = _stream_mac(value)
                if not mac:
                    m = re.search(r'(?i)\b([0-9a-f]{2}(?::[0-9a-f]{2}){5})\b', str(value or ''))
                    mac = m.group(1).upper() if m else ""
                return "****" + mac[-5:] if mac else "<none>"
            except Exception:
                return "<none>"

        def _extract_link(data):
            if isinstance(data, list):
                xbmc.log(f"[Stalker] create_link lieferte Liste statt Objekt: {data}", xbmc.LOGWARNING)
                return None
            if not isinstance(data, dict):
                xbmc.log(f"[Stalker] create_link unerwartete Antwort: {type(data)} {data}", xbmc.LOGWARNING)
                return None
            js = data.get("js")
            if isinstance(js, list):
                xbmc.log(f"[Stalker] create_link lieferte js-Liste statt Objekt: {data}", xbmc.LOGWARNING)
                return None
            if self.use_fallback or self.use_fallback_2:
                link_value = data.get("cmd") or (js.get("cmd") if isinstance(js, dict) else "") or ""
            else:
                link_value = (js.get("cmd") if isinstance(js, dict) else "") or ""
            if not link_value:
                xbmc.log(f"[Stalker] Kein cmd in Antwort: {data}", xbmc.LOGERROR)
                return None
            return link_value.replace("ffmpeg ", "").replace("ffrt3 ", "")

        cmd_enc = quote(cmd.replace("ffmpeg ", ""))
        link_type = 'itv' if content_type == 'itv' else 'vod'

        def _request_link(cache_bust=False):
            if self.use_fallback or self.use_fallback_2:
                url = f"{self.base}/portal.php?type={link_type}&action=create_link&cmd={cmd_enc}"
                if content_type == "series" and ep_id:
                    url += f"&series={ep_id}"
                if cache_bust:
                    url += f"&codex_nocache={int(time.time() * 1000)}"
                    headers = dict(self.headers_2() if self.use_fallback_2 else self.headers())
                    headers["Cache-Control"] = "no-cache"
                    headers["Pragma"] = "no-cache"
                else:
                    headers = self.headers_2() if self.use_fallback_2 else self.headers()
                return requests.get(url, headers=headers, timeout=STALKER_LINK_TIMEOUT)

            url = f"{self.url}/portal.php?type={link_type}&action=create_link&cmd={cmd_enc}"
            if content_type == "series" and ep_id:
                url += f"&series={ep_id}"
            url += "&JsHttpRequest=1-xml"
            if cache_bust:
                url += f"&codex_nocache={int(time.time() * 1000)}"
                headers = dict(getattr(self.session, 'headers', {}) or {})
                headers["Cache-Control"] = "no-cache"
                headers["Pragma"] = "no-cache"
                return self.session.get(url, headers=headers, timeout=STALKER_LINK_TIMEOUT)
            return self.session.get(url, timeout=STALKER_LINK_TIMEOUT)

        link = _extract_link(self.get_json_safe(_request_link(False)))
        if not link:
            return None

        if content_type == "itv":
            active_mac = str(getattr(self, "mac", "") or "").upper()
            link_mac = _stream_mac(link)
            if active_mac and link_mac and link_mac != active_mac:
                xbmc.log(
                    f"[Stalker] CODEX-MACSIMUM-TV create_link stale MAC retry: "
                    f"link={_redact_mac(link_mac)} active={_redact_mac(active_mac)}",
                    xbmc.LOGWARNING,
                )
                retry_link = _extract_link(self.get_json_safe(_request_link(True)))
                retry_mac = _stream_mac(retry_link)
                if retry_link and (not retry_mac or retry_mac == active_mac):
                    return retry_link
                xbmc.log(
                    f"[Stalker] CODEX-MACSIMUM-TV create_link stale MAC abort: "
                    f"link={_redact_mac(retry_mac or retry_link)} active={_redact_mac(active_mac)}",
                    xbmc.LOGERROR,
                )
                return None

        return link


# ----------------------------- Globale Initialisierung (angepasst) -----------------------------
ADDON = xbmcaddon.Addon()
vod_cache_path = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/cache/vod_cache.json')
epg_path = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/epg/epg.json')
epg_cache_path = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/epg/epg_cache.json')
epg_path2 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/epg/epg_data.xml')
epg_cache = {}
epg_caches = {}

def _codex_mac_pool_files():
    paths = []
    try:
        profile_path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if profile_path:
            paths.append(os.path.join(profile_path, 'macsimum_mac_pool.txt'))
    except Exception:
        pass
    try:
        paths.append(xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/tokens/macsimum_mac_pool.txt'))
    except Exception:
        pass
    try:
        paths.append(xbmcvfs.translatePath('special://home/addons/plugin.video.stalker.macsimum/resources/macsimum_mac_pool.txt'))
    except Exception:
        pass
    return paths

def _codex_load_mac_pool_if_empty(reason="startup"):
    try:
        existing = [m for m in getattr(G, 'mac_list', []) if m]
        if existing:
            return len(existing)
    except Exception:
        existing = []

    mac_pattern = re.compile(r'(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b')
    for path in _codex_mac_pool_files():
        try:
            if not path or not os.path.exists(path):
                continue
            with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                text = fh.read()
            seen = set()
            macs = []
            for match in mac_pattern.findall(text):
                mac_value = match.upper()
                if mac_value not in seen:
                    seen.add(mac_value)
                    macs.append(mac_value)
            if macs:
                try:
                    G.mac_list = macs
                except Exception:
                    setattr(G, 'mac_list', macs)
                try:
                    xbmc.log(
                        "[CODEX-MAC-ANALYTICS][Portal1/service] loaded-mac-pool reason=%s count=%d source=%s" % (
                            reason or "-",
                            len(macs),
                            os.path.basename(path),
                        ),
                        xbmc.LOGWARNING,
                    )
                except Exception:
                    pass
                return len(macs)
        except Exception as exc:
            try:
                xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] load-mac-pool-error reason=%s file=%s error=%s" % (reason or "-", path, exc), xbmc.LOGWARNING)
            except Exception:
                pass
    try:
        xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] load-mac-pool-empty reason=%s" % (reason or "-"), xbmc.LOGWARNING)
    except Exception:
        pass
    return 0

_codex_load_mac_pool_if_empty("module-start")

def _codex_scope_from_query(action="", query=None):
    action = (action or "").strip().lower()
    query = query or {}
    if action == "codex_macsimum_handshake":
        scope = str((query.get("scope") or ["root"])[0] or "").strip().lower()
        if scope in ("live", "tv", "livetv"):
            return "live"
        if scope in ("series", "serien"):
            return "series"
        return "vod"
    if action in ("tv", "live", "tv_listing", "codex_macsimum_bridge_play",
                  "codex_macsimum_scope_scan", "codex_macsimum_all_scan",
                  "codex_macsimum_gap_scan", "codex_macsimum_missing_m3u_repair"):
        return "live"
    if action in ("series", "ser_listing", "seasons", "season", "episodes",
                  "episode", "codex_macsimum_episode_play", "search_series"):
        return "series"
    if action in ("vod", "listing", "search", "play", "create_link",
                  "codex_macsimum_vod_play", "nova_trailer_choice"):
        return "vod"
    return ""

def _codex_normalize_scope(scope):
    scope = str(scope or "").strip().lower()
    if scope in ("favorites", "favourites", "favoriten"):
        return "vod"
    if scope in ("tv", "livetv"):
        return "live"
    if scope in ("serien",):
        return "series"
    if scope in ("vod", "series", "live"):
        return scope
    return ""

def _codex_normalize_mac(value):
    match = re.search(r'(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b', str(value or ""))
    return match.group(0).upper() if match else ""

def _codex_mac_state_current_tuple(state):
    if not isinstance(state, dict):
        return "", 0.0, ""
    mac = _codex_normalize_mac(state.get('current_mac') or "")
    try:
        at = float(state.get('current_at') or 0)
    except Exception:
        at = 0.0
    scope = _codex_normalize_scope(state.get('current_scope') or "")
    return mac, at, scope

def _codex_mac_state_verified_scopes(state):
    scopes = {}
    if not isinstance(state, dict):
        return scopes
    raw = state.get('verified_scopes')
    if isinstance(raw, dict):
        for raw_scope, raw_entry in raw.items():
            scope = _codex_normalize_scope(raw_scope)
            if not scope:
                continue
            if isinstance(raw_entry, dict):
                mac = _codex_normalize_mac(raw_entry.get('mac') or raw_entry.get('current_mac') or "")
                try:
                    at = float(raw_entry.get('at', raw_entry.get('current_at', 0)) or 0)
                except Exception:
                    at = 0.0
            else:
                mac = _codex_normalize_mac(raw_entry)
                at = 0.0
            if mac and at:
                scopes[scope] = {'mac': mac, 'at': at}
    current, current_at, current_scope = _codex_mac_state_current_tuple(state)
    if current and current_at and current_scope and current_scope not in scopes:
        scopes[current_scope] = {'mac': current, 'at': current_at}
    return scopes

def _codex_mac_state_scope_failure_matches(state, scope, mac):
    scope = _codex_normalize_scope(scope)
    mac = _codex_normalize_mac(mac)
    raw = state.get('scope_failures') if isinstance(state, dict) else None
    if not scope or not mac or not isinstance(raw, dict):
        return False
    entry = raw.get(scope)
    if not isinstance(entry, dict):
        return False
    return _codex_normalize_mac(entry.get('mac') or "") == mac

def _codex_current_session_mac_from_state():
    # Nur die kurze current_mac-Session darf dieser Service uebernehmen.
    # Keine Bewertungslisten, keine stundenlangen Pins, keine Sperrlisten.
    try:
        raw_query = sys.argv[2] if len(sys.argv) > 2 else ""
        query = urllib.parse.parse_qs((raw_query or "").lstrip("?"), keep_blank_values=True)
        action = str((query.get("action") or [""])[0] or "").strip().lower()
        invocation_mac = str((query.get("source_mac") or query.get("choice_source_mac") or [""])[0] or "").strip().upper()
        if re.match(r'(?i)^[0-9a-f]{2}(?::[0-9a-f]{2}){5}$', invocation_mac):
            xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] one-shot-source-mac reason=plugin-url after=****%s" % invocation_mac[-5:], xbmc.LOGWARNING)
            return invocation_mac
    except Exception:
        query = {}
        action = ""
        pass
    try:
        wanted_scope = _codex_scope_from_query(action, query)
        profile_path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        state_path = os.path.join(profile_path, 'mac_session.json')
        if not os.path.exists(state_path):
            return ""
        with open(state_path, 'r', encoding='utf-8', errors='ignore') as fh:
            state = json.load(fh)
        if not isinstance(state, dict):
            return ""
        changed = False
        current, current_at, current_scope = _codex_mac_state_current_tuple(state)
        wanted_scope = _codex_normalize_scope(wanted_scope)
        verified_scopes = _codex_mac_state_verified_scopes(state)
        if wanted_scope:
            entry = verified_scopes.get(wanted_scope) or {}
            scope_mac = _codex_normalize_mac(entry.get('mac') or "")
            try:
                scope_at = float(entry.get('at') or 0)
            except Exception:
                scope_at = 0.0
            if scope_mac and scope_at:
                xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] session-current-reuse reason=verified-scope-session scope=%s after=****%s" % (wanted_scope, scope_mac[-5:]), xbmc.LOGWARNING)
                return scope_mac
        if re.match(r'(?i)^[0-9a-f]{2}(?::[0-9a-f]{2}){5}$', current) and current_at:
            if wanted_scope and current_scope != wanted_scope:
                if _codex_mac_state_scope_failure_matches(state, wanted_scope, current):
                    xbmc.log(
                        "[CODEX-MAC-ANALYTICS][Portal1/service] session-current-scope-failed-skip reason=wanted=%s stored=%s after=****%s" % (
                            wanted_scope,
                            current_scope or "legacy",
                            current[-5:],
                        ),
                        xbmc.LOGWARNING,
                    )
                    return ""
                xbmc.log(
                    "[CODEX-MAC-ANALYTICS][Portal1/service] session-current-cross-scope-tentative reason=wanted=%s stored=%s after=****%s" % (
                        wanted_scope,
                        current_scope or "legacy",
                        current[-5:],
                    ),
                    xbmc.LOGWARNING,
                )
                return current
            if changed:
                with open(state_path, 'w', encoding='utf-8') as fh:
                    json.dump(state, fh, ensure_ascii=True, indent=2, sort_keys=True)
            xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] session-current-reuse reason=verified-current-session scope=%s after=****%s" % (current_scope or "-", current[-5:]), xbmc.LOGWARNING)
            return current
        if current:
            for key in ('current_mac', 'current_at', 'current_scope'):
                if key in state:
                    state.pop(key, None)
                    changed = True
        if changed:
            with open(state_path, 'w', encoding='utf-8') as fh:
                json.dump(state, fh, ensure_ascii=True, indent=2, sort_keys=True)
            xbmc.log("[CODEX-MAC-ANALYTICS][Portal1/service] session-current-invalid-cleared reason=missing verification timestamp", xbmc.LOGWARNING)
    except Exception:
        pass
    return ""

# MAC-Adresse aus G.portal_config (gesetzt durch init_globals) oder generieren
_codex_session_mac = _codex_current_session_mac_from_state()
if _codex_session_mac:
    mac = _codex_session_mac
    G.portal_config.mac = mac
elif hasattr(G.portal_config, 'mac') and G.portal_config.mac:
    mac = G.portal_config.mac
else:
    _codex_load_mac_pool_if_empty("initial-mac")
    _codex_initial_pool = [m for m in getattr(G, 'mac_list', []) if m]
    if _codex_initial_pool:
        mac = random.choice(_codex_initial_pool)
    else:
        mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
    G.portal_config.mac = mac

# Portal-URL aus config übernehmen (jetzt gesetzt durch init_globals)
portal_url = G.portal_config.portal_base_url
if not portal_url:
    xbmc.log("[Stalker] Keine Portal-URL in der Konfiguration gefunden!", xbmc.LOGERROR)
    # Fallback: Aus Addon-Einstellungen lesen (falls vorhanden)
    portal_url = ADDON.getSetting('portal_url')
    if not portal_url:
        raise ValueError("[Stalker] Keine Portal-URL konfiguriert")

def _codex_redact_initial_mac(value):
    try:
        match = re.search(r"(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b", str(value or ""))
        mac_value = match.group(0).upper() if match else ""
        return "****" + mac_value[-5:] if mac_value else "<none>"
    except Exception:
        return "<none>"

def _codex_pick_initial_mac(exclude=None):
    exclude = set(exclude or [])
    _codex_load_mac_pool_if_empty("initial-auth-retry")
    candidates = [m for m in getattr(G, 'mac_list', []) if m and m not in exclude]
    if not candidates:
        candidates = [m for m in getattr(G, 'mac_list', []) if m]
    if candidates:
        return random.choice(candidates)
    return ':'.join(re.findall('..', '%012x' % uuid.getnode()))

def _codex_set_active_mac(value):
    try:
        G.portal_config.mac = value
        G.portal_config.mac_cookie = 'mac=' + value
    except Exception:
        pass

def _codex_is_portal_timeout_error(exc):
    text = str(exc or "").lower()
    name = exc.__class__.__name__.lower()
    return (
        "connecttimeout" in name or
        "readtimeout" in name or
        "timeout" in name or
        "timed out" in text or
        "read timed out" in text or
        "connect timeout" in text or
        "max retries exceeded" in text
    )

# StalkerPortal-Instanz erzeugen.
# Wichtig: keine Bewertungslisten und kein blindes, unverifiziertes Pinning.
# Live-TV/Handshake bleiben bewusst bei genau 1 Versuch, weil mehrere schnelle
# Auths Stalker Portal 1/IP kurz blockieren koennen.
# Normale Filme-/Serien-Menues bleiben beim Initialstart bei 1 Versuch; der
# Addon-Wrapper entscheidet danach kontrolliert, ob ein einzelner Retry noetig
# ist. So gibt es keine verdeckten Mehrfachketten.
# Bei einer per Plugin-URL mitgegebenen Einmal-MAC bleibt es bei genau dieser einen.
stalker_portal = None
_codex_initial_one_shot = bool(_codex_session_mac)
try:
    _codex_initial_query = urllib.parse.parse_qs((sys.argv[2] if len(sys.argv) > 2 else "").lstrip("?"), keep_blank_values=True)
    _codex_initial_action = str((_codex_initial_query.get("action") or [""])[0] or "").strip().lower()
except Exception:
    _codex_initial_action = ""
_codex_initial_needs_portal = _codex_initial_action in (
    "vod", "series", "listing", "ser_listing", "search", "search_series",
    "tv", "live", "tv_listing",
    "seasons", "season", "episodes", "episode", "play", "create_link",
    "codex_macsimum_vod_play", "codex_macsimum_episode_play",
    "codex_macsimum_bridge_play", "codex_macsimum_handshake",
    "codex_macsimum_scope_scan", "codex_macsimum_all_scan", "codex_macsimum_gap_scan",
    "codex_macsimum_missing_m3u_repair",
)
if _codex_initial_one_shot:
    _codex_initial_attempts = 1
elif _codex_initial_action == "codex_macsimum_gap_scan":
    # Der Luecken-Scan muss ruhig bleiben: wenn das Portal gerade nicht
    # antwortet, sauber abbrechen statt mit mehreren MACs zu haemmern.
    _codex_initial_attempts = 1
elif _codex_initial_action in ("codex_macsimum_bridge_play", "codex_macsimum_handshake"):
    # Live-TV-3/Handshake: genau 1 Versuch. Ein fehlgeschlagener Sender oder
    # Handshake darf nicht automatisch mehrere MACs/Auths hintereinander feuern.
    _codex_initial_attempts = 1
elif _codex_initial_action in ("vod", "series", "listing", "ser_listing", "search", "search_series", "seasons", "season", "episodes", "episode"):
    # Normale VOD-/Serien-Menues: genau 1 Initialversuch.
    _codex_initial_attempts = 1
else:
    # Direkte Playback-/Sonderaktionen bleiben defensiv bei einem Versuch.
    _codex_initial_attempts = 1
_codex_tried_initial_macs = []
_codex_last_initial_error = None
for _codex_attempt in range(1, _codex_initial_attempts + 1):
    if _codex_attempt > 1:
        mac = _codex_pick_initial_mac(_codex_tried_initial_macs)
    _codex_tried_initial_macs.append(mac)
    _codex_set_active_mac(mac)
    stalker_portal = StalkerPortal(portal_url, mac)
    try:
        xbmc.log(
            "[CODEX-MAC-ANALYTICS][Portal1/service] initial-auth-start attempt=%s/%s mac=%s one_shot=%s" % (
                _codex_attempt,
                _codex_initial_attempts,
                _codex_redact_initial_mac(mac),
                _codex_initial_one_shot,
            ),
            xbmc.LOGWARNING,
        )
        stalker_portal.authenticate()
        xbmc.log(
            "[CODEX-MAC-ANALYTICS][Portal1/service] initial-auth-ok attempt=%s/%s mac=%s" % (
                _codex_attempt,
                _codex_initial_attempts,
                _codex_redact_initial_mac(mac),
            ),
            xbmc.LOGWARNING,
        )
        break
    except Exception as e:
        _codex_last_initial_error = e
        xbmc.log(
            "[CODEX-MAC-ANALYTICS][Portal1/service] initial-auth-failed attempt=%s/%s mac=%s reason=%s" % (
                _codex_attempt,
                _codex_initial_attempts,
                _codex_redact_initial_mac(mac),
                e,
            ),
            xbmc.LOGWARNING,
        )
        if _codex_is_portal_timeout_error(e):
            xbmc.log(
                "[CODEX-MAC-ANALYTICS][Portal1/service] initial-auth-stop-timeout attempt=%s/%s mac=%s reason=%s" % (
                    _codex_attempt,
                    _codex_initial_attempts,
                    _codex_redact_initial_mac(mac),
                    e,
                ),
                xbmc.LOGWARNING,
            )
            break
        if _codex_attempt < _codex_initial_attempts:
            try:
                time.sleep(0.65)
            except Exception:
                pass

if stalker_portal is not None and not getattr(stalker_portal, 'token', '') and _codex_last_initial_error is not None:
    xbmc.log(f"[Stalker] Initial authentication failed after guarded attempts: {_codex_last_initial_error}", xbmc.LOGERROR)

# ----------------------------- Hilfsfunktionen -----------------------------
def is_json(myjson):
    try:
        json.loads(myjson)
        return True
    except ValueError:
        return False

@dataclasses.dataclass
class Token:
    value: str = None

_mac_rotation_lock = threading.Lock()

def _analytics_redact_mac(value):
    try:
        match = re.search(r"(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b", str(value or ""))
        mac_value = match.group(0).upper() if match else ""
        return "****" + mac_value[-5:] if mac_value else "<none>"
    except Exception:
        return "<none>"

def _analytics_mac_pool_size():
    try:
        return len([m for m in getattr(G, 'mac_list', []) if m])
    except Exception:
        return -1

def _analytics_log_mac(event, before=None, after=None, reason=""):
    try:
        current = getattr(getattr(G, 'portal_config', None), 'mac', None)
        xbmc.log(
            "[CODEX-MAC-ANALYTICS][Portal1/service] %s reason=%s before=%s after=%s current=%s pool=%s" % (
                event,
                reason or "-",
                _analytics_redact_mac(before),
                _analytics_redact_mac(after),
                _analytics_redact_mac(current),
                _analytics_mac_pool_size(),
            ),
            xbmc.LOGWARNING,
        )
    except Exception:
        pass

def _rotate_mac_and_refresh(min_delay=0.05, max_delay=0.35):
    global stalker_portal
    if stalker_portal is None:
        return None
    try:
        with _mac_rotation_lock:
            current_mac = getattr(G.portal_config, 'mac', None)
            _analytics_log_mac("rotation-start", before=current_mac)
            _codex_load_mac_pool_if_empty("rotation")
            candidates = [m for m in getattr(G, 'mac_list', []) if m and m != current_mac]
            if not candidates:
                candidates = getattr(G, 'mac_list', [])[:]
            if not candidates:
                logging.warning("[Stalker] Keine MACs in G.mac_list gefunden; überspringe Rotation.")
                _analytics_log_mac("rotation-skipped-empty-pool", before=current_mac)
                return None
            new_mac = random.choice(candidates)
            _analytics_log_mac("rotation-selected", before=current_mac, after=new_mac)
            G.portal_config.mac = new_mac
            G.portal_config.mac_cookie = 'mac=' + new_mac
            stalker_portal.mac = new_mac
            stalker_portal.cookie = f"mac={new_mac}; stb_lang=en; timezone=Europe/Amsterdam;"
            stalker_portal.session.headers.update({"Cookie": stalker_portal.cookie})
            stalker_portal.token = ""
            stalker_portal.use_fallback = False
            stalker_portal.use_fallback_2 = False
            try:
                stalker_portal.authenticate()
                _analytics_log_mac("rotation-auth-ok", before=current_mac, after=new_mac)
            except Exception as e:
                _analytics_log_mac("rotation-auth-failed", before=current_mac, after=new_mac, reason=str(e))
                logging.debug(f"[Stalker] Fehler bei Neuauthentifizierung nach MAC-Rotation: {e}")
    except Exception as exc:
        _analytics_log_mac("rotation-error", reason=str(exc))
        logging.error(f"[Stalker] Fehler in _rotate_mac_and_refresh: {exc}")
        return None

    try:
        delay = random.uniform(float(min_delay), float(max_delay))
        time.sleep(delay)
    except Exception:
        pass

    return new_mac

def rotate_mac_now(reason="unknown"):
    try:
        xbmc.log(f"[Stalker] MAC-Rotation ausgelöst ({reason})", xbmc.LOGWARNING)
        before = getattr(G.portal_config, 'mac', None)
        new_mac = _rotate_mac_and_refresh()
        _analytics_log_mac("rotate-mac-now-result", before=before, after=new_mac, reason=reason)
        return new_mac
    except Exception as e:
        _analytics_log_mac("rotate-mac-now-error", reason="%s: %s" % (reason, e))
        xbmc.log(f"[Stalker] MAC-Rotation fehlgeschlagen: {e}", xbmc.LOGERROR)
    return None

def _extract_stream_cmd(response):
    if response is None:
        return None, "No response"
    if isinstance(response, list):
        return None, "Response is list (auth/session error)"
    if not isinstance(response, dict):
        return None, f"Unexpected response type: {type(response)}"

    js = response.get("js")
    if isinstance(js, dict):
        cmd = js.get("cmd")
        if cmd:
            return cmd, None
        return None, "Missing cmd in js"
    if isinstance(js, list):
        return None, "js is list (session expired?)"
    return None, "Invalid js structure"

# ----------------------------- EPG-Funktionen -----------------------------
_epg_mem = None
_epg_loaded_ts = 0

def get_timestamp():
    return int(time.time())

def is_cache_expired(timestamp):
    current_time = get_timestamp()
    return (current_time - timestamp) > (3 * 60 * 60)

def save_epg_cache():
    with open(epg_cache_path, 'w') as cache_file:
        json.dump(epg_cache, cache_file)

def load_epg_cache():
    try:
        with open(epg_cache_path, 'r') as cache_file:
            return json.load(cache_file)
    except FileNotFoundError:
        return {}

def get_epg_data():
    if stalker_portal is None:
        return {}
    params = {
        'type': 'itv',
        'action': 'get_epg_info',
        'period': '2',
        'JsHttpRequest': '1-xml'
    }
    try:
        resp = stalker_portal.api_request(params)
    except Exception as e:
        logging.error(f"[Stalker] get_epg_data: API request failed: {e}")
        return {}
    if not resp or 'js' not in resp:
        logging.warning("[Stalker] get_epg_data: no 'js' in response")
        return {}
    data = resp['js'].get('data', {})
    if not data:
        logging.warning("[Stalker] get_epg_data: no data in response")
        return {}
    # Cache in Datei speichern
    try:
        with open(epg_path, 'w') as f:
            json.dump(data, f, indent=4, sort_keys=False)
    except Exception as e:
        logging.error(f"[Stalker] get_epg_data: could not write cache: {e}")
    return data

def get_epg_dict():
    global _epg_mem, _epg_loaded_ts
    # Prüfe, ob der Cache noch aktuell ist
    if _epg_mem is not None and not is_cache_expired(_epg_loaded_ts):
        return _epg_mem
    # Versuche, aus Datei zu laden
    if os.path.exists(epg_path):
        try:
            with open(epg_path, 'r', encoding='utf-8') as f:
                _epg_mem = json.load(f)
                _epg_loaded_ts = get_timestamp()
                return _epg_mem
        except Exception as e:
            logging.error(f"[Stalker] get_epg_dict: could not read cache: {e}")
    # Datei existiert nicht oder ist fehlerhaft -> neu laden
    _epg_mem = get_epg_data()
    _epg_loaded_ts = get_timestamp()
    return _epg_mem

def short_epg_from_dict(epgid, epg_dict):
    items = epg_dict.get(str(epgid)) or epg_dict.get(int(epgid))
    if not items:
        return "[COLOR=red]Keine Informationen vorhanden[/COLOR]"
    lines = [
        f"[B]{i['t_time']} - {i['t_time_to']}:[/B] {i['name']}"
        for i in items[:3]
    ]
    return "\n".join(lines)

# ----------------------------- Datenabruffunktionen -----------------------------
def get_tv_genres():
    if stalker_portal is None:
        return None
    params = {'type': 'itv', 'action': 'get_genres', 'JsHttpRequest': '1-xml'}
    try:
        resp = stalker_portal.api_request(params)
    except Exception as e:
        logging.warning(f"[Stalker] get_tv_genres: portal call raised: {e}")
        return None
    if not resp:
        logging.warning("[Stalker] get_tv_genres: no response from portal")
        return None
    try:
        js = resp.get('js') if isinstance(resp, dict) else None
        if not js:
            logging.warning("[Stalker] get_tv_genres: 'js' missing or empty in response")
            return None
        return js
    except Exception as e:
        logging.error(f"[Stalker] get_tv_genres: parsing error: {e}")
        return None

def get_tv_channels(category_id, page):
    params = {'type': 'itv', 'action': 'get_ordered_list', 'genre': category_id, 'sortby': 'number', 'JsHttpRequest': '1-xml'}
    return get_tv_listing(params, page)

def get_categories():
    if stalker_portal is None:
        return None
    params = {'type': 'vod', 'action': 'get_categories', 'JsHttpRequest': '1-xml'}
    try:
        resp = stalker_portal.api_request(params)
    except Exception as e:
        logging.warning(f"[Stalker] get_categories: portal call raised: {e}")
        return None
    if not resp:
        logging.warning("[Stalker] get_categories: no response from portal")
        return None
    try:
        js = resp.get('js') if isinstance(resp, dict) else None
        if not js:
            logging.warning("[Stalker] get_categories: 'js' missing or empty in response")
            return None
        return js
    except Exception as e:
        logging.error(f"[Stalker] get_categories: parsing error: {e}")
        return None

def get_ser_categories():
    if stalker_portal is None:
        return None
    params = {'type': 'series', 'action': 'get_categories', 'JsHttpRequest': '1-xml'}
    try:
        resp = stalker_portal.api_request(params)
    except Exception as e:
        logging.warning(f"[Stalker] get_ser_categories: portal call raised: {e}")
        return None
    if not resp:
        logging.warning("[Stalker] get_ser_categories: no response from portal")
        return None
    try:
        js = resp.get('js') if isinstance(resp, dict) else None
        if not js:
            logging.warning("[Stalker] get_ser_categories: 'js' missing or empty in response")
            return None
        return js
    except Exception as e:
        logging.error(f"[Stalker] get_ser_categories: parsing error: {e}")
        return None

def get_videos(category_id, page, search_term):
    params = {'type': 'vod', 'action': 'get_ordered_list', 'category': category_id, 'sortby': 'added', 'orderby': 'added', 'order': 'desc', 'sort_order': 'desc', 'JsHttpRequest': '1-xml'}
    if bool(search_term.strip()):
        params.update({'search': search_term})
    return get_listing(params, page)

def get_series(category_id, page, search_term):
    params = {'type': 'series', 'action': 'get_ordered_list', 'category': category_id, 'sortby': 'added', 'orderby': 'added', 'order': 'desc', 'sort_order': 'desc', 'JsHttpRequest': '1-xml'}
    if search_term.strip():
        params.update({'search': search_term})
    return get_listing(params, page)

def get_seasons(series_id, category_id, page=None):
    params = {
        'type': 'series',
        'action': 'get_ordered_list',
        'category': category_id,
        'movie_id': f"{series_id}:{series_id}",
        'sortby': 'added',
        'orderby': 'added',
        'order': 'desc',
        'sort_order': 'desc',
        'season_id': 0,
        'episod_id': 0,
        'JsHttpRequest': '1-xml'
    }
    return get_listing(params, page)

def _normalize_series_id_for_episodes(value):
    value = str(value or '').strip()
    if ':' in value:
        value = value.split(':', 1)[0]
    return value

def _normalize_season_id_for_episodes(series_id, season_id):
    sid = str(season_id or '').strip()
    if not sid:
        raw_series = str(series_id or '').strip()
        if ':' in raw_series:
            sid = raw_series.split(':', 1)[1]
    match = re.search(r'(\d+)', sid)
    return match.group(1) if match else sid

def get_episodes(series_id, season_id, page='1'):
    clean_series_id = _normalize_series_id_for_episodes(series_id)
    clean_season_id = _normalize_season_id_for_episodes(series_id, season_id)
    try:
        xbmc.log("[Stalker] get_episodes normalized: series=%s -> %s, season=%s -> %s" % (series_id, clean_series_id, season_id, clean_season_id), xbmc.LOGINFO)
    except Exception:
        pass
    params = {
        'type': 'series',
        'action': 'get_ordered_list',
        'movie_id': clean_series_id,
        'season_id': clean_season_id,
        'episod_id': 0,
        'page': page,
        'JsHttpRequest': '1-xml'
    }
    return get_listing(params, page)

def _first_value(item, names):
    if not isinstance(item, dict):
        return ''
    for name in names:
        value = item.get(name)
        if value not in (None, '', [], {}):
            return value
    return ''

def _parse_sort_timestamp(value):
    text = str(value or '').strip()
    if not text:
        return 0
    try:
        if re.match(r'^\d{10,13}$', text):
            number = int(text)
            return number // 1000 if number > 9999999999 else number
    except Exception:
        pass
    for fmt in (
        '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d',
        '%d.%m.%Y %H:%M:%S', '%d.%m.%Y', '%d/%m/%Y', '%m/%d/%Y'
    ):
        try:
            return int(datetime.strptime(text[:19], fmt).timestamp())
        except Exception:
            pass
    match = re.search(r'\b((?:19|20)\d{2})\b', text)
    if match:
        try:
            return int(match.group(1)) * 100000000
        except Exception:
            pass
    return 0

def _media_sort_key(item, original_index):
    upload_value = _first_value(item, (
        'added', 'added_at', 'added_date', 'addtime', 'add_time',
        'created', 'created_at', 'updated', 'updated_at', 'last_modified', 'date'
    ))
    upload_ts = _parse_sort_timestamp(upload_value)
    year_value = _first_value(item, ('year', 'release_date', 'first_air_date', 'premiered'))
    year_ts = _parse_sort_timestamp(year_value)
    return (max(upload_ts, year_ts), -original_index)

def _sort_media_data_newest_first(data):
    if not isinstance(data, list) or len(data) < 2:
        return data
    keyed = []
    sortable_count = 0
    for idx, item in enumerate(data):
        key = _media_sort_key(item, idx)
        if key[0]:
            sortable_count += 1
        keyed.append((key, idx, item))
    if sortable_count < 2:
        return data
    keyed.sort(key=lambda row: (-row[0][0], row[1]))
    return [item for _key, _idx, item in keyed]

def get_listing_with_pagination(params, page, max_page_limit):
    if stalker_portal is None:
        return {'max_page_items': 0, 'total_items': 0, 'data': []}
    params.update({'p': str(page)})
    response = stalker_portal.api_request(params)
    if not response or 'js' not in response:
        return {'max_page_items': 0, 'total_items': 0, 'data': []}
    js = response['js']
    if isinstance(js, list):
        return {'max_page_items': len(js), 'total_items': len(js), 'data': js}
    videos = js.get('data', [])
    total_items = js.get('total_items', 0)
    max_page_items = js.get('max_page_items', 0)
    total_pages = int(math.ceil(float(total_items) / float(max_page_items))) if max_page_items > 0 else 0
    for page_no in range(int(page) + 1, min(int(page) + max_page_limit, total_pages + 1)):
        params['p'] = str(page_no)
        resp = stalker_portal.api_request(params)
        if resp and 'js' in resp:
            videos += resp['js'].get('data', [])
    if str(params.get('type') or '').lower() in ('vod', 'series') and str(params.get('action') or '').lower() == 'get_ordered_list':
        videos = _sort_media_data_newest_first(videos)
    return {'max_page_items': max_page_items, 'total_items': total_items, 'data': videos}

def get_listing(params, page):
    try:
        page_limit = max(int(getattr(G.addon_config, 'max_page_limit', 0) or 0), CODEX_VOD_SERIES_PAGE_LIMIT)
    except Exception:
        page_limit = CODEX_VOD_SERIES_PAGE_LIMIT
    return get_listing_with_pagination(params, page, page_limit)

def get_tv_listing(params, page):
    return get_listing_with_pagination(params, page, G.addon_config.max_page_limit_tv)

# ----------------------------- DoH und Stream-URLs -----------------------------
import dns.message
import dns.query
import dns.rdatatype

def resolve_hostname_doh(hostname):
    try:
        request = dns.message.make_query(hostname, dns.rdatatype.A)
        response = dns.query.https(request, 'https://cloudflare-dns.com/dns-query')
        for answer in response.answer:
            for item in answer.items:
                if item.rdtype == dns.rdatatype.A:
                    return item.address
    except Exception as e:
        xbmc.log(f"[DoH] Resolution failed for {hostname}: {e}", xbmc.LOGERROR)
    return None

def _attempt_resolve_and_patch_url(original_url):
    try:
        parsed = urlparse(original_url)
        hostname = parsed.hostname
        if not hostname:
            logging.debug(f"[DoH] Keine Host-Komponente in URL: {original_url}")
            return original_url, False, None, None

        resolved_ip = resolve_hostname_doh(hostname)
        if resolved_ip:
            port = parsed.port
            if port:
                new_netloc = f"{resolved_ip}:{port}"
            else:
                new_netloc = resolved_ip

            patched = urlunparse((
                parsed.scheme,
                new_netloc,
                parsed.path or "",
                parsed.params or "",
                parsed.query or "",
                parsed.fragment or ""
            ))

            logging.info(f"[DoH] {hostname} -> {resolved_ip} (patched URL)")
            try:
                xbmcgui.Dialog().notification("DoH", f"{hostname} → {resolved_ip}", xbmcgui.NOTIFICATION_INFO, 2500)
            except Exception:
                pass

            return patched, True, hostname, resolved_ip

        logging.debug(f"[DoH] Keine IP via DoH für {hostname}")
        return original_url, False, hostname, None

    except Exception as e:
        logging.error(f"[DoH] Fehler beim Patchen der URL {original_url}: {e}")
        return original_url, False, None, None

def get_vod_stream_url(cmd, max_attempts=3):
    if stalker_portal is None:
        return None
    for attempt in range(1, max_attempts + 1):
        try:
            if attempt > 1:
                new_mac = _rotate_mac_and_refresh()
                logging.debug(f"[MAC] VOD Retry {attempt}: rotated → {new_mac}")

            stream_url = stalker_portal.get_stream_link(cmd, content_type="vod")
            if stream_url:
                patched_url, did_resolve, orig_host, resolved_ip = _attempt_resolve_and_patch_url(stream_url)
                if did_resolve:
                    logging.debug(f"[DoH] VOD: {orig_host} → {resolved_ip}")
                    return patched_url
                return stream_url

            logging.warning(f"[VOD] Attempt {attempt} failed: no stream URL")
            time.sleep(0.2)
        except Exception as e:
            logging.exception(f"[VOD] Unexpected error: {e}")
            break

    xbmcgui.Dialog().notification("Stalker VOD", "Stream momentan nicht verfügbar", xbmcgui.NOTIFICATION_ERROR, 3000)
    return None

def get_episode_stream_url(video_id, series, max_attempts=3):
    if stalker_portal is None:
        return None
    cmd = f"/media/{video_id}.mpg"
    for attempt in range(1, max_attempts + 1):
        try:
            if attempt > 1:
                new_mac = _rotate_mac_and_refresh()
                logging.debug(f"[MAC] EP Retry {attempt}: rotated → {new_mac}")

            stream_url = stalker_portal.get_stream_link(cmd, content_type="series", ep_id=series)
            if stream_url:
                patched_url, did_resolve, orig_host, resolved_ip = _attempt_resolve_and_patch_url(stream_url)
                if did_resolve:
                    logging.debug(f"[DoH] EP: {orig_host} → {resolved_ip}")
                    return patched_url
                return stream_url

            logging.warning(f"[EP] Attempt {attempt} failed: no stream URL")
            time.sleep(0.2)
        except Exception as e:
            logging.exception(f"[EP] Unexpected error: {e}")
            break

    xbmcgui.Dialog().notification("Stalker Episode", "Episode konnte nicht geladen werden", xbmcgui.NOTIFICATION_ERROR, 3000)
    return None

def get_tv_stream_url(cmd, max_attempts=3):
    if stalker_portal is None:
        return None
    for attempt in range(1, max_attempts + 1):
        try:
            if attempt > 1:
                new_mac = _rotate_mac_and_refresh()
                logging.debug(f"[MAC] TV Retry {attempt}: rotated → {new_mac}")

            stream_url = stalker_portal.get_stream_link(cmd, content_type="itv")
            if stream_url:
                patched_url, did_resolve, orig_host, resolved_ip = _attempt_resolve_and_patch_url(stream_url)
                if did_resolve:
                    logging.debug(f"[DoH] TV: {orig_host} → {resolved_ip}")
                    return patched_url
                return stream_url

            logging.warning(f"[TV] Attempt {attempt} failed: no stream URL")
            time.sleep(0.2)
        except Exception as e:
            logging.exception(f"[TV] Unexpected error: {e}")
            break

    xbmcgui.Dialog().notification("Stalker Live-TV", "Stream momentan nicht verfügbar", xbmcgui.NOTIFICATION_ERROR, 3000)
    return None


# ----------------------------- Stalker-Macsimum-Kompatibilitaet -----------------------------
# Der Kern dieses Service stammt aus Talker3, Stalker Maximums aelterer
# addon.pyc erwartet aber teils noch die alten Funktionsnamen. Diese duennen
# Alias-Funktionen halten die alte Oberflaeche kompatibel, ohne die neue
# Talker3-Authentifizierung wieder zu umgehen.

def get_vod(category_id, page, search_term=""):
    return get_videos(category_id, page, search_term or "")


def getShortEPG(epgid, *args, **kwargs):
    try:
        return short_epg_from_dict(epgid, get_epg_dict())
    except Exception:
        return "[COLOR=red]Keine Informationen vorhanden[/COLOR]"


def load_epg_caches(*args, **kwargs):
    return load_epg_cache()


def get_tv_stream_url2(cmd, *args, **kwargs):
    return get_tv_stream_url(cmd)


def getProfile(*args, **kwargs):
    if stalker_portal is None:
        return {}
    return stalker_portal.get_profile()


def __OOO000O00OO00OOOO(cmd, content_type="vod", ep_id=None):
    if stalker_portal is None:
        return None
    return stalker_portal.get_stream_link(cmd, content_type=content_type, ep_id=ep_id)


class Auth:
    TOKEN_FILE = "token.json"

    def __init__(self, *args, **kwargs):
        pass

    def get_token(self):
        if stalker_portal is None:
            return Token()
        if not getattr(stalker_portal, "token", ""):
            stalker_portal.authenticate()
        return Token(getattr(stalker_portal, "token", ""))

    def clear_cache(self):
        try:
            if stalker_portal is not None:
                stalker_portal.token = ""
                stalker_portal.session.headers.pop("Authorization", None)
        except Exception:
            pass
