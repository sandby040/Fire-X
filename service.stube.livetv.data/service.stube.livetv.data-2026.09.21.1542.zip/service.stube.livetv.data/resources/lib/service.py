# -*- coding: utf-8 -*-
import hashlib
import os
import shutil

import xbmc
import xbmcvfs


ADDON_ID = "service.stube.livetv.data"


def log(message):
    xbmc.log("%s: %s" % (ADDON_ID, message), xbmc.LOGINFO)


def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:
        return xbmc.translatePath(path)


def copy_if_changed(src, dst):
    if os.path.exists(dst):
        try:
            if md5_file(src) == md5_file(dst):
                return False
        except Exception:
            pass
    parent = os.path.dirname(dst)
    if parent and not os.path.exists(parent):
        os.makedirs(parent)
    shutil.copy2(src, dst)
    return True


def sync_data():
    addon_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    src_root = os.path.join(addon_root, "resources", "data", "userdata")
    dst_root = translate("special://userdata")
    changed = 0
    total = 0
    if not os.path.isdir(src_root):
        log("Keine Daten im Paket gefunden")
        return
    for root, dirs, files in os.walk(src_root):
        for name in files:
            src = os.path.join(root, name)
            rel = os.path.relpath(src, src_root)
            dst = os.path.join(dst_root, rel)
            total += 1
            try:
                if copy_if_changed(src, dst):
                    changed += 1
            except Exception as exc:
                log("Konnte Datei nicht spiegeln: %s -> %s (%s)" % (src, dst, exc))
    log("Live-TV-Daten gespiegelt: %d/%d geaendert" % (changed, total))


if __name__ == "__main__":
    sync_data()
else:
    sync_data()
