# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!
import re, time, requests, json

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from json import loads
#from xbmc import LOGINFO as LOGNOTICE, LOGERROR, log

SITE_IDENTIFIER = 'kinox'
SITE_NAME = 'KinoX'
SITE_ICON = 'kinox.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'kinoz.to') # Domain Auswahl über die Streaming Archiv Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

# Domain Auswahl über die Streaming Archiv Einstellungen möglich
URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'https://ww19.kinox.to'
URL_NEWS = URL_MAIN + '/index.php'
URL_CINEMA_PAGE = URL_MAIN + '/Kino-Filme.html'
URL_GENRE_PAGE = URL_MAIN + '/Genre.html'
URL_MOVIE_PAGE = URL_MAIN + '/Movies.html'
URL_SERIE_PAGE = URL_MAIN + '/Series.html'
URL_DOCU_PAGE = URL_MAIN + '/Documentations.html'
URL_FAVOURITE_MOVIE_PAGE = URL_MAIN + '/Popular-Movies.html'
URL_FAVOURITE_SERIE_PAGE = URL_MAIN + '/Popular-Series.html'
URL_FAVOURITE_DOCU_PAGE = URL_MAIN + '/Popular-Documentations.html'
URL_LATEST_MOVIE_PAGE = URL_MAIN + '/Latest-Movies.html'
URL_LATEST_SERIE_PAGE = URL_MAIN + '/Latest-Series.html'
URL_LATEST_DOCU_PAGE = URL_MAIN + '/Latest-Documentations.html'
URL_SEARCH = URL_MAIN + '/Search.html?q=%s'
URL_MIRROR = URL_MAIN + '/aGET/Mirror/'
URL_EPISODE_URL = URL_MAIN + '/aGET/MirrorByEpisode/'
URL_AJAX = URL_MAIN + '/aGET/List/'
URL_LANGUAGE = URL_MAIN + '/aSET/PageLang/1'

def cap(html):
    ids = re.findall(r'data-id="([^"]+)" data-value="[^>]+ title="([^"]+)', html)
    text_match = re.search(r"<h3>([^<]+)", html)
    p1 = re.findall(r'text" name="([^"]+)', html)
    p2 = re.findall(r'name="([^"]+)" value="([^"]+)', html)
    p3 = re.findall(r'submit" name="([^"]+)', html)
    p4 = re.findall(r'hidden" name="([^"]+)" id', html)
    if all([ids, text_match, p1, p2, p3, p4]):
        allowed = {v for k, v in ids}
        text_match = text_match.group(1)
        words = re.findall(r"\b\w+\b", text_match)
        wert = [w for w in words if w in allowed]
        resultat = ",".join([str(b) for a in wert for b, c in ids if a == c])
        return {p1[0]: "", p2[0][0]: p2[0][1], p3[0]: "", p4[0]: resultat}
    return None



def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    oGui = cGui()

    parms = ParameterHandler()
    parms.setParam('sUrl', URL_NEWS)
    parms.setParam('page', 1)
    parms.setParam('mediaType', 'news')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showNews'), parms)    # New

    parms = ParameterHandler()
    parms.setParam('sUrl', URL_SEARCH)
    parms.setParam('mediaType', '')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), parms)  # Search

    parms = ParameterHandler()
    parms.setParam('sUrl', URL_MOVIE_PAGE)
    parms.setParam('mediaType', 'movie')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMovieMenu'), parms)   # Movies

    parms = ParameterHandler()
    parms.setParam('sUrl', URL_SERIE_PAGE)
    parms.setParam('mediaType', 'series')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeriesMenu'), parms)  # Series

    parms = ParameterHandler()
    parms.setParam('sUrl', URL_DOCU_PAGE)
    parms.setParam('mediaType', 'documentation')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30505), SITE_IDENTIFIER, 'showDocuMenu'), parms)    # Documentations
    oGui.setEndOfDirectory()


def __createMenuEntry(oGui, sFunction, sLabel, dOutputParameter):
    parms = ParameterHandler()
    try:
        for param, value in dOutputParameter.items():
            parms.setParam(param, value)
    except Exception as e:
        logger.error("Can't add parameter to menu entry with label: %s: %s" % (sLabel, e))
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setFunction(sFunction)
    oGuiElement.setTitle(sLabel)
    oGui.addFolder(oGuiElement, parms)


def showMovieMenu():
    oGui = cGui()
    parms = ParameterHandler()
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showCinemaMovies'), parms)# Current films in the cinema
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_MOVIE_PAGE)
    parms.setParam('page', 1)
    parms.setParam('mediaType', 'movie')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)  # From A-Z
    parms = ParameterHandler()
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenres'), parms)  # Genre
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_FAVOURITE_MOVIE_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showFavItems'), parms)    # popular Movies
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_LATEST_MOVIE_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30541), SITE_IDENTIFIER, 'showFavItems'), parms)    # new Movies
    oGui.setEndOfDirectory()


def showSeriesMenu():
    oGui = cGui()
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_SERIE_PAGE)
    parms.setParam('page', 1)
    parms.setParam('mediaType', 'series')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)# From A-Z
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_FAVOURITE_SERIE_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showFavItems'), parms)# popular Series
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_LATEST_SERIE_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30514), SITE_IDENTIFIER, 'showFavItems'), parms)# new Series
    oGui.setEndOfDirectory()


def showDocuMenu():
    oGui = cGui()
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_DOCU_PAGE)
    parms.setParam('page', 1)
    parms.setParam('mediaType', 'documentation')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)  # From A-Z
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_FAVOURITE_DOCU_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30522), SITE_IDENTIFIER, 'showFavItems'), parms)# Popular Documentations
    parms = ParameterHandler()
    parms.setParam('sUrl', URL_LATEST_DOCU_PAGE)
    parms.setParam('page', 1)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30523), SITE_IDENTIFIER, 'showFavItems'), parms)# New Documentations
    oGui.setEndOfDirectory()


def __createLanguage(sLangID): # Sprachenkürzel nach der internationalen Norm ISO-639-1
    return {'1': 'DE', '2': 'EN', '4': 'ZA', '5': 'ES', '6': 'FR', '7': 'TR',
            '8': 'JA', '9': 'AR', '11': 'IT', '12': 'HR', '13': 'SR',
            '14': 'BS', '15': 'DE / EN', '16': 'NL', '17': 'KO',
            '24': 'EL', '25': 'RU', '26': 'HI', }.get(sLangID, sLangID)


def __checkSubLanguage(sTitle):
    if ' subbed*' not in sTitle:
        return [sTitle, '']
    temp = sTitle.split(' *')
    subLang = temp[-1].split('subbed*')[0].strip()
    title = ' '.join(temp[0:-1]).strip()
    return [title, 'de'] if subLang == 'german' else [title, subLang]


def __getHtmlContent(sUrl=None, ignoreErrors=False):
    parms = ParameterHandler()
    if sUrl is None and not parms.exist('sUrl'):
        logger.error('There is no url we can request.')
        return False
    elif sUrl is None:
        sUrl = parms.getValue('sUrl')
    sPrefLang = __getPreferredLanguage()
    oRequest = cRequestHandler(sUrl, ignoreErrors=ignoreErrors)
    oRequest.addHeaderEntry('Cookie', sPrefLang + 'ListDisplayYears=Always;')
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    return oRequest.request()


def __getPreferredLanguage():
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '1': # Voreingestellte Sprache Deutsch
        sPrefLang = 'ListNeededLanguage=25%2C24%2C26%2C2%2C5%2C6%2C7%2C8%2C11%2C15%2C16%2C9%2C12%2C13%2C14%2C17%2C4'
    elif sLanguage == '2':  # Voreingestellte Sprache Englisch
        sPrefLang = 'ListNeededLanguage=25%2C24%2C26%2C5%2C6%2C7%2C8%2C11%2C15%2C16%2C9%2C12%2C13%2C14%2C17%2C4%2C1'
    else:
        sPrefLang = ''
    return sPrefLang


def __stripHtml(sValue):
    return re.sub(r'<[^>]+>', '', sValue or '').replace('&nbsp;', ' ').strip()


def __guessMediaTypeFromUrl(sUrl):
    sUrl = (sUrl or '').lower()
    if 'series' in sUrl or 'tvserien' in sUrl:
        return 'series'
    if 'document' in sUrl or 'dokument' in sUrl or 'doku' in sUrl:
        return 'documentation'
    return 'movie'


def __addDisplayItem(oGui, sTitle, sUrl, mediaType, total=0, sLang='', subLang='', sYear='', sThumbnail='', sDesc='', sRating=''):
    parms = ParameterHandler()
    oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
    if sLang:
        oGuiElement.setLanguage(sLang)
    if subLang:
        oGuiElement.setSubLanguage(subLang)
    if sYear:
        oGuiElement.setYear(sYear)
    if sThumbnail:
        oGuiElement.setThumbnail(sThumbnail if sThumbnail.startswith('http') else URL_MAIN + sThumbnail)
    if sDesc:
        oGuiElement.setDescription(__stripHtml(sDesc))
    if sRating:
        oGuiElement.addItemValue('rating', sRating)
    parms.setParam('sUrl', sUrl if sUrl.startswith('http') else URL_MAIN + sUrl)
    parms.setParam('mediaType', mediaType)
    if mediaType == 'series':
        oGuiElement.setMediaType('tvshow')
        oGuiElement.setTVShowTitle(sTitle)
        oGui.addFolder(oGuiElement, parms, True, total)
        return 'tvshows'
    oGuiElement.setMediaType('movie')
    oGui.addFolder(oGuiElement, parms, False, total)
    return 'movies'


def __displayItems(sGui, sHtmlContent):
    oGui = sGui if sGui else cGui()
    targetView = 'movies'
    mediaTypeHint = __guessMediaTypeFromUrl(ParameterHandler().getValue('sUrl'))
    pattern = '<td class="Icon"><img width="16" height="11" src="/gr/sys/lng/(\d+).png" alt="language"></td>' + \
              '.*?title="([^\"]+)".*?<td class="Title">.*?<a href="([^\"]+)" onclick="return false;">([^<]+)</a> <span class="Year">([0-9]+)</span>'
    aResult = cParser.parse(sHtmlContent, pattern)
    if aResult[0]:
        total = len(aResult[1])
        for aEntry in aResult[1]:
            sTitle = aEntry[3]
            sTitle, subLang = __checkSubLanguage(sTitle)
            sLang = __createLanguage(aEntry[0])
            if aEntry[1] == 'movie' or aEntry[1] == 'cinema':
                mediaType = 'movie'
            elif aEntry[1] == 'series':
                mediaType = 'series'
            else:
                mediaType = 'documentation'
            targetView = __addDisplayItem(oGui, sTitle, aEntry[2], mediaType, total, sLang, subLang, aEntry[4])
        return targetView, total

    pattern = '<div class="ModuleHead mHead">[\\s\\S]*?<div class="Opt leftOpt Headlne"><a title="([^"]+)" href="([^"]+)"><h1>.*?</h1></a></div>[\\s\\S]*?<div class="MiniEntry">[\\s\\S]*?<div class="Thumb"><img[^>]+src="([^"]+)"[^>]*>[\\s\\S]*?<div class="Descriptor">(.*?)</div>[\\s\\S]*?/lng/([0-9]+)\\.png[\\s\\S]*?(?:<b>IMDb:</b>\\s*([^<]+))?'
    aResult = cParser.parse(sHtmlContent, pattern)
    if not aResult[0]:
        logger.error('Could not find an item')
        return False, 0

    total = len(aResult[1])
    for sRawTitle, sUrl, sThumb, sDesc, sLangId, sRawRating in aResult[1]:
        sTitle = __stripHtml(sRawTitle)
        sYear = ''
        yearMatch = re.search(r'^(.*?)\s+\((\d{4})\)$', sTitle)
        if yearMatch:
            sTitle = yearMatch.group(1).strip()
            sYear = yearMatch.group(2)
        sTitle, subLang = __checkSubLanguage(sTitle)
        sLang = __createLanguage(sLangId)
        sRating = ''
        if sRawRating:
            sRating = sRawRating.split('/')[0].strip()
        targetView = __addDisplayItem(oGui, sTitle, sUrl, mediaTypeHint, total, sLang, subLang, sYear, sThumb, sDesc, sRating)
    return targetView, total


def __buildPagedUrl(sUrl, iPage):
    if re.search(r'([?&])Page=\d+', sUrl):
        return re.sub(r'([?&])Page=\d+', r'\1Page=' + str(iPage), sUrl)
    return sUrl + ('&' if '?' in sUrl else '?') + 'Page=' + str(iPage)


def __hasDisplayItems(sHtmlContent):
    if not sHtmlContent:
        return False
    if re.search(r'<td class="Icon"><img width="16" height="11" src="/gr/sys/lng/(\d+).png" alt="language"></td>', sHtmlContent):
        return True
    return re.search(r'<div class="ModuleHead mHead">', sHtmlContent) is not None


def showFavItems():
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    try:
        iPage = int(parms.getValue('page'))
        if iPage < 1:
            iPage = 1
    except Exception:
        iPage = 1
    sHtmlContent = __getHtmlContent(sUrl)
    targetView, total = __displayItems(oGui, sHtmlContent)
    if total >= 60:
        sNextUrl = __buildPagedUrl(sUrl, iPage + 1)
        sNextHtml = __getHtmlContent(sNextUrl, ignoreErrors=True)
        if __hasDisplayItems(sNextHtml):
            nextParms = ParameterHandler()
            nextParms.setParam('sUrl', sNextUrl)
            nextParms.setParam('page', iPage + 1)
            oGui.addNextPage(SITE_IDENTIFIER, 'showFavItems', nextParms)
    if targetView:
        oGui.setView(targetView)
    oGui.setEndOfDirectory()


def showNews():
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    pattern = '<div class="Opt leftOpt Headlne"><h1>([a-zA-Z0-9\s.]+)</h1></div>\s*(?:<div.*?)?<div class="Opt rightOpt Hint">Insgesamt: (.*?)</div>'
    sHtmlContent = __getHtmlContent(sUrl)
    aResult = cParser.parse(sHtmlContent, pattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            sTitle = str(aEntry[0]) + ' (' + str(aEntry[1]) + ')'
            oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseNews')
            parms.addParams({'sUrl': URL_NEWS, 'page': 1, 'mediaType': 'news', 'sNewsTitle': aEntry[0]})
            oGui.addFolder(oGuiElement, parms)
        oGui.setView('movies')
    else:
        pattern = '<div class="image">\s*<a title="([^"]+)" href="([^"]+)">\s*<img src="([^"]+)"'
        aResult = cParser.parse(sHtmlContent, pattern)
        if aResult[0]:
            total = len(aResult[1])
            for sTitle, sUrl, sThumb in aResult[1]:
                oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
                oGuiElement.setThumbnail(URL_MAIN + sThumb)
                oGuiElement.setMediaType('movie')
                oGuiElement.setForceMeta(True)
                oGuiElement.setMetaAdvanced(False)
                parms.setParam('sUrl', URL_MAIN + sUrl)
                parms.setParam('mediaType', 'movie')
                oGui.addFolder(oGuiElement, parms, False, total)
            oGui.setView('movies')
    oGui.setEndOfDirectory()


def parseNews():
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    sNewsTitle = parms.getValue('sNewsTitle')
    if 'Serien' in sNewsTitle and 'Filme' not in sNewsTitle:
        mediaType = 'series'
    else:
        mediaType = 'movie'
    pattern = '<div class="Opt leftOpt Headlne"><h1>' + sNewsTitle \
              + '</h1></div>(.*?)<div class="ModuleFooter">'
    sHtmlContent = __getHtmlContent(sUrl)
    aResult = cParser.parse(sHtmlContent, pattern)

    if not aResult[0]:
        logger.info("Can't get any news")
        oGui.setEndOfDirectory()
        return

    pattern = '<td class="Icon"><img src="/gr/sys/lng/(\d+).png" alt="language" width="16" height="11".*?<td class="Title.*?rel="([^"]+)"><(?:a|span) href="([^\"]+)".*?class="OverlayLabel">([^<]+)(?:<span class="EpisodeDescr">)?([^<]+)'
    aResult = cParser.parse(aResult[1][0], pattern)
    if not aResult[0]:
        logger.info("Can't get any news")
        oGui.setEndOfDirectory()
        return
    total = len(aResult[1])
    target_view = 'movies'

    for aEntry in aResult[1]:
        sLang = __createLanguage(aEntry[0])
        sTitle = aEntry[3] + aEntry[4]
        if sTitle.endswith(': '):
            sTitle = sTitle[:-2]
        sTitle, subLang = __checkSubLanguage(sTitle)
        sUrl = aEntry[2]
        aUrl = sUrl.split(',')
        if len(aUrl) > 0:
            sUrl = aUrl[0]
            oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
            oGuiElement.setLanguage(sLang)
            oGuiElement.setSubLanguage(subLang)
            oGuiElement.setThumbnail(URL_MAIN + str(aEntry[1]))
            parms.setParam('sUrl', URL_MAIN + sUrl)
            parms.setParam('mediaType', mediaType)
            if mediaType == 'series':
                oGuiElement.setMediaType('tvshow')
                oGuiElement.setTVShowTitle(sTitle)
                oGuiElement.setForceMeta(True)
                oGuiElement.setMetaAdvanced(False)
                oGui.addFolder(oGuiElement, parms, True, total)
                target_view = 'tvshows'
            else:
                oGuiElement.setMediaType('movie')
                oGuiElement.setForceMeta(True)
                oGuiElement.setMetaAdvanced(False)
                oGui.addFolder(oGuiElement, parms, False, total)
                target_view = 'movies'
    oGui.setView(target_view)
    oGui.setEndOfDirectory()


def showCharacters():
    oGui = cGui()
    parms = ParameterHandler()

    if parms.exist('sUrl') and parms.exist('page') and parms.exist('mediaType'):
        siteUrl = parms.getValue('sUrl')
        sHtmlContent = __getHtmlContent(siteUrl)
        pattern = 'class="LetterMode.*?>([^>]+)</a>'
        aResult = cParser.parse(sHtmlContent, pattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            oGuiElement = cGuiElement(aEntry, SITE_IDENTIFIER, 'ajaxCall')
            parms.setParam('character', aEntry[0])
            if parms.exist('mediaTypePageId'):
                sMediaTypePageId = parms.getValue('mediaTypePageId')
                parms.setParam('mediaTypePageId', sMediaTypePageId)
            oGui.addFolder(oGuiElement, parms)
    oGui.setEndOfDirectory()


def showGenres():
    logger.info('load displayGenreSite')
    pattern = '<td class="Title"><a.*?href="/Genre/([^"]+)">([^<]+)</a>.*?Tipp-([0-9]+).html">'
    sHtmlContent = __getHtmlContent(URL_GENRE_PAGE)
    aResult = cParser.parse(sHtmlContent, pattern)
    oGui = cGui()
    if aResult[0]:
        for aEntry in aResult[1]:
            iGenreId = aEntry[2]
            __createMenuEntry(oGui, 'ajaxCall', aEntry[1], {'page': 1, 'character': 'All', 'mediaType': 'movie', 'mediaTypePageId': iGenreId, 'sUrl': URL_MOVIE_PAGE})
    oGui.setEndOfDirectory()


def showCinemaMovies():
    logger.info('load displayCinemaSite')
    oGui = cGui()
    _cinema(oGui)
    oGui.setView('movies')
    oGui.setEndOfDirectory()


def _cinema(oGui):
    pattern = '<div class="Opt leftOpt Headlne"><a title="(.*?)" href="(.*?)">.*?src="(.*?)".*?class="Descriptor">(.*?)</div.*?/lng/([0-9]+).png".*?IMDb:</b> (.*?) /'
    parms = ParameterHandler()
    sHtmlContent = __getHtmlContent(URL_CINEMA_PAGE)
    aResult = cParser.parse(sHtmlContent, pattern)
    if not aResult[0]: return
    total = len(aResult[1])
    for aEntry in aResult[1]:
        sMovieTitle = aEntry[0]
        lang = __createLanguage(aEntry[4])
        rating = aEntry[5]
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setFunction('parseMovieEntrySite')
        oGuiElement.setLanguage(lang)
        oGuiElement.setTitle(sMovieTitle)
        oGuiElement.setDescription(aEntry[3])
        oGuiElement.setMediaType('movie')
        oGuiElement.setThumbnail(URL_MAIN + str(aEntry[2]))
        oGuiElement.addItemValue('rating', rating)
        parms.setParam('sUrl', URL_MAIN + str(aEntry[1]))
        oGui.addFolder(oGuiElement, parms, False, total)


def parseMovieEntrySite():
    parms = ParameterHandler()
    if parms.exist('sUrl'):
        sUrl = parms.getValue('sUrl')
        sHtmlContent = __getHtmlContent(sUrl)
        sMovieTitle = __createMovieTitle(sHtmlContent)
        result = cParser.parse(sHtmlContent, '<div class="Grahpics">.*?<img src="([^"]+)"')
        thumbnail = URL_MAIN + str(result[1][0]) if result[0] else False
        bIsSerie = __isSerie(sHtmlContent)
        if bIsSerie:
            oGui = cGui()
            aSeriesItems = parseSerieSite(sHtmlContent)
            if not aSeriesItems[0]: return
            total = len(aSeriesItems)
            for aEntry in aSeriesItems[1]:
                seasonNum = str(aEntry)
                guiElement = cGuiElement('%s - Staffel %s' % (sMovieTitle, seasonNum), SITE_IDENTIFIER, 'showEpisodes')
                guiElement.setMediaType('season')
                guiElement.setSeason(seasonNum)
                guiElement.setTVShowTitle(sMovieTitle)
                parms.setParam('Season', seasonNum)
                if thumbnail:
                    guiElement.setThumbnail(thumbnail)
                oGui.addFolder(guiElement, parms, total)
            oGui.setView('seasons')
            oGui.setEndOfDirectory()
        else:
            logger.info('Movie')
            result = showHosters()
            return result


def showEpisodes():
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    seasonNum = parms.getValue('Season')
    sHtmlContent = __getHtmlContent(sUrl)
    sMovieTitle = __createMovieTitle(sHtmlContent)
    result = cParser.parse(sHtmlContent, '<div class="Grahpics">.*?<img src="([^"]+)"')
    thumbnail = URL_MAIN + str(result[1][0]) if result[0] else False
    aSeriesItems = parseSerieEpisodes(sHtmlContent, seasonNum)
    if not aSeriesItems[0]: return
    for item in aSeriesItems:
        oGuiElement = cGuiElement(item['title'], SITE_IDENTIFIER, 'showHosters')
        sShowTitle = sMovieTitle.split('(')[0].split('*')[0]
        oGuiElement.setThumbnail(thumbnail)
        oGuiElement.setMediaType('episode')
        oGuiElement.setSeason(item['season'])
        oGuiElement.setEpisode(item['episode'])
        oGuiElement.setTVShowTitle(sShowTitle)
        parms.addParams({'sUrl': item['url'], 'episode': item['episode'], 'season': item['season']})
        oGui.addFolder(oGuiElement, parms, False, len(aSeriesItems))
    oGui.setView('episodes')
    oGui.setEndOfDirectory()


def __createMovieTitle(sHtmlContent):
    pattern = '<h1><span style="display: inline-block">(.*?)</h1>'
    aResult = cParser.parse(sHtmlContent, pattern)
    if aResult[0]:
        return str(aResult[1][0])
    return False


def parseSerieSite(sHtmlContent):
    pattern = '<option[^>]+value="(\d+)"[^>]+>Staffel.+?</option>'
    return cParser.parse(sHtmlContent, pattern)


def parseSerieEpisodes(sHtmlContent, seasonNum):
    aSeriesItems = []
    pattern = 'id="SeasonSelection" rel="([^"]+)"'
    aResult = cParser.parse(sHtmlContent, pattern)
    if aResult[0]:
        aSeriesUrls = aResult[1][0].split("&")
        sSeriesUrl = '&' + str(aSeriesUrls[0]) + '&' + str(aSeriesUrls[1])
    pattern = '<option.*?value="%d" rel="([^"]+)".*?>Staffel.*?</option>' % int(seasonNum)
    aResult = cParser.parse(sHtmlContent, pattern)
    logger.info(aResult[1])
    if aResult[0]:
        aSeriesIds = aResult[1][0].split(',')
        for iSeriesIds in aSeriesIds:
            aSeries = {}
            iEpisodeNum = iSeriesIds
            sTitel = 'Folge ' + str(iEpisodeNum)
            sUrl = URL_EPISODE_URL + sSeriesUrl + '&Season=' + str(seasonNum) + '&Episode=' + str(iEpisodeNum)
            aSeries['title'] = sTitel
            aSeries['url'] = sUrl
            aSeries['season'] = seasonNum
            aSeries['episode'] = iEpisodeNum
            aSeriesItems.append(aSeries)
    return aSeriesItems


def __isSerie(sHtmlContent):
    pattern = 'id="SeasonSelection" rel="([^"]+)"'
    aResult = cParser.parse(sHtmlContent, pattern)
    return aResult[0] == True


def ajaxCall():
    oGui = cGui()
    metaOn = oGui.isMetaOn
    parms = ParameterHandler()
    if parms.exist('page') and parms.exist('mediaType'):
        iPage = parms.getValue('page')
        sMediaType = parms.getValue('mediaType')
    iMediaTypePageId = False
    if parms.exist('mediaTypePageId'):
        iMediaTypePageId = parms.getValue('mediaTypePageId')
    sCharacter = 'A'
    if parms.exist('character'):
        sCharacter = parms.getValue('character')
    logger.info('MediaType: ' + sMediaType + ' , Page: ' + str(iPage) + ' , iMediaTypePageId: ' + str(
        iMediaTypePageId) + ' , sCharacter: ' + str(sCharacter))
    sHtmlContent = __getAjaxContent(sMediaType, iPage, iMediaTypePageId, metaOn, sCharacter)
    #log('DEBUG: %s ' % sHtmlContent, LOGNOTICE)
    if not sHtmlContent:
        return
    if metaOn and not sMediaType == 'documentation':
        aData = loads(sHtmlContent)['aaData']
        total = len(aData)

        for aEntry in aData:
            pattern = '<a href="([^"]+)".*?onclick="return false;">([^<]+)<.*?>([0-9]{4})<'
            aResult = cParser.parse(aEntry[2], pattern)
            if aResult[0]:
                sYear = str(aResult[1][0][2]).strip()
                sTitle = aResult[1][0][1]
                sLang = aEntry[0]
                sUrl = URL_MAIN + str(aResult[1][0][0])
                oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
                oGuiElement.setYear(sYear)
                oGuiElement.setLanguage(sLang)
                parms.setParam('sUrl', sUrl)
                if sMediaType == 'series':
                    oGuiElement.setMediaType('tvshow')
                    oGui.addFolder(oGuiElement, parms, total)
                else:
                    oGuiElement.setMediaType('movie')
                    oGui.addFolder(oGuiElement, parms, False, total)
        pattern = '"iTotalDisplayRecords":"([^"]+)'
        aResult = cParser.parse(sHtmlContent, pattern)
        if aResult[0]:
            for aEntry in aResult[1]:
                iTotalCount = int(aEntry[0])
                iNextPage = int(iPage) + 1
                iCurrentDisplayStart = __createDisplayStart(iNextPage)
                if iCurrentDisplayStart < iTotalCount:
                    parms = ParameterHandler()
                    parms.setParam('page', iNextPage)
                    parms.setParam('character', sCharacter)
                    parms.setParam('mediaType', sMediaType)
                if iMediaTypePageId:
                    parms.setParam('mediaTypePageId', iMediaTypePageId)
                oGui.addNextPage(SITE_IDENTIFIER, 'ajaxCall', parms)
    else:
        aData = loads(sHtmlContent)
        pattern = '<div class="Opt leftOpt Headlne"><a title="(.*?)" href="(.*?)">.*?src="(.*?)".*?class="Descriptor">(.*?)</div.*?lng/(.*?).png'
        aResult = cParser.parse(aData['Content'], pattern)
        if aResult[0]:
            total = len(aResult[1])
            for aEntry in aResult[1]:
                sMovieTitle, subLang = __checkSubLanguage(aEntry[0])
                lang = __createLanguage(aEntry[4])
                oGuiElement = cGuiElement(sMovieTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
                oGuiElement.setDescription(aEntry[3])
                oGuiElement.setThumbnail(URL_MAIN + str(aEntry[2]))
                oGuiElement.setLanguage(lang)
                oGuiElement.setSubLanguage(subLang)
                parms.setParam('sUrl', URL_MAIN + str(aEntry[1]))
                if sMediaType == 'series':
                    oGui.addFolder(oGuiElement, parms, total)
                else:
                    oGui.addFolder(oGuiElement, parms, False, total)
            iTotalCount = int(aData['Total'])
            iNextPage = int(iPage) + 1
            if __createDisplayStart(iNextPage) < iTotalCount:
                parms = ParameterHandler()
                parms.setParam('page', iNextPage)
                if iMediaTypePageId:
                    parms.setParam('mediaTypePageId', iMediaTypePageId)
                oGui.addNextPage(SITE_IDENTIFIER, 'ajaxCall', parms)
    if sMediaType == 'series':
        oGui.setView('tvshows')
    else:
        oGui.setView('movies')
    oGui.setEndOfDirectory()


def __createDisplayStart(iPage):
    return (30 * int(iPage)) - 30


def __getAjaxContent(sMediaType, iPage, iMediaTypePageId, metaOn, sCharacter=''):
    iDisplayStart = __createDisplayStart(iPage)
    sPrefLang = __getPreferredLanguage()
    oRequest = cRequestHandler(URL_AJAX)
    if not iMediaTypePageId:
        oRequest.addParameters('additional', '{"fType":"' + str(sMediaType) + '","Length":60,"fLetter":"' + str(sCharacter) + '"}')
    else:
        oRequest.addParameters('additional', '{"foo":"bar","' + str(
            sMediaType) + '":"' + iMediaTypePageId + '","fType":"movie","fLetter":"' + str(sCharacter) + '"}')
    oRequest.addParameters('iDisplayLength', '30')
    oRequest.addParameters('iDisplayStart', iDisplayStart)
    if metaOn and not sMediaType == 'documentation':
        oRequest.addParameters('bSortable_0', 'true')
        oRequest.addParameters('bSortable_1', 'true')
        oRequest.addParameters('bSortable_2', 'true')
        oRequest.addParameters('bSortable_3', 'false')
        oRequest.addParameters('bSortable_4', 'false')
        oRequest.addParameters('bSortable_5', 'false')
        oRequest.addParameters('bSortable_6', 'true')
        oRequest.addParameters('iColumns', '7')
        oRequest.addParameters('iSortCol_0', '2')
        oRequest.addParameters('iSortingCols', '1')
        oRequest.addParameters('sColumns', '')
        oRequest.addParameters('sEcho', iPage)
        oRequest.addParameters('sSortDir_0', 'asc')
        sUrl = oRequest.getRequestUri()
        oRequest = cRequestHandler(sUrl)
    else:
        oRequest.addParameters('ListMode', 'cover')
        oRequest.addParameters('Page', str(iPage))
        oRequest.addParameters('Per_Page', '30')
        oRequest.addParameters('per_page', '30')
        oRequest.addParameters('dir', 'desc')
        oRequest.addParameters('sort', 'title')
        sUrl = oRequest.getRequestUri()
        oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Cookie', sPrefLang + 'ListDisplayYears=Always;')
    #log('DEBUG: %s ' % oRequest.getRequestUri(), LOGNOTICE)
    return oRequest.request()


def showHosters():
    parms = ParameterHandler()
    if parms.exist('sUrl'):
        sUrl = parms.getValue('sUrl')
    sHtmlContent = __getHtmlContent(sUrl)
    pattern = 'class="MirBtn.*?rel="([^"]+)".*?class="Named">([^<]+)</div>(.*?)</div>'
    aResult = cParser.parse(sHtmlContent, pattern)
    hosters = []
    if aResult[0]:
        for aEntry in aResult[1]:
            sHoster = aEntry[1]
            if cConfig().isBlockedHoster(sHoster)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            pattern = '<b>Mirror</b>: [0-9]+/([0-9]+)'
            aResult = cParser.parse(aEntry[2], pattern)
            mirrors = 1
            if aResult[0]:
                mirrors = int(aResult[1][0])
            for i in range(1, mirrors + 1):
                sUrl = URL_MIRROR + cParser.unquotePlus(aEntry[0])
                mirrorName = ''
                if mirrors > 1:
                    mirrorName = ' Mirror ' + str(i)
                    sUrl = cParser.replace(r'Mirror=[0-9]+', 'Mirror=' + str(i), sUrl)
                hoster = {'name': sHoster, 'link': sUrl, 'displayedName': sHoster + mirrorName}
                hosters.append(hoster)
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0", "Accept": "*/*", "X-Requested-With": "XMLHttpRequest"}
    session = requests.Session()
    session.headers.update(headers)
    resp = session.get(sUrl, timeout=10)
    data = resp.text
    js = json.loads(data)
    match = re.search(r'src="([^"]+)', js.get("Stream"))
    if match:
        url2 = "https://www22.kinox.to" + match.group(1)
        resp = session.get(url2, timeout=10)
        html = resp.text
        if "ust reload" in html:
            resp = session.get(url2, timeout=10)
            html = resp.text
        time.sleep(2)
        von = re.search(r"von (\d)", html)
        if von:
            von = von.group(1)
            for _ in range(int(von)):
                time.sleep(2)
                action_match = re.search(r'<form[^>]*action="([^"]+)"', html).group(1)
                resp = session.post("https://www22.kinox.to" + action_match, data=cap(html), timeout=10, allow_redirects=False)
                htm = resp.text
                if resp.headers.get('Location'):
                    return [{'streamUrl': resp.headers.get('Location'), 'resolved': False}]
                html = htm


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    sHtmlContent = __getHtmlContent(URL_SEARCH % cParser.quotePlus(sSearchText), ignoreErrors=(oGui is not False))
    __displayItems(oGui, sHtmlContent)
