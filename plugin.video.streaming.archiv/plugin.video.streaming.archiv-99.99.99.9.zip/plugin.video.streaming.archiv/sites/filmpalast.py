# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# Sprachauswahl für Filme
# HTML LangzeitCache hinzugefügt
# showValue:     24 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden

import re

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui


SITE_IDENTIFIER = 'filmpalast'
SITE_NAME = 'FilmPalast'
SITE_ICON = 'filmpalast.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'filmpalast.to') # Domain Auswahl über die Streaming Archiv Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'https://filmpalast.to'
URL_MOVIES = URL_MAIN + '/movies/%s'
URL_SERIES = URL_MAIN + '/serien/view'
URL_ENGLISH = URL_MAIN + '/search/genre/Englisch'
URL_SEARCH = URL_MAIN + '/search/title/%s'
PAGE_SIZE = 100


def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # New
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMovieMenu'), params)    # Movies
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeriesMenu'), params)  # Series
    cGui().setEndOfDirectory()


def _clean_detail_text(sValue):
    if not sValue:
        return ''
    sValue = re.sub('<[^>]+>', '', sValue)
    return sValue.replace('&nbsp;', ' ').replace('&#8211;', '-').strip()


def _next_page_url(sHtmlContent):
    pattern = '<a class="pageing[^"]*"\s*href=([^>]+)>[^\+]+\+</a>\s*</div>'
    isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, pattern)
    if not isMatchNextPage:
        return ''
    sNextUrl = sNextUrl.replace("'", "").replace('"', '')
    if sNextUrl.startswith('/'):
        sNextUrl = URL_MAIN + sNextUrl
    return sNextUrl


def _collect_entry_pages(entryUrl, limit=PAGE_SIZE, ignoreErrors=False):
    results = []
    next_url = entryUrl
    seen = set()
    while next_url and len(results) < limit and next_url not in seen:
        seen.add(next_url)
        oRequest = cRequestHandler(next_url, ignoreErrors=ignoreErrors, bypass_dns=True)
        if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
            oRequest.cacheTime = 60 * 60 * 6
        sHtmlContent = oRequest.request()
        page_results = _parse_articles(sHtmlContent)
        if not page_results:
            break
        results.extend(page_results)
        next_url = _next_page_url(sHtmlContent)
    return results, next_url


def _extract_entry_meta(snippet):
    meta = {}
    cleaned = _clean_detail_text(snippet)
    if not cleaned:
        return meta
    year_match = re.search(r'Jahr:\s*(\d{4})', cleaned, re.IGNORECASE)
    duration_match = re.search(r'(?:Laufzeit|Spielzeit):\s*(\d+)', cleaned, re.IGNORECASE)
    rating_match = re.search(r'Imdb:\s*([\d,.]+)', cleaned, re.IGNORECASE)

    if year_match:
        meta['year'] = year_match.group(1)
    if duration_match:
        meta['duration'] = duration_match.group(1)
    if rating_match:
        meta['rating'] = rating_match.group(1).replace(',', '.').strip()

    cleaned = re.sub(r'\b(?:Jahr|Laufzeit|Spielzeit|Imdb):\s*[^|/]+', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\b\d+\s*Stimmen\b', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\bstream\s+', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s{2,}', ' ', cleaned)
    cleaned = cleaned.strip(' |-/')
    if cleaned and len(cleaned) > 20:
        meta['plot'] = cleaned
    return meta


def _matches_search(search_text, title):
    if not search_text:
        return True
    search_text = _clean_detail_text(search_text).lower()
    title = _clean_detail_text(title).lower()
    if not search_text:
        return True
    return search_text in title


def _parse_articles(html):
    articles = re.findall(r'(?s)<article[^>]*>(.*?)</article>', html)
    entries = []
    for article in articles:
        link_match = re.search(r'<a href="([^"]+)"[^>]*title="([^"]+)"', article, re.IGNORECASE)
        if not link_match:
            continue
        sUrl = link_match.group(1)
        sName = _clean_detail_text(link_match.group(2))
        if not sName:
            continue

        thumb_match = re.search(r'<img[^>]*src=["\']([^"\']*/files/[^"\']+)["\']', article, re.IGNORECASE)
        if not thumb_match:
            thumb_match = re.search(r'<img[^>]*class=["\'][^"\']*cover[^"\']*["\'][^>]*src=["\']([^"\']+)["\']', article, re.IGNORECASE)
        if not thumb_match:
            thumb_match = re.search(r'<img[^>]*src=["\']([^"\']+\.(?:jpg|jpeg|png|webp)[^"\']*)["\']', article, re.IGNORECASE)
        sThumbnail = thumb_match.group(1) if thumb_match else ''
        entries.append((sUrl, sName, sThumbnail, article))
    return entries


def _get_entry_fallback_meta(entryUrl):
    if not entryUrl:
        return {}
    if entryUrl.startswith('//'):
        detailUrl = 'https:' + entryUrl
    elif entryUrl.startswith('/'):
        detailUrl = URL_MAIN + entryUrl
    else:
        detailUrl = entryUrl
    oRequest = cRequestHandler(detailUrl, ignoreErrors=True, bypass_dns=True)
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return {}
    meta = {}
    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<meta[^>]+name="description"[^>]+content="([^"]+)')
    if not isDesc:
        isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '"description">([^<]+)')
    if isDesc:
        meta['plot'] = _clean_detail_text(sDesc)
    isYear, sYear = cParser.parseSingleResult(sHtmlContent, 'Jahr:[^>]([\d]+)')
    if isYear:
        meta['year'] = sYear
    isDuration, sDuration = cParser.parseSingleResult(sHtmlContent, '(?:Laufzeit|Spielzeit):[^>]([\d]+)')
    if isDuration:
        meta['duration'] = sDuration
    isRating, sRating = cParser.parseSingleResult(sHtmlContent, 'Imdb:[^>]([^/]+)')
    if isRating:
        meta['rating'] = sRating.replace(',', '.').strip()
    isThumbnail, sThumbnail = cParser.parseSingleResult(sHtmlContent, '<meta[^>]+property="og:image"[^>]+content="([^"]+)')
    if isThumbnail:
        meta['thumbnail'] = sThumbnail
    return meta


def showMovieMenu(): # Menu structure of movie menu
    params = ParameterHandler()
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '0' or '1':    # Alle Sprachen oder Deutsch
        params.setParam('sUrl', URL_MOVIES % 'new')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)   # New
        params.setParam('sUrl', URL_MOVIES % 'top')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30509), SITE_IDENTIFIER, 'showEntries'), params)  # Top movies
        params.setParam('sUrl', URL_MOVIES % 'imdb')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30510), SITE_IDENTIFIER, 'showEntries'), params) # IMDB rating
        if sLanguage == '0': # Nur bei Alle Sprachen
            params.setParam('sUrl', URL_ENGLISH)
            cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30104), SITE_IDENTIFIER, 'showEntries'), params) # English
        params.setParam('sUrl', URL_MOVIES % 'new')
        params.setParam('value', 'genre')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)    # Genre
        params.setParam('value', 'movietitle')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showValue'), params)  # From A-Z
        cGui().setEndOfDirectory()
    if sLanguage == '2':    # English
        params.setParam('sUrl', URL_ENGLISH)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30104), SITE_IDENTIFIER, 'showEntries'), params) # English
        cGui().setEndOfDirectory()
    elif sLanguage == '3':    # Japanisch
        cGui().showLanguage()
        cGui().setEndOfDirectory()


def showSeriesMenu():   # Menu structure of series menu
    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)  # Series
    params.setParam('value', 'movietitle')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showValue'), params)  # From A-Z
    cGui().setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    value = params.getValue("value")
    oRequest = cRequestHandler(params.getValue('sUrl'), bypass_dns=True)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    pattern = '<section[^>]id="%s">(.*?)</section>' % value # Suche in der Section Einträge
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sContainer, 'href="([^"]+)">([^<]+)')
        for sUrl, sName in aResult:
            params.setParam('sUrl', sUrl)
            cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if not sGui and not sSearchText:
        aResult, sNextUrl = _collect_entry_pages(entryUrl, PAGE_SIZE, ignoreErrors=False)
    else:
        oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False), bypass_dns=True)
        if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
            oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
        sHtmlContent = oRequest.request()
        aResult = _parse_articles(sHtmlContent)
        sNextUrl = _next_page_url(sHtmlContent)
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    entries = []
    isSearchPage = '/search/title/' in entryUrl
    for sUrl, sName, sThumbnail, sDummy in aResult:
        if not _matches_search(sSearchText, sName):
            continue
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail
        isTvshow = bool(re.search(r'S\d\dE\d\d', sName))
        entryMeta = _extract_entry_meta(sDummy)
        fallbackMeta = {}
        if isSearchPage and (not entryMeta.get('year') or not entryMeta.get('rating') or not entryMeta.get('plot')):
            fallbackMeta = _get_entry_fallback_meta(sUrl)
        entries.append((sUrl, sName, sThumbnail, entryMeta, fallbackMeta, isTvshow))

    if not entries:
        if not sGui: oGui.showInfo()
        return

    total = len(entries)
    lastIsTvshow = False
    for sUrl, sName, sThumbnail, entryMeta, fallbackMeta, isTvshow in entries:
        lastIsTvshow = isTvshow
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(fallbackMeta.get('thumbnail', sThumbnail))
        if entryMeta.get('year'):
            oGuiElement.setYear(entryMeta.get('year'))
        elif fallbackMeta.get('year'):
            oGuiElement.setYear(fallbackMeta.get('year'))
        if entryMeta.get('duration'):
            oGuiElement.addItemValue('duration', entryMeta.get('duration'))
        elif fallbackMeta.get('duration'):
            oGuiElement.addItemValue('duration', fallbackMeta.get('duration'))
        if entryMeta.get('rating'):
            oGuiElement.addItemValue('rating', entryMeta.get('rating'))
        elif fallbackMeta.get('rating'):
            oGuiElement.addItemValue('rating', fallbackMeta.get('rating'))
        if entryMeta.get('plot'):
            oGuiElement.setDescription(entryMeta.get('plot'))
        elif fallbackMeta.get('plot'):
            oGuiElement.setDescription(fallbackMeta.get('plot'))
        # Parameter übergeben
        if sUrl.startswith('//'):
            params.setParam('entryUrl', 'https:' + sUrl)
        else:
            params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui and not sSearchText:
        if sNextUrl:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if lastIsTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    # Parameter laden
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue("sThumbnail")
    sName = params.getValue('sName')
    oRequest = cRequestHandler(sUrl, bypass_dns=True)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*class="staffTab"[^>]*data-sid="(\d+)"[^>]*>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return
    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '"description">([^<]+)')
    total = len(aResult)
    for sSeason in aResult:
        oGuiElement = cGuiElement('Staffel ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setTVShowTitle(sName)
        oGuiElement.setSeason(sSeason)
        oGuiElement.setMediaType('season')
        oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    # Parameter laden
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue("sThumbnail")
    sSeason = params.getValue('season')
    sShowName = params.getValue('TVShowTitle')
    oRequest = cRequestHandler(sUrl, bypass_dns=True)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="staffelWrapperLoop[^"]*"[^>]*data-sid="%s">(.*?)</ul></div>' % sSeason
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    pattern = 'href="([^"]+)'
    isMatch, aResult = cParser.parse(sContainer, pattern)
    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '"description">([^<]+)')
    total = len(aResult)
    for sUrl in aResult:
        isMatch, sName = cParser.parseSingleResult(sUrl, 'e(\d+)')
        oGuiElement = cGuiElement('Episode ' + str(sName), SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setTVShowTitle(sShowName)
        oGuiElement.setSeason(sSeason)
        oGuiElement.setEpisode(sName)
        oGuiElement.setMediaType('episode')
        if sUrl.startswith('//'):
            params.setParam('entryUrl', 'https:' + sUrl)
        else:
            params.setParam('entryUrl', sUrl)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _stream_page_state(sUrl):
    """Return whether a hoster page still looks usable without resolving it fully."""
    try:
        check = cRequestHandler(sUrl, caching=False, ignoreErrors=True, bypass_dns=True)
        check.requestTimeout = 5
        content = check.request() or ''
        status = str(check.getStatus() or '')
        text = content.lower()
        dead_markers = (
            'video has been removed',
            'file was deleted',
            'file not found',
            'video not found',
            'not found',
            'removed due to',
            'seite nicht erreichbar',
            'this video has been removed',
        )
        if status in ('404', '410'):
            return 'dead', status
        if any(marker in text for marker in dead_markers):
            return 'dead', 'removed'
        if 'window.location.replace' in text or 'window.location.href' in text or 'const currenturl' in text:
            return 'ok', 'redirect'
        if status.startswith('2') and len(content) > 2000:
            return 'ok', status
        if status in ('403', '429'):
            return 'blocked', status
        if content:
            return 'unknown', status or 'content'
        return 'dead', status or 'empty'
    except Exception as e:
        return 'error', str(e)


def _extract_media_id(sUrl):
    match = re.search(r'/(?:e|v)/([0-9A-Za-z]+)', sUrl or '')
    if match:
        return match.group(1)
    match = re.search(r'/([0-9A-Za-z]{8,})/?(?:\?|$)', sUrl or '')
    if match:
        return match.group(1)
    return ''


def _repair_stream_hoster(sName, sUrl):
    """Try known move/alias domains first. Return fixed URL, original URL, or None to skip."""
    hoster = (sName or '').lower()
    url = (sUrl or '').lower()
    if not any(x in hoster or x in url for x in ('voe', 'vidara', 'vidmatrix', 'streamix', 'stmix')):
        return sUrl

    media_id = _extract_media_id(sUrl)
    if not media_id:
        return sUrl

    candidates = [sUrl]
    if 'voe' in hoster or 'voe' in url:
        # VOE zieht öfter auf neue Unblock-Domains um. Erst Alternativen prüfen, nicht stumpf sperren.
        for host in ('voeunblock2.com', 'voe-unblock.net', 'v-o-e-unblock.com', 'voe-unblock.com', 'voeunblk.com'):
            candidates.append('https://%s/e/%s' % (host, media_id))
    elif any(x in hoster or x in url for x in ('vidara', 'vidmatrix', 'streamix', 'stmix')):
        # Vidara/Streamix/VidMatrix teilen sich teils dieselben Filecodes, aber melden entfernte Videos sauber.
        for host in ('vidara.to', 'vidara.so', 'vidmatrixa.com', 'streamix.so', 'stmix.io'):
            candidates.append('https://%s/e/%s' % (host, media_id))
            candidates.append('https://%s/v/%s' % (host, media_id))

    seen = set()
    checked = []
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        state, reason = _stream_page_state(candidate)
        checked.append('%s=%s' % (candidate, reason))
        if state == 'ok':
            if candidate != sUrl:
                logger.info('-> [filmpalast]: repaired hoster %s: %s -> %s' % (sName, sUrl, candidate))
            return candidate
        if state in ('blocked', 'unknown') and candidate == sUrl:
            # Nicht vorschnell rauswerfen: ResolveURL kann blockierte Seiten teils noch selbst behandeln.
            logger.info('-> [filmpalast]: keep unchecked hoster %s (%s): %s' % (sName, sUrl, reason))
            return sUrl

    logger.info('-> [filmpalast]: skip hoster after alternative check %s (%s): %s' % (sName, sUrl, ' | '.join(checked[:6])))
    return None


def showHosters():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    if '-english' in sUrl: sLang = '(EN)'
    else: sLang = ''
    sHtmlContent = cRequestHandler(sUrl, caching=False, bypass_dns=True).request()
    pattern = 'hostName">([^<]+).*?(http[^"]+)' # Hoster Link
    releaseQuality = 'class="rb">.*?(\d\d\d+)p\.' # Release Qualität
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    isQuality, sQuality = cParser.parseSingleResult(sHtmlContent, releaseQuality)  # sReleaseQuality auslesen z.B. 1080
    if not isQuality: sQuality = '720'
    hosters = []
    if isMatch:
        for sName, sUrl in aResult:
            sName = sName.split(' HD')[0].strip()
            sUrl = _repair_stream_hoster(sName, sUrl)
            if not sUrl:
                continue
            if 'Filemoon' in sName or 'Swiftload' in sName or 'Vidhide' in sName:
                sUrl = sUrl + '$$https://filmpalast.to/' # Referer hinzugefügt
                if cConfig().isBlockedHoster(sName)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'languageCode': sLang, 'quality': sQuality}  # Qualität Anzeige aus Release Eintrag
                hosters.append(hoster)
            else:
                if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'languageCode': sLang, 'quality': sQuality} # Qualität Anzeige aus Release Eintrag
                hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters

def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)
