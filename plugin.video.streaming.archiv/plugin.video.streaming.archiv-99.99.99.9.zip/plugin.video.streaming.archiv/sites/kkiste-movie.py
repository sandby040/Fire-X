# -*- coding: utf-8 -*-
# Python 3

from json import loads
import re

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser, cUtil
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'kkiste-movie'
SITE_NAME = 'KKiste-movie'
SITE_ICON = 'kkiste-movie.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'kkiste.club')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_API = 'https://' + DOMAIN.rstrip('/')
REFERER = URL_API + '/'

URL_BROWSE = URL_API + '/data/browse/?lang=%s&keyword=%s&year=&genre=%s&country=&cast=&directors=&type=movies&order_by=%s&page=%s&limit=24'
URL_SEARCH = URL_API + '/data/search/?lang=%s&keyword=%s'
URL_THUMBNAIL = 'https://image.tmdb.org/t/p/w300%s'
URL_WATCH = URL_API + '/data/watch/?_id=%s'

GENRES = {
    'Abenteuer': 'Abenteuer',
    'Action': 'Action',
    'Animation': 'Animation',
    'Biographie': 'Biographie',
    'Dokumentation': 'Dokumentation',
    'Drama': 'Drama',
    'Familie': 'Familie',
    'Fantasy': 'Fantasy',
    'Geschichte': 'Geschichte',
    'Horror': 'Horror',
    'Komödie': 'Komödie',
    'Krieg': 'Krieg',
    'Krimi': 'Krimi',
    'Musik': 'Musik',
    'Mystery': 'Mystery',
    'Romantik': 'Romantik',
    'Sci-Fi': 'Sci-Fi',
    'Sport': 'Sport',
    'Thriller': 'Thriller',
    'Western': 'Western'
}


def _language():
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '0':
        return 'all'
    if sLanguage == '1':
        return '2'
    if sLanguage == '2':
        return '3'
    cGui().showLanguage()
    return False


def _browse_url(lang, order_by='releases', page='1', genre='', keyword=''):
    return URL_BROWSE % (
        lang,
        cParser.quotePlus(keyword),
        cParser.quotePlus(genre),
        order_by,
        page
    )


def _request_json(url, cache_time=0, ignore_errors=False):
    oRequest = cRequestHandler(url, ignoreErrors=ignore_errors)
    if cache_time:
        oRequest.cacheTime = cache_time
    oRequest.addHeaderEntry('Referer', REFERER)
    return loads(oRequest.request())


def _items_from_json(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get('movies', [])
    return []


def _get_quality(value):
    isMatch, aResult = cParser.parse(str(value), '(HDCAM|HD|WEB|BLUERAY|BRRIP|DVD|TS|SD|CAM)', 1, True)
    if isMatch:
        return aResult[0]
    return str(value)


def _thumbnail(movie):
    for key in ('poster_path', 'backdrop_path'):
        if movie.get(key):
            return URL_THUMBNAIL % str(movie[key])
    return URL_API + '/data/getimg/?_id=' + str(movie.get('_id'))


def _add_movie(oGui, movie, params, total, search_text=False):
    if '_id' not in movie or movie.get('tv'):
        return
    sTitle = str(movie.get('title', ''))
    if search_text and not cParser.search(search_text, sTitle) and not cUtil.isSimilarByToken(search_text.lower(), sTitle.lower()):
        return

    sThumbnail = _thumbnail(movie)
    oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'showHosters')
    oGuiElement.setThumbnail(sThumbnail)
    if movie.get('storyline'):
        oGuiElement.setDescription(str(movie['storyline']))
    elif movie.get('overview'):
        oGuiElement.setDescription(str(movie['overview']))
    if movie.get('year') and len(str(movie['year'])) == 4:
        oGuiElement.setYear(movie['year'])
    if movie.get('quality'):
        oGuiElement.setQuality(_get_quality(movie['quality']))
    if movie.get('rating'):
        oGuiElement.addItemValue('rating', movie['rating'])
    if movie.get('runtime'):
        isMatch, sRuntime = cParser.parseSingleResult(str(movie['runtime']), r'\d+')
        if isMatch:
            oGuiElement.addItemValue('duration', sRuntime)
    if movie.get('lang') == 2:
        oGuiElement.setLanguage('DE')
    elif movie.get('lang') == 3:
        oGuiElement.setLanguage('EN')
    oGuiElement.setMediaType('movie')

    params.setParam('entryUrl', URL_WATCH % str(movie['_id']))
    params.setParam('sThumbnail', sThumbnail)
    params.setParam('sName', sTitle)
    oGui.addFolder(oGuiElement, params, False, total)


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    lang = _language()
    if not lang:
        return
    params.setParam('sLanguage', lang)

    params.setParam('sUrl', _browse_url(lang, 'releases'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    params.setParam('sUrl', _browse_url(lang, 'featured'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', _browse_url(lang, 'trending'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', _browse_url(lang, 'views'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30537), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenre'), params)
    cGui().setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    lang = params.getValue('sLanguage') or _language()
    for genre_name in sorted(GENRES.keys()):
        params.setParam('sUrl', _browse_url(lang, 'views', genre=GENRES[genre_name]))
        cGui().addFolder(cGuiElement(genre_name, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')

    try:
        data = _request_json(entryUrl, 60 * 60 * 6, ignore_errors=(sGui is not False))
    except Exception:
        if not sGui:
            oGui.showInfo()
        return

    movies = _items_from_json(data)
    if not movies:
        if not sGui:
            oGui.showInfo()
        return

    total = len([movie for movie in movies if '_id' in movie and not movie.get('tv')])
    for movie in movies:
        _add_movie(oGui, movie, params, total, sSearchText)

    if not sGui and not sSearchText and isinstance(data, dict) and data.get('pager'):
        curPage = data['pager'].get('currentPage', 1)
        totalPages = data['pager'].get('totalPages', 1)
        if curPage < totalPages:
            sNextUrl = re.sub(r'page=\d+', 'page=' + str(curPage + 1), entryUrl)
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('entryUrl')
    try:
        data = _request_json(sUrl)
    except Exception:
        return hosters

    for i, stream in enumerate(data.get('streams', [])):
        if not stream.get('stream'):
            continue
        sHoster = str(i) + ':'
        isMatch, aName = cParser.parse(stream['stream'], '//([^/]+)/')
        if isMatch and '.' in aName[0]:
            sName = aName[0][:aName[0].rindex('.')]
            if cConfig().isBlockedHoster(sName)[0]:
                continue
            sHoster += ' ' + sName
        if stream.get('release'):
            sHoster += ' [I][' + _get_quality(stream['release']) + '][/I]'
        hosters.append({'link': stream['stream'], 'name': sHoster})
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    lang = _language()
    if not lang:
        return
    showEntries(URL_SEARCH % (lang, cParser.quotePlus(sSearchText)), oGui, sSearchText)
