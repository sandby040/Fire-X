# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# Language selection for hosters included.
# Ajax search function included.
# HTML long-term cache added
# showValue:     24 hours
# showAllSeries: 24 hours
# showEpisodes:   4 hours
# SSsearch:      24 hours
    
# 2022-12-06 Heptamer - Search function reworked
# 2026-12-29 viewIT   - Hotfix for V2 of SerienStream
# 2026-02-02 SatBandit - Hotfix for V2 of SerienStream
import xbmcgui
import string  # MERGED: Required for A-Z loop
import re
import json
import sys

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser, cUtil
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from urllib.parse import quote_plus, urljoin, urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener
from urllib.error import HTTPError
from html import unescape

SITE_IDENTIFIER = 'serienstream'
SITE_NAME = 'SerienStream'
SITE_ICON = 'serienstream.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain query
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain') # Domain selection via addon settings
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Domain status code query
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Whether plugin is active or not

# URL_MAIN = 'https://s.to/'
# DNS bypass is handled centrally by resources.lib.handler.requestHandler.
# Keep SerienStream on its real hostname so request-safe Host/SNI handling can
# resolve the current IP dynamically instead of pinning the provider to an old
# hard-coded IP/proxy path.
if not DOMAIN or DOMAIN == '186.2.175.5':
    DOMAIN = 'serienstream.to'
URL_MAIN = 'https://' + DOMAIN
REFERER = 'https://' + DOMAIN
proxy = 'false'
URL_SERIES = URL_MAIN + '/serien'
URL_NEW_SERIES = URL_MAIN + '/neu'
URL_NEW_EPISODES = URL_MAIN + '/neue-episoden'
URL_POPULAR = URL_MAIN + '/beliebte-serien'
URL_LOGIN = URL_MAIN + '/login'
URL_SEARCH = URL_MAIN + '/suche?term='
SERIES_PAGE_SIZE = 100
TMDB_API_KEY = '86dd18b04874d9c94afadde7993d94e3'
TMDB_POSTER = 'https://image.tmdb.org/t/p/w342%s'
URL_TMDB_POPULAR_SERIES = (
    'https://api.themoviedb.org/3/discover/tv'
    '?api_key=%s&language=de-DE&sort_by=popularity.desc&vote_count.gte=100'
    '&include_adult=false&without_genres=10763,10764,10767,10766,10762,99&page=%s'
)

# DNS bypass is handled centrally by resources.lib.handler.requestHandler.
# Do not hard-write an IP as provider domain here; that bypasses the
# request-safe Host/SNI handling and can leave the add-on pinned to stale IPs.



# --- Compatibility helpers (older xStream cores) ---
def _show_keyboard(heading_text):
    """Call cGui().showKeyBoard with backward compatibility."""
    try:
        return cGui().showKeyBoard(sHeading=heading_text)
    except TypeError:
        # older cores don't support keyword args
        try:
            return cGui().showKeyBoard(heading_text)
        except Exception:
            return cGui().showKeyBoard()


# --- Helpers / runtime checks ---
def _is_login_page(html):
    if not html:
        return False
    # Typical markers for s.to login page
    return ('/login' in html and ('name="password"' in html or 'passwort' in html.lower() or 'type="password"' in html))

def _notify_login_required():
    try:
        xbmcgui.Dialog().ok(SITE_NAME, 'Für diesen Inhalt ist ein (kostenloses) Benutzerkonto erforderlich.\nBitte Zugangsdaten in den Addon-Einstellungen eintragen.')
    except Exception:
        pass
# --- /Guest mode helpers ---

def _normalize_thumbnail(sThumbnail):
    if not sThumbnail:
        return ''
    sThumbnail = str(sThumbnail).strip()
    if sThumbnail.startswith('//'):
        sThumbnail = 'https:' + sThumbnail
    elif sThumbnail.startswith('/'):
        sThumbnail = URL_MAIN + sThumbnail
    if 'data:image' in sThumbnail:
        return ''
    return sThumbnail.replace('format=webp', 'format=jpg').replace('format=avif', 'format=jpg')


def _create_series_gui_element(sTitle, sThumbnail='', sDescription=''):
    oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'showSeasons')
    oGuiElement.setMediaType('tvshow')
    oGuiElement.setTVShowTitle(sTitle)
    oGuiElement.setForceMeta(True)
    oGuiElement.setMetaAdvanced(False)
    sThumbnail = _normalize_thumbnail(sThumbnail)
    if sThumbnail:
        oGuiElement.setThumbnail(sThumbnail)
    if sDescription:
        oGuiElement.setDescription(sDescription)
    return oGuiElement


def _clean_section_title(sTitle):
    sTitle = unescape(re.sub(r'<[^>]*>', '', sTitle or ''))
    return re.sub(r'\s+', ' ', sTitle).strip()


def _format_genre_display(sName):
    sDisplay = (sName or '').replace('filter.genre_', '').replace('_', ' ').replace('-', ' ').strip()
    if not sDisplay:
        return sName
    return ' '.join(part.capitalize() for part in sDisplay.split())


def _format_slug_display(sSlug):
    sDisplay = (sSlug or '').replace('-', ' ').replace('_', ' ').strip()
    if not sDisplay:
        return sSlug
    aliases = {
        'dokusoap': 'Doku-Soap',
        'k drama': 'K-Drama',
        'science fiction': 'Science Fiction',
        'true crime': 'True Crime',
    }
    key = sDisplay.lower()
    if key in aliases:
        return aliases[key]
    return ' '.join(part.capitalize() for part in sDisplay.split())


def _series_match_key(sName):
    sName = unescape(str(sName or '')).lower()
    sName = re.sub(r'\([^)]*\)', ' ', sName)
    sName = re.sub(r'&amp;', '&', sName)
    sName = re.sub(r'[^a-z0-9äöüß]+', '', sName)
    return sName


def _parse_search_cards(sHtmlContent):
    sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent or '')
    pattern = r'class="card cover-card.*?href="(/serie/[^"]+)".*?(?:data-src|src)="([^"]+)".*?alt="([^"]+)"'
    results = []
    seen = set()
    for sLink, sThumbnail, sTitle in re.findall(pattern, sHtmlContent):
        if sLink in seen or 'data:image/gif' in sThumbnail:
            continue
        seen.add(sLink)
        sTitle = unescape(sTitle).strip()
        results.append({
            'url': URL_MAIN + sLink if sLink.startswith('/') else sLink,
            'title': sTitle,
            'thumb': _normalize_thumbnail(sThumbnail),
        })
    return results


def _find_seriesstream_series(sTitle, sOriginalTitle=''):
    search_terms = []
    for term in (sTitle, sOriginalTitle):
        term = unescape(str(term or '')).strip()
        if term and term not in search_terms:
            search_terms.append(term)

    for term in search_terms:
        sUrl = '%s/suche?term=%s&tab=shows&page=1' % (URL_MAIN, quote_plus(term))
        sHtmlContent = cRequestHandler(sUrl, caching=False, ignoreErrors=True).request()
        if _is_login_page(sHtmlContent):
            _notify_login_required()
            return None
        candidates = _parse_search_cards(sHtmlContent)
        if not candidates:
            continue

        wanted = _series_match_key(term)
        for item in candidates:
            if _series_match_key(item.get('title')) == wanted:
                return item
        for item in candidates:
            key = _series_match_key(item.get('title'))
            if wanted and (wanted in key or key in wanted):
                return item
        return candidates[0]
    return None


def _parse_popular_sections(sHtmlContent):
    sections = []
    sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent or '')
    seen_titles = set()
    pattern = r'<h3[^>]*class="[^"]*h5[^"]*"[^>]*>(.*?)</h3>(.*?)(?=<h3[^>]*class="[^"]*h5[^"]*"|$)'
    for sRawTitle, sBlock in re.findall(pattern, sHtmlContent):
        sTitle = _clean_section_title(sRawTitle)
        if not sTitle or sTitle.lower() in ('entdecken', 'kategorien'):
            continue
        if sTitle in seen_titles:
            continue
        sGenreUrl = ''
        mGenre = re.search(r'href="(/genre/[^"]+)"', sBlock)
        if mGenre:
            sGenreUrl = URL_MAIN + mGenre.group(1)
        seen_titles.add(sTitle)
        sections.append({'title': sTitle, 'genre_url': sGenreUrl})
    return sections


def _extract_section_fragment(sHtmlContent, sTargetTitle):
    sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent or '')
    if sTargetTitle == 'Angesagt':
        pattern = r'<h2[^>]*>[^<]*' + re.escape(sTargetTitle) + r'[^<]*</h2>(.*?</section>)'
        match = re.search(pattern, sHtmlContent, re.DOTALL)
        return match.group(1) if match else ''

    if sTargetTitle == 'Meistgesehen gerade':
        pattern = r'<h2[^>]*>[^<]*' + re.escape(sTargetTitle) + r'[^<]*</h2>(.*?)(?=<div class="mb-5">|<section id=|$)'
        match = re.search(pattern, sHtmlContent, re.DOTALL)
        return match.group(1) if match else ''

    pattern = r'<(?:h4|h5)[^>]*>\s*' + re.escape(sTargetTitle) + r'\s*</(?:h4|h5)>(.*?<ul[^>]*class="[^"]*discover-list[^"]*"[^>]*>.*?</ul>)'
    match = re.search(pattern, sHtmlContent, re.DOTALL)
    if match:
        return match.group(1)

    pattern = r'<(?:h2|h3|h4|h5)[^>]*>\s*' + re.escape(sTargetTitle) + r'\s*</(?:h2|h3|h4|h5)>(.*?)(?=<(?:h2|h3|h4|h5)\b|$)'
    match = re.search(pattern, sHtmlContent, re.DOTALL)
    return match.group(1) if match else ''


def _parse_discover_items(sFragment):
    items = []
    seen_links = set()
    blocks = re.findall(r'<li[^>]*class="[^"]*d-flex[^"]*"[^>]*>(.*?)</li>', sFragment or '', re.DOTALL)

    for block in blocks:
        link_match = re.search(r'href="(/serie/[^"]+)"', block)
        if not link_match:
            continue
        sLink = link_match.group(1).split('/staffel-')[0]
        if sLink in seen_links:
            continue

        thumb_match = re.search(r'(?:data-src|src)="([^"]+)"', block)
        title_candidates = re.findall(r'<a[^>]*href="/serie/[^"]+"[^>]*>(.*?)</a>', block, re.DOTALL)

        sTitle = ''
        for candidate in title_candidates:
            candidate = _clean_section_title(candidate)
            if candidate:
                sTitle = candidate
                break

        if not sTitle:
            continue

        seen_links.add(sLink)
        items.append({
            'url': URL_MAIN + sLink,
            'title': sTitle,
            'thumb': _normalize_thumbnail(thumb_match.group(1)) if thumb_match else ''
        })

    return items


def _parse_trend_items(sFragment):
    items = []
    seen_links = set()
    blocks = re.findall(r'<article[^>]*class="[^"]*trend-card[^"]*"[^>]*>(.*?)</article>', sFragment or '', re.DOTALL)

    for block in blocks:
        link_match = re.search(r'<h3[^>]*class="[^"]*trend-title[^"]*"[^>]*>\s*<a[^>]*href="(/serie/[^"]+)"', block, re.DOTALL)
        if not link_match:
            link_match = re.search(r'href="(/serie/[^"]+)"', block)
        if not link_match:
            continue

        sLink = link_match.group(1).split('/staffel-')[0]
        if sLink in seen_links:
            continue

        title_match = re.search(r'<h3[^>]*class="[^"]*trend-title[^"]*"[^>]*>\s*<a[^>]*>(.*?)</a>', block, re.DOTALL)
        if not title_match:
            continue

        thumb_match = re.search(r'(?:data-src|src)="([^"]+)"', block)
        sTitle = _clean_section_title(title_match.group(1))
        if not sTitle:
            continue

        seen_links.add(sLink)
        items.append({
            'url': URL_MAIN + sLink,
            'title': sTitle,
            'thumb': _normalize_thumbnail(thumb_match.group(1)) if thumb_match else ''
        })

    return items


def _add_series_items(oGui, items, iPageIndex=1, iPageSize=SERIES_PAGE_SIZE, sTargetTitle='', sSourceUrl=''):
    if not items:
        oGui.showInfo()
        return

    iStart = max(0, (iPageIndex - 1) * iPageSize)
    iEnd = iStart + iPageSize
    sliced = items[iStart:iEnd]

    for item in sliced:
        oGuiElement = _create_series_gui_element(item['title'], sThumbnail=item.get('thumb', ''))
        p = ParameterHandler()
        p.setParam('sUrl', item['url'])
        p.setParam('sName', item['title'])
        p.setParam('TVShowTitle', item['title'])
        if item.get('thumb'):
            p.setParam('sThumbnail', item['thumb'])
        oGui.addFolder(oGuiElement, p)

    if iEnd < len(items):
        p_next = ParameterHandler()
        p_next.setParam('sSectionTitle', sTargetTitle)
        p_next.setParam('sSourceUrl', sSourceUrl)
        p_next.setParam('pageIndex', iPageIndex + 1)
        target = 'showExpandedSection' if sSourceUrl == 'expanded' else 'showSectionContent'
        oGui.addNextPage(SITE_IDENTIFIER, target, p_next)


def _parse_grid_card_items(sFragment):
    items = []
    seen_links = set()
    pattern = r'<a href="(/serie/[^"]+)"\s+class="show-card[^"]*".*?(?:data-src|src)="([^"]+)".*?alt="([^"]+)"'
    for sLink, sThumb, sTitle in re.findall(pattern, sFragment or '', re.DOTALL):
        sSeriesLink = sLink.split('/staffel-')[0]
        if sSeriesLink in seen_links:
            continue
        seen_links.add(sSeriesLink)
        items.append({
            'url': URL_MAIN + sSeriesLink,
            'title': _clean_section_title(sTitle),
            'thumb': _normalize_thumbnail(sThumb),
        })
    return items

def load():  # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)

    username = cConfig().getSetting('serienstream.user')
    password = cConfig().getSetting('serienstream.pass')

    # Do not hard-block the addon menu: browsing may work without login, but playback might require it.
    if username == '' or password == '':
        xbmcgui.Dialog().ok(cConfig().getLocalizedString(30241), cConfig().getLocalizedString(30264))

    params = ParameterHandler()
    cGui().addFolder(cGuiElement('Beliebte Serien', SITE_IDENTIFIER, 'showPopularSeries'), params)

    params = ParameterHandler()
    params.setParam('sUrl', URL_SEARCH)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)

    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES + "?by=genre")
    cGui().addFolder(cGuiElement("Genre", SITE_IDENTIFIER, 'showGenericMenu'), params)

    cGui().setEndOfDirectory()


import xbmc # Required for logging

def showCatalog(entryUrl=False, sTargetGenre=False):
    params = ParameterHandler()
    sUrl = entryUrl if entryUrl else params.getValue('sUrl')
    sTargetGenre = sTargetGenre if sTargetGenre else params.getValue('sGenreFilter')
    try:
        iPageIndex = int(params.getValue('pageIndex'))
        if iPageIndex < 1:
            iPageIndex = 1
    except Exception:
        iPageIndex = 1
    
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent: return
    oGui = cGui()
    oGui.setView('tvshows')

    # --- NEU: Globaler Bilder-Index (Dictionary) ---
    # Wir suchen auf der gesamten Seite nach Bild+Name Kombinationen
    dictThumbs = {}
    # s.to Kacheln haben oft: <img src="URL" alt="Serienname">
    # oder data-src. Dieser Regex fischt alle Bilder mit ihren Titeln ab.
    all_images = re.findall(r'(?:data-src|src)="([^"]+)"[^>]*alt="([^"]+)"', sHtmlContent)
    for sThumb, sTitle in all_images:
        name_key = unescape(sTitle).strip()
        if sThumb.startswith('/'): sThumb = URL_MAIN + sThumb
        dictThumbs[name_key] = sThumb

    # 1. Block-Isolierung (Deine funktionierende Logik)
    if sTargetGenre:
        safe_genre = re.escape(sTargetGenre)
        pattern = r'<h3[^>]*>\s*' + safe_genre + r'\s*</h3>([\s\S]*?)(?=<div[^>]*class="[^"]*mt-4[^"]*"|<h3|$)'
        match = re.search(pattern, sHtmlContent)
        sContent = match.group(1) if match else sHtmlContent
        pattern_list = r'<li[^>]*>\s*<a href="(/serie/[^"]+)"[^>]*>([^<]+)</a>\s*</li>'
    else:
        match_container = re.search(r'class="row g-3">([\s\S]*?)<nav', sHtmlContent)
        sContent = match_container.group(1) if match_container else sHtmlContent
        pattern_list = r'<h6[^>]*>\s*<a href="(/serie/[^"]+)"[^>]*>([^<]+)</a>\s*</h6>'

    all_results = re.findall(pattern_list, sContent)
    results = all_results
    iPageSize = SERIES_PAGE_SIZE
    iEnd = len(all_results)
    if sTargetGenre:
        iStart = (iPageIndex - 1) * iPageSize
        iEnd = iStart + iPageSize
        results = all_results[iStart:iEnd]

    # 2. Schleife mit Bild-Zuweisung
    for sLink, sSeriesName in results:
        sSeriesName = unescape(sSeriesName).strip()

        # Erst schauen wir im Dictionary nach (Genre-Modus Vorteil)
        sThumb = dictThumbs.get(sSeriesName, "")

        # Fallback for A-Z mode (window logic for safety)
        if not sThumb and not sTargetGenre:
            thumb_match = re.search(r'href="' + re.escape(sLink) + r'"[\s\S]*?(?:data-src|src)="([^"]+)"', sContent)
            if thumb_match:
                sThumb = thumb_match.group(1)
        sThumb = _normalize_thumbnail(sThumb)
        oGuiElement = _create_series_gui_element(sSeriesName, sThumbnail=sThumb)
        
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sLink if not sLink.startswith('http') else sLink)
        p.setParam('sName', sSeriesName)
        p.setParam('TVShowTitle', sSeriesName)
        if sThumb:
            p.setParam('sThumbnail', sThumb)
        oGui.addFolder(oGuiElement, p)

    # 3. Pagination (unchanged)
    if sTargetGenre:
        if iEnd < len(all_results):
            p_next = ParameterHandler()
            p_next.setParam('sUrl', sUrl)
            p_next.setParam('sName', params.getValue('sName'))
            p_next.setParam('sGenreFilter', sTargetGenre)
            p_next.setParam('pageIndex', iPageIndex + 1)
            oGui.addNextPage(SITE_IDENTIFIER, 'showCatalog', p_next)
    else:
        match_next = re.search(r'href="([^"]+)"[^>]*rel="next"', sHtmlContent)
        if match_next:
            next_url = match_next.group(1)
            if not next_url.startswith('http'): next_url = URL_MAIN + next_url
            
            p_next = ParameterHandler()
            p_next.setParam('sUrl', next_url)
            p_next.setParam('sName', params.getValue('sName'))
            oGui.addFolder(cGuiElement(">>> Nächste Seite", SITE_IDENTIFIER, 'showCatalog'), p_next)

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()
            
def showGenericMenu():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sHtmlContent = cRequestHandler(sUrl).request()
    if not sHtmlContent: return
    oGui = cGui()
    oGui.setView('files')

    if 'by=genre' in sUrl:
        # Search for h3 headings
        pattern = r'<h3[^>]*class="[^"]*h5[^"]*"[^>]*>([^<]+)</h3>'
        results = re.findall(pattern, sHtmlContent)
        
        for sGenreName in results:
            sName = sGenreName.strip()
            sDisplay = _format_genre_display(sName)
            
            p = ParameterHandler()
            p.setParam('sUrl', sUrl)
            p.setParam('sName', sDisplay) # "Action"
            p.setParam('sGenreFilter', sName) # "filter.genre_action" for HTML search
            p.setParam('pageIndex', 1)
            oGui.addFolder(cGuiElement(sDisplay, SITE_IDENTIFIER, 'showCatalog'), p)
    else:
        # A-Z Logik (bleibt wie gehabt)
        match_bar = re.search(r'class="alphabet-bar[^"]*">([\s\S]*?)</nav>', sHtmlContent)
        if match_bar:
            results = re.findall(r'href="(/katalog/[^"]+)"[^>]*>([^<]+)</a>', match_bar.group(1))
            for sNextUrl, sTitle in results:
                p = ParameterHandler()
                p.setParam('sUrl', URL_MAIN + sNextUrl)
                p.setParam('sName', sTitle.strip())
                oGui.addFolder(cGuiElement(sTitle.strip(), SITE_IDENTIFIER, 'showCatalog'), p)

    oGui.setEndOfDirectory()
                    
def showValue():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, '<ul[^>]*class="%s"[^>]*>(.*?)<\\/ul>' % params.getValue('sCont'))
    if isMatch:
        isMatch, aResult = cParser.parse(sContainer, '<li>\s*<a[^>]*href="([^"]*)"[^>]*>(.*?)<\\/a>\s*<\\/li>')
    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        sUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showCatalog'), params)
    cGui().setEndOfDirectory()


def showAllSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    pattern = '<a[^>]*href="(\\/serie\\/[^"]*)"[^>]*>(.*?)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName in aResult:
        # --- FIX HTML-ENTITIES (Satbandit) ---
        #sName = unescape(sName)
        sName = unescape(sName)
        # ----------------------------------
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = _create_series_gui_element(sName)
        p = ParameterHandler()
        p.setParam('sUrl', sUrl if sUrl.startswith('http') else URL_MAIN + sUrl)
        p.setParam('sName', sName)
        p.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, p, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


# Hilfsfunktion: Extrahiert alle Cards aus einem HTML-Block
def extractCards(sHtml):
    # s.to uses 'data-src' for images (lazy load)
    # Das Pattern sucht den Link, das Bild und den Namen
    pattern = r'href="([^"]+)"[^>]*class="show-card[^"]*".*?data-src="([^"]+)"[^>]*alt="([^"]+)"'
    
    # (?s) allows line breaks within a card
    return re.findall(r'(?s)' + pattern, sHtml)

def showGenericSeriesList(entryUrl=False):
    oGui = cGui()
    params = ParameterHandler()
    
    sUrl = params.getValue('sUrl') or (URL_MAIN + '/beliebte-serien')
    sectionName = params.getValue('sectionName')
    
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    dump_to_file(sHtmlContent, 'beliebte.html')

    # Clean HTML: collapse all whitespace/newlines to single space
    sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent)

    if sectionName and sectionName in sHtmlContent:
        # Start: Direkt nach dem Sektionsnamen
        sHtmlContent = sHtmlContent.split(sectionName, 1)[1]
        
        # Ende: Wir suchen das Ende der Liste. 
        # S.to often closes grids with </ul> or </section>
        # A safe anchor is the next <h2 (next section heading)
        if '<h2' in sHtmlContent:
            sHtmlContent = sHtmlContent.split('<h2', 1)[0]
        elif '</section>' in sHtmlContent:
            sHtmlContent = sHtmlContent.split('</section>', 1)[0]
    
    # Cards extrahieren
    aResult = extractCards(sHtmlContent)

    if not aResult:
        # Fallback-Suche, falls das erste Pattern zu streng war
        pattern_fallback = r'href="([^"]+)"[^>]*>.*?data-src="([^"]+)"[^>]*alt="([^"]+)"'
        aResult = re.findall(r'(?s)' + pattern_fallback, sHtmlContent)

    seen = set()
    for sUrl, sThumbnail, sName in aResult:
        if sUrl in seen: continue
        seen.add(sUrl)
        
        if sUrl.startswith('/'): sUrl = URL_MAIN + sUrl
        sThumbnail = _normalize_thumbnail(sThumbnail)
        oGuiElement = _create_series_gui_element(sName, sThumbnail=sThumbnail)
        
        # Important: New parameter instance for each folder!
        p = ParameterHandler()
        p.setParam('sUrl', sUrl)
        p.setParam('sName', sName)
        p.setParam('TVShowTitle', sName)
        if sThumbnail:
            p.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, p, True, len(aResult))

    oGui.setView('tvshows')
    oGui.setEndOfDirectory() 

def showRoot():
    oGui = cGui()
    sHtmlContent = cRequestHandler(URL_MAIN, caching=True).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    
    if sHtmlContent:
        # Suche alle Buttons: data-bs-target="#section-0">Neueste Episoden</button>
        pattern = r'data-bs-target="#([^"]+)"[^>]*>([^<]+)</button>'
        sections = re.findall(pattern, sHtmlContent)

        seen_ids = set()
        for sId, sName in sections:
            sName = sName.strip()
            # Only add if this section (id) is not yet in the menu
            if sId not in seen_ids and "section-" in sId:
                oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHomeSection')
                p = ParameterHandler()
                p.setParam('section_id', sId)
                p.setParam('sName', sName)
                oGui.addFolder(oGuiElement, p)
                seen_ids.add(sId)
    
    oGui.addFolder(cGuiElement('Suche', SITE_IDENTIFIER, 'showSearch'), ParameterHandler())
    oGui.setEndOfDirectory()


def showNewEpisodes():
    oGui = cGui()
    sHtmlContent = cRequestHandler(URL_NEW_EPISODES, caching=True).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent:
        oGui.showInfo()
        return

    renderEpisodes(oGui, re.sub(r'\s+', ' ', sHtmlContent))
    oGui.setView('tvshows')
    oGui.setEndOfDirectory()

def showNewSeries():
    """
    Zeigt die 'Neu auf S.to' Kacheln von der Homepage.
    """
    oGui = cGui()

    sHtmlContent = cRequestHandler(URL_MAIN, caching=True).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent:
        oGui.showInfo()
        return

    sHtml = re.sub(r'\s+', ' ', sHtmlContent)
    match_section = re.search(r'class="[^"]*new-shows-slider[^"]*"(.*?)</section>', sHtml, re.DOTALL)
    if not match_section:
        logger.error('[%s] showNewSeries: new-shows-slider nicht gefunden' % SITE_IDENTIFIER)
        oGui.showInfo()
        return

    fragment = match_section.group(1)
    cards = re.findall(r'<article[^>]*class="[^"]*continue-card[^"]*"[^>]*>(.*?)</article>', fragment, re.DOTALL)

    seen = set()
    clean = []
    for card in cards:
        link_match = re.search(r'href="(/serie/[^"]+)"', card)
        img_match = re.search(r'<img\s+src="([^"]+)"[^>]*alt="([^"]+)"', card)
        if not link_match or not img_match:
            continue
        sLink = link_match.group(1)
        sThumb = img_match.group(1)
        sTitle = unescape(img_match.group(2)).strip()
        if sLink in seen or 'data:image' in sThumb:
            continue
        seen.add(sLink)
        clean.append((sLink, sThumb, sTitle))

    if not clean:
        logger.error('[%s] showNewSeries: Keine Kacheln gefunden' % SITE_IDENTIFIER)
        oGui.showInfo()
        return

    total = len(clean)
    for sLink, sThumb, sTitle in clean:
        sFullUrl = URL_MAIN + sLink if sLink.startswith('/') else sLink
        sFullThumb = _normalize_thumbnail(sThumb)

        oGuiElement = _create_series_gui_element(sTitle, sThumbnail=sFullThumb)

        p = ParameterHandler()
        p.setParam('sUrl', sFullUrl)
        p.setParam('sName', sTitle)
        p.setParam('TVShowTitle', sTitle)
        if sFullThumb:
            p.setParam('sThumbnail', sFullThumb)
        oGui.addFolder(oGuiElement, p, True, total)

    p_next = ParameterHandler()
    p_next.setParam('sUrl', URL_NEW_SERIES)
    oGui.addNextPage(SITE_IDENTIFIER, 'showCatalog', p_next)

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()
    
def showHomeSection():
    params = ParameterHandler()
    section_id = params.getValue('section_id')
    oGui = cGui()
    
    sHtmlContent = cRequestHandler(URL_MAIN, caching=True).request()
    if sHtmlContent:
        sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent)
        # Search from ID to next section or end of tab-content
        section_pattern = f'id="{section_id}".*?(?:id="section-|</div> </div> </section>)'
        section_match = re.search(section_pattern, sHtmlContent)
        
        if section_match:
            fragment = section_match.group(0)
            if 'latest-episode-row' in fragment:
                renderEpisodes(oGui, fragment)
            else:
                renderCards(oGui, fragment)

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()

def renderEpisodes(oGui, sHtml):
    latest_pattern = (
        r'class="latest-episode-row[^"]*"\s+href="([^"]+/staffel-(\d+)/episode-(\d+))".*?'
        r'class="ep-title"\s+title="([^"]+)".*?'
        r'class="ep-season">S?(\d+).*?'
        r'class="ep-episode">E?(\d+).*?'
        r'use href="#icon-flag-([^"]+)"'
    )
    results = re.findall(latest_pattern, sHtml, re.DOTALL)

    if not results:
        row_pattern = (
            r'<tr[^>]*>.*?'
            r'<a href="([^"]+/staffel-(\d+)/episode-(\d+))"[^>]*class="[^"]*text-white[^"]*"[^>]*>([^<]+)</a>.*?'
            r'<span[^>]*>S(\d+)</span>.*?'
            r'<span[^>]*>E(\d+)</span>.*?'
            r'title="([^"]+)"'
        )
        results = re.findall(row_pattern, sHtml, re.DOTALL)

    for sLink, sSeasonNumFromUrl, sEpisodeNumFromUrl, sTitle, sSeasonNum, sEpisodeNum, sLang in results:
        if sLink.startswith('#'):
            continue

        sTitle = unescape(sTitle).strip()
        sSeriesUrl = re.sub(r'/staffel-\d+/episode-\d+', '', sLink)
        sSeasonUrl = re.sub(r'/episode-\d+', '', sLink)

        sSeason = 'S%02d' % int(sSeasonNum or sSeasonNumFromUrl)
        sEpisode = 'E%02d' % int(sEpisodeNum or sEpisodeNumFromUrl)
        sLangClean = unescape(sLang).strip().lower()
        if 'ger-sub' in sLangClean or 'english-german' in sLangClean:
            sLangLabel = 'Ger-Sub'
        elif 'german' in sLangClean:
            sLangLabel = 'DE'
        elif 'english' in sLangClean:
            sLangLabel = 'EN'
        else:
            sLangLabel = unescape(sLang).strip()

        sDisplay = '%s (%s%s) [%s]' % (sTitle, sSeason, sEpisode, sLangLabel)
        sFullUrl = URL_MAIN + sSeriesUrl if sSeriesUrl.startswith('/') else sSeriesUrl

        oGuiElement = cGuiElement(sDisplay, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        oGuiElement.setTVShowTitle(sTitle)
        oGuiElement.setSeason(str(int(sSeasonNum or sSeasonNumFromUrl)))
        oGuiElement.setForceMeta(True)
        oGuiElement.setDescription('Neueste Folge: %s%s [%s]' % (sSeason, sEpisode, sLangLabel))

        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sSeasonUrl if sSeasonUrl.startswith('/') else sSeasonUrl)
        p.setParam('sName', sTitle)
        p.setParam('TVShowTitle', sTitle)
        p.setParam('season', str(int(sSeasonNum or sSeasonNumFromUrl)))
        p.setParam('sTargetEpisode', str(int(sEpisodeNum or sEpisodeNumFromUrl)))

        oGui.addFolder(oGuiElement, p)

def renderCards(oGui, sHtml):
    # Dieses Regex deckt die Card-Struktur ab:
    # 1. Das Bild (data-src)
    # 2. Den Link zur Serie (href)
    # 3. Den Titel (im h3-Tag oder title-Attribut)
    pattern = r'<img\s+data-src="([^"]+)"[^>]*>.*?<a\s+href="([^"]+)">\s*<h3\s+title="([^"]+)"'
    
    # re.DOTALL needed due to line breaks between image and link
    results = re.findall(pattern, sHtml, re.DOTALL)
    
    for sThumb, sLink, sTitle in results:
        # If URL is relative, prepend main URL
        sFullUrl = URL_MAIN + sLink if sLink.startswith('/') else sLink
        sTitle = unescape(sTitle).strip()
        sThumb = _normalize_thumbnail(sThumb)
        oGuiElement = _create_series_gui_element(sTitle, sThumbnail=sThumb)
        
        p = ParameterHandler()
        p.setParam('sUrl', sFullUrl)
        p.setParam('sName', sTitle)
        p.setParam('TVShowTitle', sTitle)
        if sThumb:
            p.setParam('sThumbnail', sThumb)
        oGui.addFolder(oGuiElement, p)
    
def showBeliebte(sGui=False):
    oGui = sGui if sGui else cGui()
    sHtmlContent = cRequestHandler(URL_POPULAR, caching=True).request()
    
    if not sHtmlContent: return
    sections = _parse_popular_sections(sHtmlContent)
    for section in sections:
        targetFunction = 'showCatalog' if section.get('genre_url') else 'showSectionContent'
        oGuiElement = cGuiElement(section['title'], SITE_IDENTIFIER, targetFunction)
        p = ParameterHandler()
        p.setParam('sSectionTitle', section['title'])
        if section.get('genre_url'):
            p.setParam('sUrl', section['genre_url'])
            p.setParam('sName', section['title'])
        oGui.addFolder(oGuiElement, p)

    oGui.setEndOfDirectory()


def showPopularGenres():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl') or URL_POPULAR
    sHtmlContent = cRequestHandler(sUrl).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent:
        cGui().showInfo()
        return

    oGui = cGui()
    seen = set()
    matches = re.findall(r'href="(/genre/([^"]+))"', sHtmlContent)
    for sHref, sSlug in matches:
        if sHref in seen:
            continue
        seen.add(sHref)
        sName = _format_slug_display(sSlug)
        if not sName:
            continue
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sHref)
        p.setParam('sName', sName)
        oGui.addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showCatalog'), p)

    if not seen:
        oGui.showInfo()
        return

    oGui.setView('files')
    oGui.setEndOfDirectory()


def showPopularSeries():
    params = ParameterHandler()
    try:
        iPageIndex = int(params.getValue('pageIndex'))
        if iPageIndex < 1:
            iPageIndex = 1
    except Exception:
        iPageIndex = 1

    oGui = cGui()
    results = []
    first_tmdb_page = ((iPageIndex - 1) * 5) + 1

    for tmdb_page in range(first_tmdb_page, first_tmdb_page + 5):
        sUrl = URL_TMDB_POPULAR_SERIES % (TMDB_API_KEY, tmdb_page)
        sJson = cRequestHandler(sUrl, caching=False, ignoreErrors=True).request()
        if not sJson:
            continue
        try:
            data = json.loads(sJson)
        except Exception:
            continue
        for item in data.get('results', []):
            sName = unescape(str(item.get('name') or item.get('original_name') or '')).strip()
            if not sName:
                continue
            sOriginalName = unescape(str(item.get('original_name') or '')).strip()
            sOverview = unescape(str(item.get('overview') or '')).strip()
            sPoster = item.get('poster_path') or ''
            sThumbnail = TMDB_POSTER % sPoster if sPoster else ''
            sYear = str(item.get('first_air_date') or '')[:4]
            results.append({
                'title': sName,
                'original_title': sOriginalName,
                'thumb': sThumbnail,
                'overview': sOverview,
                'year': sYear,
            })

    if not results:
        oGui.showInfo()
        return

    total = len(results)
    for item in results[:SERIES_PAGE_SIZE]:
        sTitle = item.get('title', '')
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'openPopularSeries')
        oGuiElement.setMediaType('tvshow')
        oGuiElement.setTVShowTitle(sTitle)
        oGuiElement.setForceMeta(False)
        if item.get('thumb'):
            oGuiElement.setThumbnail(item.get('thumb'))
        if item.get('overview'):
            oGuiElement.setDescription(item.get('overview'))
        if item.get('year'):
            try:
                oGuiElement.setYear(item.get('year'))
            except Exception:
                pass

        p = ParameterHandler()
        p.setParam('sName', sTitle)
        p.setParam('TVShowTitle', sTitle)
        p.setParam('sOriginalName', item.get('original_title', ''))
        if item.get('thumb'):
            p.setParam('sThumbnail', item.get('thumb'))
        oGui.addFolder(oGuiElement, p, True, total)

    p_next = ParameterHandler()
    p_next.setParam('pageIndex', iPageIndex + 1)
    oGui.addNextPage(SITE_IDENTIFIER, 'showPopularSeries', p_next)

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()


def openPopularSeries():
    params = ParameterHandler()
    sTitle = params.getValue('sName') or params.getValue('TVShowTitle')
    sOriginalTitle = params.getValue('sOriginalName')
    found = _find_seriesstream_series(sTitle, sOriginalTitle)
    if not found:
        xbmcgui.Dialog().notification(SITE_NAME, 'Keine Serienstream-Zuordnung gefunden')
        SSsearch(False, sTitle)
        return

    sys.argv[2] = '?' + urlencode({
        'sUrl': found.get('url', ''),
        'sName': found.get('title', sTitle),
        'TVShowTitle': found.get('title', sTitle),
        'sThumbnail': found.get('thumb', params.getValue('sThumbnail') or ''),
    })
    showSeasons()

def showSectionContent():
    params = ParameterHandler()
    sTargetTitle = params.getValue('sSectionTitle')
    sSourceUrl = params.getValue('sSourceUrl') or URL_POPULAR
    try:
        iPageIndex = int(params.getValue('pageIndex'))
        if iPageIndex < 1:
            iPageIndex = 1
    except Exception:
        iPageIndex = 1
    sHtmlContent = cRequestHandler(sSourceUrl, caching=True).request()
    if not sHtmlContent:
        return

    if sSourceUrl == URL_POPULAR:
        for section in _parse_popular_sections(sHtmlContent):
            if section['title'] == sTargetTitle and section.get('genre_url'):
                showCatalog(section['genre_url'])
                return

    oGui = cGui()
    sFragment = _extract_section_fragment(sHtmlContent, sTargetTitle)
    items = []

    if sTargetTitle == 'Angesagt':
        items = _parse_trend_items(sFragment)
    else:
        items = _parse_discover_items(sFragment)

    _add_series_items(
        oGui,
        items,
        iPageIndex=iPageIndex,
        iPageSize=SERIES_PAGE_SIZE,
        sTargetTitle=sTargetTitle,
        sSourceUrl=sSourceUrl,
    )

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()


def showExpandedSection():
    params = ParameterHandler()
    sTargetTitle = params.getValue('sSectionTitle')
    try:
        iPageIndex = int(params.getValue('pageIndex'))
        if iPageIndex < 1:
            iPageIndex = 1
    except Exception:
        iPageIndex = 1

    sSourceUrl = URL_POPULAR if sTargetTitle == 'Meistgesehen gerade' else URL_MAIN
    sHtmlContent = cRequestHandler(sSourceUrl, caching=True).request()
    if not sHtmlContent:
        cGui().showInfo()
        return

    sFragment = _extract_section_fragment(sHtmlContent, sTargetTitle)
    if sTargetTitle == 'Angesagt':
        primary_items = _parse_trend_items(sFragment)
    elif sTargetTitle == 'Meistgesehen gerade':
        primary_items = _parse_grid_card_items(sFragment)
    else:
        primary_items = _parse_discover_items(sFragment)

    oGui = cGui()
    _add_series_items(
        oGui,
        primary_items,
        iPageIndex=iPageIndex,
        iPageSize=SERIES_PAGE_SIZE,
        sTargetTitle=sTargetTitle,
        sSourceUrl='expanded',
    )

    oGui.setView('tvshows')
    oGui.setEndOfDirectory()

def extractPoster(sHtml):
    sThumbnail = ""
    # 1. Versuch: Desktop-Container (aus deinem Dump: col-lg-2)
    match = re.search(r'class="[^"]*col-lg-2[^"]*">.*?<img[^>]+data-src="([^"]+)"', sHtml, re.DOTALL)
    
    # 2. Versuch: Mobile-Container (aus deinem Dump: show-cover-mobile)
    if not match:
        match = re.search(r'class="[^"]*show-cover-mobile[^"]*">.*?<img[^>]+data-src="([^"]+)"', sHtml, re.DOTALL)
        
    if match:
        sThumbnail = match.group(1).strip()
        # Complete relative URLs
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail
        # Optimize image format for Kodi (jpg instead of webp/avif)
        sThumbnail = sThumbnail.replace('format=webp', 'format=jpg').replace('format=avif', 'format=jpg')
        
    return sThumbnail      
         
def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sName = params.getValue('sName')
    sThumbnail = params.getValue('sThumbnail')
    
    oGui = cGui()
    sHtmlContent = cRequestHandler(sUrl, caching=True).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent: return

    # 1. Serienname fixen (falls von Favoriten/Suche kommend)
    title_match = re.search(r'<title>(.*?)\s+Staffel', sHtmlContent)
    if title_match:
        sName = title_match.group(1).strip()
    elif not sName or sName == 'False':
        sName = "Serie"

    # 2. Description (extract from span "description-text")
    sDesc = ''
    # Suche speziell nach dem span-Inhalt
    match_span = re.search(r'<span class="description-text">(.*?)</span>', sHtmlContent, re.DOTALL)
    if match_span:
        sDesc = unescape(match_span.group(1)).strip()
        # HTML-Reste entfernen (falls vorhanden)
        sDesc = re.sub(r'<[^>]*>', '', sDesc)
    
    # Fallback auf Meta-Description, falls der span leer war
    if not sDesc:
        match_desc = re.search(r'name="description"\s+content="([^"]+)"', sHtmlContent)
        if match_desc:
            sDesc = unescape(match_desc.group(1)).strip()

    # 3. Poster extrahieren
    if not sThumbnail: sThumbnail = extractPoster(sHtmlContent)

    # 4. Staffeln finden (aus deinem Web-Dump)
    # Sucht nach Links wie /staffel-1, /staffel-2 etc.
    pattern = r'href="([^"]+/staffel-(\d+))"'
    results = re.findall(pattern, sHtmlContent)

    # --- FIX START Aki: Sortierung der Staffeln ---
    # Dubletten entfernen und Mapping erstellen
    seasons_map = {}
    for sSeasonUrl, sSeasonNum in results:
        if sSeasonNum not in seasons_map:
            seasons_map[sSeasonNum] = sSeasonUrl

    # Sortieren nach Zahl (damit 0 vor 1 kommt, und 10 nach 2)
    sorted_keys = sorted(seasons_map.keys(), key=lambda x: int(x))

    for sSeasonNum in sorted_keys:
        sSeasonUrl = seasons_map[sSeasonNum]
        
        # Fix for movies instead of Season 0 (renamed specials)
        if sSeasonNum == '0':
            sDisplay = "Specials"
        else:
            sDisplay = "Staffel %s" % sSeasonNum
        
        oGuiElement = cGuiElement(sDisplay, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        oGuiElement.setSeason(sSeasonNum)
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setTVShowTitle(sName)
        
        # Beschreibung hier ebenfalls setzen
        if sDesc:
            oGuiElement.setDescription(sDesc)

        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sSeasonUrl if sSeasonUrl.startswith('/') else sSeasonUrl)
        p.setParam('sName', sName)
        p.setParam('sThumbnail', sThumbnail)
        # Pass description to next level
        p.setParam('sDescription', sDesc) 
        
        oGui.addFolder(oGuiElement, p)
    # --- FIX END ---

    oGui.setView('seasons')
    oGui.setEndOfDirectory()
    
def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    sThumbnail = params.getValue('sThumbnail')
    sDesc = params.getValue('sDescription')
    
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    if not sHtmlContent: return

    # 1. Serienname & Beschreibung (wie gehabt)
    if not sTVShowTitle or sTVShowTitle == 'False':
        title_match = re.search(r'<title>(.*?)\s+Staffel', sHtmlContent)
        if title_match: sTVShowTitle = title_match.group(1).strip()
        
    if not sDesc:
       # 1. Plot/Beschreibung extrahieren
       match_plot = re.search(r'<span class="description-text">(.*?)</span>', sHtmlContent, re.DOTALL)
       if match_plot:
          sDesc = unescape(match_plot.group(1)).strip()

    if not sThumbnail: sThumbnail = extractPoster(sHtmlContent)
		
    # 2. Episoden-Tabelle parsen
    # Wir suchen die Nummer (episode-number-cell) und den deutschen Titel (episode-title-ger)
    # Und wir brauchen den Link zur Episode (den wir aus der Navigation oder den Zeilen holen)
    
    # Extract rows/blocks to link URLs and titles
    # Da die Links in der Navigation oben stehen und die Titel unten in der Tabelle,
    # Most stable approach: use the table for names:
    pattern = r'<th[^>]*>\s*(\d+)\s*</th>[\s\S]*?class="[^"]*episode-title-(?:ger|eng)"[^>]*>\s*([^<]+)\s*<'
    titles_dict = dict(re.findall(pattern, sHtmlContent, re.DOTALL))

    # Jetzt holen wir die Links aus der Navigation (wie zuvor)
    pattern_nav = r'href="([^"]*/episode-(\d+))"'
    nav_links = re.findall(pattern_nav, sHtmlContent)
    
    # Dubletten aus der Navigation entfernen (da oft mehrfach vorhanden)
    seen_eps = set()
    unique_nav = []
    for url, ep_nr in nav_links:
        if ep_nr not in seen_eps:
            seen_eps.add(ep_nr)
            unique_nav.append((url, ep_nr))

    oGui = cGui()
    total = len(unique_nav)
    
    for sUrl2, sEpNr in unique_nav:
        # Den passenden Titel aus unserem Tabellen-Dict holen
        sEpName = titles_dict.get(sEpNr, "").strip()
        sEpName = unescape(sEpName)
        
        # Formatierung: "1 - Der Tote am See"
        sDisplayTitle = "Episode %s" % sEpNr
        if sEpName:
            sDisplayTitle += " - %s" % sEpName
        
        oGuiElement = cGuiElement(sDisplayTitle, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode')
        
        if sThumbnail: oGuiElement.setThumbnail(sThumbnail)
        if sDesc: oGuiElement.setDescription(sDesc)
        
        oGuiElement.setTVShowTitle(sTVShowTitle)
        
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sUrl2 if not sUrl2.startswith('http') else sUrl2)
        p.setParam('sThumbnail', sThumbnail)
        p.setParam('sDescription', sDesc)
        
        oGui.addFolder(oGuiElement, p, False, total)
        
    oGui.setView('episodes')
    oGui.setEndOfDirectory()


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('sUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    
    if not sHtmlContent:
        return []

    # Find all buttons (containers)
    button_pattern = r'<button[^>]*class="[^"]*link-box[^"]*"[^>]*>'
    buttons = re.findall(button_pattern, sHtmlContent)

    for sButton in buttons:
        # Individual extraction: HTML order does not matter
        url_match = re.search(r'data-play-url="([^"]+)"', sButton)
        name_match = re.search(r'data-provider-name="([^"]+)"', sButton)
        lang_match = re.search(r'data-language-id="([^"]+)"', sButton)

        if url_match and name_match and lang_match:
            sHUrl = url_match.group(1)
            sName = name_match.group(1)
            sLang = lang_match.group(1)

            # --- Language filter logic ---
            if cConfig().isBlockedHoster(sName)[0]: continue
            
            sLanguage = cConfig().getSetting('prefLanguage')
            if sLanguage == '1' and sLang != '1': continue
            if sLanguage == '2' and sLang != '2': continue
            
            sLangLabel = '(DE)' if sLang == '1' else '(EN)' if sLang == '2' else sLang
            sQuality = ''
            
            # Structure required by the core for display
            hoster = {
                'link': [sHUrl, sName], 
                'name': sName, 
                'displayedName': '%s [I]%s[/I]' % (sName, sLangLabel), 
                'quality': sQuality, 
                'languageCode': sLangLabel
            }
            hosters.append(hoster)

    # Append function name for core callback
    if hosters:
        hosters.append('getHosterUrl')
    if not hosters:
        cGui().showLanguage()
    return hosters

def getHosterUrl(hUrl):
    if type(hUrl) == str: hUrl = eval(hUrl)
    referer = ParameterHandler().getValue('sUrl') or ParameterHandler().getValue('entryUrl') or URL_MAIN
    if 'voe' in hUrl[1].lower():
        sUrl = _get_redirect_location(URL_MAIN + hUrl[0], referer)
        if sUrl:
            return [{'streamUrl': sUrl, 'resolved': False}]

    # Optional login: only attempt if credentials are set.
    # Some deployments return HTTP 419 (CSRF/session) for direct login calls.
    # We ignore such errors silently because most hoster redirects work without a session.
    username = cConfig().getSetting('serienstream.user')
    password = cConfig().getSetting('serienstream.pass')
    if username and password:
        try:
            Handler = cRequestHandler(URL_LOGIN, caching=False, ignoreErrors=True)
            Handler.addHeaderEntry('Upgrade-Insecure-Requests', '1')
            Handler.addHeaderEntry('Referer', referer)
            Handler.addParameters('email', username)
            Handler.addParameters('password', password)
            Handler.request()
        except Exception as e:
            logger.info('[%s] login skipped/failed (ignored): %s' % (SITE_IDENTIFIER, str(e)))

    Request = cRequestHandler(URL_MAIN + hUrl[0], caching=False)
    Request.addHeaderEntry('Referer', referer)
    Request.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    Request.request()
    sUrl = Request.getRealUrl()

    if 'voe' in hUrl[1].lower():
        isBlocked, sDomain = cConfig().isBlockedHoster(sUrl)  # Die funktion gibt 2 werte zurück!
        if isBlocked:
            logger.info('[%s] unresolved VOE redirect kept original url: %s' % (SITE_IDENTIFIER, sUrl))

    return [{'streamUrl': sUrl, 'resolved': False}]


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, hdrs, newurl):
        return None


def _get_redirect_location(url, referer):
    request = Request(url)
    request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
    request.add_header('Accept-Language', 'de,en-US;q=0.7,en;q=0.3')
    request.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8')
    request.add_header('Connection', 'keep-alive')
    if referer:
        request.add_header('Referer', referer)
    try:
        response = build_opener(_NoRedirect).open(request, timeout=int(cConfig().getSetting('requestTimeout', 10)))
        location = response.headers.get('Location')
        if location:
            return urljoin(url, location)
        real_url = response.geturl()
        if real_url and real_url != url:
            return real_url
        content = response.read().decode('utf-8', 'replace')
        match = re.search(r'https?://(?:www\.)?voe\.[^/"\']+/e/[A-Za-z0-9_-]+', content)
        if match:
            return match.group(0)
        logger.info('[%s] redirect lookup returned no VOE location, status: %s' % (SITE_IDENTIFIER, getattr(response, 'status', '')))
    except HTTPError as e:
        if 300 <= e.code < 400:
            location = e.headers.get('Location')
            if location:
                return urljoin(url, location)
        logger.info('[%s] redirect lookup failed: %s' % (SITE_IDENTIFIER, str(e)))
    except Exception as e:
        logger.info('[%s] redirect lookup failed: %s' % (SITE_IDENTIFIER, str(e)))
    return ''



def showSearch():
    sSearchText = _show_keyboard(cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()

def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)

def SSsearch(sGui=False, sSearchText=False, iPage=1):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    
    # Suchtext priorisieren: Erst aus dem Argument, dann aus den Params
    if not sSearchText:
        sSearchText = params.getValue('sSearchText')
    
    # If iPage comes as string from params (when browsing)
    if params.getValue('iPage'):
        iPage = params.getValue('iPage')

    if not sSearchText:
        return

    # Wir bauen die URL jetzt explizit so, wie s.to sie bei direkten Aufrufen erwartet
    # Wichtig: Seite als Zahl mitschicken
    sUrl = f"{URL_MAIN}/suche?term={quote_plus(str(sSearchText))}&tab=shows&page={str(iPage)}"
    
    oRequest = cRequestHandler(sUrl, caching=True)
    sHtmlContent = oRequest.request()
    if _is_login_page(sHtmlContent):
        _notify_login_required()
        return
    
    if not sHtmlContent:
        return

    sHtmlContent = re.sub(r'\s+', ' ', sHtmlContent)
    found_links = set()

    # Regex for card structure
    pattern = r'class="card cover-card.*?href="(/serie/[^"]+)".*?(?:data-src|src)="([^"]+)".*?alt="([^"]+)"'
    aResult = re.findall(pattern, sHtmlContent)

    total = len(aResult)
    for sLink, sThumbnail, sTitle in aResult:
        if sLink in found_links: continue
        found_links.add(sLink)
        
        if 'data:image/gif' in sThumbnail: continue

        sTitle = unescape(sTitle)
        sFullUrl = URL_MAIN + sLink if sLink.startswith('/') else sLink
        sFullThumb = _normalize_thumbnail(sThumbnail)

        oGuiElement = _create_series_gui_element(sTitle, sThumbnail=sFullThumb)
        
        p = ParameterHandler()
        p.setParam('sUrl', sFullUrl)
        p.setParam('sName', sTitle)
        p.setParam('TVShowTitle', sTitle)
        if sFullThumb:
            p.setParam('sThumbnail', sFullThumb)
        
        oGui.addFolder(oGuiElement, p)

    # Next page logic
    if total >= 20:
        p = ParameterHandler()
        p.setParam('sSearchText', sSearchText)
        p.setParam('iPage', str(int(iPage) + 1)) # Explicitly increment page
        oGui.addNextPage(SITE_IDENTIFIER, 'SSsearch', p)

    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()
                
def getMetaInfo(link, title):   # Setzen von Metadata in Suche:
    oGui = cGui()
    oRequest = cRequestHandler(link if link.startswith('http') else URL_MAIN + link, caching=False)
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return

    pattern = 'show-cover-mobile.*?(?:data-src|src)="([^"]+)".*?class="series-description".*?<span[^>]*class="description-text">([^<]+)</span>' #img , descr

    aResult = cParser.parse(sHtmlContent, pattern)

    if not aResult[0]:
        return

    for sImg, sDescr in aResult[1]:
        return sImg, sDescr
        
def dump_to_file(content, filename="/tmp/debug_sto.html"):
    try:
        # Pfad im Home-Verzeichnis deines Debian-Users oder im Kodi-Temp-Ordner
        import os
        path = os.path.join(os.path.expanduser("~"), filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.info(f"[{SITE_IDENTIFIER}] Dump erstellt unter: {path}")
    except Exception as e:
        logger.error(f"[{SITE_IDENTIFIER}] Dump fehlgeschlagen: {str(e)}")
