# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showGenre:     48 Stunden
# showYears:     48 Stunden
# showEpisodes:   4 Stunden

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from urllib.parse import urljoin
import re

SITE_IDENTIFIER = 'streamcloud'
SITE_NAME = 'Streamcloud'
SITE_ICON = 'streamcloud.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'streamcloud.my') # Domain Auswahl über die Streaming Archiv Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN + '/'
# URL_MAIN = 'https://streamcloud.my/'
URL_MAINPAGE = URL_MAIN + 'streamcloud/'
URL_MOVIES = URL_MAIN + 'filme-stream/'
URL_KINO = URL_MAIN + 'kinofilme/'
URL_FAVOURITE_MOVIE_PAGE = URL_MAIN + 'beliebte-filme/'
URL_SERIES = URL_MAIN + 'serien/'
# /neue-filme/ ist auf der aktuellen Streamcloud-Seite verlinkt, liefert aber 404.
# Die echte "Neu/Updates"-Liste liegt aktuell unter /filme-stream/.
URL_NEW = URL_MOVIES
URL_SEARCH = URL_MAIN + 'index.php?story=%s&do=search&subaction=search'

#
PAGE_SIZE = 100

def _absolute_url(sUrl):
    if not sUrl:
        return ''
    return urljoin(URL_MAIN, sUrl).replace(' ', '%20')


def _clean_name(sName):
    sName = re.sub('<.*?>', ' ', sName)
    return ' '.join(sName.replace('&amp;', '&').split()).strip()


def _extract_filter_links(sHtmlContent, className):
    section = ''
    for marker in ('class="%s"' % className, "class='%s'" % className):
        start = sHtmlContent.find(marker)
        if start >= 0:
            end = sHtmlContent.find('<style>', start)
            section = sHtmlContent[start:end if end > start else start + 20000]
            break
    if not section:
        return []

    links = []
    seen = set()
    for match in re.finditer(r'<a\s+[^>]*href=(["\'])(.*?)\1[^>]*>(.*?)</a>', section, re.I | re.S):
        sUrl = _absolute_url(match.group(2))
        sName = _clean_name(match.group(3))
        if not sUrl or not sName or sUrl in seen:
            continue
        seen.add(sUrl)
        links.append((sUrl, sName))
    return links


def _add_filter_folders(aResult):
    params = ParameterHandler()
    for sUrl, sName in aResult:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def _parse_entry_page(sHtmlContent):
    pattern = 'class="thumb".*?title="([^"]+).*?href="([^"]+).*?src="([^"]+).*?_year">([^<]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    return aResult if isMatch else []


def _next_page_url(sHtmlContent):
    isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
    return _absolute_url(sNextUrl) if isMatchNextPage else ''


def _collect_entry_pages(entryUrl, limit=PAGE_SIZE, ignoreErrors=False):
    results = []
    next_url = entryUrl
    seen = set()
    while next_url and len(results) < limit and next_url not in seen:
        seen.add(next_url)
        oRequest = cRequestHandler(next_url, caching=False, ignoreErrors=ignoreErrors)
        sHtmlContent = oRequest.request()
        page_results = _parse_entry_page(sHtmlContent)
        if not page_results:
            break
        results.extend(page_results)
        next_url = _next_page_url(sHtmlContent)
    return results, next_url

#ToDo Serien auch auf reinen Filmseiten, prüfen ob Filterung möglich
def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_NEW)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # New Movies
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Current films in the cinema
    #params.setParam('sUrl', URL_FAVOURITE_MOVIE_PAGE)
    #cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showEntries'), params)  # Favorite Movies #ToDo Auskommentiert da URL auf Webseite fehlerhaft, zukünftig prüfen ob Fehler behoben
    #params.setParam('sUrl', URL_MOVIES)
    #cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)  # Movies #ToDo Auskommentiert da URL auf Webseite fehlerhaft, zukünftig prüfen ob Fehler behoben
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30507), SITE_IDENTIFIER, 'showGenre'), params)    # Categories
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showYears'), params)    # Year
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30538), SITE_IDENTIFIER, 'showCountry'), params)  # Country
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeries'), params)  # Series
    cGui().setEndOfDirectory()


def showGenre(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, caching=False)
    sHtmlContent = oRequest.request()    
    aResult = _extract_filter_links(sHtmlContent, 'genres')
    aResult = [(sUrl, sName) for sUrl, sName in aResult if sName.strip().lower() != 'serien']
    if not aResult:
        cGui().showInfo()
        return

    _add_filter_folders(aResult)


def showYears(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, caching=False)
    sHtmlContent = oRequest.request()
    aResult = _extract_filter_links(sHtmlContent, 'years')
    if not aResult:
        cGui().showInfo()
        return
    _add_filter_folders(aResult)


def showCountry(entryUrl=False): #ToDo Sortierung A-Z bei Ländern
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, caching=False)
    sHtmlContent = oRequest.request()
    aResult = _extract_filter_links(sHtmlContent, 'countries')
    if not aResult:
        cGui().showInfo()
        return

    _add_filter_folders(aResult)


def _get_entry_fallback_meta(entry_url):
    if not entry_url:
        return {}
    if entry_url.startswith('/'):
        detail_url = URL_MAIN.rstrip('/') + entry_url
    else:
        detail_url = entry_url

    oRequest = cRequestHandler(detail_url, ignoreErrors=True)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return {}

    meta = {}
    isMatch, sDesc = cParser.parseSingleResult(sHtmlContent, '<meta name="description" content="([^"]+)')
    if isMatch:
        meta['plot'] = sDesc.replace('&amp;', '&').replace('&#039;', "'").strip()
    return meta


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText = False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if not sGui and not sSearchText and not sSearchPageText:
        aResult, sNextUrl = _collect_entry_pages(entryUrl, PAGE_SIZE, ignoreErrors=False)
    else:
        oRequest = cRequestHandler(entryUrl, caching=False, ignoreErrors=(sGui is not False))
        sHtmlContent = oRequest.request()
        aResult = _parse_entry_page(sHtmlContent)
        sNextUrl = _next_page_url(sHtmlContent)
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sName, sUrl, sThumbnail, sYear in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        sThumbnail = _absolute_url(sThumbnail)

        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('movie')
        if sYear:
            oGuiElement.setYear(sYear)
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sYear', sYear)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
        
    if not sGui and not sSearchText and not sSearchPageText:
        if sNextUrl:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)

        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showSeries(entryUrl=False, sGui=False, sSearchText=False): # Neu eingebaut da auf der Webseite nicht erkennbar ist was Serien sind und was nicht
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if not sGui and not sSearchText:
        aResult, sNextUrl = _collect_entry_pages(entryUrl, PAGE_SIZE, ignoreErrors=False)
    else:
        oRequest = cRequestHandler(entryUrl, caching=False, ignoreErrors=(sGui is not False))
        sHtmlContent = oRequest.request()
        aResult = _parse_entry_page(sHtmlContent)
        sNextUrl = _next_page_url(sHtmlContent)
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sName, sUrl, sThumbnail, sYear in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        sThumbnail = _absolute_url(sThumbnail)
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('tvshow')
        if sYear:
            oGuiElement.setYear(sYear)
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sYear', sYear)

        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        if sNextUrl:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showSeries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sHtmlContent = cRequestHandler(entryUrl).request()
    isMatch, aResult = cParser.parse(sHtmlContent, 'data-num="([^"]+)')
    if not isMatch:
        cGui().showInfo()
        return

    total = len(aResult)
    for sName in aResult:
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('episode')
        params.setParam('entryUrl', entryUrl)
        params.setParam('episode', sName)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if ParameterHandler().exist('episode'): #kommt aus showSeries
        episode = ParameterHandler().getValue('episode')
        pattern = 'data-num="{0}".*?allowfull'.format(episode)
        isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
    else:
        pattern = '<iframe.*?allowfull'
        isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatch:
            isMatch, aResult = cParser.parse(sHtmlContainer, 'src="([^"]+)')
            try:
                sUrl = aResult[0]
            except:
                pass
        if not isMatch:
            cGui().showInfo()
            return
        sHtmlContent = cRequestHandler(sUrl).request()

    isMatch, aResult = cParser.parse(sHtmlContent, 'data-link="([^"]+)')
    if isMatch:
        sQuality = '720'
        for sUrl in aResult:
            if 'youtube' in sUrl:
                continue
            elif sUrl.startswith('//'):
                sUrl = 'https:' + sUrl
            sName = cParser.urlparse(sUrl).split('.')[0].strip()
            if cConfig().isBlockedHoster(sName)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
            hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30287))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage(): # Suche für die Page Funktion
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage') # URL mit nächster Seite
    sPageLast = params.getValue('sPageLast') # Anzahl gefundener Seiten
    #sHeading = 'Bitte eine Zahl zwischen 1 und ' + str(sPageLast) + ' wählen.'
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()
