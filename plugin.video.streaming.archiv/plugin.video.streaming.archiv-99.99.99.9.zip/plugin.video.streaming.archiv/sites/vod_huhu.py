# -*- coding: utf-8 -*-
# Python 3

import json
import hashlib
import os
import re
import time
import concurrent.futures
import urllib.parse
import urllib.request

import xbmc
import xbmcgui

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

try:
    from xbmcvfs import translatePath
except Exception:
    translatePath = lambda value: value

PATH = cConfig().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'art')
SITE_IDENTIFIER = 'vod_huhu'
SITE_NAME = 'VoD - Huhu'
SITE_ICON = 'vod_huhu.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = 'www.huhu.to'
URL_MAIN = 'https://' + DOMAIN + '/'
API_BASE = URL_MAIN + 'mediaurl-%s.json'
_API_MEMORY_CACHE = {}
_RESOLVED_MEMORY_CACHE = {}
CATALOG_PAGE_SIZE = 100


def _catalog_url(kind, list_name, cursor=None, search=''):
    query = {}
    if cursor is not None:
        query['cursor'] = str(cursor)
    if search:
        query['search'] = search
    suffix = ('?' + urllib.parse.urlencode(query)) if query else ''
    return 'mediaurl://catalog/%s.%s%s' % (kind, list_name, suffix)


def _source_url(kind, tmdb_id, season=None, episode=None):
    query = {'type': kind, 'id': str(tmdb_id)}
    if season is not None:
        query['season'] = str(season)
    if episode is not None:
        query['episode'] = str(episode)
    return 'mediaurl://source/?' + urllib.parse.urlencode(query)


URL_VALUE = _catalog_url('%s', '%s')
URL_SEARCH_MOVIES = _catalog_url('movie', 'popular', search='%s')
URL_SEARCH_SERIES = _catalog_url('series', 'popular', search='%s')


def _cache_dir():
    cache_dir = os.path.join(translatePath(cConfig().getAddonInfo('profile')), 'mediaurl_cache')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    return cache_dir


def _resolved_cache_dir():
    cache_dir = os.path.join(translatePath(cConfig().getAddonInfo('profile')), 'mediaurl_resolved_cache')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    return cache_dir


def _cache_key(endpoint, payload):
    raw = endpoint + ':' + json.dumps(payload, sort_keys=True, ensure_ascii=True)
    return hashlib.md5(raw.encode('utf-8')).hexdigest()


def _resolved_key(url):
    return hashlib.md5(str(url or '').encode('utf-8')).hexdigest()


def _read_resolved_cache(url, cache_seconds=300):
    key = _resolved_key(url)
    now = time.time()
    cached = _RESOLVED_MEMORY_CACHE.get(key)
    if cached and now - cached[0] < cache_seconds:
        return cached[1]
    try:
        cache_file = os.path.join(_resolved_cache_dir(), key + '.json')
        if os.path.exists(cache_file) and now - os.path.getmtime(cache_file) < cache_seconds:
            with open(cache_file, 'rb') as handle:
                data = json.loads(handle.read().decode('utf-8', 'ignore'))
            resolved = data.get('resolved') if isinstance(data, dict) else ''
            if resolved:
                _RESOLVED_MEMORY_CACHE[key] = (now, resolved)
                return resolved
    except Exception as e:
        logger.info('%s resolved cache read failed: %s' % (SITE_NAME, e))
    return ''


def _write_resolved_cache(url, resolved):
    if not url or not resolved:
        return
    key = _resolved_key(url)
    _RESOLVED_MEMORY_CACHE[key] = (time.time(), resolved)
    try:
        cache_file = os.path.join(_resolved_cache_dir(), key + '.json')
        with open(cache_file, 'wb') as handle:
            handle.write(json.dumps({'resolved': resolved}).encode('utf-8'))
    except Exception as e:
        logger.info('%s resolved cache write failed: %s' % (SITE_NAME, e))


def _read_api_cache(endpoint, payload, cache_seconds):
    if cache_seconds <= 0:
        return None
    key = _cache_key(endpoint, payload)
    cached = _API_MEMORY_CACHE.get(key)
    now = time.time()
    if cached and now - cached[0] < cache_seconds:
        return cached[1]
    try:
        cache_file = os.path.join(_cache_dir(), key + '.json')
        if os.path.exists(cache_file) and now - os.path.getmtime(cache_file) < cache_seconds:
            with open(cache_file, 'rb') as handle:
                data = json.loads(handle.read().decode('utf-8', 'ignore'))
            _API_MEMORY_CACHE[key] = (now, data)
            return data
    except Exception as e:
        logger.info('%s cache read failed: %s' % (SITE_NAME, e))
    return None


def _write_api_cache(endpoint, payload, data):
    key = _cache_key(endpoint, payload)
    _API_MEMORY_CACHE[key] = (time.time(), data)
    try:
        cache_file = os.path.join(_cache_dir(), key + '.json')
        with open(cache_file, 'wb') as handle:
            handle.write(json.dumps(data).encode('utf-8'))
    except Exception as e:
        logger.info('%s cache write failed: %s' % (SITE_NAME, e))


def _post_api(endpoint, payload, cache_seconds=0):
    cached = _read_api_cache(endpoint, payload, cache_seconds)
    if cached is not None:
        return cached
    data = {
        'language': 'de',
        'region': 'DE',
    }
    data.update(payload)
    body = json.dumps(data).encode('utf-8')
    request = urllib.request.Request(
        API_BASE % endpoint,
        data=body,
        headers={
            'Content-Type': 'application/json; charset=utf-8',
            'Accept': 'application/json',
            'Origin': URL_MAIN.rstrip('/'),
            'Referer': URL_MAIN,
            'User-Agent': 'Mozilla/5.0',
        },
        method='POST',
    )
    try:
        response = urllib.request.urlopen(request, timeout=15)
        result = json.loads(response.read().decode('utf-8', 'ignore'))
        if cache_seconds > 0:
            _write_api_cache(endpoint, payload, result)
        return result
    except Exception as e:
        logger.error('%s API request failed (%s): %s' % (SITE_NAME, endpoint, e))
        return None


def _parse_catalog_url(entry_url):
    kind = 'movie'
    list_name = 'popular'
    cursor = None
    search = ''
    entry_url = str(entry_url or '')

    if entry_url.startswith('mediaurl://catalog/'):
        parsed = urllib.parse.urlsplit(entry_url)
        parts = parsed.path.strip('/').split('.', 1)
        query = urllib.parse.parse_qs(parsed.query)
        if len(parts) == 2:
            kind, list_name = parts
        cursor_value = (query.get('cursor') or [None])[0]
        cursor = int(cursor_value) if cursor_value not in (None, '') else None
        search = (query.get('search') or [''])[0]
        return kind, list_name, cursor, search

    # Legacy favourite/menu URLs used /web-vod/api/list?id=movie.popular.
    query = urllib.parse.parse_qs(urllib.parse.urlsplit(entry_url).query)
    legacy_id = (query.get('id') or [''])[0]
    if '.search=' in legacy_id:
        legacy_id, search = legacy_id.split('.search=', 1)
        search = urllib.parse.unquote_plus(search)
    parts = legacy_id.split('.')
    if len(parts) >= 2:
        kind, list_name = parts[0], parts[1]
    return kind, list_name, cursor, search


def _parse_source_url(source_url):
    parsed = urllib.parse.urlsplit(str(source_url or ''))
    query = urllib.parse.parse_qs(parsed.query)
    kind = (query.get('type') or ['movie'])[0]
    tmdb_id = (query.get('id') or [''])[0]
    season = (query.get('season') or [None])[0]
    episode = (query.get('episode') or [None])[0]
    return kind, tmdb_id, season, episode


def _split_media_id(media_id):
    parts = str(media_id or '').split('.', 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return 'movie', str(media_id or '')


def _catalog(kind, list_name, cursor=None, search=''):
    sort_map = {
        'popular': 'popularity',
        'trending': 'trendingDay',
    }
    cache_seconds = 60 * 30 if search else 60 * 60 * 6
    return _post_api('catalog', {
        'catalogId': 'tmdb.%s' % kind,
        'id': '',
        'adult': False,
        'search': search or '',
        'sort': sort_map.get(list_name, 'popularity'),
        'filter': {},
        'cursor': cursor,
        'limit': 100,
    }, cache_seconds=cache_seconds) or {}


def _catalog_items(kind, list_name, cursor=None, search='', target=CATALOG_PAGE_SIZE):
    items = []
    seen = set()
    next_cursor = cursor
    page_count = 0
    last_response = {}

    while len(items) < target and page_count < 5:
        page = _catalog(kind, list_name, next_cursor, search)
        last_response = page if isinstance(page, dict) else {}
        page_items = last_response.get('items') or []
        if not page_items:
            break

        added = 0
        for item in page_items:
            item_kind = item.get('type') or kind
            tmdb_id = _tmdb_id(item)
            dedupe_key = '%s.%s' % (item_kind, tmdb_id or item.get('id') or item.get('name') or len(items))
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            items.append(item)
            added += 1
            if len(items) >= target:
                break

        page_count += 1
        previous_cursor = next_cursor
        next_cursor = last_response.get('nextCursor')
        if next_cursor is None or next_cursor == previous_cursor or added == 0:
            break

    return {
        'items': items[:target],
        'nextCursor': next_cursor,
    }


def _item(kind, tmdb_id):
    return _post_api('item', {
        'type': kind,
        'ids': {'tmdb_id': str(tmdb_id)},
        'name': '',
    }, cache_seconds=60 * 60 * 12) or {}


def _sources(kind, tmdb_id, season=None, episode=None):
    payload = {
        'type': kind,
        'ids': {'tmdb_id': str(tmdb_id)},
        'name': '',
    }
    if kind == 'series':
        payload['episode'] = {
            'ids': {},
            'season': int(season or 0),
            'episode': int(episode or 0),
        }
    result = _post_api('source', payload, cache_seconds=60 * 10) or []
    return result.get('value', []) if isinstance(result, dict) else result


def _tmdb_image_size(url, size):
    url = str(url or '')
    if not url or url.endswith('/originalnull'):
        return ''
    if 'image.tmdb.org/t/p/' in url:
        parts = url.split('/t/p/', 1)
        rest = parts[1].split('/', 1)
        if len(rest) == 2:
            return parts[0] + '/t/p/' + size + '/' + rest[1]
    return url


def _image(item, key):
    images = item.get('images') or {}
    return str(images.get(key) or '')


def _tmdb_id(item):
    ids = item.get('ids') or {}
    return str(ids.get('tmdb_id') or item.get('id') or '')


def _set_item_art(oGuiElement, item):
    poster = _image(item, 'poster')
    backdrop = _image(item, 'backdrop')
    oGuiElement.setThumbnail(_tmdb_image_size(poster, 'w342') or os.path.join(ART, 'no_cover.png'))
    oGuiElement.setFanart(_tmdb_image_size(backdrop, 'w780') or 'default.png')


def _quality_from_tag(tag):
    tag = str(tag or '').strip()
    if not tag:
        return ''
    return tag.replace('p', '') if tag.lower().endswith('p') else tag


def _quality_rank(value):
    text = str(value or '').strip().lower()
    if not text:
        return 0
    if '4k' in text or '2160' in text or 'uhd' in text:
        return 2160
    if 'fhd' in text or '1080' in text:
        return 1080
    if 'hd' in text or '720' in text:
        return 720
    try:
        return int(''.join(ch for ch in text if ch.isdigit()) or 0)
    except Exception:
        return 0


def _apply_detected_quality(item, probe_reason):
    try:
        match = re.search(r'(?:hls|video|bytes):(\d{3,4}p)', str(probe_reason or ''), flags=re.I)
        item['_vod_huhu_precheck_reason'] = str(probe_reason or '')
        if not match:
            return
        real_quality = match.group(1).lower()
        old_quality = str(item.get('quality') or '')
        item['_vod_huhu_detected_quality'] = real_quality
        if old_quality.lower() != real_quality:
            item['_vod_huhu_original_quality'] = old_quality
            item['quality'] = real_quality
    except Exception:
        pass


def _display_quality(item):
    try:
        if item.get('_vod_huhu_detected_quality'):
            return str(item.get('_vod_huhu_detected_quality') or '')
        claimed = str(item.get('quality') or '').strip()
        if claimed:
            return '%sp' % claimed if claimed.isdigit() else claimed
        reason = str(item.get('_vod_huhu_precheck_reason') or item.get('_vod_huhu_probe') or '').lower()
        if reason in ('hls', 'video', 'bytes', 'octet-stream') or reason.startswith('hls') or reason.startswith('video') or reason.startswith('bytes'):
            return 'SD?'
        return claimed
    except Exception:
        return str(item.get('quality') or '')


def _quality_sort_key(item):
    height = _quality_rank(item.get('quality'))
    if height > 0:
        if not item.get('_vod_huhu_detected_quality'):
            return 9000 - min(height, 480)
        return -height
    return 9999


def _refresh_display_name(item):
    try:
        quality = _display_quality(item)
        name = str(item.get('name') or '').strip() or 'Hoster'
        language = str(item.get('languageCode') or '').strip()
        if language:
            item['displayedName'] = '%s [I]%s [%s][/I]' % (name, language, quality)
        else:
            item['displayedName'] = '%s [I][%s][/I]' % (name, quality)
    except Exception:
        pass


def _language_rank(item):
    text = ' '.join([
        str(item.get('languageCode') or ''),
        str(item.get('displayedName') or ''),
        str(item.get('name') or ''),
    ]).lower()
    if '(de)' in text or ' deutsch' in text or 'german' in text or 'sub: (de)' in text:
        return 0
    if not text.strip():
        return 1
    if '(en)' in text or '(fr)' in text or '(es)' in text or '(it)' in text or '(pl)' in text or '(tr)' in text or '(ru)' in text:
        return 2
    return 1


def _server_name(name, url):
    name = str(name or '').split('(')[0].strip()
    server_map = {
        'Server A': 'Doodstream',
        'Server B': 'Doodstream',
        'Server C': 'VOE',
        'Server E': 'Mixdrop',
        'Server G': 'Luluvideo',
        'Server M': 'Supervideo',
        'Server O': 'Vidoza',
        'Server P': 'Streamtape',
        'Server R': 'Vidsonic',
        'Server W': 'Doodstream',
        'Server Z': 'Filemoon',
    }
    for prefix, label in server_map.items():
        if name.startswith(prefix):
            return label
    try:
        return urllib.parse.urlparse(url).netloc.replace('www.', '').split('.')[0].title() or name
    except Exception:
        return name or 'Hoster'


def _split_kodi_url_headers(url):
    url = str(url or '')
    if '|' not in url:
        return url, {}
    base, header_blob = url.split('|', 1)
    headers = {}
    for part in header_blob.split('&'):
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        key = key.strip()
        if not key:
            continue
        try:
            headers[key] = urllib.parse.unquote_plus(value)
        except Exception:
            headers[key] = value
    return base, headers


def _hls_quality_from_bytes(data):
    try:
        text = (data or b'').decode('utf-8', 'ignore')
        heights = []
        for match in re.finditer(r'RESOLUTION\s*=\s*\d+\s*x\s*(\d+)', text, flags=re.I):
            try:
                height = int(match.group(1))
                if height > 0:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _mp4_quality_from_bytes(data):
    try:
        blob = data or b''
        heights = []
        start = 0
        while True:
            pos = blob.find(b'tkhd', start)
            if pos < 4:
                break
            atom_start = pos - 4
            try:
                atom_size = int.from_bytes(blob[atom_start:atom_start + 4], 'big')
                atom_end = atom_start + atom_size
                if 32 <= atom_size <= len(blob) - atom_start and atom_end >= atom_start + 8:
                    width = int.from_bytes(blob[atom_end - 8:atom_end - 4], 'big') >> 16
                    height = int.from_bytes(blob[atom_end - 4:atom_end], 'big') >> 16
                    if 240 <= height <= 2160 and 320 <= width <= 4096:
                        heights.append(height)
            except Exception:
                pass
            start = pos + 4
        for codec in (b'avc1', b'hvc1', b'hev1', b'mp4v', b'encv'):
            start = 0
            while True:
                pos = blob.find(codec, start)
                if pos < 4:
                    break
                atom_start = pos - 4
                if atom_start + 28 <= len(blob):
                    try:
                        width = int.from_bytes(blob[atom_start + 24:atom_start + 26], 'big')
                        height = int.from_bytes(blob[atom_start + 26:atom_start + 28], 'big')
                        if 240 <= height <= 2160 and 320 <= width <= 4096:
                            heights.append(height)
                    except Exception:
                        pass
                start = pos + 4
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _quality_from_url(url):
    try:
        matches = re.findall(r'(?<!\d)(\d{3,4})p(?!\d)', urllib.parse.unquote(str(url or '')).lower())
        heights = []
        for value in matches:
            try:
                height = int(value)
                if 240 <= height <= 2160:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _tail_quality_from_url(base_url, headers, timeout):
    try:
        tail_headers = dict(headers or {})
        tail_headers['Range'] = 'bytes=-1048576'
        request = urllib.request.Request(base_url, headers=tail_headers)
        response = urllib.request.urlopen(request, timeout=min(timeout, 2.5))
        data = response.read(1048576) or b''
        return _mp4_quality_from_bytes(data)
    except Exception:
        return ''


def _probe_stream_url(url, timeout=3.0):
    try:
        base_url, headers = _split_kodi_url_headers(url)
        if not base_url or '://' not in base_url:
            return False, 'empty'
        headers = dict(headers or {})
        headers.setdefault('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
        headers.setdefault('Accept', '*/*')
        headers.setdefault('Range', 'bytes=0-524287')
        request = urllib.request.Request(base_url, headers=headers)
        response = urllib.request.urlopen(request, timeout=timeout)
        content_type = str(response.headers.get('Content-Type') or '').lower()
        data = response.read(524288) or b''
        lower_head = data[:256].lower()

        if 'image/' in content_type or data.startswith(b'\x89PNG') or data.startswith(b'GIF8') or data.startswith(b'\xff\xd8'):
            return False, 'image'
        if 'text/html' in content_type or b'<html' in lower_head or b'<!doctype html' in lower_head:
            return False, 'html'
        if 'application/json' in content_type and b'#extm3u' not in lower_head:
            return False, 'json'
        if '.m3u8' in base_url.lower() or 'mpegurl' in content_type or b'#extm3u' in lower_head:
            if b'#extm3u' in lower_head or 'mpegurl' in content_type:
                real_quality = _hls_quality_from_bytes(data) or _quality_from_url(base_url)
                return True, 'hls:%s' % real_quality if real_quality else 'hls'
            return False, 'hls-empty'
        if 'video/' in content_type or 'octet-stream' in content_type:
            real_quality = _mp4_quality_from_bytes(data) or _quality_from_url(base_url) or _tail_quality_from_url(base_url, headers, timeout)
            return True, 'video:%s' % real_quality if real_quality else 'video'
        if data and not lower_head.strip().startswith((b'{', b'[', b'<')):
            real_quality = _mp4_quality_from_bytes(data) or _quality_from_url(base_url) or _tail_quality_from_url(base_url, headers, timeout)
            return True, 'bytes:%s' % real_quality if real_quality else (content_type or 'bytes')
        return False, content_type or 'unknown'
    except Exception as exc:
        return False, str(exc)[:80]


def _resolve_hoster_link(url):
    cached = _read_resolved_cache(url)
    if cached:
        return cached, 'cache'
    try:
        import resolveurl as resolver
    except Exception:
        try:
            import urlresolver as resolver
        except Exception as exc:
            return '', 'resolver-import: %s' % str(exc)[:60]
    try:
        hmf = resolver.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
        if hmf and hmf.valid_url():
            resolved = hmf.resolve()
        else:
            resolved = resolver.resolve(url)
        if resolved:
            return resolved, 'resolved'
        return '', 'no-resolve'
    except Exception as exc:
        return '', str(exc)[:100]


def _precheck_hosters(hosters):
    candidates = [dict(item) for item in (hosters or []) if isinstance(item, dict) and item.get('link')]
    if not candidates:
        return hosters

    max_items = min(len(candidates), 30)
    global_budget = 16.0
    workers = min(5, max_items)
    started = time.time()
    checked = []
    completed = 0
    playable_count = 0
    progress = None

    def progress_update(percent, message=''):
        try:
            if progress is not None:
                progress.update(int(max(0, min(100, percent))), message=message)
        except TypeError:
            try:
                progress.update(int(max(0, min(100, percent))), message)
            except Exception:
                pass
        except Exception:
            pass

    def check_one(index_item):
        index, item = index_item
        item = dict(item)
        raw_url = item.get('link')
        t0 = time.time()
        resolved, resolve_reason = _resolve_hoster_link(raw_url)
        if not resolved:
            return False, time.time() - t0, item, resolve_reason
        ok, probe_reason = _probe_stream_url(resolved, timeout=3.0)
        elapsed = time.time() - t0
        if ok:
            _write_resolved_cache(raw_url, resolved)
            _apply_detected_quality(item, probe_reason)
            _refresh_display_name(item)
            item['_vod_huhu_elapsed'] = elapsed
            item['_vod_huhu_probe'] = probe_reason
        return ok, elapsed, item, '%s/%s' % (resolve_reason, probe_reason)

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('Quellenprüfung', 'VoD-Huhu Streams werden geprüft...')
        progress_update(0, '0 von %d geprüft' % max_items)
    except Exception as exc:
        progress = None
        logger.info('%s precheck progress failed: %s' % (SITE_NAME, exc))

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=workers)
    future_map = {}
    try:
        future_map = {
            executor.submit(check_one, (idx, item)): idx
            for idx, item in enumerate(candidates[:max_items])
        }
        try:
            for future in concurrent.futures.as_completed(future_map, timeout=global_budget):
                try:
                    ok, elapsed, item, reason = future.result(timeout=0)
                    checked.append((ok, elapsed, item, reason))
                    completed += 1
                    if ok:
                        playable_count += 1
                    logger.info('%s precheck %s %.2fs: %s / %s / %s' % (
                        SITE_NAME,
                        'OK' if ok else 'DROP',
                        elapsed,
                        item.get('name'),
                        item.get('link'),
                        reason,
                    ))
                except Exception as exc:
                    completed += 1
                    logger.info('%s precheck future failed: %s' % (SITE_NAME, exc))
                progress_update(
                    100.0 * completed / float(max_items or 1),
                    '%d funktionierende von %d geprüft' % (playable_count, completed)
                )
                if time.time() - started >= global_budget:
                    break
        except concurrent.futures.TimeoutError:
            logger.info('%s precheck reached %.1fs budget' % (SITE_NAME, global_budget))
    finally:
        for future in future_map:
            try:
                future.cancel()
            except Exception:
                pass
        try:
            executor.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=False)
        try:
            progress_update(100, '%d funktionierende Quellen' % playable_count)
            if progress is not None:
                progress.close()
        except Exception:
            pass

    good = [item for ok, elapsed, item, reason in checked if ok]
    if not good:
        logger.info('%s precheck found no playable sources; keeping original hoster list' % SITE_NAME)
        return hosters

    good = sorted(
        good,
        key=lambda item: (
            _language_rank(item),
            _quality_sort_key(item),
            float(item.get('_vod_huhu_elapsed') or 99.0),
            str(item.get('name') or '').lower(),
        )
    )
    logger.info('%s precheck kept %d/%d sources in %.1fs' % (SITE_NAME, len(good), max_items, time.time() - started))
    return good


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('icon', SITE_ICON)
    params.setParam('sUrl', _catalog_url('movie', 'popular'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30547), SITE_IDENTIFIER, 'showSearchMovies'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30548), SITE_IDENTIFIER, 'showSearchSeries'), params)
    params.setParam('sUrl', _catalog_url('movie', 'trending'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30545), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', _catalog_url('series', 'popular'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', _catalog_url('series', 'trending'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30546), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')

    kind, list_name, cursor, search = _parse_catalog_url(entryUrl)
    if sSearchText and not search:
        search = sSearchText
    jSearch = _catalog_items(kind, list_name, cursor, search, CATALOG_PAGE_SIZE)
    aResults = jSearch.get('items') or []
    total = len(aResults)
    if total == 0:
        if not sGui:
            oGui.showInfo()
        return

    isTvshow = kind == 'series'
    for item in aResults:
        item_kind = item.get('type') or kind
        tmdb_id = _tmdb_id(item)
        if not tmdb_id:
            continue
        sName = str(item.get('name') or item.get('originalName') or '')
        isTvshow = item_kind == 'series'
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        release_date = str(item.get('releaseDate') or '')
        if release_date:
            oGuiElement.setYear(release_date.split('-')[0])
        if item.get('description'):
            oGuiElement.setDescription(str(item.get('description')))
        _set_item_art(oGuiElement, item)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        params.setParam('sId', '%s.%s' % (item_kind, tmdb_id))
        params.setParam('sName', sName)
        params.setParam('sUrl', _source_url(item_kind, tmdb_id))
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        next_cursor = jSearch.get('nextCursor')
        if next_cursor is not None:
            params.setParam('sUrl', _catalog_url(kind, list_name, next_cursor, search))
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    kind, tmdb_id = _split_media_id(params.getValue('sId'))
    jSearch = _item(kind, tmdb_id)
    episodes = jSearch.get('episodes') or []
    if not episodes:
        if not sGui:
            oGui.showInfo()
        return

    sThumbnail = _tmdb_image_size(_image(jSearch, 'poster'), 'w342') or os.path.join(ART, 'no_cover.png')
    sDesc = str(jSearch.get('description') or ' ')
    sFanart = _tmdb_image_size(_image(jSearch, 'backdrop'), 'w780') or 'default.png'
    seasons = sorted({str(e.get('season')) for e in episodes if e.get('season') is not None}, key=lambda x: int(x))
    total = len(seasons)
    for sSeasonNr in seasons:
        title = 'Extras' if sSeasonNr == '0' else 'Staffel ' + sSeasonNr
        oGuiElement = cGuiElement(title, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setDescription(sDesc)
        oGuiElement.setFanart(sFanart)
        oGuiElement.setMediaType('season')
        oGuiElement.setSeason(sSeasonNr)
        params.setParam('sSeasonNr', sSeasonNr)
        params.setParam('sId', '%s.%s' % (kind, tmdb_id))
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sDesc', sDesc)
        params.setParam('sFanart', sFanart)
        oGui.addFolder(oGuiElement, params, True, total)
    oGui.setView('seasons')
    oGui.setEndOfDirectory()


def showEpisodes(sGui=False):
    oGui = cGui()
    params = ParameterHandler()
    sSeasonNr = params.getValue('sSeasonNr')
    kind, tmdb_id = _split_media_id(params.getValue('sId'))
    sThumbnail = params.getValue('sThumbnail')
    sDesc = params.getValue('sDesc')
    sFanart = params.getValue('sFanart')
    jSearch = _item(kind, tmdb_id)
    episodes = [e for e in (jSearch.get('episodes') or []) if str(e.get('season')) == str(sSeasonNr)]
    episodes.sort(key=lambda e: int(e.get('episode') or 0))
    total = len(episodes)
    if total == 0:
        if not sGui:
            oGui.showInfo()
        return
    for episode in episodes:
        sEpisodeNr = str(episode.get('episode') or '')
        sName = str(episode.get('name') or '')
        oGuiElement = cGuiElement('Episode ' + sEpisodeNr + ' - ' + sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setEpisode(sEpisodeNr)
        oGuiElement.setSeason(sSeasonNr)
        oGuiElement.setMediaType('episode')
        oGuiElement.setThumbnail(_tmdb_image_size(episode.get('poster'), 'w342') or sThumbnail)
        oGuiElement.setDescription(str(episode.get('description') or sDesc))
        oGuiElement.setFanart(sFanart)
        params.setParam('sUrl', _source_url('series', tmdb_id, sSeasonNr, sEpisodeNr))
        oGui.addFolder(oGuiElement, params, False, total)
    oGui.setView('episodes')
    oGui.setEndOfDirectory()


def showHosters(sGui=False):
    oGui = sGui if sGui else cGui()
    hosters = []
    params = ParameterHandler()
    kind, tmdb_id, season, episode = _parse_source_url(params.getValue('sUrl'))
    aResults = _sources(kind, tmdb_id, season, episode)
    if not aResults:
        if not sGui:
            oGui.showInfo()
        return

    sLanguage = cConfig().getSetting('prefLanguage')
    for item in aResults:
        if item.get('type') != 'url':
            continue
        hUrl = str(item.get('url') or '')
        if not hUrl.startswith('http'):
            continue
        languages = item.get('languages') or []
        sLang = str(languages[0] if languages else '').lower()
        if sLanguage == '1' and sLang == 'en':
            continue
        if sLanguage == '2' and sLang == 'de':
            continue
        if sLanguage == '3':
            oGui.showLanguage()
            continue
        display_lang = {'de': '(DE)', 'en': '(EN)'}.get(sLang, '(' + sLang.upper() + ')' if sLang else '')
        sName = _server_name(item.get('name'), hUrl)
        sQuality = _quality_from_tag(item.get('tag'))
        hosters.append({
            'link': hUrl,
            'name': sName,
            'displayedName': '%s [I]%s [%s][/I]' % (sName, display_lang, sQuality),
            'quality': sQuality,
            'languageCode': display_lang,
        })
    if hosters:
        hosters = _precheck_hosters(hosters)
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    resolved = _read_resolved_cache(sUrl)
    if resolved:
        logger.info('%s resolved stream served from precheck cache: %s' % (SITE_NAME, sUrl))
        return [{'streamUrl': resolved, 'resolved': True}]
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearchMovies():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30287))
    if not sSearchText:
        return
    _searchMovies(False, sSearchText)
    cGui().setEndOfDirectory()


def _searchMovies(oGui, sSearchText):
    showEntries(_catalog_url('movie', 'popular', search=sSearchText), oGui)


def showSearchSeries():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30288))
    if not sSearchText:
        return
    _searchSeries(False, sSearchText)
    cGui().setEndOfDirectory()


def _searchSeries(oGui, sSearchText):
    showEntries(_catalog_url('series', 'popular', search=sSearchText), oGui)


def _search(oGui, sSearchText):
    showEntries(_catalog_url('movie', 'popular', search=sSearchText), oGui, sSearchText)
    showEntries(_catalog_url('series', 'popular', search=sSearchText), oGui, sSearchText)
