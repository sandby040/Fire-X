# -*- coding: utf-8 -*-
# Python 3


# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showGenre:     48 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'einschalten'
SITE_NAME = 'Einschalten'
SITE_ICON = 'einschalten.png'
PAGE_SIZE = 100

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'einschalten.in') # Domain Auswahl über die Streaming Archiv Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
URL_MOVIES = URL_MAIN + '/movies'
URL_NEW_MOVIES = URL_MAIN + '/movies/new'
URL_GENRES = URL_MAIN + '/genres'
URL_LAST_MOVIES = URL_MAIN + '/movies/recently-added'
URL_COLLECTIONS = URL_MAIN + '/collections'
URL_SEARCH = URL_MAIN + '/search?query=%s'
URL_THUMBNAIL = URL_MAIN + '/api/image/poster'


def _append_page(entryUrl, iPage):
    if iPage <= 0:
        return entryUrl
    separator = '&' if '?' in entryUrl else '?'
    return entryUrl + separator + 'page=' + str(iPage)


def _safe_page(value):
    try:
        page = int(value)
    except:
        page = 1
    if page <= 0:
        page = 1
    return page


def _request_page(entryUrl, iPage, cacheTime=0, ignoreErrors=False):
    oRequest = cRequestHandler(_append_page(entryUrl, iPage), ignoreErrors=ignoreErrors)
    if cacheTime:
        oRequest.cacheTime = cacheTime
    return oRequest.request()


def _parse_movie_entries(sHtmlContent):
    pattern = '{"id":([^,"]+).*?title":"([^"]+).*?Date":"([^-]+).*?"posterPath":"([^"]+).*?collectionId":([^}]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    return aResult if isMatch else []


def _parse_collection_entries(sHtmlContent):
    pattern = '{"id":([^,"]+).*?name":"([^"]+).*?"overview":"([^"]*).*?"posterPath":"([^"]+).*?"backdropPath":"([^"]*).*?"releaseDateFrom":"([^"]*).*?"releaseDateTo":"([^"]*).*?"voteAverage":([^,}\\]]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    return aResult if isMatch else []


def _collect_entry_pages(entryUrl, startPage, parser, limit=PAGE_SIZE, cacheTime=0, ignoreErrors=False):
    page = _safe_page(startPage)
    results = []
    while len(results) < limit:
        page_results = parser(_request_page(entryUrl, page, cacheTime, ignoreErrors))
        if not page_results:
            break
        results.extend(page_results)
        page += 1
    return results, page


def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_NEW_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30541), SITE_IDENTIFIER, 'showEntries'), params)  # New Movies
    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    params.setParam('sUrl', URL_LAST_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30549), SITE_IDENTIFIER, 'showEntriesLast'), params)  # Recently added movies
    params.setParam('sUrl', URL_COLLECTIONS)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30543), SITE_IDENTIFIER, 'showCollections'), params)  # Collections
    params.setParam('sUrl', URL_GENRES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenre'), params)    # Genre
    cGui().setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    oRequest = cRequestHandler(URL_GENRES)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '{"id":([^,"]+).*?name":"([^"]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return
    for sUrl, sName in aResult:
        entryUrl = URL_MOVIES + '?genre=' + sUrl
        params.setParam('sUrl', entryUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showGenreEntries'), params)
    cGui().setEndOfDirectory()


def showGenreEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        cacheTime = 60 * 60 * 6  # 6 Stunden
    else:
        cacheTime = 0
    if not sGui and not sSearchText:
        aResult, nextPage = _collect_entry_pages(entryUrl, params.getValue('page'), _parse_movie_entries, cacheTime=cacheTime, ignoreErrors=False)
    else:
        aResult = _parse_movie_entries(_request_page(entryUrl, _safe_page(params.getValue('page')), cacheTime, (sGui is not False)))
        nextPage = _safe_page(params.getValue('page')) + 1
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sYear, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setYear(sYear)
        oGuiElement.setThumbnail(URL_THUMBNAIL + sThumbnail)
        oGuiElement.setMediaType('movie')
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, False, total)
    if not sGui and not sSearchText:
        params.setParam('page', int(nextPage))
        params.setParam('sUrl', entryUrl)
        oGui.addNextPage(SITE_IDENTIFIER, 'showGenreEntries', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        cacheTime = 60 * 60 * 6  # 6 Stunden
    else:
        cacheTime = 0
    if not sGui and not sSearchText:
        aResult, nextPage = _collect_entry_pages(entryUrl, params.getValue('page'), _parse_movie_entries, cacheTime=cacheTime, ignoreErrors=False)
    else:
        aResult = _parse_movie_entries(_request_page(entryUrl, _safe_page(params.getValue('page')), cacheTime, (sGui is not False)))
        nextPage = _safe_page(params.getValue('page')) + 1
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sYear, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setYear(sYear)
        oGuiElement.setThumbnail(URL_THUMBNAIL + sThumbnail)
        oGuiElement.setMediaType('movie')
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, False, total)
    if not sGui and not sSearchText:
        params.setParam('page', int(nextPage))
        params.setParam('sUrl', entryUrl)
        oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showCollections(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        cacheTime = 60 * 60 * 6  # 6 Stunden
    else:
        cacheTime = 0
    if not sGui and not sSearchText:
        aResult, nextPage = _collect_entry_pages(entryUrl, params.getValue('page'), _parse_collection_entries, cacheTime=cacheTime, ignoreErrors=False)
    else:
        aResult = _parse_collection_entries(_request_page(entryUrl, _safe_page(params.getValue('page')), cacheTime, (sGui is not False)))
        nextPage = _safe_page(params.getValue('page')) + 1
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sOverview, sThumbnail, sBackdrop, sDateFrom, sDateTo, sRating in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER,'showCollectionEntries')
        oGuiElement.setThumbnail(URL_THUMBNAIL + sThumbnail)
        if sBackdrop:
            oGuiElement.setFanart(URL_THUMBNAIL + sBackdrop)
        description_parts = []
        if sDateFrom:
            oGuiElement.addItemValue('premiered', sDateFrom)
            try:
                oGuiElement.setYear(str(sDateFrom)[:4])
            except:
                pass
        try:
            rating_value = round(float(str(sRating).replace(',', '.')), 1)
            oGuiElement.addItemValue('TMDb_Rating', rating_value)
            description_parts.append('[COLOR blue]Bewertung: %.1f[/COLOR]' % rating_value)
        except:
            pass
        if sDateTo and sDateTo != sDateFrom:
            description_parts.append('Zeitraum: %s bis %s' % (sDateFrom, sDateTo))
        if sOverview:
            description_parts.append(sOverview)
        if description_parts:
            oGuiElement.setDescription('\n\n'.join(description_parts).strip())
        oGuiElement.setMediaType('movie')
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui and not sSearchText:
        params.setParam('page', int(nextPage))
        params.setParam('sUrl', entryUrl)
        oGui.addNextPage(SITE_IDENTIFIER, 'showCollections', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showCollectionEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = URL_COLLECTIONS + '/' + params.getValue('entryUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '{"id":([^,"]+).*?title":"([^"]+).*?Date":"([^-]+).*?"posterPath":"([^"]+).*?collectionId":([^}]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return
    total = len(aResult)
    for sUrl, sName, sYear, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setYear(sYear)
        oGuiElement.setThumbnail(URL_THUMBNAIL + sThumbnail)
        oGuiElement.setMediaType('movie')
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, False, total)
    if not sGui and not sSearchText:
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showEntriesLast(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        cacheTime = 60 * 60 * 6  # 6 Stunden
    else:
        cacheTime = 0
    if not sGui and not sSearchText:
        aResult, nextPage = _collect_entry_pages(entryUrl, params.getValue('page'), _parse_movie_entries, cacheTime=cacheTime, ignoreErrors=False)
    else:
        aResult = _parse_movie_entries(_request_page(entryUrl, _safe_page(params.getValue('page')), cacheTime, (sGui is not False)))
        nextPage = _safe_page(params.getValue('page')) + 1
    if not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sYear, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setYear(sYear)
        oGuiElement.setThumbnail(URL_THUMBNAIL + sThumbnail)
        oGuiElement.setMediaType('movie')
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, False, total)
    if not sGui and not sSearchText:
        params.setParam('page', int(nextPage))
        params.setParam('sUrl', entryUrl)
        oGui.addNextPage(SITE_IDENTIFIER, 'showEntriesLast', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showHosters():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    hosters = []
    sUrl = URL_MAIN + '/api/movies/' + entryUrl + '/watch'
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = 'streamUrl":"([^"]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch: return
    sQuality = '720'
    for sUrl in aResult:
        sName = cParser.urlparse(sUrl)
        if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
        hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
        hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30287))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)
