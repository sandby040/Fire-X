# -*- coding: utf-8 -*-
# Python 3

#Always pay attention to the translations in the menu!
# Sprachauswahl für Hoster enthalten.
# Ajax Suchfunktion enthalten.
# HTML LangzeitCache hinzugefügt
# showValue:     24 Stunden
# showAllSeries: 24 Stunden
# showEpisodes:   4 Stunden
# SSsearch:      24 Stunden
    
# 2022-12-06 Heptamer - Suchfunktion überarbeitet

import re
import xbmcgui
from html import unescape
from urllib.parse import urljoin
from urllib.request import HTTPRedirectHandler, Request, build_opener
from urllib.error import HTTPError

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser, cUtil
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'aniworld'
SITE_NAME = 'AniWorld'
SITE_ICON = 'aniworld.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain') # Domain Auswahl über die Streaming Archiv Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'https://aniworld.to'
URL_SERIES = URL_MAIN + '/animes'
URL_POPULAR = URL_MAIN + '/beliebte-animes'
URL_NEW_EPISODES = URL_MAIN + '/neue-episoden'
URL_LOGIN = URL_MAIN + '/login'
REFERER = 'https://' + DOMAIN

#

def _normalize_thumbnail(sThumbnail):
    if not sThumbnail:
        return ''
    sThumbnail = str(sThumbnail).strip()
    if sThumbnail.startswith('//'):
        sThumbnail = 'https:' + sThumbnail
    elif sThumbnail.startswith('/'):
        sThumbnail = URL_MAIN + sThumbnail
    if 'data:image' in sThumbnail:
        return ''
    return sThumbnail.replace('format=webp', 'format=jpg').replace('format=avif', 'format=jpg')


def _clean_html_text(sValue):
    if not sValue:
        return ''
    sValue = re.sub('<[^>]+>', ' ', sValue)
    sValue = unescape(sValue)
    return re.sub(r'\s+', ' ', sValue).strip()


def _extract_image_from_html(sHtml):
    oMatch = re.search(r'<img[^>]*data-src="([^"]+)"', sHtml, re.S)
    if not oMatch:
        oMatch = re.search(r'<img[^>]*src="([^"]+)"', sHtml, re.S)
    return _normalize_thumbnail(oMatch.group(1)) if oMatch else ''


def _get_homepage_section_content(sHtmlContent, sHeading):
    oMatch = re.search(
        r'<h2>\s*%s\s*</h2>(.*?)(?=<div class="pageTitle15|<ul class="homeContentGenresList"|<div class="shoutbox"|$)' % re.escape(sHeading),
        sHtmlContent,
        re.S
    )
    return oMatch.group(1) if oMatch else ''


def _parse_homepage_section_entries(sHtmlContent, sHeading):
    sSection = _get_homepage_section_content(sHtmlContent, sHeading)
    if not sSection:
        return []

    aEntries = []
    aSeen = set()

    if 'coverListItem' in sSection:
        aBlocks = re.findall(r'(<div class="coverListItem">\s*<a .*?</a></div>)', sSection, re.S)
        for sBlock in aBlocks:
            oUrl = re.search(r'<a[^>]*href="([^"]+)"', sBlock, re.S)
            oTitle = re.search(r'<h3>(.*?)</h3>', sBlock, re.S)
            if not oUrl or not oTitle:
                continue
            sUrl = oUrl.group(1)
            if sUrl in aSeen:
                continue
            aSeen.add(sUrl)
            oDesc = re.search(r'<small>(.*?)</small>', sBlock, re.S)
            aEntries.append({
                'url': sUrl,
                'title': _clean_html_text(oTitle.group(1)),
                'thumbnail': _extract_image_from_html(sBlock),
                'description': _clean_html_text(oDesc.group(1)) if oDesc else ''
            })
    else:
        aBlocks = re.findall(r'(<a href="/anime/stream/[^"]+".*?</a>)', sSection, re.S)
        for sBlock in aBlocks:
            oUrl = re.search(r'<a[^>]*href="([^"]+)"', sBlock, re.S)
            oTitle = re.search(r'<h3>(.*?)</h3>', sBlock, re.S)
            if not oUrl or not oTitle:
                continue
            sUrl = oUrl.group(1)
            if sUrl in aSeen:
                continue
            aSeen.add(sUrl)
            oDesc = re.search(r'<h4>(.*?)</h4>', sBlock, re.S)
            aEntries.append({
                'url': sUrl,
                'title': _clean_html_text(oTitle.group(1)),
                'thumbnail': _extract_image_from_html(sBlock),
                'description': _clean_html_text(oDesc.group(1)) if oDesc else ''
            })

    return aEntries


def _create_series_gui_element(sTitle, sDisplayTitle=None, sThumbnail='', sDescription=''):
    oGuiElement = cGuiElement(sDisplayTitle or sTitle, SITE_IDENTIFIER, 'showSeasons')
    oGuiElement.setMediaType('tvshow')
    oGuiElement.setTVShowTitle(sTitle)
    oGuiElement.setForceMeta(True)
    oGuiElement.setMetaAdvanced(False)
    sThumbnail = _normalize_thumbnail(sThumbnail)
    if sThumbnail:
        oGuiElement.setThumbnail(sThumbnail)
    if sDescription:
        oGuiElement.setDescription(sDescription)
    return oGuiElement

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    username = cConfig().getSetting('aniworld.user')    # Username
    password = cConfig().getSetting('aniworld.pass')    # Password
    if username == '' or password == '':                # If no username and password were set, close the plugin!
        xbmcgui.Dialog().ok(cConfig().getLocalizedString(30241), cConfig().getLocalizedString(30263))   # Info Dialog!
    else:
        params = ParameterHandler()
        params.setParam('sUrl', URL_MAIN)
        params.setParam('sHeading', 'Derzeit beliebt')
        cGui().addFolder(cGuiElement('Derzeit beliebt', SITE_IDENTIFIER, 'showHomepageSection'), params)

        params = ParameterHandler()
        params.setParam('sUrl', URL_SERIES)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search

        params = ParameterHandler()
        params.setParam('sUrl', URL_NEW_EPISODES)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30516), SITE_IDENTIFIER, 'showNewEpisodes'), params)  # New Episodes

        params = ParameterHandler()
        params.setParam('sUrl', URL_MAIN)
        params.setParam('sHeading', 'Das sehen andere AniWorld Nutzer')
        cGui().addFolder(cGuiElement('Das sehen andere AniWorld-Nutzer', SITE_IDENTIFIER, 'showHomepageSection'), params)

        params = ParameterHandler()
        params.setParam('sUrl', URL_POPULAR)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showEntries'), params)    # Popular Series

        params = ParameterHandler()
        params.setParam('sUrl', URL_MAIN)
        params.setParam('sCont', 'homeContentGenresList')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)    # Genre

        params = ParameterHandler()
        params.setParam('sUrl', URL_MAIN)
        params.setParam('sCont', 'catalogNav')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showValue'), params)    # From A-Z

        cGui().setEndOfDirectory()


def showHomepageSection():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl') or URL_MAIN
    sHeading = params.getValue('sHeading')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()
    aEntries = _parse_homepage_section_entries(sHtmlContent, sHeading)
    if not aEntries:
        cGui().showInfo()
        return

    oGui = cGui()
    total = len(aEntries)
    for aEntry in aEntries:
        oGuiElement = _create_series_gui_element(
            aEntry.get('title', ''),
            sThumbnail=aEntry.get('thumbnail', ''),
            sDescription=aEntry.get('description', '')
        )
        p = ParameterHandler()
        sEntryUrl = aEntry.get('url', '')
        if not sEntryUrl.startswith('http'):
            sEntryUrl = URL_MAIN + sEntryUrl
        p.setParam('sUrl', sEntryUrl)
        p.setParam('sName', aEntry.get('title', ''))
        p.setParam('TVShowTitle', aEntry.get('title', ''))
        if aEntry.get('thumbnail'):
            p.setParam('sThumbnail', aEntry.get('thumbnail'))
        oGui.addFolder(oGuiElement, p, True, total)
    oGui.setView('tvshows')
    oGui.setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, '<ul[^>]*class="%s"[^>]*>(.*?)<\\/ul>' % params.getValue('sCont'))
    if isMatch:
        isMatch, aResult = cParser.parse(sContainer, '<li>\s*<a[^>]*href="([^"]*)"[^>]*>(.*?)<\\/a>\s*<\\/li>')
    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        sUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showAllSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*href="(\\/anime\\/[^"]*)"[^>]*>(.*?)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = _create_series_gui_element(sName)
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sUrl)
        p.setParam('sName', sName)
        p.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, p, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showNewEpisodes(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4 # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="col-md-[^"]*"[^>]*>\s*<a[^>]*href="([^"]*)"[^>]*>\s*<strong>([^<]+)</strong>\s*<span[^>]*>([^<]+)</span>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sInfo in aResult:
        sMovieTitle = sName + ' ' + sInfo
        oGuiElement = _create_series_gui_element(sName, sMovieTitle)
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sUrl)
        p.setParam('sName', sName)
        p.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, p, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6 # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    #Aufbau pattern
    #'<div[^>]*class="col-md-[^"]*"[^>]*>.*?'  # start element
    #'<a[^>]*href="([^"]*)"[^>]*>.*?'  # url
    #'<img[^>]*src="([^"]*)"[^>]*>.*?'  # thumbnail
    #'<h3>(.*?)<span[^>]*class="paragraph-end">.*?'  # title
    #'<\\/div>'  # end element
    pattern = '<div[^>]*class="col-md-[^"]*"[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>.*?<img[^>]*src="([^"]*)"[^>]*>.*?<h3>(.*?)<span[^>]*class="paragraph-end">.*?</div>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sThumbnail, sName in aResult:
        sThumbnail = _normalize_thumbnail(sThumbnail)
        oGuiElement = _create_series_gui_element(sName, sThumbnail=sThumbnail)
        p = ParameterHandler()
        p.setParam('sUrl', URL_MAIN + sUrl)
        p.setParam('sName', sName)
        p.setParam('TVShowTitle', sName)
        if sThumbnail:
            p.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, p, True, total)
    if not sGui:
        pattern = 'pagination">.*?<a href="([^"]+)">&gt;</a>.*?</a></div>'
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="hosterSiteDirectNav"[^>]*>.*?<ul>(.*?)</ul>'
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        pattern = '<a[^>]*href="([^"]*)"[^>]*title="([^"]*)"[^>]*>(.*?)</a>.*?'
        isMatch, aResult = cParser.parse(sContainer, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<p[^>]*data-full-description="(.*?)"[^>]*>')
    isThumbnail, sThumbnail = cParser.parseSingleResult(sHtmlContent, '<div[^>]*class="seriesCoverBox"[^>]*>.*?<img[^>]*src="([^"]*)"[^>]*>')
    if isThumbnail:
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail

    total = len(aResult)
    for sUrl, sName, sNr in aResult:
        isMovie = sUrl.endswith('filme')
        if 'Alle Filme' in sName:
            sName = 'Filme'
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season' if not isMovie else 'movie')
        if isThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        if not isMovie:
            oGuiElement.setTVShowTitle(sTVShowTitle)
            oGuiElement.setSeason(sNr)
            params.setParam('sSeason', sNr)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sUrl', URL_MAIN + sUrl)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    sSeason = params.getValue('sSeason')
    sThumbnail = params.getValue('sThumbnail')
    if not sSeason:
        sSeason = '0'
    isMovieList = sUrl.endswith('filme')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<table[^>]*class="seasonEpisodesList"[^>]*>(.*?)</table>'
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        if isMovieList == True:
            pattern = '<tr[^>]*data-episode-season-id="(\d+).*?<a href="([^"]+)">\s([^<]+).*?<strong>([^<]+)'
            isMatch, aResult = cParser.parse(sContainer, pattern)
            if not isMatch:
                pattern = '<tr[^>]*data-episode-season-id="(\d+).*?<a href="([^"]+)">\s([^<]+).*?<span>([^<]+)'
                isMatch, aResult = cParser.parse(sContainer, pattern)
        else:
            pattern = '<tr[^>]*data-episode-season-id="(\d+).*?<a href="([^"]+).*?(?:<strong>(.*?)</strong>.*?)?(?:<span>(.*?)</span>.*?)?<'
            isMatch, aResult = cParser.parse(sContainer, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<p[^>]*data-full-description="(.*?)"[^>]*>')
    total = len(aResult)
    for sID, sUrl2, sNameGer, sNameEng in aResult:
        sName = '%d - ' % int(sID)
        if isMovieList == True:
            sName += sNameGer + '- ' + sNameEng
        else:
            sName += sNameGer if sNameGer else sNameEng
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode' if not isMovieList else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        if not isMovieList:
            oGuiElement.setSeason(sSeason)
            oGuiElement.setEpisode(int(sID))
            oGuiElement.setTVShowTitle(sTVShowTitle)
        params.setParam('sUrl', URL_MAIN + sUrl2)
        params.setParam('entryUrl', sUrl)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes' if not isMovieList else 'movies')
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('sUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain') == 'www.aniworld.info':
        pattern = '<li[^>]*episodeLink([^"]+)"\sdata-lang-key="([^"]+).*?data-link-target="([^"]+).*?<h4>([^<]+)<([^>]+)'
        pattern2 = 'itemprop="keywords".content=".*?Season...([^"]+).S.*?'  # HD Kennzeichen
        # data-lang-key="1" Deutsch
        # data-lang-key="2" Japanisch mit englischen Untertitel
        # data-lang-key="3" Japanisch mit deutschen Untertitel
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
        aResult2 = cParser.parse(sHtmlContent, pattern2)  # pattern 2 auslesen
        if isMatch:
            for sID, sLang, sUrl, sName, sQuality in aResult:
                # Die Funktion gibt 2 werte zurück!
                # element 1 aus array "[0]" True bzw. False
                # element 2 aus array "[1]" Name von domain / hoster - wird hier nicht gebraucht!
                sUrl = sUrl.replace('/dl/2010', '/redirect/' + sID)
                if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                sLanguage = cConfig().getSetting('prefLanguage')
                if sLanguage == '1':        # Voreingestellte Sprache Deutsch in settings.xml
                    if '2' in sLang:        # data-lang-key="2" Japanisch mit englischen Untertitel
                        continue
                    elif '3' in sLang:        # data-lang-key="3" Japanisch mit deutschen Untertitel
                        continue
                    elif sLang == '1':        # data-lang-key="1" Deutsch
                        sLang = '(DE)'      # Anzeige der Sprache Deutsch
                if sLanguage == '2':        # Voreingestellte Sprache Englisch in settings.xml
                    cGui().showLanguage()   # Kein Eintrag in der ausgewählten Sprache verfügbar
                    continue
                if sLanguage == '3':        # Voreingestellte Sprache Japanisch in settings.xml
                    if '1' in sLang:        # data-lang-key="1" Deutsch
                        continue
                    elif sLang == '3':        # data-lang-key="3" Japanisch mit deutschen Untertitel
                        sLang = '(JPN) Sub: (DE)'  # Anzeige der Sprache Japanisch mit deutschen Untertitel
                    elif sLang == '2':       # data-lang-key="2" Japanisch mit englischen Untertitel
                        sLang = '(JPN) Sub: (EN)'   # Anzeige der Sprache Japanisch mit englischen Untertitel
                if sLanguage == '0':        # Alle Sprachen
                    if sLang == '1':    # data-lang-key="1"
                        sLang = '(DE)'   # Anzeige der Sprache
                    elif sLang == '3':  # data-lang-key="3"
                        sLang = '(JPN) Sub: (DE)'  # Anzeige der Sprache Japanisch mit deutschen Untertitel
                    elif sLang == '2':    # data-lang-key="2"
                        sLang = '(JPN) Sub: (EN)'   # Anzeige der Sprache Japanisch mit englischen Untertitel
                if 'HD' in aResult2[1]:  # Prüfen ob tuple aResult2 das Kennzeichen HD enthält, dann übersteuern
                    sQuality = '720'
                else:
                    sQuality = '480'
                    # Ab hier wird der sName mit abgefragt z.B:
                    # aus dem Log [serienstream]: ['/redirect/12286260', 'VOE']
                    # hier ist die sUrl = '/redirect/12286260' und der sName 'VOE'
                    # hoster.py 194
                hoster = {'link': [sUrl, sName], 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'quality': sQuality, 'languageCode': sLang} # Language Code für hoster.py Sprache Prio
                hosters.append(hoster)
            if hosters:
                hosters.append('getHosterUrl')
            if not hosters:
                cGui().showLanguage()
            return hosters
    else:
        pattern = '<li[^>]*data-lang-key="([^"]+).*?data-link-target="([^"]+).*?<h4>([^<]+)<([^>]+)'
        pattern2 = 'itemprop="keywords".content=".*?Season...([^"]+).S.*?'  # HD Kennzeichen
        # data-lang-key="1" Deutsch
        # data-lang-key="2" Japanisch mit englischen Untertitel
        # data-lang-key="3" Japanisch mit deutschen Untertitel
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
        aResult2 = cParser.parse(sHtmlContent, pattern2)  # pattern 2 auslesen
        if isMatch:
            for sLang, sUrl, sName, sQuality in aResult:
                # Die Funktion gibt 2 werte zurück!
                # element 1 aus array "[0]" True bzw. False
                # element 2 aus array "[1]" Name von domain / hoster - wird hier nicht gebraucht!
                if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                sLanguage = cConfig().getSetting('prefLanguage')
                if sLanguage == '1':  # Voreingestellte Sprache Deutsch in settings.xml
                    if '2' in sLang:  # data-lang-key="2" Japanisch mit englischen Untertitel
                        continue
                    elif '3' in sLang:  # data-lang-key="3" Japanisch mit deutschen Untertitel
                        continue
                    elif sLang == '1':  # data-lang-key="1" Deutsch
                        sLang = '(DE)'  # Anzeige der Sprache Deutsch
                if sLanguage == '2':  # Voreingestellte Sprache Englisch in settings.xml
                    cGui().showLanguage()  # Kein Eintrag in der ausgewählten Sprache verfügbar
                    continue
                if sLanguage == '3':  # Voreingestellte Sprache Japanisch in settings.xml
                    if '1' in sLang:  # data-lang-key="1" Deutsch
                        continue
                    elif sLang == '3':  # data-lang-key="3" Japanisch mit deutschen Untertitel
                        sLang = '(JPN) Sub: (DE)'  # Anzeige der Sprache Japanisch mit deutschen Untertitel
                    elif sLang == '2':  # data-lang-key="2" Japanisch mit englischen Untertitel
                        sLang = '(JPN) Sub: (EN)'  # Anzeige der Sprache Japanisch mit englischen Untertitel
                if sLanguage == '0':  # Alle Sprachen
                    if sLang == '1':  # data-lang-key="1"
                        sLang = '(DE)'  # Anzeige der Sprache
                    elif sLang == '3':  # data-lang-key="3"
                        sLang = '(JPN) Sub: (DE)'  # Anzeige der Sprache Japanisch mit deutschen Untertitel
                    elif sLang == '2':  # data-lang-key="2"
                        sLang = '(JPN) Sub: (EN)'  # Anzeige der Sprache Japanisch mit englischen Untertitel
                if 'HD' in aResult2[1]:  # Prüfen ob tuple aResult2 das Kennzeichen HD enthält, dann übersteuern
                    sQuality = '720'
                else:
                    sQuality = '480'
                    # Ab hier wird der sName mit abgefragt z.B:
                    # aus dem Log [serienstream]: ['/redirect/12286260', 'VOE']
                    # hier ist die sUrl = '/redirect/12286260' und der sName 'VOE'
                    # hoster.py 194
                hoster = {'link': [sUrl, sName], 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'quality': sQuality, 'languageCode': sLang} # Language Code für hoster.py Sprache Prio
                hosters.append(hoster)
            if hosters:
                hosters.append('getHosterUrl')
            if not hosters:
                cGui().showLanguage()
            return hosters


def getHosterUrl(hUrl):
    if type(hUrl) == str: hUrl = eval(hUrl)
    referer = ParameterHandler().getValue('sUrl') or ParameterHandler().getValue('entryUrl') or URL_MAIN
    if 'voe' in hUrl[1].lower():
        sUrl = _get_redirect_location(URL_MAIN + hUrl[0], referer)
        if sUrl:
            return [{'streamUrl': sUrl, 'resolved': False}]

    username = cConfig().getSetting('aniworld.user')
    password = cConfig().getSetting('aniworld.pass')
    if username and password:
        Handler = cRequestHandler(URL_LOGIN, caching=False, ignoreErrors=True)
        Handler.addHeaderEntry('Upgrade-Insecure-Requests', '1')
        Handler.addHeaderEntry('Referer', referer)
        Handler.addParameters('email', username)
        Handler.addParameters('password', password)
        Handler.request()

    Request = cRequestHandler(URL_MAIN + hUrl[0], caching=False)
    Request.addHeaderEntry('Referer', referer)
    Request.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    Request.request()
    sUrl = Request.getRealUrl()

    if 'voe' in hUrl[1].lower():
        isBlocked, sDomain = cConfig().isBlockedHoster(sUrl)  # Die funktion gibt 2 werte zurück!
        if isBlocked:
            logger.info('[%s] unresolved VOE redirect kept original url: %s' % (SITE_IDENTIFIER, sUrl))

    return [{'streamUrl': sUrl, 'resolved': False}]


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, hdrs, newurl):
        return None


def _get_redirect_location(url, referer):
    request = Request(url)
    request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
    request.add_header('Accept-Language', 'de,en-US;q=0.7,en;q=0.3')
    request.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8')
    request.add_header('Connection', 'keep-alive')
    if referer:
        request.add_header('Referer', referer)
    try:
        response = build_opener(_NoRedirect).open(request, timeout=int(cConfig().getSetting('requestTimeout', 10)))
        location = response.headers.get('Location')
        if location:
            return urljoin(url, location)
        real_url = response.geturl()
        if real_url and real_url != url:
            return real_url
        content = response.read().decode('utf-8', 'replace')
        match = re.search(r'https?://(?:www\.)?voe\.[^/"\']+/e/[A-Za-z0-9_-]+', content)
        if match:
            return match.group(0)
        logger.info('[%s] redirect lookup returned no VOE location, status: %s' % (SITE_IDENTIFIER, getattr(response, 'status', '')))
    except HTTPError as e:
        if 300 <= e.code < 400:
            location = e.headers.get('Location')
            if location:
                return urljoin(url, location)
        logger.info('[%s] redirect lookup failed: %s' % (SITE_IDENTIFIER, str(e)))
    except Exception as e:
        logger.info('[%s] redirect lookup failed: %s' % (SITE_IDENTIFIER, str(e)))
    return ''


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    params.getValue('sSearchText')
    oRequest = cRequestHandler(URL_SERIES, caching=True, ignoreErrors=(sGui is not False))
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', REFERER  + '/animes')
    oRequest.addHeaderEntry('Origin', REFERER)
    oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24  # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()

    if not sHtmlContent:
            return

    sst = sSearchText.lower()

    pattern = '<li><a data.+?href="([^"]+)".+?">(.*?)\<\/a><\/l' #link - title

    aResult = cParser.parse(sHtmlContent, pattern)

    if not aResult[0]:
        oGui.showInfo()
        return

    total = len(aResult[1])
    for link, title in aResult[1]:
        titleLow = title.lower()
        if not sst in titleLow and not cUtil.isSimilarByToken(sst, titleLow):
            continue
        else:
            #get images thumb / descr pro call. (optional)
            try:
                sThumbnail, sDescription = getMetaInfo(link, title)
                oGuiElement = _create_series_gui_element(title, sThumbnail=sThumbnail, sDescription=sDescription)
                p = ParameterHandler()
                p.setParam('sUrl', URL_MAIN + link)
                p.setParam('sName', title)
                p.setParam('TVShowTitle', title)
                oGui.addFolder(oGuiElement, p, True, total)
            except Exception:
                oGuiElement = _create_series_gui_element(title)
                p = ParameterHandler()
                p.setParam('sUrl', URL_MAIN + link)
                p.setParam('sName', title)
                p.setParam('TVShowTitle', title)
                oGui.addFolder(oGuiElement, p, True, total)

        if not sGui:
            oGui.setView('tvshows')


def getMetaInfo(link, title):   # Setzen von Metadata in Suche:
    oGui = cGui()
    oRequest = cRequestHandler(URL_MAIN + link, caching=False)
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', REFERER + '/animes')
    oRequest.addHeaderEntry('Origin', REFERER)

    #GET CONTENT OF HTML
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return

    pattern = 'seriesCoverBox">.*?<img src="([^"]+)"\ al.+?data-full-description="([^"]+)"' #img , descr

    aResult = cParser.parse(sHtmlContent, pattern)

    if not aResult[0]:
        return

    for sImg, sDescr in aResult[1]:
        return sImg, sDescr
