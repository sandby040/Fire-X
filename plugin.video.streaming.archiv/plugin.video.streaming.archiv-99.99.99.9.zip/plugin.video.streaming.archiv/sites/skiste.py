# -*- coding: utf-8 -*-
# Python 3

import re
from datetime import datetime
from json import loads

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'skiste'
SITE_NAME = 'SKiste'
SITE_ICON = 'skiste.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'streamkiste.sx')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

ORIGIN = 'https://' + DOMAIN + '/'
REFERER = ORIGIN
URL_BROWSE = ORIGIN + 'data/browse/?lang=%s&type=%s&order_by=%s&page=%s'
URL_SEARCH = ORIGIN + 'data/browse/?lang=%s&keyword=%s&page=%s&limit=0'
URL_GENRE = ORIGIN + 'data/browse/?lang=%s&type=%s&order_by=%s&genre=%s&page=%s'
URL_CAST = ORIGIN + 'data/browse/?lang=%s&type=%s&order_by=%s&cast=%s&page=%s'
URL_YEAR = ORIGIN + 'data/browse/?lang=%s&type=%s&order_by=%s&year=%s&page=%s'
URL_WATCH = ORIGIN + 'data/watch/?_id=%s'
URL_THUMBNAIL = 'https://image.tmdb.org/t/p/w300%s'


def _get_language():
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '1':
        return '2'
    if sLanguage == '2':
        return '3'
    if sLanguage == '3':
        cGui().showLanguage()
        return None
    return 'all'


def _get_genres(sLanguage):
    if sLanguage in ['2', 'all']:
        return {
            'Action': 'Action',
            'Abenteuer': 'Abenteuer',
            'Animation': 'Animation',
            'Biographie': 'Biographie',
            'Dokumentation': 'Dokumentation',
            'Drama': 'Drama',
            'Familie': 'Familie',
            'Fantasy': 'Fantasy',
            'Geschichte': 'Geschichte',
            'Horror': 'Horror',
            'Komödie': 'Komödie',
            'Krieg': 'Krieg',
            'Krimi': 'Krimi',
            'Musik': 'Musik',
            'Mystery': 'Mystery',
            'Romantik': 'Romantik',
            'Reality-TV': 'Reality-TV',
            'Sci-Fi': 'Sci-Fi',
            'Sports': 'Sport',
            'Thriller': 'Thriller',
            'Western': 'Western'
        }
    return {
        'Action': 'Action',
        'Adventure': 'Abenteuer',
        'Animation': 'Animation',
        'Biography': 'Biographie',
        'Comedy': 'Komödie',
        'Crime': 'Krimi',
        'Documentation': 'Dokumentation',
        'Drama': 'Drama',
        'Family': 'Familie',
        'Fantasy': 'Fantasy',
        'History': 'Geschichte',
        'Horror': 'Horror',
        'Music': 'Musik',
        'Mystery': 'Mystery',
        'Romance': 'Romantik',
        'Reality-TV': 'Reality-TV',
        'Sci-Fi': 'Sci-Fi',
        'Sports': 'Sport',
        'Thriller': 'Thriller',
        'War': 'Krieg',
        'Western': 'Western'
    }


def _get_quality(sQuality):
    isMatch, aResult = cParser.parse(sQuality, '(HDCAM|HD|WEB|BLUERAY|BRRIP|DVD|TS|SD|CAM)', 1, True)
    if isMatch:
        return aResult[0]
    return sQuality


def load():
    logger.info('Load %s' % SITE_NAME)
    sLanguage = _get_language()
    if not sLanguage:
        return

    params = ParameterHandler()
    params.setParam('sLanguage', sLanguage)
    params.setParam('sUrl', URL_BROWSE % (sLanguage, 'movies', 'new', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_SEARCH)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMovieMenu'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30551), SITE_IDENTIFIER, 'showGenreMMenu'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeriesMenu'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30529), SITE_IDENTIFIER, 'showGenreSMenu'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showYearsMenu'), params)
    cGui().addFolder(cGuiElement('Schauspieler Suche', SITE_IDENTIFIER, 'showSearchActor'), params)
    cGui().setEndOfDirectory()


def showMovieMenu():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    items = [
        ('Trending', URL_BROWSE % (sLanguage, 'movies', 'Trending', '1')),
        ('Neue Filme', URL_BROWSE % (sLanguage, 'movies', 'new', '1')),
        ('Views', URL_BROWSE % (sLanguage, 'movies', 'views', '1')),
        ('Rating', URL_BROWSE % (sLanguage, 'movies', 'rating', '1')),
        ('Votes', URL_BROWSE % (sLanguage, 'movies', 'votes', '1')),
        ('Updates', URL_BROWSE % (sLanguage, 'movies', 'updates', '1')),
        ('Name', URL_BROWSE % (sLanguage, 'movies', 'name', '1')),
        ('Featured', URL_BROWSE % (sLanguage, 'movies', 'featured', '1')),
        ('Requested', URL_BROWSE % (sLanguage, 'movies', 'requested', '1')),
        ('Releases', URL_BROWSE % (sLanguage, 'movies', 'releases', '1'))
    ]
    for title, url in items:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showSeriesMenu():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    items = [
        ('Trending', URL_BROWSE % (sLanguage, 'series', 'Trending', '1')),
        ('Neue Serien', URL_BROWSE % (sLanguage, 'series', 'new', '1')),
        ('Views', URL_BROWSE % (sLanguage, 'series', 'views', '1')),
        ('Rating', URL_BROWSE % (sLanguage, 'series', 'rating', '1')),
        ('Votes', URL_BROWSE % (sLanguage, 'series', 'votes', '1')),
        ('Updates', URL_BROWSE % (sLanguage, 'series', 'updates', '1')),
        ('Name', URL_BROWSE % (sLanguage, 'series', 'name', '1')),
        ('Featured', URL_BROWSE % (sLanguage, 'series', 'featured', '1')),
        ('Requested', URL_BROWSE % (sLanguage, 'series', 'requested', '1')),
        ('Releases', URL_BROWSE % (sLanguage, 'series', 'releases', '1'))
    ]
    for title, url in items:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showGenreMMenu():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    for genre, searchGenre in _get_genres(sLanguage).items():
        params.setParam('sUrl', URL_GENRE % (sLanguage, 'movies', 'new', searchGenre, '1'))
        cGui().addFolder(cGuiElement(genre, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showGenreSMenu():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    for genre, searchGenre in _get_genres(sLanguage).items():
        params.setParam('sUrl', URL_GENRE % (sLanguage, 'series', 'new', searchGenre, '1'))
        cGui().addFolder(cGuiElement(genre, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showYearsMenu():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    currentYear = datetime.now().year
    for year in range(currentYear, 1949, -1):
        params.setParam('sUrl', URL_YEAR % (sLanguage, 'movies', 'new', year, '1'))
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showSearchActor():
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not sLanguage:
        return
    sName = cGui().showKeyBoard(sHeading='Schauspieler suchen')
    if not sName:
        return
    showEntries(URL_CAST % (sLanguage, 'movies', 'new', cParser.quotePlus(sName), '1'))
    cGui().setEndOfDirectory()


def _build_plot(movie, title):
    if movie.get('storyline'):
        return str(movie['storyline'])
    if movie.get('overview'):
        return str(movie['overview'])
    return '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]'.format(SITE_NAME, title)


def _build_thumbnail(movie):
    if movie.get('poster_path_season'):
        return URL_THUMBNAIL % str(movie['poster_path_season'])
    if movie.get('poster_path'):
        return URL_THUMBNAIL % str(movie['poster_path'])
    if movie.get('backdrop_path'):
        return URL_THUMBNAIL % str(movie['backdrop_path'])
    return ''


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    sLanguage = params.getValue('sLanguage') or _get_language()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')

    try:
        oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
        if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
            oRequest.cacheTime = 60 * 60 * 6
        oRequest.addHeaderEntry('Referer', REFERER)
        oRequest.addHeaderEntry('Origin', ORIGIN.rstrip('/'))
        aJson = loads(oRequest.request())
    except Exception:
        if not sGui:
            oGui.showInfo()
        return

    movies = aJson.get('movies')
    if not isinstance(movies, list) or not movies:
        if not sGui:
            oGui.showInfo()
        return

    valid_movies = [movie for movie in movies if '_id' in movie]
    if not valid_movies:
        if not sGui:
            oGui.showInfo()
        return

    total = len(valid_movies)
    lastIsTvshow = False
    for movie in valid_movies:
        sTitle = str(movie.get('title', '')).strip()
        if not sTitle:
            continue
        if sSearchText and not cParser.search(sSearchText, sTitle):
            continue

        isTvshow = 'Staffel' in sTitle or 'Season' in sTitle
        lastIsTvshow = isTvshow
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        sThumbnail = _build_thumbnail(movie)
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setDescription(_build_plot(movie, sTitle))
        if 'year' in movie and len(str(movie['year'])) == 4:
            oGuiElement.setYear(movie['year'])
        if movie.get('quality'):
            oGuiElement.setQuality(_get_quality(movie['quality']))
        if movie.get('rating'):
            oGuiElement.addItemValue('rating', movie['rating'])
        if 'lang' in movie:
            if sLanguage != '1' and movie['lang'] == 2:
                oGuiElement.setLanguage('DE')
            if sLanguage != '2' and movie['lang'] == 3:
                oGuiElement.setLanguage('EN')
        if movie.get('runtime'):
            isMatch, sRuntime = cParser.parseSingleResult(str(movie['runtime']), '\\d+')
            if isMatch:
                oGuiElement.addItemValue('duration', sRuntime)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')

        params.setParam('entryUrl', URL_WATCH % str(movie['_id']))
        params.setParam('sName', sTitle)
        params.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        pager = aJson.get('pager', {})
        currentPage = pager.get('currentPage')
        totalPages = pager.get('totalPages')
        if isinstance(currentPage, int) and isinstance(totalPages, int) and currentPage < totalPages:
            sNextUrl = re.sub(r'page=\\d+', 'page=' + str(currentPage + 1), entryUrl)
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if lastIsTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sName = params.getValue('sName')
    try:
        oRequest = cRequestHandler(sUrl)
        if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
            oRequest.cacheTime = 60 * 60 * 4
        oRequest.addHeaderEntry('Referer', REFERER)
        oRequest.addHeaderEntry('Origin', ORIGIN.rstrip('/'))
        aJson = loads(oRequest.request())
    except Exception:
        cGui().showInfo()
        return

    if 'streams' not in aJson or len(aJson['streams']) == 0:
        cGui().showInfo()
        return

    seasons = sorted(set(int(stream['s']) for stream in aJson['streams'] if 's' in stream))
    total = len(seasons)
    for seasonNr in seasons:
        oGuiElement = cGuiElement('Staffel ' + str(seasonNr), SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setTVShowTitle(sName)
        oGuiElement.setSeason(seasonNr)
        oGuiElement.setMediaType('season')
        params.setParam('season', seasonNr)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    try:
        oRequest = cRequestHandler(sUrl)
        if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
            oRequest.cacheTime = 60 * 60 * 4
        oRequest.addHeaderEntry('Referer', REFERER)
        oRequest.addHeaderEntry('Origin', ORIGIN.rstrip('/'))
        aJson = loads(oRequest.request())
    except Exception:
        cGui().showInfo()
        return

    if 'streams' not in aJson or len(aJson['streams']) == 0:
        cGui().showInfo()
        return

    episodes = sorted(set(int(stream['e']) for stream in aJson['streams'] if 'e' in stream and str(stream.get('s')) == str(sSeason)))
    total = len(episodes)
    for episodeNr in episodes:
        oGuiElement = cGuiElement('Episode ' + str(episodeNr), SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setSeason(sSeason)
        oGuiElement.setTVShowTitle(params.getValue('sName'))
        oGuiElement.setEpisode(episodeNr)
        oGuiElement.setMediaType('episode')
        params.setParam('episode', episodeNr)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sEpisode = params.getValue('episode')
    try:
        oRequest = cRequestHandler(sUrl, caching=False)
        oRequest.addHeaderEntry('Referer', REFERER)
        oRequest.addHeaderEntry('Origin', ORIGIN.rstrip('/'))
        aJson = loads(oRequest.request())
    except Exception:
        return hosters

    if 'streams' not in aJson:
        return hosters

    index = 0
    for stream in aJson['streams']:
        if sEpisode and str(stream.get('e')) != str(sEpisode):
            continue
        if not sEpisode and 'e' in stream:
            continue
        stream_url = stream.get('stream')
        if not stream_url:
            continue
        sHoster = str(index) + ':'
        isMatch, aName = cParser.parse(stream_url, '//([^/]+)/')
        if isMatch:
            sName = aName[0][:aName[0].rindex('.')]
            if cConfig().isBlockedHoster(sName)[0]:
                continue
            sHoster += ' ' + sName
        if stream.get('release'):
            sHoster += ' [I][' + _get_quality(stream['release']) + '][/I]'
        hosters.append({'link': stream_url, 'name': sHoster})
        index += 1

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    sLanguage = _get_language()
    if not sLanguage:
        return
    showEntries(URL_SEARCH % (sLanguage, cParser.quotePlus(sSearchText), '1'), oGui, sSearchText)
