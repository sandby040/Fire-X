
## Willkommen bei Streaming Archiv für Kodi!!


![Streaming Archiv logo](https://raw.githubusercontent.com/streaming-archiv-local/StreamingArchivRepoWeb/gh-pages/config/plugin.png)

Streaming Archiv ist ein Video-Addon für Kodi. Streaming Archiv dient als Suchmaschine für Filme und Serien auf verschiedenen Webseiten. Streaming Archiv verfügt über eine intuitive und optisch ansprechende Benutzeroberfläche, wobei man direkt in den einzelnen Sitplugins der Webseiten nach Streams suchen kann, oder alle Webseiten gemeinsam durchsucht.

Sowohl der Funktionsumfang von Streaming Archiv als auch das Angebot an Webseiten-Inhalten wird von den beteiligten Entwicklern stetig weiterentwickelt bzw. um neue Webseiten erweitert.

Diese werden auch als Site-Plugins bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! Der bereitgestellte Inhalt der Webseiten steht in keinem Bezug zu Streaming Archiv oder den Entwicklern! Streaming Archiv läuft ausschließlich unter Python 3 und funktioniert somit ab Kodi Version 19 und höher!

***

Habt Ihr Fragen rund um Streaming Archiv findet Ihr sicher eure Antworten in unserer Wiki bzw. FAQ.

[![FaQ aufrufen](https://raw.githubusercontent.com/streaming-archiv-local/StreamingArchivRepo/repo/config/faq.png)](https://github.com/streaming-archiv-local/StreamingArchivRepoWeb/wiki)

***

Für alles weitere findet Ihr auch Informationen auf unserer Webseite die Ihr auch als Quelle in Kodi einbinden könnt.

[![Web Portal aufrufen](https://raw.githubusercontent.com/streaming-archiv-local/StreamingArchivRepo/repo/config/web.png)](https://streaming-archiv-local.github.io/StreamingArchivRepoWeb/)

***

Oder nutzt unseren Chat wenn Ihr irgendwelche anderen Fragen um Streaming Archiv beantwortet haben möchtet.

[![Gitter Chat](https://raw.githubusercontent.com/streaming-archiv-local/StreamingArchivRepo/repo/config/gitter.png)](https://gitter.im/streaming-archiv-local/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

[![Matrix.to Chat](https://raw.githubusercontent.com/streaming-archiv-local/StreamingArchivRepo/repo/config/element.png)](https://matrix.to/#/#streaming-archiv-local_community:gitter.im)
