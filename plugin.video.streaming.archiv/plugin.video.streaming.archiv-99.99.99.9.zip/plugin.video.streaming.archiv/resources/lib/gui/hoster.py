# -*- coding: utf-8 -*-
# Python 3
#
# 24.01.23 - Heptamer: Korrektur getpriorities (nun werden alle Hoster gelesen und sortiert)
# 22.12.24 - Heptamer: m3u8 und mpd Files über inputstream adaptive abspielen lassen

import xbmc
import xbmcgui 
import xbmcplugin
import concurrent.futures
import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from resources.lib.player import cPlayer
from resources.lib.tools import logger

try:
    from xbmcvfs import translatePath
except Exception:
    translatePath = lambda value: value


STREAMING_ARCHIV_PRECHECK_SITES = {
    'moflix-stream',
    'filmpalast',
    'einschalten',
    'streamcloud',
    'serienstream',
    'aniworld',
}
_RESOLVED_PRECHECK_MEMORY_CACHE = {}


def _precheck_cache_dir():
    cache_dir = os.path.join(translatePath(cConfig().getAddonInfo('profile')), 'hoster_precheck_cache')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    return cache_dir


def _precheck_key(url):
    return hashlib.md5(str(url or '').encode('utf-8')).hexdigest()


def _read_precheck_cache(url, cache_seconds=300):
    key = _precheck_key(url)
    now = time.time()
    cached = _RESOLVED_PRECHECK_MEMORY_CACHE.get(key)
    if cached and now - cached[0] < cache_seconds:
        return cached[1]
    try:
        cache_file = os.path.join(_precheck_cache_dir(), key + '.json')
        if os.path.exists(cache_file) and now - os.path.getmtime(cache_file) < cache_seconds:
            with open(cache_file, 'rb') as handle:
                data = json.loads(handle.read().decode('utf-8', 'ignore'))
            resolved = data.get('resolved') if isinstance(data, dict) else ''
            if resolved:
                _RESOLVED_PRECHECK_MEMORY_CACHE[key] = (now, resolved)
                return resolved
    except Exception as exc:
        logger.info('-> [hoster]: precheck cache read failed: %s' % exc)
    return ''


def _write_precheck_cache(url, resolved):
    if not url or not resolved:
        return
    key = _precheck_key(url)
    _RESOLVED_PRECHECK_MEMORY_CACHE[key] = (time.time(), resolved)
    try:
        cache_file = os.path.join(_precheck_cache_dir(), key + '.json')
        with open(cache_file, 'wb') as handle:
            handle.write(json.dumps({'resolved': resolved}).encode('utf-8'))
    except Exception as exc:
        logger.info('-> [hoster]: precheck cache write failed: %s' % exc)


def _split_kodi_url_headers(url):
    url = str(url or '')
    if '|' not in url:
        return url, {}
    base, header_blob = url.split('|', 1)
    headers = {}
    for part in header_blob.split('&'):
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        key = key.strip()
        if not key:
            continue
        try:
            headers[key] = urllib.parse.unquote_plus(value)
        except Exception:
            headers[key] = value
    return base, headers


def _hls_quality_from_bytes(data):
    try:
        text = (data or b'').decode('utf-8', 'ignore')
        heights = []
        for match in re.finditer(r'RESOLUTION\s*=\s*\d+\s*x\s*(\d+)', text, flags=re.I):
            try:
                height = int(match.group(1))
                if height > 0:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _mp4_quality_from_bytes(data):
    try:
        blob = data or b''
        heights = []
        start = 0
        while True:
            pos = blob.find(b'tkhd', start)
            if pos < 4:
                break
            atom_start = pos - 4
            try:
                atom_size = int.from_bytes(blob[atom_start:atom_start + 4], 'big')
                atom_end = atom_start + atom_size
                if 32 <= atom_size <= len(blob) - atom_start and atom_end >= atom_start + 8:
                    width = int.from_bytes(blob[atom_end - 8:atom_end - 4], 'big') >> 16
                    height = int.from_bytes(blob[atom_end - 4:atom_end], 'big') >> 16
                    if 240 <= height <= 2160 and 320 <= width <= 4096:
                        heights.append(height)
            except Exception:
                pass
            start = pos + 4
        for codec in (b'avc1', b'hvc1', b'hev1', b'mp4v', b'encv'):
            start = 0
            while True:
                pos = blob.find(codec, start)
                if pos < 4:
                    break
                atom_start = pos - 4
                if atom_start + 28 <= len(blob):
                    try:
                        width = int.from_bytes(blob[atom_start + 24:atom_start + 26], 'big')
                        height = int.from_bytes(blob[atom_start + 26:atom_start + 28], 'big')
                        if 240 <= height <= 2160 and 320 <= width <= 4096:
                            heights.append(height)
                    except Exception:
                        pass
                start = pos + 4
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _quality_from_url(url):
    try:
        matches = re.findall(r'(?<!\d)(\d{3,4})p(?!\d)', urllib.parse.unquote(str(url or '')).lower())
        heights = []
        for value in matches:
            try:
                height = int(value)
                if 240 <= height <= 2160:
                    heights.append(height)
            except Exception:
                pass
        if heights:
            return '%sp' % max(heights)
    except Exception:
        pass
    return ''


def _tail_quality_from_url(base_url, headers, timeout):
    try:
        tail_headers = dict(headers or {})
        tail_headers['Range'] = 'bytes=-1048576'
        request = urllib.request.Request(base_url, headers=tail_headers)
        response = urllib.request.urlopen(request, timeout=min(timeout, 2.5))
        data = response.read(1048576) or b''
        return _mp4_quality_from_bytes(data)
    except Exception:
        return ''


def _probe_stream_url(url, timeout=3.0):
    try:
        base_url, headers = _split_kodi_url_headers(url)
        if not base_url or '://' not in base_url:
            return False, 'empty'
        headers = dict(headers or {})
        headers.setdefault('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
        headers.setdefault('Accept', '*/*')
        headers.setdefault('Range', 'bytes=0-524287')
        request = urllib.request.Request(base_url, headers=headers)
        response = urllib.request.urlopen(request, timeout=timeout)
        content_type = str(response.headers.get('Content-Type') or '').lower()
        data = response.read(524288) or b''
        lower_head = data[:256].lower()

        if 'image/' in content_type or data.startswith(b'\x89PNG') or data.startswith(b'GIF8') or data.startswith(b'\xff\xd8'):
            return False, 'image'
        if 'text/html' in content_type or b'<html' in lower_head or b'<!doctype html' in lower_head:
            return False, 'html'
        if 'application/json' in content_type and b'#extm3u' not in lower_head:
            return False, 'json'
        if '.m3u8' in base_url.lower() or 'mpegurl' in content_type or b'#extm3u' in lower_head:
            if b'#extm3u' in lower_head or 'mpegurl' in content_type:
                real_quality = _hls_quality_from_bytes(data) or _quality_from_url(base_url)
                return True, 'hls:%s' % real_quality if real_quality else 'hls'
            return False, 'hls-empty'
        if 'video/' in content_type or 'octet-stream' in content_type:
            real_quality = _mp4_quality_from_bytes(data) or _quality_from_url(base_url) or _tail_quality_from_url(base_url, headers, timeout)
            return True, 'video:%s' % real_quality if real_quality else 'video'
        if data and not lower_head.strip().startswith((b'{', b'[', b'<')):
            real_quality = _mp4_quality_from_bytes(data) or _quality_from_url(base_url) or _tail_quality_from_url(base_url, headers, timeout)
            return True, 'bytes:%s' % real_quality if real_quality else (content_type or 'bytes')
        return False, content_type or 'unknown'
    except Exception as exc:
        return False, str(exc)[:80]


def _raw_hoster_link(hoster):
    try:
        link = hoster.get('link')
        return link[0] if isinstance(link, list) else link
    except Exception:
        return ''


def _quality_rank(value):
    text = str(value or '').strip().lower()
    if not text:
        return 0
    if '4k' in text or '2160' in text or 'uhd' in text:
        return 2160
    if 'fhd' in text or '1080' in text:
        return 1080
    if 'hd' in text or '720' in text:
        return 720
    try:
        return int(''.join(ch for ch in text if ch.isdigit()) or 0)
    except Exception:
        return 0


def _apply_detected_quality(item, probe_reason):
    try:
        match = re.search(r'(?:hls|video|bytes):(\d{3,4}p)', str(probe_reason or ''), flags=re.I)
        item['_streaming_archiv_precheck_reason'] = str(probe_reason or '')
        if not match:
            return
        real_quality = match.group(1).lower()
        old_quality = str(item.get('quality') or '')
        item['_streaming_archiv_detected_quality'] = real_quality
        if old_quality.lower() != real_quality:
            item['_streaming_archiv_original_quality'] = old_quality
            item['quality'] = real_quality
    except Exception:
        pass


def _display_quality(item):
    try:
        if item.get('_streaming_archiv_detected_quality'):
            return str(item.get('_streaming_archiv_detected_quality') or '')
        claimed = str(item.get('quality') or '').strip()
        if claimed:
            return '%sp' % claimed if claimed.isdigit() else claimed
        reason = str(item.get('_streaming_archiv_precheck_reason') or item.get('_streaming_archiv_precheck_probe') or '').lower()
        if reason in ('hls', 'video', 'bytes', 'octet-stream') or reason.startswith('hls') or reason.startswith('video') or reason.startswith('bytes'):
            return 'SD?'
        return claimed
    except Exception:
        return str(item.get('quality') or '')


def _quality_sort_key(item):
    height = _quality_rank(item.get('quality'))
    if height > 0:
        if not item.get('_streaming_archiv_detected_quality'):
            return 9000 - min(height, 480)
        return -height
    return 9999


def _refresh_display_name(item):
    try:
        quality = _display_quality(item)
        name = str(item.get('name') or '').strip() or 'Hoster'
        language = str(item.get('languageCode') or '').strip()
        if language:
            item['displayedName'] = '%s [I]%s [%s][/I]' % (name, language, quality)
        else:
            item['displayedName'] = '%s [I][%s][/I]' % (name, quality)
    except Exception:
        pass


def _language_rank(item):
    text = ' '.join([
        str(item.get('languageCode') or ''),
        str(item.get('displayedName') or ''),
        str(item.get('name') or ''),
    ]).lower()
    # Echte deutsche Tonspur soll vor Untertiteln stehen.
    # AniWorld schreibt z.B. "(DE)" fuer Deutsch und "(JPN) Sub: (DE)" fuer
    # Japanisch mit deutschen Untertiteln. Vorher war beides derselbe Rang,
    # weil in beiden Texten "(DE)" vorkommt.
    if 'sub: (de)' in text:
        return 1
    if '(de)' in text or ' deutsch' in text or 'german' in text:
        return 0
    if not text.strip():
        return 2
    if '(en)' in text or '(fr)' in text or '(es)' in text or '(it)' in text or '(pl)' in text or '(tr)' in text or '(ru)' in text:
        return 3
    return 2


def _resolve_for_precheck(url):
    cached = _read_precheck_cache(url)
    if cached:
        return cached, 'cache'
    try:
        import resolveurl as resolver
    except Exception:
        try:
            import urlresolver as resolver
        except Exception as exc:
            return '', 'resolver-import: %s' % str(exc)[:60]
    try:
        hmf = resolver.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
        if hmf and hmf.valid_url():
            resolved = hmf.resolve()
        else:
            resolved = resolver.resolve(url)
        if resolved:
            return resolved, 'resolved'
        return '', 'no-resolve'
    except Exception as exc:
        return '', str(exc)[:100]


class cHosterGui:
    SITE_NAME = 'cHosterGui'

    def __init__(self):
        self.maxHoster = int(cConfig().getSetting('maxHoster', 100))
        self.dialog = False

    # TODO: unify parts of play, download etc.
    def _getInfoAndResolve(self, siteResult):
        oGui = cGui()
        params = ParameterHandler()
        # get data
        mediaUrl = params.getValue('sMediaUrl')
        fileName = params.getValue('MovieTitle')
        try:
            try:
                import resolveurl as resolver
            except:
                import urlresolver as resolver
            # resolve
            if siteResult:
                mediaUrl = siteResult.get('streamUrl', False)
                mediaId = siteResult.get('streamID', False)
                if mediaUrl:
                    logger.info('-> [hoster]: resolve: ' + mediaUrl)
                    cached_link = '' if siteResult.get('resolved') else _read_precheck_cache(mediaUrl)
                    if cached_link:
                        logger.info('-> [hoster]: using prechecked stream for: ' + mediaUrl)
                        link = cached_link
                    else:
                        link = mediaUrl if siteResult['resolved'] else resolver.resolve(mediaUrl)
                elif mediaId:
                    logger.info('-> [hoster]: resolve: hoster: %s - mediaID: %s' % (siteResult['host'], mediaId))
                    link = resolver.HostedMediaFile(host=siteResult['host'].lower(), media_id=mediaId).resolve()
                else:
                    oGui.showError('xStream', cConfig().getLocalizedString(30134), 5)
                    return False
            elif mediaUrl:
                logger.info('-> [hoster]: resolve: ' + mediaUrl)
                link = resolver.resolve(mediaUrl)
            else:
                oGui.showError('xStream', cConfig().getLocalizedString(30134), 5)
                return False
        except resolver.resolver.ResolverError as e:
            logger.error('-> [hoster]: ResolverError: %s' % e)
            oGui.showError('xStream', cConfig().getLocalizedString(30135), 7)
            return False
        except Exception as e:
            logger.error('-> [hoster]: Resolve failed: %s' % e)
            oGui.showError('xStream', cConfig().getLocalizedString(30135), 7)
            return False
        # resolver response
        if link is not False:
            data = {'title': fileName, 'season': params.getValue('season'), 'episode': params.getValue('episode'), 'showTitle': params.getValue('TVShowTitle'), 'thumb': params.getValue('thumb'), 'link': link}
            return data
        return False

    def play(self, siteResult=False):
        logger.info('-> [hoster]: attempt to play file')
        data = self._getInfoAndResolve(siteResult)
        if not data:
            return False
        if self.dialog:
            try:
                self.dialog.close()
            except:
                pass

        vers = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])

        logger.info('-> [hoster]: play file link: ' + str(data['link']))
        list_item = xbmcgui.ListItem(path=data['link'])
        #m3u8 und mpd via inputstream, exklusive Filemoon, da IA mit dem Hoster nicht unter Android läuft
        if not 'filemoon' in siteResult['streamUrl']:
            if '.mpd' in data['link']:
                list_item.setProperty("inputstream", "inputstream.adaptive")
                if vers < 21: list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                list_item.setMimeType('application/dash+xml')
                if '|' in data['link']:
                    data['link'], header = data['link'].split('|')
                    list_item.setProperty('inputstream.adaptive.stream_headers', header)
                    if vers > 19: list_item.setProperty('inputstream.adaptive.manifest_headers', header)
            elif '.m3u8' in data['link']:
                source_url = str(siteResult.get('streamUrl', '') if isinstance(siteResult, dict) else '')
                if 'moflix' in source_url.lower() or 'moflix' in str(data['link']).lower():
                    list_item.setProperty("inputstream", "inputstream.adaptive")
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    if '|' in data['link']:
                        stream_url, header = data['link'].split('|', 1)
                        list_item.setProperty('inputstream.adaptive.stream_headers', header)
                        if vers > 19: list_item.setProperty('inputstream.adaptive.manifest_headers', header)
                        data['link'] = stream_url + '|' + header
                list_item.setMimeType("application/vnd.apple.mpegurl")

        if 'youtube' in data['link']:
            import time
            time.sleep(1)
        info = {'Title': data['title']}
        if data['thumb']:
            list_item.setArt(data['thumb'])
        if data['showTitle']:
            info['Episode'] = data['episode']
            info['Season'] = data['season']
            info['TVShowTitle'] = data['showTitle']

        #Neuer Video-Tag, mit Kodi 19 nicht kompatibel, daher folgende Abfrage
        kodi_version = xbmc.getInfoLabel('System.BuildVersion')
        if kodi_version[:2] < '20':
            list_item.setInfo(type="Video", infoLabels=info)
        else:
            vtag = list_item.getVideoInfoTag()
            vtag.setMediaType('video')
            if 'Title' in info:
                try:
                    vtag.setTitle(str(info['Title']))
                except: pass
            if 'Season' in info:
                try:
                    vtag.setSeason(int(info['Season']))
                except: pass
            if 'Episode' in info:
                try:
                    vtag.setEpisode(int(info['Episode']))
                except: pass
            if 'TVShowTitle' in info:
                try:
                    vtag.setTvShowTitle(info['TVShowTitle'])
                except: pass

        list_item.setProperty('IsPlayable', 'true')
        if cGui().pluginHandle > 0:
            xbmcplugin.setResolvedUrl(cGui().pluginHandle, True, list_item)
        else:
            xbmc.Player().play(data['link'], list_item)
        return cPlayer().startPlayer()

    def addToPlaylist(self, siteResult=False):
        oGui = cGui()
        logger.info('-> [hoster]: attempt addToPlaylist')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        logger.info('-> [hoster]: addToPlaylist file link: ' + str(data['link']))
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(self.SITE_NAME)
        oGuiElement.setMediaUrl(data['link'])
        oGuiElement.setTitle(data['title'])
        if data['thumb']:
            oGuiElement.setThumbnail(data['thumb'])
        if data['showTitle']:
            oGuiElement.setEpisode(data['episode'])
            oGuiElement.setSeason(data['season'])
            oGuiElement.setTVShowTitle(data['showTitle'])
        if self.dialog:
            self.dialog.close()
        oPlayer = cPlayer()
        oPlayer.addItemToPlaylist(oGuiElement)
        oGui.showInfo(cConfig().getLocalizedString(30136), cConfig().getLocalizedString(30137), 5)
        return True

    def download(self, siteResult=False):
        from resources.lib.download import cDownload
        logger.info('-> [hoster]: attempt download')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        logger.info('-> [hoster]: download file link: ' + data['link'])
        if self.dialog:
            self.dialog.close()
        oDownload = cDownload()
        oDownload.download(data['link'], data['title'])
        return True

    def sendToPyLoad(self, siteResult=False):
        from resources.lib.handler.pyLoadHandler import cPyLoadHandler
        logger.info('-> [hoster]: attempt download with pyLoad')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        cPyLoadHandler().sendToPyLoad(data['title'], data['link'])
        return True

    def sendToJDownloader(self, sMediaUrl=False):
        from resources.lib.handler.jdownloaderHandler import cJDownloaderHandler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to JDownloader: ' + sMediaUrl)
        cJDownloaderHandler().sendToJDownloader(sMediaUrl)

    def sendToJDownloader2(self, sMediaUrl=False):
        from resources.lib.handler.jdownloader2Handler import cJDownloader2Handler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to JDownloader2: ' + sMediaUrl)
        cJDownloader2Handler().sendToJDownloader2(sMediaUrl)

    def sendToMyJDownloader(self, sMediaUrl=False, sMovieTitle='xStream'):
        from resources.lib.handler.myjdownloaderHandler import cMyJDownloaderHandler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        sMovieTitle = params.getValue('MovieTitle')
        if not sMovieTitle:
            sMovieTitle = params.getValue('Title')
        if not sMovieTitle:  # only temporary
            sMovieTitle = params.getValue('sMovieTitle')
        if not sMovieTitle:
            sMovieTitle = params.getValue('title')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to My.JDownloader: ' + sMediaUrl)
        cMyJDownloaderHandler().sendToMyJDownloader(sMediaUrl, sMovieTitle)

    def __getPriorities(self, hosterList, filter=True):
        # Sort hosters based on their resolvers priority.
        ranking = []
        # handles multihosters but is about 10 times slower
        for hoster in hosterList:

            # we try to load resolveurl within the loop, making sure that the resolver loads new with every cycle
            try:
                import resolveurl as resolver
            except:
                import urlresolver as resolver
                 
            # accept hoster which is marked as resolveable by sitePlugin
            if hoster.get('resolveable', False):
                ranking.append([0, hoster])
                continue
             
            try:
                # serienstream VOE hoster = {'link': [sUrl, sName], aus array "[0]" True bzw. False
                link = hoster['link'][0] if isinstance(hoster['link'], list) else hoster['link']
                hmf = resolver.HostedMediaFile(url=link)
                #hmf = resolver.HostedMediaFile(url=hoster['link'])
            except:
                continue

            if not hmf.valid_url():
                hmf = resolver.HostedMediaFile(host=hoster['name'].lower(), media_id='dummy')

            if len(hmf.get_resolvers()):
                priority = False
                for resolver in hmf.get_resolvers():
                    # prefer individual priority
                    if not resolver.isUniversal():
                        priority = resolver._get_priority()
                        break
                    if not priority:
                        priority = resolver._get_priority()
                if priority:
                    ranking.append([priority, hoster])
            elif not filter:
                ranking.append([999, hoster])

            # Reset resolver so we have a fresh instance when loop starts again
            del(resolver) 

        if any('quality' in hoster[1] for hoster in ranking):
            try:
                # Sortiere Hoster nach Qualität (cConfig().getSetting('preferedQuality') == '5')
                pref_quali = cConfig().getSetting('preferedQuality')
                if pref_quali != '5' and any('quality' in hoster[1] and int(hoster[1]['quality']) == int(pref_quali) for hoster in ranking):
                    ranking = sorted(ranking, key=lambda hoster: int('quality' in hoster[1] and hoster[1]['quality']) == int(pref_quali), reverse=True)
                else:
                # Wenn Hosterliste prüfen an ist, sortiere Hoster nach Prio Qualität
                    ranking = sorted(ranking, key=lambda hoster: 'quality' in hoster[1] and int(hoster[1]['quality']), reverse=True)
            except:
                pass
        # After sorting Quality, we sort for Hoster-Priority :) -Hep 24.01.23
        # ranking = sorted(ranking, key=lambda ranking: ranking[0])

        # Hoster Sprache über sLang im Siteplugin Prio nach sLang Code Reihenfolge (Deutsch, Englisch, Englisch mit untertitel
        if ranking:
            if  "languageCode" in ranking[0][1]:
                ranking = sorted(ranking, key=lambda ranking: (ranking[1]["languageCode"],ranking[0]))
            else:
                ranking = sorted(ranking, key=lambda ranking: ranking[0])
        
        
        hosterQueue = []
        
        for i, hoster in ranking:
            hosterQueue.append(hoster)
        return hosterQueue

    def __precheckHosters(self, siteName, hosterList, plugin=None, functionName='', show_progress=True):
        if siteName not in STREAMING_ARCHIV_PRECHECK_SITES:
            return hosterList
        candidates = [dict(item) for item in (hosterList or []) if isinstance(item, dict) and _raw_hoster_link(item)]
        if not candidates:
            return hosterList

        max_items = min(len(candidates), 50)
        global_budget = 18.0
        workers = min(5, max_items)
        started = time.time()
        checked = []
        completed = 0
        playable_count = 0
        progress = None

        def progress_update(percent, message=''):
            try:
                if progress is not None:
                    progress.update(int(max(0, min(100, percent))), message=message)
            except TypeError:
                try:
                    progress.update(int(max(0, min(100, percent))), message)
                except Exception:
                    pass
            except Exception:
                pass

        def check_one(index_item):
            index, item = index_item
            item = dict(item)
            raw_url = _raw_hoster_link(item)
            t0 = time.time()
            source_url = raw_url

            # AniWorld und SerienStream liefern erst interne Redirect-Links.
            # Diese sind noch keine ResolveURL-Hosterlinks und wuerden in der
            # Vorpruefung als tot durchfallen. Deshalb wird hier exakt der
            # normale Addon-Weg benutzt, um zuerst den echten Zielhoster zu holen.
            if siteName in ('aniworld', 'serienstream') and plugin is not None and functionName:
                try:
                    site_function = getattr(plugin, functionName)
                    site_links = site_function(item.get('link'))
                    if site_links and not isinstance(site_links, list):
                        site_links = [site_links]
                    if site_links and isinstance(site_links[0], dict) and site_links[0].get('streamUrl'):
                        source_url = site_links[0].get('streamUrl')
                    else:
                        return False, time.time() - t0, item, '%s-no-target' % siteName
                except Exception as exc:
                    return False, time.time() - t0, item, '%s-target: %s' % (siteName, str(exc)[:80])

            resolved, resolve_reason = _resolve_for_precheck(source_url)
            if not resolved:
                return False, time.time() - t0, item, resolve_reason
            ok, probe_reason = _probe_stream_url(resolved, timeout=3.0)
            elapsed = time.time() - t0
            if ok:
                _write_precheck_cache(raw_url, resolved)
                if source_url != raw_url:
                    _write_precheck_cache(source_url, resolved)
                    _write_precheck_cache(str(item.get('link')), resolved)
                _apply_detected_quality(item, probe_reason)
                _refresh_display_name(item)
                item['_streaming_archiv_precheck_elapsed'] = elapsed
                item['_streaming_archiv_precheck_probe'] = probe_reason
                item['_streaming_archiv_precheck_target'] = source_url
            return ok, elapsed, item, '%s/%s' % (resolve_reason, probe_reason)

        if show_progress:
            try:
                if self.dialog:
                    try:
                        self.dialog.close()
                    except Exception:
                        pass
                progress = xbmcgui.DialogProgress()
                progress.create('Quellenprüfung', 'Streams werden geprüft...')
                progress_update(0, '0 von %d geprüft' % max_items)
            except Exception as exc:
                progress = None
                logger.info('-> [hoster]: precheck progress failed: %s' % exc)

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=workers)
        future_map = {}
        try:
            future_map = {
                executor.submit(check_one, (idx, item)): idx
                for idx, item in enumerate(candidates[:max_items])
            }
            try:
                for future in concurrent.futures.as_completed(future_map, timeout=global_budget):
                    try:
                        ok, elapsed, item, reason = future.result(timeout=0)
                        checked.append((ok, elapsed, item, reason))
                        completed += 1
                        if ok:
                            playable_count += 1
                        logger.info('-> [hoster]: precheck %s %.2fs: %s / %s / %s / %s' % (
                            'OK' if ok else 'DROP',
                            elapsed,
                            siteName,
                            item.get('name'),
                            _raw_hoster_link(item),
                            reason,
                        ))
                    except Exception as exc:
                        completed += 1
                        logger.info('-> [hoster]: precheck future failed: %s' % exc)
                    progress_update(
                        100.0 * completed / float(max_items or 1),
                        '%d funktionierende von %d geprüft' % (playable_count, completed)
                    )
                    if time.time() - started >= global_budget:
                        break
            except concurrent.futures.TimeoutError:
                logger.info('-> [hoster]: precheck reached %.1fs budget for %s' % (global_budget, siteName))
        finally:
            for future in future_map:
                try:
                    future.cancel()
                except Exception:
                    pass
            try:
                executor.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                executor.shutdown(wait=False)
            try:
                progress_update(100, '%d funktionierende Quellen' % playable_count)
                if progress is not None:
                    progress.close()
            except Exception:
                pass

        good = [item for ok, elapsed, item, reason in checked if ok]
        if not good:
            logger.info('-> [hoster]: precheck found no playable source for %s; hiding original hoster list after real check (%d/%d completed)' % (siteName, completed, max_items))
            return []

        good = sorted(
            good,
            key=lambda item: (
                _language_rank(item),
                _quality_sort_key(item),
                float(item.get('_streaming_archiv_precheck_elapsed') or 99.0),
                str(item.get('name') or '').lower(),
            )
        )
        logger.info('-> [hoster]: precheck kept %d/%d sources for %s in %.1fs' % (len(good), max_items, siteName, time.time() - started))
        return good

    def stream(self, playMode, siteName, function, url):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30138))
        # load site as plugin and run the function
        self.dialog.update(5, cConfig().getLocalizedString(30139))
        plugin = __import__(siteName, globals(), locals())
        function = getattr(plugin, function)
        self.dialog.update(10, cConfig().getLocalizedString(30140))
        if url:
            siteResult = function(url)
        else:
            siteResult = function()
        self.dialog.update(40)
        if not siteResult:
            self.dialog.close()
            cGui().showInfo('xStream', cConfig().getLocalizedString(30141))
            return
        # if result is not a list, make in one
        if not type(siteResult) is list:
            temp = [siteResult]
            siteResult = temp
        # field "name" marks hosters
        if 'name' in siteResult[0]:
            functionName = siteResult[-1]
            del siteResult[-1]
            if not siteResult:
                self.dialog.close()
                cGui().showInfo('xStream', cConfig().getLocalizedString(30142))
                return

            self.dialog.update(60, cConfig().getLocalizedString(30143))
            # Sitplugins VOD mit in automatische Abspielliste aufnehmen (Da Links bei der Überprüfung der Verfügbarkeit gekickt werden)
            if (playMode != 'jd') and (playMode != 'jd2') and (playMode != 'pyload') and (cConfig().getSetting('presortHoster') == 'true') and (playMode != 'myjd'):
            #if (not siteName.startswith('vod_')) and (playMode != 'jd') and (playMode != 'jd2') and (playMode != 'pyload') and (cConfig().getSetting('presortHoster') == 'true') and (playMode != 'myjd'):
                siteResult = self.__getPriorities(siteResult)
            if (playMode != 'jd') and (playMode != 'jd2') and (playMode != 'pyload') and (playMode != 'myjd') and siteName != 'vod_huhu':
                siteResult = self.__precheckHosters(siteName, siteResult, plugin, functionName)
            if not siteResult:
                self.dialog.close()
                cGui().showInfo('xStream', cConfig().getLocalizedString(30144))
                return False
            self.dialog.update(90)
            # self.dialog.close()
            if len(siteResult) > self.maxHoster:
                siteResult = siteResult[:self.maxHoster - 1]
            if cConfig().getSetting('hosterSelect') == 'List':
                self.showHosterFolder(siteResult, siteName, functionName)
                return
            if len(siteResult) > 1:
                # choose hoster
                siteResult = self._chooseHoster(siteResult)
                if not siteResult:
                    return
            else:
                siteResult = siteResult[0]
            # get stream links
            logger.info(siteResult['link'])
            function = getattr(plugin, functionName)
            siteResult = function(siteResult['link'])
            # if result is not a list, make in one
            if not type(siteResult) is list:
                temp = [siteResult]
                siteResult = temp
        # choose part
        if len(siteResult) > 1:
            siteResult = self._choosePart(siteResult)
            if not siteResult:
                logger.info('-> [hoster]: no part selected')
                return
        else:
            siteResult = siteResult[0]

        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30145))
        self.dialog.update(95, cConfig().getLocalizedString(30146))
        if playMode == 'play':
            self.play(siteResult)
        elif playMode == 'download':
            self.download(siteResult)
        elif playMode == 'enqueue':
            self.addToPlaylist(siteResult)
        elif playMode == 'jd':
            self.sendToJDownloader(siteResult['streamUrl'])
        elif playMode == 'jd2':
            self.sendToJDownloader2(siteResult['streamUrl'])
        elif playMode == 'myjd':
            self.sendToMyJDownloader(siteResult['streamUrl'])
        elif playMode == 'pyload':
            self.sendToPyLoad(siteResult)

    def streamAuto(self, playMode, siteName, function):
        logger.info('-> [hoster]: auto stream initiated')
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30138))
        # load site as plugin and run the function
        self.dialog.update(5, cConfig().getLocalizedString(30139))
        plugin = __import__(siteName, globals(), locals())
        function = getattr(plugin, function)
        self.dialog.update(10, cConfig().getLocalizedString(30140))
        siteResult = function()
        if not siteResult:
            self.dialog.close()
            cGui().showInfo('xStream', cConfig().getLocalizedString(30141))
            return False
        # if result is not a list, make in one
        if not type(siteResult) is list:
            temp = [siteResult]
            siteResult = temp
        # field "name" marks hosters
        if 'name' in siteResult[0]:
            self.dialog.update(90, cConfig().getLocalizedString(30143))
            functionName = siteResult[-1]
            del siteResult[-1]
            # Sitplugins aus dem VOD Bereich bei self.__getPriorities(siteResult) ausschliessen da sonst die Hoster gekickt werden.
            if siteName.startswith('dummy'): #Falls Servernamen im VOD sich ändern, hier vod_ eintragen
                hosters = siteResult
            else:
                hosters = self.__getPriorities(siteResult)
            if not hosters:
                self.dialog.close()
                cGui().showInfo('xStream', cConfig().getLocalizedString(30144))
                return False
            if len(siteResult) > self.maxHoster:
                siteResult = siteResult[:self.maxHoster - 1]
            check = False
            self.dialog.create('xStream', cConfig().getLocalizedString(30147))
            total = len(hosters)
            for count, hoster in enumerate(hosters):
                if self.dialog.iscanceled() or xbmc.Monitor().abortRequested() or check: return
                percent = (count + 1) * 100 // total
                try:
                    logger.info('-> [hoster]: try hoster %s' % hoster['name'])
                    self.dialog.create('xStream', cConfig().getLocalizedString(30147))
                    self.dialog.update(percent, cConfig().getLocalizedString(30147) + ' %s' % hoster['name'])
                    # get stream links
                    function = getattr(plugin, functionName)
                    siteResult = function(hoster['link'])
                    check = self.__autoEnqueue(siteResult, playMode)
                    if check:
                        return True
                except:
                    self.dialog.update(percent, cConfig().getLocalizedString(30148) % hoster['name'])
                    logger.error('-> [hoster]: playback with hoster %s failed' % hoster['name'])
        # field "resolved" marks streamlinks
        elif 'resolved' in siteResult[0]:
            for stream in siteResult:
                try:
                    if self.__autoEnqueue(siteResult, playMode):
                        self.dialog.close()
                        return True
                except:
                    pass

    def _chooseHoster(self, siteResult):
        dialog = xbmcgui.Dialog()
        titles = []
        for result in siteResult:
            if 'displayedName' in result:
                titles.append(str(result['displayedName']))
            else:
                titles.append(str(result['name']))
        index = dialog.select(cConfig().getLocalizedString(30149), titles)
        if index > -1:
            siteResult = siteResult[index]
            return siteResult
        else:
            logger.info('-> [hoster]: no hoster selected')
            return False

    def _choosePart(self, siteResult):
        self.dialog = xbmcgui.Dialog()
        titles = []
        for result in siteResult:
            titles.append(str(result['title']))
        index = self.dialog.select(cConfig().getLocalizedString(30150), titles)
        if index > -1:
            siteResult = siteResult[index]
            return siteResult
        else:
            return False

    def showHosterFolder(self, siteResult, siteName, functionName):
        oGui = cGui()
        total = len(siteResult)
        params = ParameterHandler()
        for hoster in siteResult:
            if 'displayedName' in hoster:
                name = hoster['displayedName']
            else:
                name = hoster['name']
            oGuiElement = cGuiElement(name, siteName, functionName)
            oGuiElement.setThumbnail(str(params.getValue('thumb')))
            params.setParam('url', hoster['link'])
            params.setParam('isHoster', 'true')
            oGui.addFolder(oGuiElement, params, iTotal=total, isHoster=True)
        oGui.setEndOfDirectory()

    def __autoEnqueue(self, partList, playMode):
        # choose part
        if not partList:
            return False
        for i in range(len(partList) - 1, -1, -1):
            try:
                if playMode == 'play' and i == 0:
                    if not self.play(partList[i]):
                        return False
                elif playMode == 'download':
                    self.download(partList[i])
                elif playMode == 'enqueue' or (playMode == 'play' and i > 0):
                    self.addToPlaylist(partList[i])
            except:
                return False
        logger.info('-> [hoster]: autoEnqueue successful')
        return True


class Hoster:
    def __init__(self, name, link):
        self.name = name
        self.link = link
