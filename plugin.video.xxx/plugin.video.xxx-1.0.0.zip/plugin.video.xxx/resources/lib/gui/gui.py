﻿# -*- coding: utf-8 -*-
# Python 3

import json
import os
import re
import sqlite3
import sys
import xbmc
import xbmcgui 
import xbmcplugin
try:
    import xbmcvfs
except:
    xbmcvfs = None

from resources.lib import utils
from resources.lib.config import cConfig
from resources.lib.gui.contextElement import cContextElement
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from urllib.parse import quote_plus, urlencode, parse_qs, urlsplit, urlunsplit, quote, unquote, unquote_plus


NEXT_PAGE_ART = 'special://home/addons/plugin.video.xxx/resources/art/next_page.png'
XXX_BIG_LIST_VIEW_ROW = (0, 197115, 0, 1, 0, 'skin.aeon.nox.silvo')


def _translate_path(path):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(path)
    except:
        pass
    try:
        return xbmc.translatePath(path)
    except:
        return path


class cGui:
    # This class "abstracts" a list of xbmc listitems.
    _suppressInfoNotifications = False

    def __init__(self):
        try:
            self.pluginHandle = int(sys.argv[1])
        except:
            self.pluginHandle = 0
        try:
            self.pluginPath = sys.argv[0]
        except:
            self.pluginPath = ''
        try:
            self.currentUrl = sys.argv[0] + (sys.argv[2] or '')
        except:
            self.currentUrl = self.pluginPath
        self.isMetaOn = cConfig().getSetting('TMDBMETA') == 'true'
        if cConfig().getSetting('metaOverwrite') == 'true':
            self.metaMode = 'replace'
        else:
            self.metaMode = 'add'
        # for globalSearch or alterSearch
        self.globalSearch = False
        self._collectMode = False
        self._isViewSet = False
        self._viewContent = ''
        self.searchResults = []

    def __hasFastMetadata(self, oGuiElement):
        try:
            values = oGuiElement.getItemValues()
        except:
            return False
        for key in ('rating', 'TMDb_Rating', 'IMDb_Rating', 'Trakt_Rating'):
            value = values.get(key)
            try:
                if value not in ('', None) and float(str(value).replace(',', '.')) > 0:
                    return True
            except:
                pass
        return False

    def addFolder(self, oGuiElement, params='', bIsFolder=True, iTotal=0, isHoster=False):
        # add GuiElement to Gui, adds listitem to a list
        # abort xbmc list creation if user requests abort
        if xbmc.Monitor().abortRequested():
            self.setEndOfDirectory(False)
            raise RuntimeError('UserAborted')
        # store result in list if we searched global for other sources
        if self._collectMode:
            import copy
            self.searchResults.append({'guiElement': oGuiElement, 'params': copy.deepcopy(params), 'isFolder': bIsFolder})
            return
        if not oGuiElement._isMetaSet and self.isMetaOn and oGuiElement._mediaType and (iTotal < 100 or getattr(oGuiElement, '_forceMeta', False)):
            if getattr(oGuiElement, '_forceMeta', False) or not self.__hasFastMetadata(oGuiElement):
                tmdbID = params.getValue('tmdbID')
                if tmdbID:
                    oGuiElement.getMeta(oGuiElement._mediaType, tmdbID, mode=self.metaMode)
                else:
                    oGuiElement.getMeta(oGuiElement._mediaType, mode=self.metaMode)
        isNextPage = bIsFolder and self.__isNextPageItem(oGuiElement, params)
        if isNextPage:
            sUrl = self.__createNextPageUrl(oGuiElement, params)
        else:
            sUrl = self.__createItemUrl(oGuiElement, bIsFolder, params)
#kasi
        try:
            if params.exist('trumb'):
                inheritedThumb = params.getValue('trumb')
                if inheritedThumb and not self.__isNextPageArtValue(inheritedThumb):
                    oGuiElement.setIcon(inheritedThumb)
        except:
            pass

        listitem = self.createListItem(oGuiElement)
        if isNextPage:
            try:
                listitem.setArt({'icon': NEXT_PAGE_ART, 'thumb': NEXT_PAGE_ART, 'poster': NEXT_PAGE_ART, 'fanart': oGuiElement.getFanart()})
            except:
                pass
        use_trailer_choice = self.__useTrailerChoice(oGuiElement, params, bIsFolder)
        if use_trailer_choice:
            sUrl = self.__createTrailerChoiceUrl(oGuiElement, sUrl, bIsFolder, params)
            bIsFolder = False
        if not bIsFolder and cConfig().getSetting('hosterSelect') == 'List':
            bIsFolder = True
        if isHoster:
            bIsFolder = False
        listitem = self.__createContextMenu(oGuiElement, listitem, bIsFolder, sUrl)
        if not bIsFolder and not use_trailer_choice:
            listitem.setProperty('IsPlayable', 'true')
        if isNextPage:
            self.__copyCurrentViewToNextPage(sUrl)
        xbmcplugin.addDirectoryItem(self.pluginHandle, sUrl, listitem, bIsFolder, iTotal)

    def addNextPage(self, site, function, params=''):
        guiElement = cGuiElement(cConfig().getLocalizedString(30279), site, function)
        self.addFolder(guiElement, params)

    def searchNextPage(self, sTitle, site, function, params=''):
        guiElement = cGuiElement(sTitle, site, function)
        self.addFolder(guiElement, params)

    def __translatePath(self, path):
        try:
            if xbmcvfs is not None:
                return xbmcvfs.translatePath(path)
        except:
            pass
        try:
            return xbmc.translatePath(path)
        except:
            return path

    def __viewDbPath(self):
        databasePath = self.__translatePath('special://database/')
        try:
            candidates = [name for name in os.listdir(databasePath) if name.lower().startswith('viewmodes') and name.lower().endswith('.db')]
            if candidates:
                candidates.sort()
                return os.path.join(databasePath, candidates[-1])
        except:
            pass
        return os.path.join(databasePath, 'ViewModes6.db')

    def __viewPrefsPath(self):
        profilePath = self.__translatePath('special://profile/addon_data/plugin.video.xxx/')
        try:
            if not os.path.exists(profilePath):
                os.makedirs(profilePath)
        except:
            pass
        return os.path.join(profilePath, 'view_prefs.json')

    def __syncedContentKey(self):
        if self._viewContent in ('movies', 'tvshows'):
            return 'video_titles'
        return ''

    def __loadViewPrefs(self):
        try:
            path = self.__viewPrefsPath()
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return {}

    def __saveViewPrefs(self, prefs):
        try:
            with open(self.__viewPrefsPath(), 'w', encoding='utf-8') as f:
                json.dump(prefs, f, sort_keys=True)
        except:
            pass

    def __rememberContentViewRow(self, sourceRow):
        try:
            viewMode = int(sourceRow[1] or 0)
            if not viewMode:
                return
            key = self.__syncedContentKey() or 'video_titles'
            prefs = self.__loadViewPrefs()
            prefs[key] = {
                'viewMode': viewMode,
                'sortMethod': int(sourceRow[2] or 0),
                'sortOrder': int(sourceRow[3] or 1),
                'sortAttributes': int(sourceRow[4] or 0),
                'skin': sourceRow[5] or 'skin.aeon.nox.silvo',
            }
            self.__saveViewPrefs(prefs)
        except:
            pass

    def __loadContentViewRow(self):
        key = self.__syncedContentKey()
        if not key:
            return None
        if key == 'video_titles':
            return XXX_BIG_LIST_VIEW_ROW
        try:
            data = self.__loadViewPrefs().get(key)
            if data and int(data.get('viewMode') or 0):
                return (
                    0,
                    int(data.get('viewMode') or 0),
                    int(data.get('sortMethod') or 0),
                    int(data.get('sortOrder') or 1),
                    int(data.get('sortAttributes') or 0),
                    data.get('skin') or 'skin.aeon.nox.silvo',
                )
        except:
            pass
        return None

    def __isNextPageItem(self, oGuiElement, params):
        try:
            title = oGuiElement.getTitle().lower()
        except:
            title = ''
        if 'nÃ¤chste' in title or 'naechste' in title or 'next' in title:
            return True
        return False

    def __isNextPageArtValue(self, value):
        try:
            value = unquote_plus(str(value or '')).replace('\\', '/').lower()
            return 'next_page.png' in value and 'plugin.video.xxx' in value
        except:
            return False

    def __pluginPathForViewDb(self, url):
        try:
            split = urlsplit(url)
            query = split.query
            if not query and '?' in url:
                query = url.split('?', 1)[1]
            params = parse_qs(query, keep_blank_values=True)
            ordered = []
            for key in sorted(params.keys()):
                for value in params[key]:
                    ordered.append('%s=%s' % (quote(str(key), safe=''), quote(str(value), safe='')))
            return urlunsplit((split.scheme, split.netloc, split.path, '&'.join(ordered), split.fragment))
        except:
            return url

    def __createNextPageUrl(self, oGuiElement, params):
        blockedKeys = set([
            'MovieTitle', 'TVShowTitle', 'entryUrl', 'mediaType', 'sName',
            'sThumbnail', 'thumb', 'tmdbID', 'imdbID', 'season', 'episode',
            'year', 'duration', 'rating', 'genre', 'plot', 'desc', 'cast',
            'director', 'writer', 'premiered', 'trailer', 'playMode',
        ])
        try:
            values = dict(params.getAllParameters())
        except:
            values = {}
        cleanValues = {}
        for key, value in values.items():
            if key in blockedKeys or key in ('site', 'function', 'title', 'params', 'trumb'):
                continue
            if value is False or value is None or str(value) == '':
                continue
            cleanValues[key] = unquote_plus(str(value))
        sParams = urlencode(cleanValues)
        if not sParams:
            sParams = 'params=0'
        thumb = ''
        return "%s?site=%s&function=%s&title=%s&trumb=%s&%s" % (
            self.pluginPath,
            oGuiElement.getSiteName(),
            oGuiElement.getFunction(),
            quote_plus(oGuiElement.getTitle()),
            quote_plus(str(thumb or '')),
            sParams
        )

    def __paramsFromPluginUrl(self, url):
        try:
            split = urlsplit(url)
            query = split.query
            if not query and '?' in url:
                query = url.split('?', 1)[1]
            parsed = parse_qs(query, keep_blank_values=True)
            params = {}
            for key, values in parsed.items():
                if values:
                    params[key] = values[-1]
            return params
        except:
            return {}

    def __pageFromSUrl(self, sUrl):
        try:
            query = urlsplit(sUrl).query
            values = parse_qs(query, keep_blank_values=True).get('page')
            if values:
                return int(values[-1])
        except:
            pass
        try:
            match = re.search(r'/page/(\d+)/?$', urlsplit(sUrl).path)
            if match:
                return int(match.group(1))
        except:
            pass
        return 0

    def __pageFromPluginParams(self, params):
        try:
            value = params.get('page')
            if value:
                return int(value)
        except:
            pass
        try:
            value = params.get('pageIndex')
            if value:
                return int(value)
        except:
            pass
        return self.__pageFromSUrl(params.get('sUrl', ''))

    def __isTitleListPath(self, path):
        params = self.__paramsFromPluginUrl(path)
        return params.get('function', '') in (
            'showEntries', 'showNewSeries', 'showSearch',
            'showCatalog', 'showExpandedSection', 'showSectionContent',
            'showNewEpisodes', 'showFavItems', 'SSsearch', 'listCams'
        )

    def __isNextPagePath(self, path):
        try:
            title = unquote_plus(self.__paramsFromPluginUrl(path).get('title', '')).lower()
            return 'nÃ¤chste' in title or 'naechste' in title or 'next' in title
        except:
            return False

    def __sUrlFamily(self, sUrl):
        try:
            split = urlsplit(sUrl)
            params = parse_qs(split.query, keep_blank_values=True)
            params.pop('page', None)
            query = urlencode(sorted((key, value) for key, values in params.items() for value in values))
            path = re.sub(r'/page/\d+/?$', '/', split.path or '/')
            if path != '/':
                path = path.rstrip('/')
            return urlunsplit((split.scheme.lower(), split.netloc.lower(), path, query, '')).lower()
        except:
            return ''

    def __findPreviousPageViewRow(self, con, currentPath):
        currentParams = self.__paramsFromPluginUrl(currentPath)
        currentFunction = currentParams.get('function', '')
        if currentFunction not in ('showEntries', 'showCatalog', 'showExpandedSection', 'showSectionContent', 'showNewSeries', 'showNewEpisodes', 'showFavItems', 'showSearch', 'SSsearch', 'listCams'):
            return None
        currentSUrl = currentParams.get('sUrl', '')
        currentPage = self.__pageFromPluginParams(currentParams)
        if currentPage <= 1:
            return None
        currentFamily = self.__sUrlFamily(currentSUrl)
        if not currentFamily:
            return None
        currentSite = currentParams.get('site', '')
        rows = con.execute(
            'select idView, path, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path like ? and viewMode<>0 order by idView desc limit 500',
            (10025, 'plugin://plugin.video.xxx/%')
        ).fetchall()
        best = None
        bestPage = -1
        fallback = None
        for row in rows:
            path = row[1] or ''
            if path == currentPath:
                continue
            if self.__isNextPagePath(path):
                continue
            params = self.__paramsFromPluginUrl(path)
            if params.get('function', '') != currentFunction:
                continue
            if currentSite and params.get('site', '') != currentSite:
                continue
            mismatch = False
            for key in ('sGenreFilter', 'sName', 'sSectionTitle'):
                if currentParams.get(key, '') and params.get(key, '') != currentParams.get(key, ''):
                    mismatch = True
                    break
            if mismatch:
                continue
            rowSUrl = params.get('sUrl', '')
            if self.__sUrlFamily(rowSUrl) != currentFamily:
                continue
            rowPage = self.__pageFromPluginParams(params)
            sourceRow = (row[0], row[2], row[3], row[4], row[5], row[6])
            if rowPage and rowPage < currentPage and rowPage > bestPage:
                best = sourceRow
                bestPage = rowPage
            elif fallback is None:
                fallback = sourceRow
        return best or fallback

    def __findLatestTitleListViewRow(self, con):
        savedRow = self.__loadContentViewRow()
        if savedRow:
            return savedRow
        try:
            rows = con.execute(
                'select idView, path, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path like ? and viewMode<>0 order by idView desc limit 500',
                (10025, 'plugin://plugin.video.xxx/%')
            ).fetchall()
            for row in rows:
                if self.__isTitleListPath(row[1] or ''):
                    return (row[0], row[2], row[3], row[4], row[5], row[6])
        except:
            pass
        return None

    def __getViewRow(self, con, path):
        try:
            row = con.execute(
                'select idView, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path=?',
                (10025, path)
            ).fetchone()
            if row:
                return row
        except:
            pass
        normalized = self.__pluginPathForViewDb(path)
        if normalized != path:
            try:
                return con.execute(
                    'select idView, viewMode, sortMethod, sortOrder, sortAttributes, skin from view where window=? and path=?',
                    (10025, normalized)
                ).fetchone()
            except:
                pass
        return None

    def __setViewRow(self, con, path, sourceRow):
        if not sourceRow:
            return
        viewMode = int(sourceRow[1] or 0)
        if not viewMode:
            return
        sortMethod = int(sourceRow[2] or 0)
        sortOrder = int(sourceRow[3] or 1)
        sortAttributes = int(sourceRow[4] or 0)
        skin = sourceRow[5] or 'skin.aeon.nox.silvo'
        targetPath = path
        existing = self.__getViewRow(con, targetPath)
        if existing:
            con.execute(
                'update view set viewMode=?, sortMethod=?, sortOrder=?, sortAttributes=?, skin=? where idView=?',
                (viewMode, sortMethod, sortOrder, sortAttributes, skin, existing[0])
            )
        else:
            nextId = con.execute('select coalesce(max(idView), 0) + 1 from view').fetchone()[0]
            con.execute(
                'insert into view (idView, window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) values (?, ?, ?, ?, ?, ?, ?, ?)',
                (nextId, 10025, targetPath, viewMode, sortMethod, sortOrder, sortAttributes, skin)
            )

    def __inheritViewForCurrentPage(self):
        try:
            dbPath = self.__viewDbPath()
            if not os.path.exists(dbPath):
                return 0
            con = sqlite3.connect(dbPath, timeout=0.5)
            try:
                sourceRow = None
                if self.__syncedContentKey() and self.__isTitleListPath(self.currentUrl):
                    sourceRow = self.__loadContentViewRow()
                if not sourceRow:
                    sourceRow = self.__findPreviousPageViewRow(con, self.currentUrl)
                if not sourceRow and self.__syncedContentKey() and self.__isTitleListPath(self.currentUrl):
                    sourceRow = self.__findLatestTitleListViewRow(con)
                if not sourceRow or not int(sourceRow[1] or 0):
                    return 0
                self.__setViewRow(con, self.currentUrl, sourceRow)
                self.__rememberContentViewRow(sourceRow)
                con.commit()
                viewId = int(sourceRow[1] or 0) & 0xffff
                try:
                    xbmc.log('[Streaming Archiv] inherited view %s for paged list' % viewId, xbmc.LOGINFO)
                except:
                    pass
                return viewId
            finally:
                con.close()
        except Exception as e:
            try:
                xbmc.log('[Streaming Archiv] view inherit failed: %s' % e, xbmc.LOGWARNING)
            except:
                pass
        return 0

    def __copyCurrentViewToNextPage(self, nextUrl):
        try:
            if not nextUrl.startswith('plugin://plugin.video.xxx/'):
                return
            dbPath = self.__viewDbPath()
            if not os.path.exists(dbPath):
                return
            con = sqlite3.connect(dbPath, timeout=0.2)
            try:
                sourceRow = self.__getViewRow(con, self.currentUrl)
                if not sourceRow or not int(sourceRow[1] or 0):
                    return
                self.__rememberContentViewRow(sourceRow)
                self.__setViewRow(con, nextUrl, sourceRow)
                con.commit()
            finally:
                con.close()
        except Exception as e:
            try:
                xbmc.log('[Streaming Archiv] view carry failed: %s' % e, xbmc.LOGWARNING)
            except:
                pass

    def createListItem(self, oGuiElement):
        itemValues = oGuiElement.getItemValues()
        itemTitle = oGuiElement.getTitle()
        infoString = ''
        if self.globalSearch: # Reihenfolge der zu anzeigenden GUI Elemente
            infoString += ' %s' % oGuiElement.getSiteName()
        if oGuiElement._sLanguage != '':
            infoString += ' (%s)' % oGuiElement._sLanguage
        if oGuiElement._sSubLanguage != '':
            infoString += ' *Sub: %s*' % oGuiElement._sSubLanguage
        if oGuiElement._sQuality != '':
            infoString += ' [%s]' % oGuiElement._sQuality
        if oGuiElement._sInfo != '':
            infoString += ' [%s]' % oGuiElement._sInfo    
        # if self.globalSearch:
        #     infoString += ' %s' % oGuiElement.getSiteName()
        if infoString:
            infoString = '[I]%s[/I]' % infoString
        itemValues['title'] = itemTitle + infoString
        self._enrichPlot(itemValues)
        try:
            if not 'plot' in str(itemValues) or itemValues['plot'] == '':
                itemValues['plot'] = 'Â ' #kasi Alt 255
        except:
            pass
        #listitem = xbmcgui.ListItem(itemTitle + infoString, oGuiElement.getIcon(), oGuiElement.getThumbnail())
        listitem = xbmcgui.ListItem(itemTitle + infoString)
        # Function: setInfo(type, infoLabels)
        # listitem.setInfo('video', { 'genre': 'Comedy' })
        listitem.setInfo(oGuiElement.getType(), self._sanitizeInfoLabels(itemValues))
        #Wenn Kodi 19, dann ignoriere setinfotagvideo
        kodi_version = xbmc.getInfoLabel('System.BuildVersion')
        if kodi_version[:2]  > '19':
            self.setInfoTagVideo(oGuiElement, listitem)
        try:
            listitem.setLabel(itemTitle + infoString)
        except:
            pass

        icon = oGuiElement.getIcon()
        thumb = oGuiElement.getThumbnail()
        fanart = oGuiElement.getFanart()
        listitem.setProperty('fanart_image', fanart)
        listitem.setArt({'icon': icon, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        aProperties = oGuiElement.getItemProperties()
        if len(aProperties) > 0:
            for sPropertyKey in aProperties.keys():
                listitem.setProperty(sPropertyKey, aProperties[sPropertyKey])
        return listitem

    def _normalizeMultiValue(self, value):
        if value in ['', None]:
            return []
        if isinstance(value, tuple):
            value = list(value)
        if isinstance(value, list):
            return [str(entry).strip() for entry in value if str(entry).strip()]
        if isinstance(value, str):
            value = value.replace(' / ', ',')
            return [entry.strip() for entry in value.split(',') if entry.strip()]
        return []

    def _normalizeStudioValues(self, value, limit=1):
        if value in ['', None]:
            return []
        if isinstance(value, tuple):
            value = list(value)
        entries = value if isinstance(value, list) else [value]
        studios = []
        seen = set()
        for entry in entries:
            for studio in re.split(r'\s*/\s*|\s*\|\s*', str(entry or '')):
                studio = re.sub(r'\s+', ' ', studio).strip()
                if not studio or studio.lower() in ('none', 'null', 'n/a'):
                    continue
                key = studio.lower()
                if key in seen:
                    continue
                seen.add(key)
                studios.append(studio)
                if len(studios) >= limit:
                    return studios
        return studios

    def _sanitizeInfoLabels(self, itemValues):
        allowed = {
            'title', 'sorttitle', 'originaltitle', 'plot', 'plotoutline', 'tagline',
            'genre', 'year', 'duration', 'rating', 'votes', 'trailer', 'studio',
            'premiered', 'season', 'episode', 'tvshowtitle', 'country', 'countries',
            'dateadded', 'director', 'writer', 'cast',
            'mediatype', 'status', 'code', 'aired', 'mpaa'
        }
        infoLabels = {}
        for key, value in itemValues.items():
            if value in ['', None]:
                continue
            normalized_key = 'tvshowtitle' if key == 'TVShowTitle' else key
            if normalized_key == 'genre':
                value = self._normalizeMultiValue(value)
                if not value:
                    continue
            if normalized_key == 'studio':
                studios = self._normalizeStudioValues(value)
                if not studios:
                    continue
                value = studios[0]
            if normalized_key in allowed:
                infoLabels[normalized_key] = value
        return infoLabels

    def _enrichPlot(self, itemValues):
        details = []

        year = itemValues.get('year')
        if year:
            details.append(str(year))

        duration = itemValues.get('duration')
        try:
            if duration:
                duration = int(float(duration))
                hours = duration // 60
                minutes = duration % 60
                if hours > 0:
                    details.append('%dh %02dm' % (hours, minutes))
                else:
                    details.append('%d min' % minutes)
        except:
            pass

        genre = itemValues.get('genre') or itemValues.get('genres')
        if genre:
            details.append(str(genre))

        rating_parts = []
        rating = itemValues.get('rating')
        try:
            if rating not in ['', None]:
                rating_parts.append('Bewertung: %.1f' % float(str(rating).replace(',', '.')))
        except:
            pass

        votes = itemValues.get('votes')
        if votes not in ['', None]:
            rating_parts.append('Stimmen: %s' % votes)

        plot = itemValues.get('plot', '')
        meta_lines = []
        if rating_parts:
            meta_lines.append('[COLOR blue]%s[/COLOR]' % ' | '.join(rating_parts))
        if details:
            meta_lines.append('[COLOR blue]%s[/COLOR]' % ' | '.join(details))

        if meta_lines:
            clean_plot = str(plot).strip()
            itemValues['plot'] = '[CR]'.join(meta_lines + ([clean_plot] if clean_plot else []))

    ### Ã„NDERUNG ANFANG ###
    def setInfoTagVideo(self, oGuiElement, listitem):
        itemValues = oGuiElement.getItemValues()
        vtag = listitem.getVideoInfoTag()

        media_type = oGuiElement._mediaType or itemValues.get('mediatype')
        if media_type:
            try:
                vtag.setMediaType(media_type)
            except:
                pass

        if not self.globalSearch:
            try:
                vtag.setTitle(oGuiElement.getTitle())
            except:
                pass
        if 'plot' in itemValues:
            try:
                vtag.setPlot(itemValues['plot'])
            except: pass
        if 'year' in itemValues:
            try:
                vtag.setYear(int(itemValues['year']))
            except: pass
        if 'season' in itemValues:
            try:
                vtag.setSeason(int(itemValues['season']))
            except: pass
        if 'episode' in itemValues:
            try:
                vtag.setEpisode(int(itemValues['episode']))
            except: pass
        if 'TVShowTitle' in itemValues:
            try:
                vtag.setTvShowTitle(itemValues['TVShowTitle'])
            except: pass
        if 'cast' in itemValues:
            try:
                vtag.setCast([xbmc.Actor(cast[0], cast[1], thumbnail=cast[2]) for cast in itemValues['cast']])
            except: pass
        if 'countries' in itemValues:
            try:
                vtag.setCountries(itemValues['countries'])
            except: pass
        if 'country' in itemValues:
            try:
                vtag.setCountries([itemValues['country']])
            except: pass
        if 'dateadded' in itemValues:
            try:
                vtag.setDateAdded(itemValues['dateadded'])
            except: pass
        directors = itemValues.get('directors')
        if not directors and itemValues.get('director'):
            directors = [d.strip() for d in str(itemValues['director']).split(' / ') if d.strip()]
        if directors:
            try:
                if isinstance(directors, str):
                    directors = [d.strip() for d in directors.split(' / ') if d.strip()]
                vtag.setDirectors(directors)
            except: pass
        writers = itemValues.get('writers')
        if not writers and itemValues.get('writer'):
            writers = [w.strip() for w in str(itemValues['writer']).split(' / ') if w.strip()]
        if writers:
            try:
                if isinstance(writers, str):
                    writers = [w.strip() for w in writers.split(' / ') if w.strip()]
                vtag.setWriters(writers)
            except: pass
        if 'duration' in itemValues:
            # minuten in sekunden umrechnen
            try:
                vtag.setDuration(int(itemValues['duration']) * 60)
            except: pass
        if 'rating' in itemValues:
            try:
                vtag.setRating(float(itemValues['rating']))
            except: pass
        if 'TMDb_Rating' in itemValues:
            try:
                tmdb_rating = float(str(itemValues['TMDb_Rating']).replace(',', '.'))
                votes_value = 0
                try:
                    votes_value = int(float(itemValues.get('votes', 0)))
                except:
                    votes_value = 0
                for rating_type in ['themoviedb', 'tmdb']:
                    try:
                        vtag.setRating(tmdb_rating, votes_value, rating_type, rating_type == 'themoviedb')
                    except:
                        try:
                            vtag.setRating(tmdb_rating, votes_value, rating_type)
                        except:
                            pass
                try:
                    listitem.setRating('themoviedb', tmdb_rating, votes_value, True)
                except:
                    pass
                try:
                    listitem.setRating('tmdb', tmdb_rating, votes_value, False)
                except:
                    pass
            except:
                pass
        if 'IMDb_Rating' in itemValues:
            try:
                imdb_rating = float(str(itemValues['IMDb_Rating']).replace(',', '.'))
                try:
                    vtag.setRating(imdb_rating, 0, 'imdb')
                except:
                    pass
            except:
                pass
        if 'Trakt_Rating' in itemValues:
            try:
                trakt_rating = float(str(itemValues['Trakt_Rating']).replace(',', '.'))
                try:
                    vtag.setRating(trakt_rating, 0, 'trakt')
                except:
                    pass
            except:
                pass
        if 'votes' in itemValues:
            try:
                vtag.setVotes(int(float(itemValues['votes'])))
            except: pass
        if 'genre' in itemValues or 'genres' in itemValues:
            try:
                genres = itemValues.get('genre') or itemValues.get('genres')
                genres = self._normalizeMultiValue(genres)
                if genres:
                    vtag.setGenres(tuple(genres))
            except: pass
        if 'imdb_id' in itemValues:
            try:
                vtag.setUniqueID(str(itemValues['imdb_id']), 'imdb')
            except: pass
        if 'tmdb_id' in itemValues:
            try:
                vtag.setUniqueID(str(itemValues['tmdb_id']), 'tmdb')
            except: pass
        if 'originaltitle' in itemValues:
            try:
                vtag.setOriginalTitle(itemValues['originaltitle'])
            except: pass
        if 'trailer' in itemValues:
            try:
                vtag.setTrailer(itemValues['trailer'])
            except: pass
        if 'tagline' in itemValues:
            try:
                vtag.setTagLine(itemValues['tagline'])
            except: pass
        if 'studio' in itemValues:
            try:
                studios = self._normalizeStudioValues(itemValues['studio'])
                if studios:
                    vtag.setStudios(studios)
            except: pass
        if 'premiered' in itemValues:
            try:
                vtag.setPremiered(itemValues['premiered'])
            except: pass    
    ### Ã„NDERUNG ENDE ###


    def __createContextMenu(self, oGuiElement, listitem, bIsFolder, sUrl):
        contextmenus = []
        if len(oGuiElement.getContextItems()) > 0:
            for contextitem in oGuiElement.getContextItems():
                params = contextitem.getOutputParameterHandler()
                sParams = params.getParameterAsUri()
                sTest = "%s?site=%s&function=%s&%s" % (self.pluginPath, contextitem.getFile(), contextitem.getFunction(), sParams)
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s)" % (sTest,),)]
        itemValues = oGuiElement.getItemValues()
        contextitem = cContextElement()
        # XXX keeps the context menu lean: playback/download options only.
        if 'imdb_id' in itemValues and 'title' in itemValues:
            metaParams = {}
            if itemValues['title']:
                metaParams['title'] = oGuiElement.getTitle()
            if 'mediaType' in itemValues and itemValues['mediaType']:
                metaParams['mediaType'] = itemValues['mediaType']
            elif 'TVShowTitle' in itemValues and itemValues['TVShowTitle']:
                metaParams['mediaType'] = 'tvshow'
            else:
                metaParams['mediaType'] = 'movie'
            if 'season' in itemValues and itemValues['season'] and int(itemValues['season']) > 0:
                metaParams['season'] = itemValues['season']
                metaParams['mediaType'] = 'season'
            if 'episode' in itemValues and itemValues['episode'] and int(itemValues['episode']) > 0 and 'season' in itemValues and itemValues['season'] and int(itemValues['season']):
                metaParams['episode'] = itemValues['episode']
                metaParams['mediaType'] = 'episode'

        # context options for movies or episodes
        if not bIsFolder:
            contextitem.setTitle(cConfig().getLocalizedString(30244))   # Playlist hinzufÃ¼gen
            contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=enqueue)" % (sUrl,),)]
            contextitem.setTitle(cConfig().getLocalizedString(30245))   # Download
            contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=download)" % (sUrl,),)]
            if cConfig().getSetting('jd_enabled') == 'true':
                contextitem.setTitle(cConfig().getLocalizedString(30246))   # send JD
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=jd)" % (sUrl,),)]
            if cConfig().getSetting('jd2_enabled') == 'true':
                contextitem.setTitle(cConfig().getLocalizedString(30247))   # Send JD2
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=jd2)" % (sUrl,),)]
            if cConfig().getSetting('myjd_enabled') == 'true':
                contextitem.setTitle(cConfig().getLocalizedString(30248))   # Send myjd
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=myjd)" % (sUrl,),)]
            if cConfig().getSetting('pyload_enabled') == 'true':
                contextitem.setTitle(cConfig().getLocalizedString(30249))   # Send Pyload
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=pyload)" % (sUrl,),)]
            if cConfig().getSetting('hosterSelect') == 'Auto':
                contextitem.setTitle(cConfig().getLocalizedString(30149))   # select Hoster
                contextmenus += [(contextitem.getTitle(), "RunPlugin(%s&playMode=play&manual=1)" % (sUrl,),)]
        listitem.addContextMenuItems(contextmenus)
        # listitem.addContextMenuItems(contextmenus, True)
        return listitem

    def setEndOfDirectory(self, success=True):
        # mark the listing as completed, this is mandatory
        if not self._isViewSet:
            self.setView('files')
        xbmcplugin.setPluginCategory(self.pluginHandle, "")
        # add some sort methods, these will be available in all views
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_VIDEO_RUNTIME)
        xbmcplugin.addSortMethod(self.pluginHandle, xbmcplugin.SORT_METHOD_GENRE)
        inheritedViewId = self.__inheritViewForCurrentPage()
        xbmcplugin.endOfDirectory(self.pluginHandle, success)
        try:
            if self._viewContent in ('movies', 'tvshows'):
                xbmc.executebuiltin('Container.SetViewMode(%s)' % (inheritedViewId or (XXX_BIG_LIST_VIEW_ROW[1] & 0xffff)))
        except:
            pass

    def setView(self, content='movies'):
        # set the listing to a certain content, makes special views available
        # sets view to the viewID which is selected in Streaming Archiv settings
        # see http://mirrors.xbmc.org/docs/python-docs/stable/xbmcplugin.html#-setContent
        # (seasons is also supported but not listed)
        content = content.lower()
        supportedViews = ['files', 'songs', 'artists', 'albums', 'movies', 'tvshows', 'seasons', 'episodes', 'musicvideos']
        if content in supportedViews:
            self._isViewSet = True
            self._viewContent = content
            xbmcplugin.setContent(self.pluginHandle, content)
        # View modes stay user-controlled in Kodi's view database. Streaming Archiv should not
        # force a configured view while paging through title lists.

    def updateDirectory(self):
        # update the current listing
        xbmc.executebuiltin("Container.Refresh")

    def __createItemUrl(self, oGuiElement, bIsFolder, params=''):
        if params == '':
            params = ParameterHandler()
        itemValues = oGuiElement.getItemValues()
        if 'tmdb_id' in itemValues and itemValues['tmdb_id']:
            params.setParam('tmdbID', itemValues['tmdb_id'])
        if 'TVShowTitle' in itemValues and itemValues['TVShowTitle']:
            params.setParam('TVShowTitle', itemValues['TVShowTitle'])
        if 'season' in itemValues and itemValues['season'] and int(itemValues['season']) > 0:
            params.setParam('season', itemValues['season'])
        if 'episode' in itemValues and itemValues['episode'] and float(itemValues['episode']) > 0:
            params.setParam('episode', itemValues['episode'])
        # TODO change this, it can cause bugs it influencec the params for the following listitems
        if not bIsFolder:
            params.setParam('MovieTitle', oGuiElement.getTitle())
            thumbnail = oGuiElement.getThumbnail()
            if thumbnail:
                params.setParam('thumb', thumbnail)
            if oGuiElement._mediaType:
                params.setParam('mediaType', oGuiElement._mediaType)
            elif 'TVShowTitle' in itemValues and itemValues['TVShowTitle']:
                params.setParam('mediaType', 'tvshow')
            if 'season' in itemValues and itemValues['season'] and int(itemValues['season']) > 0:
                params.setParam('mediaType', 'season')
            if 'episode' in itemValues and itemValues['episode'] and float(itemValues['episode']) > 0:
                params.setParam('mediaType', 'episode')
        sParams = params.getParameterAsUri()
        try:
            if params.getValue('sUrl').startswith("plugin://"):
                return  params.getValue('sUrl')
        except: pass
        if len(oGuiElement.getFunction()) == 0:
            sUrl = "%s?site=%s&title=%s&%s" % (self.pluginPath, oGuiElement.getSiteName(), quote_plus(oGuiElement.getTitle()), sParams)
        else:
            #kasi
            sUrl = "%s?site=%s&function=%s&title=%s&trumb=%s&%s" % (self.pluginPath, oGuiElement.getSiteName(), oGuiElement.getFunction(), quote_plus(oGuiElement.getTitle()), quote_plus(oGuiElement.getThumbnail() or ''), sParams)
            if not bIsFolder:
                sUrl += '&playMode=play'
        return sUrl

    def __useTrailerChoice(self, oGuiElement, params, bIsFolder=False):
        if oGuiElement._mediaType not in ['movie', 'season']:
            return False
        try:
            if params.exist('streamingArchivTrailerChoice'):
                return False
        except:
            pass
        return True

    def __createTrailerChoiceUrl(self, oGuiElement, originalUrl, originalIsFolder, params=None):
        itemValues = oGuiElement.getItemValues()
        wrapperParams = {
            'function': 'trailerChoice',
            'choiceTitle': oGuiElement.getTitle(),
            'choiceMediaType': oGuiElement._mediaType,
            'choiceOriginalUrl': originalUrl,
            'choiceOriginalIsFolder': '1' if originalIsFolder else '0',
        }
        year = itemValues.get('year') or oGuiElement._sYear
        if year:
            wrapperParams['choiceYear'] = year
        tmdb_id = itemValues.get('tmdb_id') or getattr(oGuiElement, '_tmdbID', '')
        if tmdb_id:
            wrapperParams['choiceTMDBID'] = tmdb_id
        show_title = itemValues.get('TVShowTitle') or itemValues.get('tvshowtitle') or ''
        if not show_title and params:
            try:
                show_title = params.getValue('sName') or params.getValue('TVShowTitle') or params.getValue('tvshowtitle') or ''
            except:
                show_title = ''
        if not show_title and originalUrl:
            try:
                query = parse_qs(urlsplit(originalUrl).query)
                show_title = (query.get('sName') or query.get('TVShowTitle') or query.get('tvshowtitle') or [''])[0]
            except:
                show_title = ''
        if show_title:
            wrapperParams['choiceTVShowTitle'] = show_title
        if getattr(oGuiElement, '_season', ''):
            wrapperParams['choiceSeason'] = oGuiElement._season
        if getattr(oGuiElement, '_episode', ''):
            wrapperParams['choiceEpisode'] = oGuiElement._episode
        return '%s?%s' % (self.pluginPath, urlencode(wrapperParams))

    @staticmethod
    def showKeyBoard(sDefaultText="", sHeading=""):
        # Create the keyboard object and display it modal
        oKeyboard = xbmc.Keyboard(sDefaultText, sHeading)
        oKeyboard.doModal()
        # If key board is confirmed and there was text entered return the text
        if oKeyboard.isConfirmed():
            sSearchText = oKeyboard.getText()
            if len(sSearchText) > 0:
                return sSearchText
        return False

    @staticmethod
    def showNumpad(defaultNum="", numPadTitle=cConfig().getLocalizedString(30251)):
        defaultNum = str(defaultNum)
        dialog = xbmcgui.Dialog()
        num = dialog.numeric(0, numPadTitle, defaultNum)
        return num

    @staticmethod
    def openSettings():
        cConfig().showSettingsWindow()

    @staticmethod
    def showNofication(sTitle, iSeconds=0):
        if iSeconds == 0:
            iSeconds = 1000
        else:
            iSeconds = iSeconds * 1000
        xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % (cConfig().getLocalizedString(30308), (cConfig().getLocalizedString(30309) % str(sTitle)), iSeconds, cConfig().getAddonInfo('icon')))

    @staticmethod
    def showError(sTitle, sDescription, iSeconds=0):
        if iSeconds == 0:
            iSeconds = 1000
        else:
            iSeconds = iSeconds * 1000
        xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % (str(sTitle), (str(sDescription)), iSeconds, cConfig().getAddonInfo('icon')))

    @staticmethod
    def showInfo(sTitle='Streaming Archiv', sDescription=cConfig().getLocalizedString(30253), iSeconds=0):
        if cGui._suppressInfoNotifications:
            return
        if iSeconds == 0:
            iSeconds = 1000
        else:
            iSeconds = iSeconds * 1000
        xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % (str(sTitle), (str(sDescription)), iSeconds, cConfig().getAddonInfo('icon')))

    @staticmethod
    def showLanguage(sTitle='Streaming Archiv', sDescription=cConfig().getLocalizedString(30403), iSeconds=0):
        if iSeconds == 0:
            iSeconds = 1000
        else:
            iSeconds = iSeconds * 1000
        xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % (str(sTitle), (str(sDescription)), iSeconds, cConfig().getAddonInfo('icon')))
