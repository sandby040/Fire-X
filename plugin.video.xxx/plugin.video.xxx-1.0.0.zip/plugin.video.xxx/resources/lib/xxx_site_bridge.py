# -*- coding: utf-8 -*-
# Python 3

import re
import sys
from html import unescape
import json
from urllib.parse import parse_qsl, quote, quote_plus, urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.tools import logger

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
BAD_TITLES = {
    'video thumbnail', 'thumbnail', 'image', 'add to', 'add to favorites',
    'zu favoriten hinzufügen', 'cancel', 'en', 'ms'
}
SKIP_URL_PARTS = (
    '/categories', '/category', '/channels', '/channel', '/tags', '/tag',
    '/pornstars', '/models', '/model', '/search', '/login', '/signup',
    '/members', '/user', '/users', '/contact', '/privacy', '/terms'
)


def _icon_path(icon):
    icon = str(icon or '')
    if not icon:
        return ''
    if icon.startswith(('http://', 'https://', 'special://', '/', '\\')):
        return icon
    return 'special://home/addons/plugin.video.xxx/resources/art/sites/' + icon


def _site_prefix(config):
    mode = config.get('latest_mode') or config.get('search_mode') or config.get('categories_mode') or ''
    return mode.split('.', 1)[0]


def _origin(url):
    split = urlsplit(str(url or ''))
    return split.scheme + '://' + split.netloc if split.scheme and split.netloc else ''


def _fetch_html(url, referer=''):
    request = Request(url, headers={
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Referer': referer or url,
    })
    with urlopen(request, timeout=20) as response:
        data = response.read()
    return data.decode('utf-8', 'replace')


def _attr(block, name):
    match = re.search(r'\b%s=["\']([^"\']+)["\']' % re.escape(name), block, flags=re.I)
    return unescape(match.group(1).strip()) if match else ''


def _clean_text(value):
    value = re.sub(r'<script\b[\s\S]*?</script>', ' ', value, flags=re.I)
    value = re.sub(r'<style\b[\s\S]*?</style>', ' ', value, flags=re.I)
    value = re.sub(r'<[^>]+>', ' ', value)
    return re.sub(r'\s+', ' ', unescape(value)).strip()


def _image_from_block(block, base_url):
    for attr in ('data-original', 'data-src', 'data-thumb', 'data-poster', 'poster', 'src'):
        for image in re.findall(r'\b%s=["\']([^"\']+)["\']' % attr, block, flags=re.I):
            image = unescape(image.strip())
            lowered = image.lower()
            if not image or lowered.startswith('data:'):
                continue
            if any(part in lowered for part in ('blank.', 'sprite.', 'logo.', 'favicon', 'placeholder')):
                continue
            if not re.search(r'\.(?:jpg|jpeg|png|webp|gif)(?:[?#].*)?$', lowered):
                continue
            return urljoin(base_url, image)
    return ''


def _video_name(anchor_attrs, anchor_html):
    values = []
    for source in (anchor_attrs, anchor_html):
        for attr in ('title', 'alt', 'aria-label'):
            values.extend(re.findall(r'\b%s=["\']([^"\']+)["\']' % re.escape(attr), source, flags=re.I))
    values.append(_clean_text(anchor_html))
    for value in values:
        cleaned = _clean_text(value)
        lowered = cleaned.lower().strip(' .:-')
        if cleaned and len(cleaned) > 2 and lowered not in BAD_TITLES:
            return cleaned
    return ''


def _is_video_url(url):
    lowered = url.lower()
    if lowered.startswith(('javascript:', 'mailto:', '#')) or not lowered:
        return False
    if any(part in lowered for part in SKIP_URL_PARTS):
        return False
    path = urlsplit(lowered).path
    if path in ('', '/'):
        return False
    return True


def _specific_video_entries(site_id, page_html, base_url):
    entries = []
    seen = set()
    if site_id == 'cum_nonktube':
        pattern = r'<div\s+class=["\']video-block[\s\S]+?<a[\s\S]+?href=["\']([^"\']+)["\'][\s\S]+?title=["\']([^"\']+)["\'][\s\S]+?<img[\s\S]+?src=["\']([^"\']+)["\'][\s\S]+?<span\s+class=["\']duration["\']>([^<]+)<'
        for href, title, image, duration in re.findall(pattern, page_html, flags=re.I):
            url = urljoin(base_url, unescape(href).strip())
            if url in seen:
                continue
            seen.add(url)
            entries.append({
                'title': _clean_text(title),
                'url': url,
                'thumbnail': urljoin(base_url, unescape(image).strip()),
                'duration': _clean_text(duration),
            })
    elif site_id == 'cum_pornone':
        pattern = r'<a\s+href=["\']([^"\']+)["\']\s+class=["\']popbop([\s\S]+?)>(\d[\d:\s]+)<[\s\S]+?(?:data-src|img\s+src)=["\']([^"\']+)["\']\s+alt=["\']([^"\']+)["\']'
        for href, hd, duration, image, title in re.findall(pattern, page_html, flags=re.I):
            url = urljoin(base_url, unescape(href).strip())
            if url in seen:
                continue
            seen.add(url)
            entries.append({
                'title': _clean_text(title),
                'url': url,
                'thumbnail': urljoin(base_url, unescape(image).strip()),
                'duration': _clean_text(duration),
                'quality': 'HD' if 'HD Video' in hd else '',
            })
    return [entry for entry in entries if entry.get('title') and entry.get('url') and entry.get('thumbnail')]


def _video_entries(page_html, base_url, site_id=''):
    specific_entries = _specific_video_entries(site_id, page_html, base_url)
    if specific_entries:
        return specific_entries
    seen = set()
    entries = []
    anchor_re = re.compile(r'<a\b([^>]*)href=["\']([^"\']+)["\']([^>]*)>([\s\S]*?)</a>', re.I)
    for match in anchor_re.finditer(page_html):
        attrs = (match.group(1) or '') + ' ' + (match.group(3) or '')
        href = unescape(match.group(2).strip())
        block = match.group(0)
        image = _image_from_block(block, base_url)
        if not image:
            continue
        video_url = urljoin(base_url, href)
        if not _is_video_url(video_url):
            continue
        key = video_url.split('#', 1)[0]
        if key in seen:
            continue
        name = _video_name(attrs, block)
        if not name or len(name) < 2:
            continue
        seen.add(key)
        entries.append({'title': name, 'url': key, 'thumbnail': image})
    return entries


def _filter_entries_by_keyword(entries, keyword):
    words = [word.lower() for word in re.split(r'\s+', _clean_text(str(keyword or ''))) if word]
    if not words:
        return entries
    matched = []
    for entry in entries:
        title = (entry.get('title') or '').lower()
        if all(word in title for word in words):
            matched.append(entry)
    return matched


def _category_entries(page_html, base_url):
    seen = set()
    entries = []
    anchor_re = re.compile(r'<a\b([^>]*)href=["\']([^"\']+)["\']([^>]*)>([\s\S]*?)</a>', re.I)
    for match in anchor_re.finditer(page_html):
        attrs = (match.group(1) or '') + ' ' + (match.group(3) or '')
        href = unescape(match.group(2).strip())
        url = urljoin(base_url, href)
        lowered = url.lower()
        if lowered.startswith(('javascript:', 'mailto:', '#')) or url in seen:
            continue
        if not any(part in lowered for part in ('categor', '/channels', '/channel', '/tags/', '/tag/')):
            continue
        name = _video_name(attrs, match.group(0))
        if not name or len(name) < 2:
            continue
        seen.add(url)
        entries.append({'title': name, 'url': url, 'thumbnail': _image_from_block(match.group(0), base_url)})
    return entries


def _next_page(page_html, base_url):
    patterns = (
        r'<a\b[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:Next|Weiter|»|›|Next Page)\s*</a>',
    )
    for pattern in patterns:
        match = re.search(pattern, page_html, flags=re.I)
        if match:
            return urljoin(base_url, unescape(match.group(1).strip()))
    return ''


def _stream_headers(referer):
    headers = {
        'User-Agent': USER_AGENT,
        'Referer': referer or '',
    }
    origin = _origin(referer)
    if origin:
        headers['Origin'] = origin
    return '|' + urlencode(headers)


def _decode_url(value):
    return unescape(str(value or '')).replace('\\/', '/').strip()


def _quality_value(label, stream_url=''):
    label = str(label or '').lower()
    if label in ('4k', 'uhd'):
        return 2160
    if label in ('fullhd', 'fhd'):
        return 1080
    if label == 'hd':
        return 720
    match = re.search(r'(\d{3,4})p?', label) or re.search(r'(\d{3,4})p', stream_url)
    return int(match.group(1)) if match else 0


def _stream_candidates_from_text(text, page_url):
    candidates = []
    direct_patterns = (
        r'<source\b[^>]+src=["\']([^"\']+)["\'][^>]*(?:label|res|size|title)=["\']?([^"\' >]*)',
        r'(?:file|src|source)\s*[:=]\s*["\']([^"\']+\.(?:mp4|m3u8|mpd)(?:\?[^"\']*)?)["\']',
        r'["\']([^"\']+\.(?:mp4|m3u8|mpd)(?:\?[^"\']*)?)["\']',
    )
    for pattern in direct_patterns:
        for match in re.finditer(pattern, text or '', flags=re.I | re.S):
            groups = match.groups()
            stream_url = _decode_url(groups[0])
            if not stream_url or stream_url.lower().startswith('data:'):
                continue
            if any(part in stream_url.lower() for part in ('.jpg', '.jpeg', '.png', '.webp', '/thumb', '/poster')):
                continue
            label = groups[1] if len(groups) > 1 else ''
            candidates.append((_quality_value(label, stream_url), urljoin(page_url, stream_url)))
    return candidates


def _playlist_candidates(text, page_url):
    candidates = []
    for playlist_url in re.findall(r'"playlist"\s*:\s*"([^"]+)"', text or '', flags=re.I):
        playlist_url = urljoin(page_url, _decode_url(playlist_url))
        try:
            data = json.loads(_fetch_html(playlist_url, page_url))
        except Exception as exc:
            logger.info('-> [XXXSiteBridge]: playlist read failed for %s: %s' % (playlist_url, exc))
            continue
        items = data.get('playlist') if isinstance(data, dict) else data
        if not isinstance(items, list):
            continue
        for item in items:
            sources = item.get('sources') if isinstance(item, dict) else None
            if not isinstance(sources, list):
                continue
            for source in sources:
                if not isinstance(source, dict):
                    continue
                stream_url = _decode_url(source.get('file') or source.get('src') or '')
                if stream_url:
                    candidates.append((_quality_value(source.get('label') or source.get('res') or '', stream_url), urljoin(playlist_url, stream_url)))
    return candidates


def _embed_urls(text, page_url):
    urls = []
    for pattern in (
        r'"embedUrl"\s*:\s*"([^"]+)"',
        r'<iframe\b[^>]+src=["\']([^"\']+)["\']',
        r'iframe[^"\']+["\'](https?://[^"\']+)["\']',
    ):
        for match in re.finditer(pattern, text or '', flags=re.I | re.S):
            url = urljoin(page_url, _decode_url(match.group(1)))
            if url and url not in urls:
                urls.append(url)
    return urls[:4]


def _best_stream_from_page(page_url):
    page_html = _fetch_html(page_url, page_url)
    candidates = []
    candidates.extend(_playlist_candidates(page_html, page_url))
    candidates.extend(_stream_candidates_from_text(page_html, page_url))
    for embed_url in _embed_urls(page_html, page_url):
        try:
            embed_html = _fetch_html(embed_url, page_url)
        except Exception as exc:
            logger.info('-> [XXXSiteBridge]: embed read failed for %s: %s' % (embed_url, exc))
            continue
        candidates.extend(_playlist_candidates(embed_html, embed_url))
        candidates.extend(_stream_candidates_from_text(embed_html, embed_url))
    unique = {}
    for quality, stream_url in candidates:
        if stream_url:
            unique[stream_url] = max(quality, unique.get(stream_url, -1))
    if not unique:
        return ''
    return sorted([(quality, url) for url, quality in unique.items()], reverse=True)[0][1]


def _search_url(config, keyword):
    url = config.get('search_url') or ''
    keyword = str(keyword or '').strip()
    if '{}' in url:
        return url.format(quote_plus(keyword))
    if url.endswith(('=', '?q=', '?s=', '&q=', '&s=')):
        return url + quote_plus(keyword)
    if url.endswith('/search/') or url.endswith('/search/videos/'):
        return url + quote(keyword.replace(' ', '-')) + '/'
    return url + quote_plus(keyword)


def _add_menu_item(title, site_id, function, target_url, icon='', action='entries', mode=''):
    icon = _icon_path(icon)
    params = ParameterHandler()
    params.setParam('sUrl', target_url)
    params.setParam('cumAction', action)
    params.setParam('cumMode', mode)
    element = cGuiElement(title, site_id, function)
    if icon:
        element.setThumbnail(icon)
        element.setIcon(icon)
    cGui().addFolder(element, params, True)


def load(config):
    icon = _icon_path(config.get('icon', ''))
    site_id = config.get('site_id', '')
    params = ParameterHandler()

    params.setParam('sUrl', config.get('search_url', ''))
    params.setParam('cumAction', 'search')
    params.setParam('cumMode', config.get('search_mode', ''))
    element = cGuiElement('Suche', site_id, 'showSearch')
    if icon:
        element.setThumbnail(icon)
        element.setIcon(icon)
    cGui().addFolder(element, params, True)

    latest_mode = config.get('latest_mode')
    latest_url = config.get('latest_url')
    if latest_mode and latest_url:
        _add_menu_item('Neueste Uploads', site_id, 'showSearch', latest_url, icon, 'entries', latest_mode)

    categories_mode = config.get('categories_mode')
    categories_url = config.get('categories_url')
    if categories_mode and categories_url:
        _add_menu_item('Kategorien', site_id, 'showSearch', categories_url, icon, 'categories', categories_mode)

    cGui().setEndOfDirectory()


def _add_video_items(config, entries, source_url, page_html=''):
    gui = cGui()
    total = len(entries)
    for entry in entries:
        title = entry.get('title') or ''
        thumb = entry.get('thumbnail') or ''
        params = ParameterHandler()
        params.setParam('entryUrl', entry.get('url') or '')
        params.setParam('sUrl', entry.get('url') or '')
        params.setParam('sName', title)
        params.setParam('sThumbnail', thumb)
        params.setParam('trumb', thumb)
        params.setParam('cumAction', 'play')
        element = cGuiElement(title, config.get('site_id', ''), 'showSearch')
        if thumb:
            element.setThumbnail(thumb)
            element.setIcon(thumb)
            element.setFanart(thumb)
        if entry.get('duration'):
            element.addItemValue('duration', entry.get('duration'))
        if entry.get('quality'):
            element.setQuality(entry.get('quality'))
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    try:
        page_html = page_html or _fetch_html(source_url)
        next_url = _next_page(page_html, source_url)
        if next_url:
            params = ParameterHandler()
            params.setParam('sUrl', next_url)
            params.setParam('cumAction', 'entries')
            params.setParam('cumMode', config.get('latest_mode', ''))
            element = cGuiElement(cConfig().getLocalizedString(30279), config.get('site_id', ''), 'showSearch')
            gui.addFolder(element, params, True)
    except Exception:
        pass

    gui.setView('movies')
    gui.setEndOfDirectory()


def show_entries(config, url, fallback_mode='', fallback_keyword=''):
    gui = cGui()
    try:
        page_html = _fetch_html(url)
        entries = _video_entries(page_html, url, config.get('site_id', ''))
        entries = _filter_entries_by_keyword(entries, fallback_keyword)
        if not entries:
            logger.info('-> [XXXSiteBridge]: no native entries for %s at %s' % (config.get('site_id', 'unknown'), url))
            gui.setEndOfDirectory(False)
            return
        _add_video_items(config, entries, url, page_html)
    except Exception as exc:
        logger.info('-> [XXXSiteBridge]: native list failed for %s: %s' % (config.get('site_id', 'unknown'), exc))
        gui.setEndOfDirectory(False)


def show_categories(config, url):
    gui = cGui()
    try:
        page_html = _fetch_html(url)
        entries = _category_entries(page_html, url)
        if not entries:
            logger.info('-> [XXXSiteBridge]: no native categories for %s at %s' % (config.get('site_id', 'unknown'), url))
            gui.setEndOfDirectory(False)
            return
        total = len(entries)
        for entry in entries:
            params = ParameterHandler()
            params.setParam('sUrl', entry.get('url') or '')
            params.setParam('cumAction', 'entries')
            params.setParam('cumMode', config.get('latest_mode', ''))
            thumb = entry.get('thumbnail') or _icon_path(config.get('icon', ''))
            params.setParam('trumb', thumb)
            element = cGuiElement(entry.get('title') or '', config.get('site_id', ''), 'showSearch')
            if thumb:
                element.setThumbnail(thumb)
                element.setIcon(thumb)
                element.setFanart(thumb)
            gui.addFolder(element, params, True, total)
        gui.setEndOfDirectory()
    except Exception as exc:
        logger.info('-> [XXXSiteBridge]: native categories failed for %s: %s' % (config.get('site_id', 'unknown'), exc))
        gui.setEndOfDirectory(False)


def show_hosters(config):
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    stream_url = _best_stream_from_page(source_url)
    if stream_url:
        return [{
            'streamUrl': stream_url + _stream_headers(source_url),
            'resolved': True,
            'title': config.get('site_id', 'XXX'),
        }]
    logger.info('-> [XXXSiteBridge]: no playable stream found for %s' % source_url)
    return []


def show_search(config):
    params = ParameterHandler()
    action = params.getValue('cumAction') or 'search'
    mode = params.getValue('cumMode') or ''
    if action == 'play':
        return show_hosters(config)
    if action == 'entries':
        return show_entries(config, params.getValue('sUrl') or config.get('latest_url', ''), mode or config.get('latest_mode', ''))
    if action == 'categories':
        return show_categories(config, params.getValue('sUrl') or config.get('categories_url', ''))

    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    url = config.get('search_url')
    if not url:
        logger.info('-> [XXXSiteBridge]: missing search config for %s' % config.get('site_id', 'unknown'))
        cGui().setEndOfDirectory(False)
        return
    return show_entries(config, _search_url(config, search_text), config.get('search_mode', ''), search_text)


def build_site(config):
    def _load():
        return load(config)

    def _showSearch():
        return show_search(config)

    return _load, _showSearch
