# -*- coding: utf-8 -*-
import json
import os
import random
import re
import sys
from html import unescape
from urllib.parse import quote_plus, urlencode, urljoin

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger

_ADDONS_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
for _module_path in (
    os.path.join(_ADDONS_DIR, 'script.module.cloudrequest'),
    os.path.join(_ADDONS_DIR, 'script.module.cloudscraper', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.requests', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.urllib3', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.chardet', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.idna', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.certifi', 'lib'),
):
    if os.path.exists(_module_path) and _module_path not in sys.path:
        sys.path.insert(0, _module_path)

try:
    import cloudscraper
except Exception:
    try:
        import cloudscraper2 as cloudscraper
    except Exception:
        cloudscraper = None

USER_AGENT = cRequestHandler.RandomUA()
IOS_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148'
_SCRAPER = None


def _get_scraper():
    global _SCRAPER
    if not cloudscraper:
        return None
    if _SCRAPER is None:
        _SCRAPER = cloudscraper.create_scraper()
    return _SCRAPER


def _clean_text(value):
    value = re.sub(r'<[^>]+>', ' ', str(value or ''))
    value = unescape(value)
    value = re.sub(r'\s+', ' ', value)
    return value.strip()


def _request(url, headers=None, referer='', method='GET', data=None):
    headers = dict(headers or {})
    headers.setdefault('User-Agent', USER_AGENT)
    if referer:
        headers.setdefault('Referer', referer)
    scraper = _get_scraper()
    if scraper:
        try:
            if method == 'POST':
                response = scraper.post(url, data=data or {}, headers=headers, timeout=12)
            else:
                response = scraper.get(url, headers=headers, timeout=12)
            if response.status_code < 400:
                return response.text
            logger.info('-> [LiveCams]: cloudscraper status %s for %s' % (response.status_code, url))
        except Exception as e:
            logger.info('-> [LiveCams]: cloudscraper failed for %s: %s' % (url, e))
    request = cRequestHandler(url, caching=False, ignoreErrors=True, method=method, data=data)
    for key, value in headers.items():
        request.addHeaderEntry(key, value)
    return request.request() or ''


def _json_request(url, headers=None, referer='', method='GET', data=None):
    text = _request(url, headers=headers, referer=referer, method=method, data=data)
    try:
        return json.loads(text)
    except Exception as e:
        logger.info('-> [LiveCams]: invalid json for %s: %s' % (url, e))
    return {} if text.strip().startswith('{') else []


def _decode_js(value):
    return unescape(str(value or '')).replace('\\/', '/').replace('\\u002F', '/').replace('\\u0026', '&')


def _json_object_after(text, key):
    marker = '"%s":' % key
    marker_pos = -1
    search_from = 0
    while True:
        marker_pos = text.find(marker, search_from)
        if marker_pos < 0:
            return {}
        preview = text[marker_pos:marker_pos + 500]
        if key != 'modelSearch' or '"models"' in preview:
            break
        search_from = marker_pos + len(marker)
    if marker_pos < 0:
        return {}
    start = text.find('{', marker_pos + len(marker))
    if start < 0:
        return {}
    depth = 0
    in_string = False
    escape = False
    for pos in range(start, len(text)):
        char = text[pos]
        if in_string:
            if escape:
                escape = False
            elif char == '\\':
                escape = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:pos + 1])
                except Exception:
                    return {}
    return {}


def _stream_headers(referer, origin=None, user_agent=None):
    origin = origin or referer.rstrip('/')
    return '|User-Agent=%s&Referer=%s&Origin=%s' % (
        quote_plus(user_agent or USER_AGENT),
        quote_plus(referer),
        quote_plus(origin),
    )


def _filter_entries(entries, query, search_mode='all'):
    query = _clean_text(query).lower()
    words = [word for word in re.split(r'\s+', query) if word]
    if not words:
        return entries
    filtered = []
    for entry in entries:
        if search_mode == 'model':
            haystack = ' '.join([entry.get('title', ''), entry.get('username', '')]).lower()
        elif search_mode == 'tag':
            haystack = ' '.join([entry.get('description', ''), entry.get('tags', ''), entry.get('country', '')]).lower()
        else:
            haystack = ' '.join([
                entry.get('title', ''),
                entry.get('username', ''),
                entry.get('description', ''),
                entry.get('tags', ''),
                entry.get('country', ''),
            ]).lower()
        if query in haystack or all(word in haystack for word in words):
            filtered.append(entry)
    return filtered


def _merge_entries(entries):
    merged = []
    seen = set()
    for entry in entries:
        key = entry.get('username') or entry.get('play_url') or entry.get('stream_url') or entry.get('title')
        if not key or key in seen:
            continue
        seen.add(key)
        merged.append(entry)
    return merged


def _first_url(*values):
    for value in values:
        value = str(value or '').strip()
        if value:
            if value.startswith('//'):
                return 'https:' + value
            return value
    return ''


def _add_cam_entries(config, entries, page, has_next=False):
    gui = cGui()
    total = len(entries)
    for entry in entries:
        thumb = entry.get('thumbnail') or entry.get('fanart') or ''
        fanart = entry.get('fanart') or thumb
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        params.setParam('playUrl', entry.get('play_url', ''))
        params.setParam('streamUrl', entry.get('stream_url', ''))
        params.setParam('sUrl', entry.get('play_url') or entry.get('stream_url') or '')
        params.setParam('sName', entry.get('title', ''))
        params.setParam('sThumbnail', thumb)
        element = cGuiElement(entry.get('title', ''), config['site_id'], 'showHosters')
        if thumb:
            element.setThumbnail(thumb)
            element.setIcon(thumb)
        if fanart:
            element.setFanart(fanart)
        if entry.get('description'):
            element.setDescription(entry['description'])
        if entry.get('quality'):
            element.setQuality(entry['quality'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    if has_next:
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        params.setParam('section', config.get('_runtime_section', 'popular'))
        params.setParam('category', config.get('_runtime_category', ''))
        params.setParam('query', config.get('_runtime_query', ''))
        params.setParam('searchMode', config.get('_runtime_search_mode', 'all'))
        params.setParam('page', str(page + 1))
        gui.addNextPage(config['site_id'], 'listCams', params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def _cam4_entries(config, category, page, query, search_mode='all'):
    per_page = 60
    entries = []
    last_count = 0
    scan_pages = 4 if query else 1
    for scan_page in range(page, page + scan_pages):
        params = {
            'directoryJson': 'true',
            'online': 'true',
            'url': 'true',
            'orderBy': 'VIEWER_COUNT',
            'page': str(scan_page),
            'resultsPerPage': str(per_page),
        }
        if category:
            params.update(config['categories'].get(category, {}).get('params', {}))
        data = _json_request(config['api'] + '?' + urlencode(params, doseq=True), headers={'User-Agent': IOS_UA})
        users = data.get('users', []) if isinstance(data, dict) else []
        last_count = len(users)
        for cam in users:
            username = cam.get('username') or ''
            title = username
            if cam.get('age'):
                title += ' [%s]' % cam.get('age')
            if cam.get('viewers'):
                title += ' - %s Zuschauer' % cam.get('viewers')
            desc = []
            if cam.get('statusMessage'):
                desc.append(cam.get('statusMessage'))
            if cam.get('countryCode'):
                desc.append('Land: %s' % cam.get('countryCode'))
            if cam.get('resolution'):
                desc.append('Aufloesung: %s' % cam.get('resolution'))
            tags = ', '.join(cam.get('showTags') or cam.get('tags') or [])
            if tags:
                desc.append(tags)
            entries.append({
                'title': title,
                'username': username,
                'thumbnail': _first_url(cam.get('snapshotImageLink'), cam.get('defaultImageLink')),
                'fanart': _first_url(cam.get('snapshotImageLink'), cam.get('defaultImageLink')),
                'description': '[CR]'.join(desc),
                'tags': tags,
                'country': cam.get('countryCode') or '',
                'quality': 'HD' if cam.get('hdStream') else '',
                'play_url': config['stream_info'].format(username),
            })
        if len(users) < per_page:
            break
    entries = _filter_entries(_merge_entries(entries), query, search_mode)
    return entries, (not query and last_count >= per_page)


def _cam4_stream(config, play_url):
    data = _json_request(play_url, headers={'User-Agent': USER_AGENT}, referer=config['referer'])
    cdn = data.get('cdnURL') if isinstance(data, dict) else ''
    candidates = cdn if isinstance(cdn, list) else ([cdn] if cdn else [])
    for stream_url in candidates:
        if stream_url:
            return stream_url + _stream_headers(config['referer'])
    return ''


def _bonga_entries(config, category, page, query, search_mode='all'):
    url = config['api']
    if category:
        url += '&categories[]=' + quote_plus(category)
    data = _json_request(url, headers={'User-Agent': USER_AGENT}, referer=config['referer'])
    if not isinstance(data, list):
        data = []
    entries = []
    for model in data:
        username = model.get('username') or ''
        images = model.get('profile_images') or {}
        thumb = _first_url(
            images.get('thumbnail_image_big_live'),
            images.get('thumbnail_image_medium_live'),
            images.get('profile_image'),
            images.get('thumbnail_image_small'),
        )
        title = model.get('display_name') or username
        if model.get('display_age'):
            title += ' [%s]' % model.get('display_age')
        if model.get('hd_cam'):
            title += ' HD'
        tags = ', '.join(model.get('tags') or [])
        desc = model.get('chat_topic') or model.get('turns_on') or tags
        entries.append({
            'title': title,
            'username': username,
            'thumbnail': thumb,
            'fanart': thumb,
            'description': _clean_text(desc),
            'tags': tags,
            'quality': 'HD' if model.get('hd_cam') else '',
            'stream_url': model.get('stream_feed_url') or '',
            'play_url': username,
        })
    return _filter_entries(entries, query, search_mode), False


def _bonga_stream(config, stream_url, play_url):
    if stream_url:
        return stream_url + _stream_headers(config['referer'])
    if not play_url:
        return ''
    post = urlencode([('method', 'getRoomData'), ('args[]', play_url), ('args[]', ''), ('args[]', '')])
    data = _json_request(config['room_api'], headers={'User-Agent': USER_AGENT, 'X-Requested-With': 'XMLHttpRequest'}, referer=config['referer'], method='POST', data=post)
    server = ((data or {}).get('localData') or {}).get('videoServerUrl') or ''
    username = ((data or {}).get('performerData') or {}).get('username') or play_url
    if server.startswith('//mobile'):
        stream_url = 'https:' + server + '/hls/stream_' + username + '.m3u8'
    elif server:
        stream_url = 'https:' + server + '/hls/stream_' + username + '/playlist.m3u8'
    else:
        stream_url = ''
    return stream_url + _stream_headers(config['referer']) if stream_url else ''


def _camsoda_entries(config, category, page, query, search_mode='all'):
    entries = []
    per_page = 0
    total = 0
    scan_pages = 4 if query else 1
    for scan_page in range(page, page + scan_pages):
        url = config['api']
        if category:
            url = urljoin(config['base'] + '/', config['categories'][category]['path'])
        elif query and search_mode == 'tag':
            url = '%s&q=%s' % (config['api'], quote_plus(_clean_text(query)))
        url = '%s%sp=%s' % (url, '&' if '?' in url else '?', scan_page)
        data = _json_request(url, headers=config['headers'], referer=config['referer'])
        users = data.get('userList', []) if isinstance(data, dict) else []
        per_page = int(data.get('perPageCount', 0) or 0) if isinstance(data, dict) else 0
        total = int(data.get('totalCount', 0) or 0) if isinstance(data, dict) else 0
        for cam in users:
            username = cam.get('username') or ''
            title = cam.get('displayName') or username
            if cam.get('connectionCount'):
                title += ' - %s Zuschauer' % cam.get('connectionCount')
            tags = ', '.join([str(value) for value in (cam.get('tags') or cam.get('tagList') or cam.get('flagList') or [])])
            desc_parts = [
                cam.get('subjectText') or '',
                cam.get('status') or '',
                cam.get('countryCode') or '',
                tags,
            ]
            entries.append({
                'title': title,
                'username': username,
                'thumbnail': _first_url(cam.get('thumbUrl'), cam.get('onlinePictureUrl'), cam.get('offlinePictureUrl')),
                'fanart': _first_url(cam.get('thumbUrl'), cam.get('onlinePictureUrl'), cam.get('offlinePictureUrl')),
                'description': _clean_text(' '.join(desc_parts)),
                'tags': tags,
                'country': cam.get('countryCode') or '',
                'play_url': config['chat_api'].format(username),
            })
        if per_page and per_page * scan_page >= total:
            break
    entries = _merge_entries(entries)
    if not (query and search_mode == 'tag'):
        entries = _filter_entries(entries, query, search_mode)
    return entries, (not query and per_page and (per_page * page) < total)


def _camsoda_stream(config, play_url):
    data = _json_request(play_url + '?username=guest_' + str(random.randrange(100, 55555)), headers=config['headers'], referer=config['referer'])
    stream = data.get('stream') if isinstance(data, dict) else {}
    servers = stream.get('edge_servers') or []
    if not servers or not stream.get('stream_name') or not stream.get('token'):
        return ''
    stream_url = 'https://%s/%s_v1/index.m3u8?token=%s' % (servers[0], stream.get('stream_name'), stream.get('token'))
    return stream_url + _stream_headers(config['referer'], config['base'], 'iPad')


def _xhamster_fetch_models(config, primary, limit=80):
    params = {'primaryTag': primary, 'limit': str(limit), 'parentTag': 'popular'}
    data = _json_request(config['api'] + '?' + urlencode(params), headers=config['headers'], referer=config['referer'])
    return data.get('models', []) if isinstance(data, dict) else []


def _xhamster_fetch_search_models(config, query, search_mode):
    slug = quote_plus(_clean_text(query)).replace('+', '-')
    if not slug:
        return []
    path = '/search/girls/models/%s' % slug if search_mode == 'model' else '/search/girls/menu/%s' % slug
    html = _request(urljoin(config['base'] + '/', path), headers=config['headers'], referer=config['referer'])
    data = _json_object_after(html, 'modelSearch')
    models = data.get('models') if isinstance(data, dict) else []
    if not isinstance(models, list):
        return []
    online = [model for model in models if model.get('isOnline') or model.get('status') == 'on' or int(model.get('viewersCount') or 0) > 0]
    return online or models[:80]


def _xhamster_entries(config, category, page, query, search_mode='all'):
    if query:
        models = _xhamster_fetch_search_models(config, query, search_mode)
    elif category:
        models = _xhamster_fetch_models(config, category, 80)
    else:
        models = []
        seen = set()
        for primary in ('girls', 'couples', 'men', 'trans'):
            for model in _xhamster_fetch_models(config, primary, 80):
                key = model.get('username') or model.get('id')
                if key in seen:
                    continue
                seen.add(key)
                models.append(model)
        models.sort(key=lambda item: int(item.get('viewersCount') or 0), reverse=True)
        models = models[:120]
    entries = []
    for model in models:
        username = model.get('username') or ''
        title = username
        if model.get('viewersCount'):
            title += ' - %s Zuschauer' % model.get('viewersCount')
        tags = ', '.join(model.get('tags') or [])
        topic = model.get('groupShowTopic') or model.get('topic') or ''
        live_thumb = _first_url(
            model.get('previewUrlThumbBig'),
            model.get('previewUrl'),
            model.get('previewUrlThumbSmall'),
            model.get('snapshotUrl'),
            model.get('avatarUrl'),
        )
        entries.append({
            'title': title,
            'username': username,
            'thumbnail': live_thumb,
            'fanart': live_thumb,
            'description': 'Land: %s[CR]Status: %s[CR]%s[CR]%s' % (model.get('country') or '', model.get('status') or '', topic, tags),
            'tags': tags,
            'country': model.get('country') or '',
            'quality': 'HD' if model.get('isHd') else '',
            'play_url': username,
        })
    if query and search_mode == 'tag':
        return entries, False
    return _filter_entries(entries, query, search_mode), False


def _xhamster_stream(config, username, fallback_url=''):
    if username:
        url = config['stream_api'] + '?' + urlencode({'limit': '1', 'modelsList': username})
        data = _json_request(url, headers=config['headers'], referer=config['referer'])
        models = data.get('models', []) if isinstance(data, dict) else []
        if models and models[0].get('username') == username:
            stream = models[0].get('stream') or {}
            urls = stream.get('urls') or {}
            stream_url = urls.get('original') or urls.get('720p') or urls.get('480p') or stream.get('url') or urls.get('240p')
            if stream_url:
                return stream_url + _stream_headers(config['referer'], config['base'])
    if fallback_url and 'doppiocdn' not in fallback_url:
        return fallback_url + _stream_headers(config['referer'], config['base'])
    return ''


def build_live_site(config):
    def load():
        gui = cGui()
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        gui.addFolder(cGuiElement('Model-Suche', config['site_id'], 'showModelSearch'), params)
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        gui.addFolder(cGuiElement('Tag-Suche', config['site_id'], 'showTagSearch'), params)
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        params.setParam('section', 'popular')
        params.setParam('page', '1')
        gui.addFolder(cGuiElement('Beliebteste Cams', config['site_id'], 'listCams'), params)
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        gui.addFolder(cGuiElement('Kategorien', config['site_id'], 'showCategories'), params)
        gui.setEndOfDirectory()

    def _run_search(search_mode, heading):
        query = cGui().showKeyBoard(sHeading=heading)
        if not query:
            cGui().setEndOfDirectory()
            return
        params = ParameterHandler()
        params.setParam('siteKey', config['key'])
        params.setParam('section', 'search')
        params.setParam('searchMode', search_mode)
        params.setParam('query', query)
        params.setParam('page', '1')
        listCams(params)

    def showModelSearch():
        _run_search('model', 'Model-Suche')

    def showTagSearch():
        _run_search('tag', 'Tag-Suche')

    def showSearch():
        showModelSearch()

    def showCategories():
        gui = cGui()
        total = len(config.get('categories', {}))
        for key, category in config.get('categories', {}).items():
            params = ParameterHandler()
            params.setParam('siteKey', config['key'])
            params.setParam('section', 'category')
            params.setParam('category', key)
            params.setParam('page', '1')
            gui.addFolder(cGuiElement(category['title'], config['site_id'], 'listCams'), params, True, total)
        gui.setEndOfDirectory()

    def listCams(override_params=None):
        params = override_params or ParameterHandler()
        category = params.getValue('category') or ''
        query = params.getValue('query') or ''
        search_mode = params.getValue('searchMode') or 'all'
        try:
            page = int(params.getValue('page') or '1')
        except Exception:
            page = 1
        runtime = dict(config)
        runtime['_runtime_section'] = params.getValue('section') or 'popular'
        runtime['_runtime_category'] = category
        runtime['_runtime_query'] = query
        runtime['_runtime_search_mode'] = search_mode
        if config['key'] == 'cam4':
            entries, has_next = _cam4_entries(runtime, category, page, query, search_mode)
        elif config['key'] == 'bongacams':
            entries, has_next = _bonga_entries(runtime, category, page, query, search_mode)
        elif config['key'] == 'camsoda':
            entries, has_next = _camsoda_entries(runtime, category, page, query, search_mode)
        elif config['key'] == 'xhamsterlive':
            entries, has_next = _xhamster_entries(runtime, category, page, query, search_mode)
        else:
            entries, has_next = [], False
        _add_cam_entries(runtime, entries, page, has_next)

    def showHosters():
        params = ParameterHandler()
        play_url = params.getValue('playUrl')
        stream_url = params.getValue('streamUrl')
        if config['key'] == 'cam4':
            resolved = _cam4_stream(config, play_url)
        elif config['key'] == 'bongacams':
            resolved = _bonga_stream(config, stream_url, play_url)
        elif config['key'] == 'camsoda':
            resolved = _camsoda_stream(config, play_url)
        elif config['key'] == 'xhamsterlive':
            resolved = _xhamster_stream(config, play_url, stream_url)
        else:
            resolved = ''
        if resolved:
            return [{'streamUrl': resolved, 'resolved': True, 'title': config.get('name', 'Live')}]
        logger.info('-> [LiveCams]: no playable stream for %s' % (play_url or stream_url))
        return []

    return load, showSearch, showModelSearch, showTagSearch, showCategories, listCams, showHosters
