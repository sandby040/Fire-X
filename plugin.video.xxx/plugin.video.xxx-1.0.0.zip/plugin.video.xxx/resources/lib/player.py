# -*- coding: utf-8 -*-
# Python 3

import xbmc
import time
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from xbmc import LOGINFO as LOGNOTICE, LOGERROR, log

class StreamingArchivPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.streamSuccess = True
        self.playedTime = 0
        self.totalTime = 999999
        log(cConfig().getLocalizedString(30166) + ' -> [player]: player instance created', LOGNOTICE)

    def onPlayBackStarted(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: starting Playback', LOGNOTICE)
        self.totalTime = self.getTotalTime()

    def onPlayBackStopped(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: Playback stopped', LOGNOTICE)
        if self.playedTime == 0 and self.totalTime == 999999:
            self.streamSuccess = False
            log(cConfig().getLocalizedString(30166) + ' -> [player]: Kodi failed to open stream', LOGERROR)
        self.streamFinished = True

    def onPlayBackEnded(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: Playback completed', LOGNOTICE)
        self.onPlayBackStopped()


class cPlayer:
    def clearPlayList(self):
        oPlaylist = self.__getPlayList()
        oPlaylist.clear()

    def __getPlayList(self):
        return xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

    def addItemToPlaylist(self, oGuiElement):
        oListItem = cGui().createListItem(oGuiElement)
        self.__addItemToPlaylist(oGuiElement, oListItem)

    def __addItemToPlaylist(self, oGuiElement, oListItem):
        oPlaylist = self.__getPlayList()
        oPlaylist.add(oGuiElement.getMediaUrl(), oListItem)

    def startPlayer(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: start player', LOGNOTICE)
        xbmcPlayer = StreamingArchivPlayer()
        monitor = xbmc.Monitor()
        started = False
        stopped_since = 0
        open_started = time.time()
        while (not monitor.abortRequested()) & (not xbmcPlayer.streamFinished):
            is_playing = xbmcPlayer.isPlayingVideo()
            if is_playing:
                started = True
                stopped_since = 0
                xbmcPlayer.playedTime = xbmcPlayer.getTime()
            elif started:
                if not stopped_since:
                    stopped_since = time.time()
                elif time.time() - stopped_since > 1.0:
                    xbmcPlayer.streamFinished = True
                    log(cConfig().getLocalizedString(30166) + ' -> [player]: playback stop detected without callback', LOGNOTICE)
            elif time.time() - open_started > 45:
                xbmcPlayer.streamSuccess = False
                xbmcPlayer.streamFinished = True
                log(cConfig().getLocalizedString(30166) + ' -> [player]: playback open timeout', LOGERROR)
            monitor.waitForAbort(0.5)
        return xbmcPlayer.streamSuccess
