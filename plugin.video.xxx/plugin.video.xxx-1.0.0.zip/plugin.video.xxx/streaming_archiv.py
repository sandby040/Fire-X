﻿# -*- coding: utf-8 -*-
# Python 3

import sys
import xbmc
import xbmcgui
import xbmcplugin
import os
import re
import time
import json
import threading
import concurrent.futures
import urllib.parse
import unicodedata
from urllib.request import Request, urlopen
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.handler.pluginHandler import cPluginHandler
from xbmc import LOGINFO as LOGNOTICE, LOGERROR, log
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from resources.lib.tools import logger, cParser, cCache

# Root menu toggles
SHOW_VOD_ROOT_MENU = False
SHOW_SETTINGS_ROOT_MENU = False

XXX_CATEGORY_GROUPS = [
        {
            'id': 'pornsites',
            'title': 'Pornoseiten',
            'icon': 'category_pornsites.png',
            'plugins': [
                'xhub', 'genteelflair', 'maturetube', 'xvideos_red', 'fuqqt', 'xfantazy',
                'cum_blendporn', 'cum_homemoviestube', 'cum_nonktube', 'cum_pornone',
                'cum_porngo', 'cum_trendyporn', 'cum_wowxxx', 'cum_xsharings',
                'cum_youcrazyx', 'cum_yrprno', 'cum_drtuber', 'cum_fullxcinema',
                'cum_6xtube',
            ],
        },
        {
            'id': 'fans',
            'title': 'Fans & Prominenz',
            'icon': 'category_fans.png',
            'plugins': ['porncream', 'bunkrsearch', 'thothd'],
        },
        {
            'id': 'livecams',
            'title': 'Livecams',
            'icon': 'category_livecams.png',
        'plugins': ['live_xhamster', 'live_cam4', 'live_bongacams', 'live_camsoda'],
        'external': [
            {
                'title': 'Chaturbate',
                'url': 'plugin://plugin.video.cb20/',
                'icon': 'special://home/addons/plugin.video.cb20/resources/icon.png',
            },
        ],
    },
        {
            'id': 'livecam_replays',
            'title': 'Livecams Wiederholung',
            'icon': 'category_livecam_replays.png',
            'plugins': ['livecamrips'],
        },
]

XXX_CATEGORY_ORDER = {group['id']: group for group in XXX_CATEGORY_GROUPS}

# Stille Streaming Archiv-interne Hinweis-/Fehlerfenster, damit Seitenfehler nur geloggt werden.
try:
    _orig_dialog_ok = xbmcgui.Dialog.ok
    _orig_dialog_notification = xbmcgui.Dialog.notification
    _orig_executebuiltin = xbmc.executebuiltin

    def _streaming_archiv_silent_ok(self, *args, **kwargs):
        try:
            log('Streaming Archiv -> suppressed Dialog.ok: %s' % (args,), LOGNOTICE)
        except Exception:
            pass
        return True

    def _streaming_archiv_silent_notification(self, *args, **kwargs):
        try:
            log('Streaming Archiv -> suppressed Dialog.notification: %s' % (args,), LOGNOTICE)
        except Exception:
            pass
        return True

    def _streaming_archiv_silent_executebuiltin(command):
        try:
            if isinstance(command, str) and command.lstrip().startswith('Notification('):
                log('Streaming Archiv -> suppressed builtin notification: %s' % command, LOGNOTICE)
                return
        except Exception:
            pass
        return _orig_executebuiltin(command)

    xbmcgui.Dialog.ok = _streaming_archiv_silent_ok
    xbmcgui.Dialog.notification = _streaming_archiv_silent_notification
    xbmc.executebuiltin = _streaming_archiv_silent_executebuiltin
except Exception:
    pass

try:
    import resolveurl as resolver
except ImportError:
    # Resolver Fehlermeldung (bei defekten oder nicht installierten Resolver)
    xbmcgui.Dialog().ok(cConfig().getLocalizedString(30119), cConfig().getLocalizedString(30120))


def viewInfo(params):
    from resources.lib.tmdbinfo import WindowsBoxes
    parms = ParameterHandler()
    sCleanTitle = params.getValue('searchTitle')
    sMeta = parms.getValue('sMeta')
    sYear = parms.getValue('sYear')
    WindowsBoxes(sCleanTitle, sCleanTitle, sMeta, sYear)


def _text_from_runs(data):
    if not data:
        return ''
    if isinstance(data, str):
        return data
    text = data.get('simpleText')
    if text:
        return text
    return ''.join([run.get('text', '') for run in data.get('runs', []) if isinstance(run, dict)])


def _walk_video_renderers(data):
    if isinstance(data, dict):
        renderer = data.get('videoRenderer')
        if renderer:
            yield renderer
        for value in data.values():
            for item in _walk_video_renderers(value):
                yield item
    elif isinstance(data, list):
        for value in data:
            for item in _walk_video_renderers(value):
                yield item


def _duration_seconds(renderer):
    text = _text_from_runs((renderer or {}).get('lengthText'))
    if not text:
        return 0
    try:
        parts = [int(part) for part in text.strip().split(':')]
    except Exception:
        return 0
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return parts[0] if parts else 0


def _tmdb_image_size(url, size):
    url = str(url or '')
    if 'image.tmdb.org/t/p/' not in url:
        return url
    parts = url.split('/t/p/', 1)
    if len(parts) != 2 or '/' not in parts[1]:
        return url
    return parts[0] + '/t/p/' + size + '/' + parts[1].split('/', 1)[1]


def _clean_trailer_lookup_title(title):
    clean = str(title or '').strip()
    clean = re.sub(r'\([^\)]*\bmulti(?:language)?\b[^\)]*\)', ' ', clean, flags=re.I)
    clean = re.sub(r'\[[^\]]*\bmulti(?:language)?\b[^\]]*\]', ' ', clean, flags=re.I)
    clean = re.sub(r'\bmulti(?:language)?\b', ' ', clean, flags=re.I)
    clean = re.sub(r'\bS\d{1,2}E\d{1,3}\b', ' ', clean, flags=re.I)
    clean = re.sub(r'\b\d{1,2}x\d{1,3}\b', ' ', clean, flags=re.I)
    clean = re.sub(r'\s+', ' ', clean)
    return clean.strip(' -:|')


def _clean_title_for_tmdb(title, year=''):
    clean = _clean_trailer_lookup_title(title)
    if year:
        clean = re.sub(r'\(?\b%s\b\)?' % re.escape(str(year)), ' ', clean)
    clean = re.sub(r'\s+', ' ', clean)
    return clean.strip(' -:')


def _extract_year(value):
    match = re.search(r'\b(?:19|20)\d{2}\b', str(value or ''))
    return match.group(0) if match else ''


def _normalize_title_for_match(title):
    text = str(title or '').replace('\u00df', 'ss').replace('\u1e9e', 'ss')
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    text = re.sub(r'[\[\]\(\)\{\}:|,._+!?/\\-]+', ' ', text.lower())
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _without_leading_articles(title):
    return re.sub(r'^(the|der|die|das|ein|eine)\s+', '', _normalize_title_for_match(title)).strip()


def _meaningful_title_tokens(title):
    ignored = set([
        'der', 'die', 'das', 'the', 'ein', 'eine', 'und', 'oder', 'of', 'and', 'a',
        'trailer', 'official', 'offiziell', 'deutsch', 'german', 'english', 'hd',
        'film', 'movie', 'kino', 'kinocheck'
    ])
    return [token for token in _normalize_title_for_match(title).split() if len(token) > 1 and token not in ignored]


def _youtube_title_matches_request(request_title, result_title, year=''):
    request_year = str(year or '')[:4]
    if not request_year:
        year_match = re.search(r'\b(?:19|20)\d{2}\b', str(request_title or ''))
        request_year = year_match.group(0) if year_match else ''
    request_tokens = [
        token for token in _meaningful_title_tokens(request_title)
        if not re.match(r'^(?:19|20)\d{2}$', token)
    ]
    result_tokens = set(_meaningful_title_tokens(result_title))
    if not request_tokens:
        return True
    if len(request_tokens) == 1:
        token = request_tokens[0]
        result_norm = _normalize_title_for_match(result_title)
        compact_initialisms = [re.sub(r'\s+', '', match) for match in re.findall(r'(?:\b[a-z0-9]\b\s*){2,}', result_norm)]
        if request_year:
            result_years = re.findall(r'\b(?:19|20)\d{2}\b', str(result_title))
            if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
                return False
        if token in compact_initialisms:
            return True
        result_tokens_clean = [
            item for item in _meaningful_title_tokens(result_title)
            if not re.match(r'^#?\d+$', item)
            and not re.match(r'^(?:19|20)\d{2}$', item)
        ]
        return result_tokens_clean == [token]
    missing = [token for token in request_tokens if token not in result_tokens]
    if request_year:
        result_years = re.findall(r'\b(?:19|20)\d{2}\b', str(result_title))
        if result_years and not any(abs(int(request_year) - int(result_year)) <= 1 for result_year in result_years):
            return False
    return len(missing) <= max(0, len(request_tokens) // 4)


def _tmdb_item_title_matches(item, lookup_title):
    candidates = [
        item.get('title'),
        item.get('name'),
        item.get('original_title'),
        item.get('original_name'),
    ]
    lookup_norm = _normalize_title_for_match(lookup_title)
    lookup_no_article = _without_leading_articles(lookup_title)
    for candidate in candidates:
        if not candidate:
            continue
        candidate_norm = _normalize_title_for_match(candidate)
        if candidate_norm == lookup_norm:
            return True
        if candidate_norm.replace(' ', '') == lookup_norm.replace(' ', ''):
            return True
        if _without_leading_articles(candidate) == lookup_no_article:
            return True
    return False


def _year_from_tmdb_item(item, media_type):
    date_value = item.get('release_date') if media_type == 'movie' else item.get('first_air_date')
    if date_value and len(date_value) >= 4:
        return date_value[:4]
    return ''


def _find_tmdb_id_by_search(title, media_type='movie', year=''):
    try:
        from resources.lib.tmdb import cTMDB
        lookup_title = _clean_title_for_tmdb(title, year)
        if not lookup_title:
            return ''
        tmdb = cTMDB(lang='de-DE')
        endpoint = 'search/movie' if media_type == 'movie' else 'search/tv'
        year_param = 'primary_release_year' if media_type == 'movie' else 'first_air_date_year'
        query = 'query=%s&page=1&include_adult=false' % urllib.parse.quote_plus(lookup_title)
        if year:
            query += '&%s=%s' % (year_param, urllib.parse.quote_plus(str(year)))
        data = tmdb._call(endpoint, query)
        results = data.get('results') or []
        if not results and year:
            data = tmdb._call(endpoint, 'query=%s&page=1&include_adult=false' % urllib.parse.quote_plus(lookup_title))
            results = data.get('results') or []
        for item in results:
            if year and _year_from_tmdb_item(item, media_type) and abs(int(str(year)) - int(_year_from_tmdb_item(item, media_type))) > 1:
                continue
            if _tmdb_item_title_matches(item, lookup_title):
                log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: TMDB match for %s: %s' % (lookup_title, item.get('id')), LOGNOTICE)
                return str(item.get('id') or '')
        if results:
            first = results[0]
            if not year or not _year_from_tmdb_item(first, media_type) or abs(int(str(year)) - int(_year_from_tmdb_item(first, media_type))) <= 1:
                log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: TMDB fallback match for %s: %s' % (lookup_title, first.get('id')), LOGNOTICE)
                return str(first.get('id') or '')
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: TMDB search failed: %s' % e, LOGERROR)
    return ''


def _tmdb_video_results(tmdb, endpoint, language):
    include = 'append_to_response=videos&include_video_language=%s' % urllib.parse.quote_plus(language)
    data = tmdb._call(endpoint, include)
    return ((data.get('videos') or {}).get('results') or data.get('results') or [])


def _jikan_year(item):
    value = item.get('year')
    if value:
        return str(value)
    aired_from = ((item.get('aired') or {}).get('from') or '')
    return str(aired_from)[:4] if aired_from else ''


def _jikan_title_candidates(item):
    values = [
        item.get('title'),
        item.get('title_english'),
        item.get('title_japanese'),
    ]
    for entry in item.get('titles') or []:
        values.append(entry.get('title'))
    seen = []
    for value in values:
        clean = _normalize_title_for_match(value)
        if clean and clean not in seen:
            seen.append(clean)
    return seen


def _jikan_title_matches(item, lookup_title):
    lookup_norm = _normalize_title_for_match(lookup_title)
    lookup_no_article = _without_leading_articles(lookup_title)
    for candidate in _jikan_title_candidates(item):
        if candidate == lookup_norm:
            return True
        if candidate.replace(' ', '') == lookup_norm.replace(' ', ''):
            return True
        if re.sub(r'^(the|der|die|das|ein|eine)\s+', '', candidate).strip() == lookup_no_article:
            return True
    return False


def _find_jikan_anime_match(title, media_type='movie', year=''):
    try:
        lookup_title = _clean_title_for_tmdb(title, year or _extract_year(title))
        if not lookup_title:
            return None
        query = urllib.parse.urlencode({'q': lookup_title, 'limit': 8, 'sfw': 'true'})
        request = Request(
            'https://api.jikan.moe/v4/anime?%s' % query,
            headers={'User-Agent': 'Kodi-Anime-Trailer-Lookup/1.0'},
        )
        data = json.loads(urlopen(request, timeout=8).read().decode('utf-8', 'ignore'))
        results = data.get('data') or []
        clean_year = str(year or _extract_year(title) or '')[:4]
        want_series = media_type in ('tvshow', 'season', 'episode', 'tv')
        best = None
        for index, item in enumerate(results):
            if not _jikan_title_matches(item, lookup_title):
                continue
            item_year = _jikan_year(item)
            if clean_year and item_year and abs(int(clean_year) - int(item_year)) > 1:
                continue
            item_type = (item.get('type') or '').lower()
            score = 20 - index
            if clean_year and item_year and clean_year == item_year:
                score += 10
            if clean_year and item_year and abs(int(clean_year) - int(item_year)) <= 1:
                score += 5
            if want_series and item_type in ('tv', 'ona'):
                score += 8
            if not want_series and item_type == 'movie':
                score += 8
            candidate = (score, item)
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best:
            item = best[1]
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Jikan anime match for %s: %s (%s)' % (
                lookup_title,
                item.get('title'),
                _jikan_year(item),
            ), LOGNOTICE)
            return item
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Jikan lookup failed: %s' % e, LOGERROR)
    return None


def _find_youtube_anime_trailer_id(title, year='', preferred_language='any', prefer_series=False):
    base_title = _clean_title_for_tmdb(title, year or _extract_year(title))
    clean_year = str(year or _extract_year(title) or '')[:4]
    if not base_title:
        return ''
    queries = []
    if preferred_language == 'de':
        if clean_year:
            queries.append('%s %s Anime Trailer Deutsch' % (base_title, clean_year))
            queries.append('%s %s Trailer Deutsch' % (base_title, clean_year))
        queries.append('%s Anime Trailer Deutsch' % base_title)
        queries.append('%s Trailer Deutsch' % base_title)
        hl = 'de'
        gl = 'DE'
    elif preferred_language == 'en':
        if clean_year:
            queries.append('%s %s Official Anime Trailer English' % (base_title, clean_year))
            queries.append('%s %s Official Anime Trailer' % (base_title, clean_year))
        queries.append('%s Official Anime Trailer English' % base_title)
        queries.append('%s Official Anime Trailer' % base_title)
        hl = 'en'
        gl = 'US'
    else:
        if clean_year:
            queries.append('%s %s Anime Trailer' % (base_title, clean_year))
            queries.append('%s %s Official Anime Trailer' % (base_title, clean_year))
        queries.append('%s Anime Trailer' % base_title)
        hl = 'en'
        gl = 'US'
    reject_words = ('review', 'kritik', 'analyse', 'reaction', 'recap', 'zusammenfassung',
                    'netflix', 'live action', 'live-action', 'realverfilmung')
    for query in queries:
        payload = json.dumps({
            'context': {
                'client': {
                    'clientName': 'WEB',
                    'clientVersion': '2.20250925.01.00',
                    'hl': hl,
                    'gl': gl,
                },
            },
            'query': query,
        }).encode('utf-8')
        request = Request(
            'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
            data=payload,
            headers={'Content-Type': 'application/json', 'Origin': 'https://www.youtube.com', 'User-Agent': 'Mozilla/5.0'},
        )
        try:
            data = json.loads(urlopen(request, timeout=10).read().decode('utf-8'))
        except Exception as e:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Anime YouTube lookup failed: %s' % e, LOGERROR)
            continue
        best = None
        for index, renderer in enumerate(_walk_video_renderers(data)):
            video_id = renderer.get('videoId')
            if not video_id:
                continue
            title_text = _text_from_runs(renderer.get('title'))
            video_title = title_text.lower()
            channel_text = ' '.join(
                _text_from_runs(renderer.get(key))
                for key in ('ownerText', 'longBylineText', 'shortBylineText')
            ).lower()
            has_german_marker = 'deutsch' in video_title or 'german' in video_title
            has_english_marker = 'english' in video_title or 'englisch' in video_title
            if 'trailer' not in video_title:
                continue
            if preferred_language == 'de' and not has_german_marker:
                continue
            if preferred_language == 'en' and has_german_marker:
                continue
            if prefer_series and re.search(r'\b(film|movie)\b', video_title):
                continue
            if any(word in video_title or word in channel_text for word in reject_words):
                continue
            duration = _duration_seconds(renderer)
            if duration and duration > 600:
                continue
            if not _youtube_title_matches_request(base_title, title_text, clean_year):
                continue
            score = -index
            if clean_year and clean_year in title_text:
                score += 10
            if preferred_language == 'de' and has_german_marker:
                score += 8
            if preferred_language == 'en' and (has_english_marker or 'official' in video_title):
                score += 4
            if 'anime' in video_title or 'crunchyroll' in channel_text or 'one piece official' in channel_text:
                score += 5
            if duration and 45 <= duration <= 300:
                score += 1
            candidate = (score, video_id, title_text)
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Anime YouTube Trailer found (%s) for %s: %s - %s' % (
                preferred_language,
                query,
                best[1],
                best[2],
            ), LOGNOTICE)
            return best[1]
    return ''


def _find_jikan_anime_trailer_id(title, media_type='movie', year=''):
    item = _find_jikan_anime_match(title, media_type, year)
    if not item:
        return ''
    trailer = item.get('trailer') or {}
    youtube_id = trailer.get('youtube_id')
    if youtube_id:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Jikan Trailer found: %s - %s' % (
            youtube_id,
            trailer.get('title') or item.get('title') or title,
        ), LOGNOTICE)
        return youtube_id
    return _find_youtube_anime_trailer_id(item.get('title') or title, _jikan_year(item) or year)


def _find_aniworld_anime_trailer_id(title, media_type='tvshow', year=''):
    item = _find_jikan_anime_match(title, media_type, year)
    anime_title = (item or {}).get('title') or title
    anime_year = _jikan_year(item) if item else year
    prefer_series = media_type in ('tvshow', 'season', 'episode', 'tv')
    video_id = _find_youtube_anime_trailer_id(anime_title, anime_year, 'de', prefer_series)
    if not video_id:
        video_id = _find_youtube_anime_trailer_id(anime_title, anime_year, 'en', prefer_series)
    if not video_id and item:
        trailer = item.get('trailer') or {}
        video_id = trailer.get('youtube_id') or ''
        if video_id:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Jikan fallback Trailer found: %s - %s' % (
                video_id,
                trailer.get('title') or item.get('title') or title,
            ), LOGNOTICE)
    if not video_id:
        video_id = _find_youtube_anime_trailer_id(anime_title, anime_year, 'any', prefer_series)
    return video_id


def _is_aniworld_trailer_choice(original_url):
    try:
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(str(original_url or '')).query)
        if (query.get('site') or [''])[0] == 'aniworld':
            return True
    except Exception:
        pass
    return 'site=aniworld' in str(original_url or '').lower()


def _find_tmdb_trailer_id(title, media_type='movie', year='', preferred_language='de'):
    try:
        from resources.lib.tmdb import cTMDB
        lookup_media_type = 'tvshow' if media_type in ('tvshow', 'season', 'episode') else 'movie'
        tmdb_id = _find_tmdb_id_by_search(title, lookup_media_type, year)
        if not tmdb_id:
            return ''
        lang_code = 'de' if preferred_language == 'de' else 'en'
        tmdb = cTMDB(lang='de-DE' if preferred_language == 'de' else 'en-US')
        endpoint = ('movie/%s' if lookup_media_type == 'movie' else 'tv/%s') % tmdb_id
        videos = _tmdb_video_results(tmdb, endpoint, lang_code)
        best = None
        for index, video in enumerate(videos):
            if (video.get('site') or '').lower() != 'youtube':
                continue
            if (video.get('iso_639_1') or '').lower() != lang_code:
                continue
            video_type = (video.get('type') or '').lower()
            name = video.get('name') or ''
            if video_type != 'trailer' and 'trailer' not in name.lower():
                continue
            official = 1 if video.get('official') else 0
            score = official * 10 + (3 if video_type == 'trailer' else 0) - index
            candidate = (score, video.get('key'), name)
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best and best[1]:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: TMDB Trailer found (%s): %s - %s' % (
                preferred_language,
                best[1],
                best[2],
            ), LOGNOTICE)
            return best[1]
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: TMDB trailer failed: %s' % e, LOGERROR)
    return ''


def _find_youtube_trailer_id(title, year='', preferred_language='de', strict_german_marker=True):
    base_title = _clean_trailer_lookup_title(title)
    query_parts = [base_title]
    if year and str(year) not in base_title:
        query_parts.append(str(year))
    base_query = ' '.join(part for part in query_parts if part).strip()
    if not base_query:
        return ''

    reject_words = ('review', 'kritik', 'analyse', 'erklaert', 'erklÃ¤rt', 'reaction',
                    'recap', 'zusammenfassung', 'ranking', 'theorie', 'erklaerung',
                    'erklÃ¤rung', 'komplett', 'ganze folge')
    if preferred_language == 'kinocheck':
        search_queries = (
            (base_query + ' KinoCheck Deutsch Trailer', True),
        )
        hl = 'de'
        gl = 'DE'
    elif preferred_language == 'de':
        if strict_german_marker:
            search_queries = (
                (base_query + ' KinoCheck Deutsch Trailer', True),
                (base_query + ' Offizieller Deutsch Trailer', False),
            )
        else:
            search_queries = (
                (base_query + ' Trailer Deutsch', False),
                (base_query + ' Offizieller Deutsch Trailer', False),
            )
        hl = 'de'
        gl = 'DE'
    else:
        search_queries = (
            (base_query + ' Official Trailer', False),
            (base_query + ' Trailer', False),
        )
        hl = 'en'
        gl = 'US'
    for query, require_kinocheck in search_queries:
        payload = json.dumps({
            'context': {
                'client': {
                    'clientName': 'WEB',
                    'clientVersion': '2.20250925.01.00',
                    'hl': hl,
                    'gl': gl,
                },
            },
            'query': query,
        }).encode('utf-8')
        request = Request(
            'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'Origin': 'https://www.youtube.com',
                'User-Agent': (
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/140.0.0.0 Safari/537.36'
                ),
            },
        )
        data = json.loads(urlopen(request, timeout=10).read().decode('utf-8'))
        best = None
        for index, renderer in enumerate(_walk_video_renderers(data)):
            video_id = renderer.get('videoId')
            if not video_id:
                continue
            title_text = _text_from_runs(renderer.get('title'))
            renderer_title = title_text.lower()
            channel_text = ' '.join(
                _text_from_runs(renderer.get(key))
                for key in ('ownerText', 'longBylineText', 'shortBylineText')
            ).lower()
            is_kinocheck = 'kinocheck' in renderer_title or 'kinocheck' in channel_text
            has_german_marker = 'deutsch' in renderer_title or 'german' in renderer_title
            has_english_marker = 'english' in renderer_title or 'englisch' in renderer_title
            duration = _duration_seconds(renderer)
            if require_kinocheck and not is_kinocheck:
                continue
            if require_kinocheck and not has_german_marker:
                continue
            if has_english_marker and not has_german_marker:
                continue
            if strict_german_marker and preferred_language in ('de', 'kinocheck') and not has_german_marker:
                log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Trailer rejected without German marker for %s: %s' % (base_query, title_text), LOGNOTICE)
                continue
            if preferred_language == 'en' and has_german_marker:
                continue
            if 'trailer' not in renderer_title:
                continue
            if any(word in renderer_title for word in reject_words):
                continue
            if duration and duration > 600:
                continue
            if not _youtube_title_matches_request(base_title, title_text, year):
                log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Trailer rejected for %s: %s' % (base_query, title_text), LOGNOTICE)
                continue
            score = 10 if is_kinocheck else 0
            if 'offiziell' in renderer_title or 'official' in renderer_title:
                score += 3
            if has_german_marker:
                score += 2
            if duration and 45 <= duration <= 300:
                score += 1
            candidate = (score, -index, video_id, title_text)
            if best is None or candidate[:3] > best[:3]:
                best = candidate
        if best:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: YouTube Trailer found (%s) for %s: %s - %s' % (
                preferred_language,
                query,
                best[2],
                best[3],
            ), LOGNOTICE)
            return best[2]
    return ''


def _play_youtube_trailer_deferred(video_id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % video_id
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmc.sleep(250)
        xbmc.executebuiltin('PlayMedia(%s)' % url)
        for _ in range(24):
            xbmc.sleep(250)
            if xbmc.Player().isPlayingVideo():
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                xbmc.sleep(250)
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                break
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Trailer starter failed: %s' % e, LOGERROR)


def _trailer_search_title(title, media_type, tvshow_title='', season='', episode=''):
    base = _clean_trailer_lookup_title(tvshow_title or title)
    media_type = str(media_type or '').lower()
    if media_type == 'season' and season:
        return '%s Staffel %s' % (base, season)
    if media_type == 'episode':
        parts = [base]
        if season:
            parts.append('Staffel %s' % season)
        if episode:
            parts.append('Episode %s' % episode)
        clean_title = _clean_trailer_lookup_title(title)
        if clean_title and clean_title not in parts:
            parts.append(clean_title)
        return ' '.join(parts).strip()
    return _clean_trailer_lookup_title(title or base)


def _as_int(value, default=0):
    try:
        if value in (None, ''):
            return default
        return int(float(str(value).replace(',', '.')))
    except Exception:
        return default


def _as_float(value):
    try:
        if value in (None, ''):
            return None
        return float(str(value).replace(',', '.'))
    except Exception:
        return None


def _set_info_tag_value(tag, method, value):
    if value in (None, '', []):
        return
    try:
        func = getattr(tag, method, None)
        if func:
            func(value)
    except Exception:
        pass


def _apply_rich_info_to_listitem(item, meta, media_type, title, year='', season=''):
    dbtype = 'tvshow' if media_type in ('tvshow', 'season', 'episode') else 'movie'
    if media_type in ('season', 'episode'):
        dbtype = media_type

    display_title = meta.get('title') or meta.get('originaltitle') or title
    info = {
        'title': display_title,
        'plot': meta.get('plot', ''),
        'mediatype': dbtype,
        'genre': meta.get('genre', ''),
        'director': meta.get('director', ''),
        'writer': meta.get('writer', ''),
        'studio': meta.get('studio', ''),
        'premiered': meta.get('premiered', ''),
        'tagline': meta.get('tagline', ''),
        'duration': _as_int(meta.get('duration')) * 60 if meta.get('duration') else 0,
        'rating': _as_float(meta.get('rating')) or 0,
        'votes': _as_int(meta.get('votes')),
    }
    if year or meta.get('year'):
        info['year'] = _as_int(meta.get('year') or year)
    if season:
        info['season'] = _as_int(season)
    try:
        item.setInfo('video', {k: v for k, v in info.items() if v not in (None, '', 0, [])})
    except Exception:
        pass

    try:
        tag = item.getVideoInfoTag()
        _set_info_tag_value(tag, 'setMediaType', dbtype)
        _set_info_tag_value(tag, 'setTitle', display_title)
        _set_info_tag_value(tag, 'setPlot', meta.get('plot', ''))
        _set_info_tag_value(tag, 'setTagLine', meta.get('tagline', ''))
        _set_info_tag_value(tag, 'setPremiered', meta.get('premiered', ''))
        _set_info_tag_value(tag, 'setGenres', [g.strip() for g in str(meta.get('genre', '')).split('/') if g.strip()])
        _set_info_tag_value(tag, 'setDirectors', [d.strip() for d in str(meta.get('director', '')).split('/') if d.strip()])
        _set_info_tag_value(tag, 'setWriters', [w.strip() for w in str(meta.get('writer', '')).split('/') if w.strip()])
        _set_info_tag_value(tag, 'setStudios', [s.strip() for s in str(meta.get('studio', '')).split('/') if s.strip()])
        if meta.get('year') or year:
            _set_info_tag_value(tag, 'setYear', _as_int(meta.get('year') or year))
        if meta.get('duration'):
            _set_info_tag_value(tag, 'setDuration', _as_int(meta.get('duration')) * 60)
        rating = _as_float(meta.get('rating'))
        if rating is not None:
            try:
                tag.setRating(rating, _as_int(meta.get('votes')), 'themoviedb', True)
            except Exception:
                pass
            try:
                tag.setRating(rating, _as_int(meta.get('votes')), 'tmdb', False)
            except Exception:
                pass
        if meta.get('tmdb_id'):
            try:
                tag.setUniqueID(str(meta.get('tmdb_id')), 'tmdb')
            except Exception:
                pass
        if meta.get('imdb_id'):
            try:
                tag.setUniqueID(str(meta.get('imdb_id')), 'imdb')
            except Exception:
                pass
    except Exception:
        pass

    art = {}
    if meta.get('cover_url'):
        cover_url = _tmdb_image_size(meta.get('cover_url'), 'w185')
        art.update({'icon': cover_url, 'thumb': cover_url, 'poster': cover_url})
    if meta.get('backdrop_url'):
        art['fanart'] = _tmdb_image_size(meta.get('backdrop_url'), 'w300')
    if art:
        try:
            item.setArt(art)
        except Exception:
            pass

    props = {
        'TmdbId': meta.get('tmdb_id', ''),
        'tmdb_id': meta.get('tmdb_id', ''),
        'imdb_id': meta.get('imdb_id', ''),
        'Budget': meta.get('budget', ''),
        'Revenue': meta.get('revenue', ''),
        'TMDb_Rating': meta.get('TMDb_Rating') or meta.get('rating', ''),
        'Trakt_Rating': meta.get('Trakt_Rating', ''),
    }
    for key, value in props.items():
        if value not in (None, ''):
            try:
                item.setProperty(key, str(value))
            except Exception:
                pass
    rating = _as_float(meta.get('TMDb_Rating') or meta.get('rating'))
    if rating is not None:
        try:
            item.setRating('themoviedb', rating, _as_int(meta.get('votes')), True)
        except Exception:
            pass
        try:
            item.setRating('tmdb', rating, _as_int(meta.get('votes')), False)
        except Exception:
            pass
    try:
        ids = {}
        if meta.get('tmdb_id'):
            ids['tmdb'] = str(meta.get('tmdb_id'))
        if meta.get('imdb_id'):
            ids['imdb'] = str(meta.get('imdb_id'))
        if ids:
            item.setUniqueIDs(ids)
    except Exception:
        pass


def _show_rich_tmdb_information(title, media_type='movie', year='', tvshow_title='', season='', tmdb_id=''):
    lookup_type = 'tvshow' if media_type in ('tvshow', 'season', 'episode') else 'movie'
    lookup_title = tvshow_title if lookup_type == 'tvshow' and tvshow_title else title
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        from resources.lib.tmdb import cTMDB
        meta = cTMDB().get_meta(lookup_type, lookup_title, tmdb_id=tmdb_id, year=year, advanced='true') or {}
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if not meta:
            xbmc.executebuiltin('Action(Info)')
            return
        item = xbmcgui.ListItem(label=meta.get('title') or lookup_title or title)
        _apply_rich_info_to_listitem(item, meta, media_type, title, year=year, season=season)
        xbmcgui.Dialog().info(item)
    except Exception as e:
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        except Exception:
            pass
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Rich info failed: %s' % e, LOGERROR)
        xbmc.executebuiltin('Action(Info)')


def _clean_favourite_label(value):
    value = str(value or '')
    value = re.sub(r'\[/?(?:B|I|COLOR[^\]]*|UPPERCASE|LOWERCASE|CAPITALIZE)\]', '', value, flags=re.I)
    value = re.sub(r'\s+', ' ', value)
    return value.strip()


def _current_plugin_url():
    query = sys.argv[2] if len(sys.argv) > 2 else ''
    if query and not query.startswith('?'):
        query = '?' + query
    return '%s%s' % (sys.argv[0], query)


def _favourite_label(title, media_type='', tvshow_title='', season='', episode=''):
    title = _clean_favourite_label(title)
    tvshow_title = _clean_favourite_label(tvshow_title)
    media_type = str(media_type or '').lower()
    if media_type == 'season' and tvshow_title:
        return '%s - %s' % (tvshow_title, title or ('Staffel %s' % season))
    if media_type == 'episode' and tvshow_title:
        parts = [tvshow_title]
        if season:
            parts.append('S%s' % season)
        if episode:
            parts.append('E%s' % episode)
        if title and title != tvshow_title:
            parts.append(title)
        return ' '.join(parts)
    return title or tvshow_title or 'Favorit'


def _favourite_thumb_from_url(url):
    try:
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        for key in ('thumb', 'trumb', 'sThumbnail', 'thumbnail', 'iconimage'):
            value = (params.get(key) or [''])[0]
            if value:
                return value
        original_url = (params.get('choiceOriginalUrl') or [''])[0]
        if original_url:
            original_params = urllib.parse.parse_qs(urllib.parse.urlsplit(original_url).query)
            for key in ('thumb', 'trumb', 'sThumbnail', 'thumbnail', 'iconimage'):
                value = (original_params.get(key) or [''])[0]
                if value:
                    return value
    except Exception:
        pass
    return ''


def _add_kodi_favourite(title, favourite_url, media_type='', tvshow_title='', season='', episode='', thumb=''):
    label = _favourite_label(title, media_type, tvshow_title, season, episode)
    thumb = thumb or _favourite_thumb_from_url(favourite_url)
    try:
        request = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'Favourites.AddFavourite',
            'params': {
                'title': label,
                'type': 'media',
                'path': favourite_url,
                'thumbnail': thumb,
            },
        }
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        if response.get('error'):
            raise RuntimeError(response.get('error'))
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: added favourite via Kodi JSON-RPC: %s' % label, LOGNOTICE)
        return True
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: add favourite failed: %s' % e, LOGERROR)
        xbmcgui.Dialog().notification('Streaming Archiv', 'Favorit konnte nicht gespeichert werden', time=2500)
        return False


def trailerChoice(params):
    title = params.getValue('choiceTitle') or params.getValue('title') or ''
    media_type = params.getValue('choiceMediaType') or 'movie'
    original_url = params.getValue('choiceOriginalUrl') or ''
    original_is_folder = params.getValue('choiceOriginalIsFolder') == '1'
    tvshow_title = (
        params.getValue('choiceTVShowTitle')
        or params.getValue('sName')
        or params.getValue('TVShowTitle')
        or params.getValue('tvshowtitle')
        or ''
    )
    if not tvshow_title and original_url:
        try:
            qs = urllib.parse.parse_qs(urllib.parse.urlsplit(original_url).query)
            tvshow_title = (qs.get('sName') or qs.get('TVShowTitle') or qs.get('tvshowtitle') or [''])[0]
        except Exception:
            tvshow_title = ''
    season = params.getValue('choiceSeason') or ''
    episode = params.getValue('choiceEpisode') or ''
    if media_type == 'tvshow':
        play_label = 'Serie wiedergeben'
    elif media_type == 'season':
        play_label = 'Staffel wiedergeben'
    elif media_type == 'episode':
        play_label = 'Episode wiedergeben'
    else:
        play_label = 'Film wiedergeben'

    selection = xbmcgui.Dialog().select(title, [play_label, 'Zu Favoriten hinzufuegen'])
    if selection == 0:
        if original_is_folder:
            xbmc.executebuiltin('Container.Update(%s)' % original_url)
        else:
            xbmc.executebuiltin('RunPlugin(%s)' % original_url)
    elif selection == 1:
        _add_kodi_favourite(title, original_url or _current_plugin_url(), media_type, tvshow_title, season, episode)
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), False)
    except:
        pass

def parseUrl():
    if xbmc.getInfoLabel('Container.PluginName') == 'plugin.video.osmosis':
        sys.exit()

    params = ParameterHandler()
    logger.info(params.getAllParameters())

    # If no function is set, we set it to the default "load" function
    if params.exist('function'):
        sFunction = params.getValue('function')
        if sFunction == 'spacer':
            return True
        elif sFunction == 'clearCache':
            cRequestHandler('dummy').clearCache()
            return
        elif sFunction == 'viewInfo':
            viewInfo(params)
            return
        elif sFunction == 'trailerChoice':
            trailerChoice(params)
            return
        elif sFunction == 'searchAlter':
            searchAlter(params)
            return
        elif sFunction == 'searchTMDB':
            searchTMDB(params)
            return
        elif sFunction == 'devUpdates':
            from resources.lib import updateManager
            updateManager.devUpdates()
            return
        elif sFunction == 'pluginInfo':
            cPluginHandler().pluginInfo()
            return
        elif sFunction == 'vod':
            vodGuiElements(sFunction)
            return
        elif sFunction == 'changelog':
            from resources.lib import tools
            cConfig().setSetting('changelog_version', '')
            tools.changelog()
            return
        elif sFunction == 'devWarning':
            from resources.lib import tools
            tools.devWarning()
            return
            
    elif params.exist('remoteplayurl'):
        try:
            remotePlayUrl = params.getValue('remoteplayurl')
            sLink = resolver.resolve(remotePlayUrl)
            if sLink:
                xbmc.executebuiltin('PlayMedia(' + sLink + ')')
            else:
                log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Could not play remote url %s ' % sLink, LOGNOTICE)
        except resolver.resolver.ResolverError as e:
            log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: ResolverError: %s' % e, LOGERROR)
        return
    else:
        sFunction = 'load'

    # Test if we should run a function on a special site
    if not params.exist('site'):
        # As a default if no site was specified, we run the default starting gui with all plugins
        showMainMenu(sFunction)
        return
    sSiteName = params.getValue('site')
    if params.exist('playMode'):
        from resources.lib.gui.hoster import cHosterGui
        url = False
        playMode = params.getValue('playMode')
        isHoster = params.getValue('isHoster')
        url = params.getValue('url')
        manual = params.exist('manual')

        if cConfig().getSetting('hosterSelect') == 'Auto' and playMode != 'jd' and playMode != 'jd2' and playMode != 'pyload' and not manual:
            cHosterGui().streamAuto(playMode, sSiteName, sFunction)
        else:
            cHosterGui().stream(playMode, sSiteName, sFunction, url)
        return

    log(cConfig().getLocalizedString(30166) + " -> [streaming_archiv]: Call function '%s' from '%s'" % (sFunction, sSiteName), LOGNOTICE)
    # If the hoster gui is called, run the function on it and return
    if sSiteName == 'cHosterGui':
        showHosterGui(sFunction)
    # If global search is called
    elif sSiteName == 'globalSearch':
        searchterm = False
        if params.exist('searchterm'):
            searchterm = params.getValue('searchterm')
        searchGlobal(searchterm)
    elif sSiteName == 'categorySearch':
        searchterm = False
        if params.exist('searchterm'):
            searchterm = params.getValue('searchterm')
        searchCategoryGlobal(params.getValue('category'), searchterm)
    elif sSiteName == 'xxxCategory':
        showXXXCategory(params.getValue('category'), sFunction)
    elif sSiteName == 'Streaming Archiv':
        oGui = cGui()
        oGui.openSettings()
        # resolves strange errors in the logfile
        #oGui.updateDirectory()
        oGui.setEndOfDirectory()
        xbmc.executebuiltin('Action(ParentDir)')
    # Resolver Einstellungen im HauptmenÃ¼
    elif sSiteName == 'resolver':
        oGui = cGui()
        resolver.display_settings()
        # resolves strange errors in the logfile
        oGui.setEndOfDirectory()
        xbmc.executebuiltin('Action(ParentDir)')
    # Manuelles Update im HauptmenÃ¼
    elif sSiteName == 'devUpdates':
        from resources.lib import updateManager
        updateManager.devUpdates()
    # Plugin Infos    
    elif sSiteName == 'pluginInfo':
        cPluginHandler().pluginInfo()
    # Changelog anzeigen    
    elif sSiteName == 'changelog':
        from resources.lib import tools
        tools.changelog()
    # Dev Warnung anzeigen
    elif sSiteName == 'devWarning':
        from resources.lib import tools
        tools.devWarning()
    # VoD MenÃ¼ Site Name
    elif sSiteName == 'vod':
        vodGuiElements(sFunction)
    # Unterordner der Einstellungen   
    elif sSiteName == 'settings':
        oGui = cGui()
        for folder in settingsGuiElements():
            oGui.addFolder(folder)
        oGui.setEndOfDirectory()
    else:
        # Else load any other site as plugin and run the function
        plugin = __import__(sSiteName, globals(), locals())
        function = getattr(plugin, sFunction)
        function()


def showMainMenu(sFunction):
    ART = os.path.join(cConfig().getAddonInfo('path'), 'resources', 'art')
    oGui = cGui()
    for group in XXX_CATEGORY_GROUPS:
        params = ParameterHandler()
        params.setParam('category', group['id'])
        oGuiElement = cGuiElement(group['title'], 'xxxCategory', 'showXXXCategory')
        icon = os.path.join(ART, 'sites', group.get('icon', ''))
        if group.get('icon') and os.path.exists(icon):
            oGuiElement.setThumbnail(icon)
            oGuiElement.setIcon(icon)
        oGui.addFolder(oGuiElement, params)
    # VoD root entry can stay hidden when the user opens it through a custom link.
    if SHOW_VOD_ROOT_MENU:
        oGuiElement = cGuiElement()
        oGuiElement.setTitle(cConfig().getLocalizedString(30412))
        oGuiElement.setSiteName('vod')
        oGuiElement.setFunction(sFunction)
        oGuiElement.setThumbnail(os.path.join(ART, 'vod.png'))
        oGuiElement.setIcon(os.path.join(ART, 'settings.png'))
        oGui.addFolder(oGuiElement)

    if SHOW_SETTINGS_ROOT_MENU:
        if cConfig().getSetting('SettingsFolder') == 'true':
            # Einstellung im MenÃ¼ mit Untereinstellungen
            oGuiElement = cGuiElement()
            oGuiElement.setTitle(cConfig().getLocalizedString(30041))
            oGuiElement.setSiteName('settings')
            oGuiElement.setFunction('showSettingsFolder')
            oGuiElement.setThumbnail(os.path.join(ART, 'settings.png'))
            oGui.addFolder(oGuiElement)
        else:
            for folder in settingsGuiElements():
                oGui.addFolder(folder)
    oGui.setEndOfDirectory()


def _plugins_by_id():
    return {plugin.get('id'): plugin for plugin in cPluginHandler().getAvailablePlugins()}


def _addPluginToGui(oGui, plugin, sFunction):
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(plugin['name'])
    oGuiElement.setSiteName(plugin['id'])
    oGuiElement.setFunction(sFunction)
    if 'icon' in plugin and plugin['icon']:
        oGuiElement.setThumbnail(plugin['icon'])
        oGuiElement.setIcon(plugin['icon'])
    oGui.addFolder(oGuiElement)


def _categorySearchGuiElement(category_id):
    ART = os.path.join(cConfig().getAddonInfo('path'), 'resources', 'art')
    params = ParameterHandler()
    params.setParam('category', category_id)
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30040))
    oGuiElement.setSiteName('categorySearch')
    oGuiElement.setFunction('categorySearch')
    oGuiElement.setThumbnail(os.path.join(ART, 'search.png'))
    oGuiElement.setIcon(os.path.join(ART, 'search.png'))
    return oGuiElement, params


def showXXXCategory(category_id=False, sFunction='load'):
    group = XXX_CATEGORY_ORDER.get(category_id)
    oGui = cGui()
    if not group:
        oGui.setEndOfDirectory(False)
        return

    searchElement, searchParams = _categorySearchGuiElement(group['id'])
    oGui.addFolder(searchElement, searchParams)

    plugins = _plugins_by_id()
    live_external_inserted = False
    for plugin_id in group.get('plugins', []):
        plugin = plugins.get(plugin_id)
        if plugin:
            _addPluginToGui(oGui, plugin, 'load')
        if group['id'] == 'livecams' and plugin_id == 'live_xhamster' and not live_external_inserted:
            for external in group.get('external', []):
                params = ParameterHandler()
                params.setParam('sUrl', external['url'])
                oGuiElement = cGuiElement(external['title'], '', '')
                oGuiElement.setThumbnail(external['icon'])
                oGuiElement.setIcon(external['icon'])
                oGui.addFolder(oGuiElement, params)
            live_external_inserted = True
    oGui.setEndOfDirectory()


def vodGuiElements(sFunction): # Vod MenÃ¼
    oGui = cGui()
    oPluginHandler = cPluginHandler()
    aPlugins = oPluginHandler.getAvailablePlugins() # Suche Plugins mit Pluginhandler
    if not aPlugins:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: No activated Vod Plugins found', LOGNOTICE)
        # Ã–ffne Einstellungen wenn keine VoD SitePlugins vorhanden
        oGui.openSettings()
        oGui.updateDirectory()
    else:
        # Erstelle ein gui element fÃ¼r alle gefundenen Siteplugins
        for aPlugin in sorted(aPlugins, key=lambda k: k['id']):
            #if cConfig().getSetting('indexVoDyes') == 'true': # Wenn VoD MenÃ¼ True
            oGuiElement = cGuiElement()
            oGuiElement.setTitle(aPlugin['name'])
            oGuiElement.setSiteName(aPlugin['id'])
            if not 'vod_' in aPlugin['id']: continue # Blende alle SitePlugins ohne vod_ am Anfang aus
            oGuiElement.setFunction(sFunction)
            if 'icon' in aPlugin and aPlugin['icon']:
                oGuiElement.setThumbnail(aPlugin['icon'])
            oGui.addFolder(oGuiElement)
    oGui.setEndOfDirectory()

def settingsGuiElements():
    ART = os.path.join(cConfig().getAddonInfo('path'), 'resources', 'art')

    # GUI Plugin Informationen
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30267))
    oGuiElement.setSiteName('pluginInfo')
    oGuiElement.setFunction('pluginInfo')
    oGuiElement.setThumbnail(os.path.join(ART, 'plugin_info.png'))
    PluginInfo = oGuiElement


    # GUI Streaming Archiv Einstellungen
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30042))
    oGuiElement.setSiteName('Streaming Archiv')
    oGuiElement.setFunction('display_settings')
    oGuiElement.setThumbnail(os.path.join(ART, 'streaming_archiv_settings.png'))
    streamingArchivSettings = oGuiElement

    # GUI Resolver Einstellungen
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30043))
    oGuiElement.setSiteName('resolver')
    oGuiElement.setFunction('display_settings')
    oGuiElement.setThumbnail(os.path.join(ART, 'resolveurl_settings.png'))
    resolveurlSettings = oGuiElement
    
    # GUI Nightly Updatemanager
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30121))
    oGuiElement.setSiteName('devUpdates')
    oGuiElement.setFunction('devUpdates')
    oGuiElement.setThumbnail(os.path.join(ART, 'manuel_update.png'))
    DevUpdateMan = oGuiElement
    return PluginInfo, streamingArchivSettings, resolveurlSettings, DevUpdateMan


def globalSearchGuiElement():
    ART = os.path.join(cConfig().getAddonInfo('path'), 'resources', 'art')

    # Create a gui element for global search
    oGuiElement = cGuiElement()
    oGuiElement.setTitle(cConfig().getLocalizedString(30040))
    oGuiElement.setSiteName('globalSearch')
    oGuiElement.setFunction('globalSearch')
    oGuiElement.setThumbnail(os.path.join(ART, 'search.png'))
    return oGuiElement


def showHosterGui(sFunction):
    from resources.lib.gui.hoster import cHosterGui
    oHosterGui = cHosterGui()
    function = getattr(oHosterGui, sFunction)
    function()
    return True


SEARCH_SITE_PRIORITY = {
    'moflix-stream': 0,
    'filmpalast': 1,
    'aniworld': 2,
    'serienstream': 3,
    'einschalten': 4,
    'movie2k': 5,
    'movie4k': 6,
    'kinox': 7,
    'hdfilme': 8,
    'hdfilme_1': 9,
    'kinoger': 10,
    'kinokiste': 11,
    'kkiste': 12,
    'kkiste-movie': 13,
    'skiste': 14,
    'megakino': 15,
    'netzkino': 16,
    'streamcloud': 17,
    'topstreamfilm': 18
}

GLOBAL_SEARCH_MAX_WORKERS = 3


def _normalize_search_title(title):
    title = str(title or '').lower()
    title = re.sub(r'\[[^\]]+\]', ' ', title)
    title = re.sub(r'\(\d{4}\)', ' ', title)
    title = re.sub(r'\b(?:s\d{1,2}e\d{1,2}|staffel\s*\d+|episode\s*\d+)\b', ' ', title)
    title = re.sub(r'[^a-z0-9]+', ' ', title)
    return re.sub(r'\s+', ' ', title).strip()


def _get_search_year(gui_element):
    try:
        return int(gui_element._sYear)
    except Exception:
        return 99999


def _get_search_site_rank(gui_element):
    return SEARCH_SITE_PRIORITY.get(gui_element.getSiteName(), 999)


def _sort_search_results(results):
    return sorted(
        results,
        key=lambda result: (
            _normalize_search_title(result['guiElement'].getTitle()),
            _get_search_site_rank(result['guiElement']),
            _get_search_year(result['guiElement']),
            result['guiElement'].getTitle().lower(),
            result['guiElement'].getSiteName().lower()
        )
    )


def _get_global_search_workers(searchable_plugins):
    try:
        plugin_count = len(searchable_plugins)
    except Exception:
        plugin_count = 0
    if plugin_count <= 0:
        return 1
    return min(GLOBAL_SEARCH_MAX_WORKERS, plugin_count)


def _filter_search_results_by_words(search_results, search_text):
	words = [word for word in _normalize_search_title(search_text).split(' ') if word]
	if not words:
		return search_results
	filtered = []
	for result in search_results:
		title = _normalize_search_title(result['guiElement'].getTitle())
		if all(word in title for word in words):
			filtered.append(result)
	return filtered


def searchGlobal(sSearchText=False):
	oGui = cGui()
	oGui.globalSearch = True
	oGui._collectMode = True
	cGui._suppressInfoNotifications = True

	if not sSearchText:
		sSearchText = oGui.showKeyBoard(sHeading=cConfig().getLocalizedString(30280))  # Bitte Suchbegriff eingeben
	if not sSearchText:
		cGui._suppressInfoNotifications = False
		oGui.setEndOfDirectory()
		return True

	aPlugins = cPluginHandler().getAvailablePlugins()
	dialog = xbmcgui.DialogProgress()
	dialog.create(cConfig().getLocalizedString(30122), cConfig().getLocalizedString(30123))

	numPlugins = len(aPlugins)
	searchablePlugins = [pluginEntry for pluginEntry in aPlugins if pluginEntry['globalsearch'] not in ['false', '']]
	if not searchablePlugins:
		cGui._suppressInfoNotifications = False
		dialog.close()
		oGui.setEndOfDirectory()
		return True

	def worker(pluginEntry):
		log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Searching for %s at %s' % (sSearchText, pluginEntry['id']),LOGNOTICE)
		_pluginSearch(pluginEntry, sSearchText, oGui)
		return pluginEntry['name']

	with concurrent.futures.ThreadPoolExecutor(max_workers=_get_global_search_workers(searchablePlugins)) as executor:
		future_to_plugin = {executor.submit(worker, pluginEntry): pluginEntry for pluginEntry in searchablePlugins}

		for count, future in enumerate(concurrent.futures.as_completed(future_to_plugin)):
			pluginEntry = future_to_plugin[future]
			if dialog.iscanceled():
				cGui._suppressInfoNotifications = False
				oGui.setEndOfDirectory()
				return
			try: pluginName = future.result()
			except Exception as e:
				pluginName = pluginEntry['name']
				log(f"Fehler bei Plugin {pluginName}: {str(e)}", LOGERROR)
			progress = (count + 1) * 50 // len(searchablePlugins)
			dialog.update(progress, pluginName + cConfig().getLocalizedString(30125))
	dialog.close()

	# Ergebnisse anzeigen
	oGui._collectMode = False
	search_results = list(oGui.searchResults)
	total = len(search_results)
	if total == 0:
		cGui._suppressInfoNotifications = False
		oGui.setEndOfDirectory()
		return True
	dialog = xbmcgui.DialogProgress()
	dialog.create(cConfig().getLocalizedString(30126), cConfig().getLocalizedString(30127))
	cGui._suppressInfoNotifications = False

	for count, result in enumerate(_sort_search_results(search_results), 1):
		if dialog.iscanceled():
			oGui.setEndOfDirectory()
			return
		oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)
		dialog.update(count * 100 // total, str(count) + cConfig().getLocalizedString(30128) + str(total) + ': ' + result['guiElement'].getTitle())

	dialog.close()
	oGui.setView()
	oGui.setEndOfDirectory()
	return True


def searchCategoryGlobal(category_id=False, sSearchText=False):
	group = XXX_CATEGORY_ORDER.get(category_id)
	oGui = cGui()
	oGui.globalSearch = True
	oGui._collectMode = True
	cGui._suppressInfoNotifications = True

	if not group:
		cGui._suppressInfoNotifications = False
		oGui.setEndOfDirectory(False)
		return True

	if not sSearchText:
		sSearchText = oGui.showKeyBoard(sHeading=cConfig().getLocalizedString(30280))  # Bitte Suchbegriff eingeben
	if not sSearchText:
		cGui._suppressInfoNotifications = False
		oGui.setEndOfDirectory()
		return True

	selected_ids = set(group.get('plugins', []))
	aPlugins = [
		pluginEntry for pluginEntry in cPluginHandler().getAvailablePlugins()
		if pluginEntry.get('id') in selected_ids and pluginEntry.get('globalsearch') not in ['false', '']
	]

	dialog = xbmcgui.DialogProgress()
	dialog.create(cConfig().getLocalizedString(30122), cConfig().getLocalizedString(30123))
	if not aPlugins:
		cGui._suppressInfoNotifications = False
		dialog.close()
		oGui.setEndOfDirectory()
		return True

	def worker(pluginEntry):
		log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Searching for %s at %s' % (sSearchText, pluginEntry['id']), LOGNOTICE)
		_pluginSearch(pluginEntry, sSearchText, oGui)
		return pluginEntry['name']

	with concurrent.futures.ThreadPoolExecutor(max_workers=_get_global_search_workers(aPlugins)) as executor:
		future_to_plugin = {executor.submit(worker, pluginEntry): pluginEntry for pluginEntry in aPlugins}

		for count, future in enumerate(concurrent.futures.as_completed(future_to_plugin)):
			pluginEntry = future_to_plugin[future]
			if dialog.iscanceled():
				cGui._suppressInfoNotifications = False
				oGui.setEndOfDirectory()
				return True
			try:
				pluginName = future.result()
			except Exception as e:
				pluginName = pluginEntry['name']
				log(f"Fehler bei Plugin {pluginName}: {str(e)}", LOGERROR)
			progress = (count + 1) * 50 // len(aPlugins)
			dialog.update(progress, pluginName + cConfig().getLocalizedString(30125))
	dialog.close()

	oGui._collectMode = False
	search_results = list(oGui.searchResults)
	if group.get('id') == 'pornsites':
		search_results = _filter_search_results_by_words(search_results, sSearchText)
	total = len(search_results)
	if total == 0:
		cGui._suppressInfoNotifications = False
		oGui.setEndOfDirectory()
		return True

	dialog = xbmcgui.DialogProgress()
	dialog.create(cConfig().getLocalizedString(30126), cConfig().getLocalizedString(30127))
	cGui._suppressInfoNotifications = False
	for count, result in enumerate(_sort_search_results(search_results), 1):
		if dialog.iscanceled():
			oGui.setEndOfDirectory()
			return True
		oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)
		dialog.update(count * 100 // total, str(count) + cConfig().getLocalizedString(30128) + str(total) + ': ' + result['guiElement'].getTitle())

	dialog.close()
	oGui.setView()
	oGui.setEndOfDirectory()
	return True

def searchAlter(params):
    searchTitle = params.getValue('searchTitle')
    searchImdbId = params.getValue('searchImdbID')
    searchYear = params.getValue('searchYear')

    # Jahr aus dem Titel extrahieren
    if ' (19' in searchTitle or ' (20' in searchTitle:
        isMatch, aYear = cParser.parse(searchTitle, '(.*?) \((\d{4})\)')
        if isMatch:
            searchTitle = aYear[0][0]
            if not searchYear:
                searchYear = str(aYear[0][1])

    # Staffel oder Episodenkennung abschneiden
    for token in [' S0', ' E0', ' - Staffel', ' Staffel']:
        if token in searchTitle:
            searchTitle = searchTitle.split(token)[0].strip()
            break

    oGui = cGui()
    oGui.globalSearch = True
    oGui._collectMode = True
    cGui._suppressInfoNotifications = True
    aPlugins = cPluginHandler().getAvailablePlugins()

    dialog = xbmcgui.DialogProgress()
    dialog.create(cConfig().getLocalizedString(30122), cConfig().getLocalizedString(30123))

    searchablePlugins = [
        pluginEntry for pluginEntry in aPlugins
        if pluginEntry['globalsearch'] not in ['false', '']
    ]
    if not searchablePlugins:
        cGui._suppressInfoNotifications = False
        dialog.close()
        oGui.setEndOfDirectory()
        return True

    def worker(pluginEntry):
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Searching for ' + searchTitle + pluginEntry['id'], LOGNOTICE)
        _pluginSearch(pluginEntry, searchTitle, oGui)
        return pluginEntry['name']

    with concurrent.futures.ThreadPoolExecutor(max_workers=_get_global_search_workers(searchablePlugins)) as executor:
        future_to_plugin = {executor.submit(worker, plugin): plugin for plugin in searchablePlugins}

        for count, future in enumerate(concurrent.futures.as_completed(future_to_plugin)):
            plugin = future_to_plugin[future]
            if dialog.iscanceled():
                cGui._suppressInfoNotifications = False
                oGui.setEndOfDirectory()
                return
            try:
                name = future.result()
            except Exception as e:
                name = plugin['name']
                log(f"Fehler bei Plugin {name}: {str(e)}", LOGERROR)
            dialog.update((count + 1) * 50 // len(searchablePlugins) + 50, name + cConfig().getLocalizedString(30125))

    dialog.close()

    # Ergebnisse filtern
    filteredResults = []
    for result in oGui.searchResults:
        guiElement = result['guiElement']
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Site: %s Titel: %s' % (guiElement.getSiteName(), guiElement.getTitle()), LOGNOTICE)
        if searchTitle not in guiElement.getTitle():
            continue
        if guiElement._sYear and searchYear and guiElement._sYear != searchYear:
            continue
        if searchImdbId and guiElement.getItemProperties().get('imdbID') != searchImdbId:
            continue
        filteredResults.append(result)

    oGui._collectMode = False
    total = len(filteredResults)
    if total == 0:
        cGui._suppressInfoNotifications = False
        oGui.setEndOfDirectory()
        xbmc.executebuiltin('Container.Update')
        return True
    cGui._suppressInfoNotifications = False
    for result in _sort_search_results(filteredResults):
        oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)

    oGui.setView()
    oGui.setEndOfDirectory()
    xbmc.executebuiltin('Container.Update')
    return True

def searchTMDB(params):
    sSearchText = params.getValue('searchTitle')
    oGui = cGui()
    oGui.globalSearch = True
    oGui._collectMode = True
    cGui._suppressInfoNotifications = True

    if not sSearchText:
        cGui._suppressInfoNotifications = False
        oGui.setEndOfDirectory()
        return True

    aPlugins = cPluginHandler().getAvailablePlugins()

    dialog = xbmcgui.DialogProgress()
    dialog.create(cConfig().getLocalizedString(30122), cConfig().getLocalizedString(30123))

    searchablePlugins = [
        pluginEntry for pluginEntry in aPlugins
        if pluginEntry['globalsearch'] != 'false'
    ]
    if not searchablePlugins:
        cGui._suppressInfoNotifications = False
        dialog.close()
        oGui.setEndOfDirectory()
        return True

    def worker(pluginEntry):
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: Searching for %s at %s' % (sSearchText, pluginEntry['id']), LOGNOTICE)
        _pluginSearch(pluginEntry, sSearchText, oGui)
        return pluginEntry['name']

    with concurrent.futures.ThreadPoolExecutor(max_workers=_get_global_search_workers(searchablePlugins)) as executor:
        future_to_plugin = {executor.submit(worker, plugin): plugin for plugin in searchablePlugins}

        for count, future in enumerate(concurrent.futures.as_completed(future_to_plugin)):
            plugin = future_to_plugin[future]
            if dialog.iscanceled():
                cGui._suppressInfoNotifications = False
                oGui.setEndOfDirectory()
                return
            try:
                name = future.result()
            except Exception as e:
                name = plugin['name']
                log(f"Fehler bei Plugin {name}: {str(e)}", LOGERROR)
            dialog.update((count + 1) * 50 // len(searchablePlugins) + 50, name + cConfig().getLocalizedString(30125))

    dialog.close()

    oGui._collectMode = False
    search_results = list(oGui.searchResults)
    total = len(search_results)
    if total == 0:
        cGui._suppressInfoNotifications = False
        oGui.setEndOfDirectory()
        return True

    dialog = xbmcgui.DialogProgress()
    dialog.create(cConfig().getLocalizedString(30126), cConfig().getLocalizedString(30127))
    cGui._suppressInfoNotifications = False

    for count, result in enumerate(_sort_search_results(search_results), 1):
        if dialog.iscanceled():
            oGui.setEndOfDirectory()
            return
        oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)
        dialog.update(count * 100 // total, str(count) + cConfig().getLocalizedString(30128) + str(total) + ': ' + result['guiElement'].getTitle())

    dialog.close()
    oGui.setView()
    oGui.setEndOfDirectory()
    return True


def _pluginSearch(pluginEntry, sSearchText, oGui):
    try:
        plugin = __import__(pluginEntry['id'], globals(), locals())
        function = getattr(plugin, '_search')
        function(oGui, sSearchText)
    except Exception:
        log(cConfig().getLocalizedString(30166) + ' -> [streaming_archiv]: ' + pluginEntry['name'] + ': search failed', LOGERROR)
        import traceback
        log(traceback.format_exc())
