# -*- coding: utf-8 -*-
# Python 3

import base64
import json
import os
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler
from html import unescape
from socketserver import TCPServer, ThreadingMixIn
from urllib.parse import parse_qs, unquote_plus, urlencode, urljoin, urlsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import cParser, logger

try:
    import xbmc
except Exception:
    xbmc = None

try:
    from xbmcvfs import translatePath
except Exception:
    try:
        from xbmc import translatePath
    except Exception:
        translatePath = None

_ADDONS_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for _module_path in (
    os.path.join(_ADDONS_DIR, 'script.module.cloudrequest'),
    os.path.join(_ADDONS_DIR, 'script.module.requests', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.urllib3', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.chardet', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.idna', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.certifi', 'lib'),
):
    if os.path.exists(_module_path) and _module_path not in sys.path:
        sys.path.insert(0, _module_path)

try:
    import cloudscraper
except Exception:
    cloudscraper = None

try:
    from resources.lib import pyaes
except Exception:
    try:
        import pyaes
    except Exception:
        pyaes = None


SITE_IDENTIFIER = 'livecamrips'
SITE_NAME = 'LiveCamRips'
SITE_ICON = 'livecamrips.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'livecamrips.to')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'
_SCRAPER = None
_ABSTREAM_PROXIES = {}


def _kodi_temp_path(filename):
    temp_dir = ''
    if translatePath:
        try:
            temp_dir = translatePath('special://temp/')
        except Exception:
            temp_dir = ''
    if not temp_dir:
        temp_dir = os.path.join(os.path.dirname(_ADDONS_DIR), 'temp')
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    return os.path.join(temp_dir, filename)


def _abstream_port_marker_path():
    return _kodi_temp_path('livecamrips_abstream_proxy.port')


def _write_abstream_port_marker(port):
    try:
        with open(_abstream_port_marker_path(), 'w', encoding='utf-8') as handle:
            handle.write(str(int(port)))
    except Exception:
        pass


def _clear_abstream_port_marker(port):
    try:
        marker = _abstream_port_marker_path()
        if not os.path.exists(marker):
            return
        with open(marker, 'r', encoding='utf-8') as handle:
            current = handle.read().strip()
        if current == str(int(port)):
            os.remove(marker)
    except Exception:
        pass


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _title_from_url(url):
    slug = urlsplit(str(url or '')).path.rstrip('/').rsplit('/', 1)[-1]
    slug = unquote_plus(slug).replace('-', ' ').replace('_', ' ')
    slug = re.sub(r'\s+', ' ', slug).strip()
    return slug.title() if slug else ''


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _origin_from_url(url):
    parsed = urlsplit(str(url or ''))
    if parsed.scheme and parsed.netloc:
        return parsed.scheme + '://' + parsed.netloc
    return ''


def _browser_headers(referer=REFERER, origin=None):
    if origin is None:
        origin = _origin_from_url(referer) or URL_MAIN
    headers = {
        'User-Agent': cRequestHandler.RandomUA(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Referer': referer or REFERER,
        'Upgrade-Insecure-Requests': '1',
    }
    if origin:
        headers['Origin'] = origin
    return headers


def _get_scraper():
    global _SCRAPER
    if not cloudscraper:
        return None
    if _SCRAPER is None:
        _SCRAPER = cloudscraper.create_scraper()
    return _SCRAPER


def _request(url, cache_hours=3, referer=REFERER, method='GET', data=None, json_data=None):
    absolute_url = _abs_url(url)
    scraper = _get_scraper()
    if scraper:
        try:
            if method == 'POST':
                if json_data is not None:
                    headers = _browser_headers(referer)
                    headers['Content-Type'] = 'application/json'
                    response = scraper.post(absolute_url, json=json_data, headers=headers, timeout=15)
                else:
                    response = scraper.post(absolute_url, data=data or {}, headers=_browser_headers(referer), timeout=15)
            else:
                response = scraper.get(absolute_url, headers=_browser_headers(referer), timeout=15)
            if response.status_code < 400:
                return response.text, response.url
            logger.info('-> [LiveCamRips]: cloudscraper status %s for %s' % (response.status_code, absolute_url))
        except Exception as e:
            logger.info('-> [LiveCamRips]: cloudscraper failed for %s: %s' % (absolute_url, e))

    request_data = json.dumps(json_data) if json_data is not None else data
    request = cRequestHandler(_abs_url(url), caching=(method == 'GET'), ignoreErrors=True, method=method, data=request_data, jspost=(json_data is not None))
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', _origin_from_url(referer) or URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    request.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8')
    if json_data is not None:
        request.addHeaderEntry('Content-Type', 'application/json')
    return request.request(), request.getRealUrl()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer, origin=''):
    headers = {
        'User-Agent': cRequestHandler.RandomUA(),
        'Referer': referer or REFERER,
        'verifypeer': 'false',
    }
    if origin:
        headers['Origin'] = origin
    return '|' + urlencode(headers)


def _stream_request_headers(referer, origin=''):
    headers = _browser_headers(referer, origin)
    headers['Accept'] = '*/*'
    headers.pop('Upgrade-Insecure-Requests', None)
    return headers


def _is_error_page(html):
    text = str(html or '')
    return any(marker in text for marker in (
        'CLOUDFLARE-SCHUTZ AKTIV',
        'SEITE NICHT ERREICHBAR',
        'URL FEHLER',
        '<title>Page Expired</title>',
    ))


def _parse_video_items(html):
    entries = []
    seen = set()
    pattern = r'<a[^>]+href=["\']([^"\']*/video/\d+)["\'][^>]*>([\s\S]*?)(?=<a[^>]+href=["\'][^"\']*/video/\d+["\']|</body>|$)'
    for match in re.finditer(pattern, html, re.I):
        href = _abs_url(match.group(1))
        block = match.group(2)
        context = html[match.start():match.end()]
        title = _clean_text(_first_match(context, [
            r'<h\d[^>]*>([\s\S]*?)</h\d>',
            r'<a[^>]+href=["\'][^"\']*/model/[^"\']+["\'][^>]*>\s*<span[^>]*>([\s\S]*?)</span>',
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ]))
        date = _first_match(context, [r'((?:19|20)\d{2}-\d{2}-\d{2}\s+\d{2}:\d{2})'])
        website = _clean_text(_first_match(context, [
            r'<a[^>]+href=["\'][^"\']*/website/[^"\']+["\'][^>]*>([\s\S]*?)</a>',
        ]))
        if title and date:
            title = title + ' - ' + date
        if title and website:
            title = title + ' - ' + website
        thumbnail = _first_match(block, [
            r'<img[^>]+src=["\']([^"\']+)["\']',
            r'data-src=["\']([^"\']+)["\']',
            r'data-default-thumb=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(context, [
            r'<span[^>]*class=["\'][^"\']*(?:duration|tm-text-gray)[^"\']*["\'][^>]*>(\d{1,2}:\d{2}(?::\d{2})?)</span>',
            r'>(\d{1,2}:\d{2}(?::\d{2})?)<',
        ]))
        if not title:
            title = 'Video ' + href.rsplit('/', 1)[-1]
        if not href or href in seen:
            continue
        seen.add(href)
        entries.append({
            'title': title,
            'url': href,
            'thumbnail': _abs_url(thumbnail) if thumbnail else '',
            'duration': duration,
        })
    return entries


def _parse_model_items(html):
    entries = []
    seen = set()
    pattern = r'<a[^>]+href=["\']([^"\']*/model/\d+/[^"\']+)["\'][^>]*>([\s\S]*?)(?=<a[^>]+href=["\'][^"\']*/model/\d+/[^"\']+["\']|</body>|$)'
    for match in re.finditer(pattern, html, re.I):
        url = _abs_url(match.group(1))
        block = match.group(2)
        title = _clean_text(_first_match(block, [
            r'<span[^>]*>([\s\S]*?)</span>',
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ]))
        if not title or title.lower() == 'image':
            title = _title_from_url(url) or title
        thumbnail = _first_match(block, [
            r'<img[^>]+src=["\']([^"\']+)["\']',
            r'data-src=["\']([^"\']+)["\']',
            r'data-default-thumb=["\']([^"\']+)["\']',
        ])
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({
            'title': title,
            'url': url,
            'thumbnail': _abs_url(thumbnail) if thumbnail else '',
        })
    return entries


def _current_page_number(url):
    path = urljoin(URL_MAIN + '/', str(url or '')).rstrip('/').rsplit('/', 1)[-1]
    return int(path) if path.isdigit() else 1


def _next_page_url(html, current_url=''):
    raw_url = _first_match(html, [
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*tm-btn-next[^"\']*["\'][^>]*>\s*Next Page\s*</a>',
        r'<a[^>]+class=["\'][^"\']*tm-btn-next[^"\']*["\'][^>]+href=["\']([^"\']+)["\'][^>]*>\s*Next Page\s*</a>',
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*Next Page\s*</a>',
    ])
    if raw_url:
        return _abs_url(raw_url)

    current = _current_page_number(current_url)
    candidates = []
    for href in re.findall(r'href=["\']([^"\']+)["\']', html, re.I):
        url = _abs_url(href)
        path = url.rstrip('/').rsplit('/', 1)[-1]
        if path.isdigit() and int(path) > current:
            candidates.append((int(path), url))
    return sorted(candidates)[0][1] if candidates else ''


def load():
    params = ParameterHandler()
    menu = [
        ('Modell Suche', 'showModelSearch', URL_MAIN + '/'),
        ('Neueste Uploads', 'showEntries', URL_MAIN + '/'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, source_html='', search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    if source_url and entries:
        next_url = _next_page_url(source_html, source_url)
        if next_url and next_url != _abs_url(source_url):
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)

    gui.setView('movies')
    gui.setEndOfDirectory()


def _is_hidden_playback_format(entry, source_url=''):
    try:
        thumbnail_host = urlsplit(entry.get('thumbnail') or '').netloc.lower()
        if thumbnail_host == 'images.livecamrips.to':
            logger.info('-> [LiveCamRips]: hidden unstable AbStream thumbnail format for %s' % (entry.get('url') or ''))
            return True
    except Exception as e:
        logger.info('-> [LiveCamRips]: hidden-format check failed for %s: %s' % (entry.get('url') or '', e))
    return False


def _filter_hidden_playback_formats(entries, source_url=''):
    visible = []
    hidden = 0
    for entry in entries:
        if _is_hidden_playback_format(entry, source_url):
            hidden += 1
            continue
        visible.append(entry)
    if hidden:
        logger.info('-> [LiveCamRips]: hidden %s unstable AbStream entries from list' % hidden)
    return visible


def _collect_paginated_entries(first_html, first_url, parser_func, max_items=100, cache_hours=0):
    entries = []
    seen = set()
    html = first_html or ''
    source_url = first_url or URL_MAIN + '/'
    last_html = html
    last_url = source_url
    pages = 0
    while html and pages < 12 and len(entries) < max_items:
        pages += 1
        page_entries = parser_func(html)
        for entry in page_entries:
            key = entry.get('url') or entry.get('title')
            if not key or key in seen:
                continue
            seen.add(key)
            entries.append(entry)
            if len(entries) >= max_items:
                break
        last_html = html
        last_url = source_url
        if len(entries) >= max_items:
            break
        next_url = _next_page_url(html, source_url)
        if not next_url or next_url == _abs_url(source_url):
            break
        html, real_url = _request(next_url, cache_hours=cache_hours, referer=source_url)
        source_url = real_url or next_url
        if _is_error_page(html):
            break
    return entries[:max_items], last_html, last_url


def _add_model_entries(entries):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, params, True, total)
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html, real_url = _request(source_url, cache_hours=2)
    source_url = real_url or source_url
    entries = _parse_video_items(html)

    if sSearchText and entries:
        needle = sSearchText.lower()
        if '/search' not in source_url and '/model/' not in source_url:
            entries = [entry for entry in entries if needle in entry['title'].lower() or cParser.search(needle, entry['title'].lower())]
    entries = _filter_hidden_playback_formats(entries, source_url)

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, params, False, total)
        return

    _add_video_entries(entries, source_url, 'showEntries', source_html=html, search_text=sSearchText or '')


def showModelSearch():
    search_text = cGui().showKeyBoard(sHeading='Modell Suche')
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def showSearch():
    showModelSearch()


def _post_model_search(search_text):
    search_text = _normalize_german_search_text(search_text)
    homepage, _ = _request(URL_MAIN + '/', cache_hours=0)
    token = _first_match(homepage, [
        r'<form[^>]+action=["\'][^"\']*/search["\'][\s\S]*?name=["\']_token["\']\s+value=["\']([^"\']+)["\']',
        r'name=["\']_token["\']\s+value=["\']([^"\']+)["\']',
    ])
    data = {'search': search_text}
    if token:
        data['_token'] = token
    return _request(URL_MAIN + '/search', cache_hours=0, referer=REFERER, method='POST', data=data)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    html, real_url = _post_model_search(sSearchText)
    if _is_error_page(html):
        logger.info('-> [LiveCamRips]: model search failed for %s' % sSearchText)
        if not sGui:
            cGui().setEndOfDirectory()
        return
    source_url = real_url or URL_MAIN + '/search'
    videos, collected_html, collected_url = _collect_paginated_entries(html, source_url, _parse_video_items, max_items=70, cache_hours=0)
    if videos:
        videos = _filter_hidden_playback_formats(videos, source_url)[:40]
        if sGui:
            params = ParameterHandler()
            total = len(videos)
            for entry in videos:
                params.setParam('entryUrl', entry['url'])
                params.setParam('sUrl', entry['url'])
                params.setParam('sName', entry['title'])
                params.setParam('sThumbnail', entry['thumbnail'])
                element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
                if entry['thumbnail']:
                    element.setThumbnail(entry['thumbnail'])
                element.setMediaType('movie')
                sGui.addFolder(element, params, False, total)
            return
        _add_video_entries(videos, collected_url, 'showEntries', source_html=collected_html, search_text=sSearchText)
        return
    if not sGui:
        models, _model_html, _model_url = _collect_paginated_entries(html, source_url, _parse_model_items, max_items=40, cache_hours=0)
        _add_model_entries(models)


def _embed_url_from_page(html):
    raw_url = _first_match(html, [
        r'<iframe[^>]+src=["\']([^"\']+)["\']',
        r'(https?://(?:www\.)?abstream\.to/embed-[^"\'<>\s]+)',
        r'(https?://(?:www\.)?(?:vidara|streamix|stmix|vidmatrix)[^"\'<>\s]+/(?:e|v)/[A-Za-z0-9]+)',
    ])
    return _abs_url(raw_url) if raw_url else ''


def _hoster_title(url):
    host = urlsplit(str(url or '')).netloc.lower()
    host = host[4:] if host.startswith('www.') else host
    if 'abstream' in host:
        return 'AbStream'
    if 'vidara' in host:
        return 'Vidara'
    if 'videosh' in host:
        return 'VideoSH'
    return host or SITE_NAME


def _host_needs_direct_resolve(url):
    host = urlsplit(str(url or '')).netloc.lower()
    return 'abstream.to' in host or 'vidara.' in host or 'videosh.' in host


def _proxy_b64(value):
    raw = str(value or '').encode('utf-8')
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _proxy_unb64(value):
    value = str(value or '')
    value += '=' * (-len(value) % 4)
    return base64.urlsafe_b64decode(value.encode('ascii')).decode('utf-8')


def _proxy_url(port, upstream_url, manifest=False):
    path = '/playlist.m3u8' if manifest else '/segment.ts'
    return 'http://127.0.0.1:%s%s?u=%s' % (port, path, _proxy_b64(upstream_url))


def _rewrite_hls_manifest(text, upstream_url, port):
    base_url = upstream_url.rsplit('/', 1)[0] + '/'
    raw_text = str(text or '')
    is_media_playlist = '#EXTINF' in raw_text

    def rewrite_attr(match):
        target = urljoin(base_url, match.group(1))
        manifest = '.m3u8' in urlsplit(target).path.lower()
        return 'URI="%s"' % _proxy_url(port, target, manifest)

    lines = []
    inserted_playlist_type = False
    for line in raw_text.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            target = urljoin(base_url, stripped)
            manifest = '.m3u8' in urlsplit(target).path.lower()
            lines.append(_proxy_url(port, target, manifest))
        else:
            lines.append(re.sub(r'URI="([^"]+)"', rewrite_attr, line, flags=re.I))
            if is_media_playlist and stripped == '#EXTM3U' and '#EXT-X-PLAYLIST-TYPE' not in raw_text:
                lines.append('#EXT-X-PLAYLIST-TYPE:VOD')
                inserted_playlist_type = True
    if is_media_playlist and '#EXT-X-ENDLIST' not in raw_text:
        lines.append('#EXT-X-ENDLIST')
    if inserted_playlist_type:
        logger.info('-> [LiveCamRips]: AbStream proxy normalized media playlist as VOD')
    return '\n'.join(lines) + '\n'


def _select_hls_media_playlist(master_url, headers):
    scraper = _get_scraper()
    if not scraper:
        return master_url
    try:
        response = scraper.get(master_url, headers=headers, timeout=(4, 8))
        if response.status_code >= 400:
            response.close()
            return master_url
        text = response.text
        response.close()
        if '#EXT-X-STREAM-INF' not in text:
            return master_url
        base_url = master_url.rsplit('/', 1)[0] + '/'
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '.m3u8' in urlsplit(line).path.lower():
                media_url = urljoin(base_url, line)
                logger.info('-> [LiveCamRips]: AbStream selected media playlist %s' % media_url)
                return media_url
    except Exception as e:
        logger.info('-> [LiveCamRips]: AbStream media playlist selection failed for %s: %s' % (master_url, e))
    return master_url


class _AbStreamProxyHandler(BaseHTTPRequestHandler):
    def setup(self):
        BaseHTTPRequestHandler.setup(self)
        try:
            self.connection.settimeout(4)
        except Exception:
            pass
        state = getattr(self.server, 'state', {})
        try:
            with state.get('lock'):
                state.setdefault('connections', set()).add(self.connection)
        except Exception:
            pass

    def finish(self):
        try:
            BaseHTTPRequestHandler.finish(self)
        finally:
            state = getattr(self.server, 'state', {})
            try:
                with state.get('lock'):
                    state.setdefault('connections', set()).discard(self.connection)
            except Exception:
                pass

    def _playback_closed(self):
        state = getattr(self.server, 'state', {})
        if not xbmc or not state.get('playback_seen'):
            return False
        try:
            if not xbmc.Player().isPlayingVideo():
                state['playback_done'] = True
                return True
        except Exception:
            pass
        return bool(state.get('playback_done'))

    def _send_gone(self):
        self.send_response(410)
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()

    def do_HEAD(self):
        path = urlsplit(self.path).path
        state = getattr(self.server, 'state', {})
        if state.get('stopping') or self._playback_closed():
            self._send_gone()
            return
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl' if path.startswith('/playlist') else 'video/mp2t')
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()

    def do_GET(self):
        if urlsplit(self.path).path == '/shutdown':
            state = getattr(self.server, 'state', {})
            state['stopping'] = True
            self.send_response(204)
            self.send_header('Connection', 'close')
            self.end_headers()

            def close_server():
                _close_abstream_proxy(self.server)

            thread = threading.Thread(target=close_server)
            thread.daemon = True
            thread.start()
            return

        state = getattr(self.server, 'state', {})
        if state.get('stopping') or self._playback_closed():
            self._send_gone()
            return
        state['last_request'] = state.get('time', lambda: 0)()
        params = parse_qs(urlsplit(self.path).query)
        raw_url = params.get('u', [''])[0]
        if not raw_url:
            self.send_error(400)
            return
        try:
            upstream_url = _proxy_unb64(raw_url)
        except Exception:
            self.send_error(400)
            return

        scraper = _get_scraper()
        if not scraper:
            self.send_error(502)
            return

        headers = dict(state.get('headers') or {})
        request_range = self.headers.get('Range')
        if request_range:
            headers['Range'] = request_range

        response = None
        try:
            is_manifest = self.path.startswith('/playlist') or '.m3u8' in urlsplit(upstream_url).path.lower()
            request_timeout = (2, 4) if is_manifest else (2, 3)
            response = scraper.get(upstream_url, headers=headers, timeout=request_timeout, stream=not is_manifest)
            if state.get('stopping'):
                response.close()
                return
            if response.status_code >= 400:
                logger.info('-> [LiveCamRips]: AbStream proxy upstream %s for %s' % (response.status_code, upstream_url))
                response.close()
                self.send_error(response.status_code)
                return

            content_type = response.headers.get('Content-Type') or ''
            if is_manifest:
                raw = response.text
                response.close()
                data = _rewrite_hls_manifest(raw, upstream_url, self.server.server_address[1]).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(data)
                return

            self.send_response(206 if response.status_code == 206 else 200)
            self.send_header('Content-Type', content_type or 'video/mp2t')
            if response.headers.get('Content-Length'):
                self.send_header('Content-Length', response.headers.get('Content-Length'))
            if response.headers.get('Content-Range'):
                self.send_header('Content-Range', response.headers.get('Content-Range'))
            self.send_header('Accept-Ranges', response.headers.get('Accept-Ranges', 'bytes'))
            self.send_header('Connection', 'close')
            self.end_headers()
            for chunk in response.iter_content(chunk_size=64 * 1024):
                if state.get('stopping'):
                    break
                if chunk:
                    self.wfile.write(chunk)
            response.close()
        except Exception as e:
            logger.info('-> [LiveCamRips]: AbStream proxy error for %s: %s' % (upstream_url, e))
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass
            try:
                self.send_error(502)
            except Exception:
                pass

    def log_message(self, *args):
        pass


class _AbStreamProxyServer(ThreadingMixIn, TCPServer):
    daemon_threads = True
    allow_reuse_address = True


def _close_abstream_proxy(server):
    try:
        state = getattr(server, 'state', {})
        state['stopping'] = True
        with state.get('lock'):
            connections = list(state.setdefault('connections', set()))
        for connection in connections:
            try:
                connection.shutdown(2)
            except Exception:
                pass
            try:
                connection.close()
            except Exception:
                pass
    except Exception:
        pass
    try:
        server.shutdown()
        server.server_close()
    except Exception:
        pass
    try:
        port = server.server_address[1]
        _ABSTREAM_PROXIES.pop(port, None)
        _clear_abstream_port_marker(port)
    except Exception:
        pass


def _start_abstream_proxy_server(stream_url, headers):
    try:
        server = _AbStreamProxyServer(('127.0.0.1', 0), _AbStreamProxyHandler)
        now = __import__('time').time
        server.state = {
            'headers': dict(headers),
            'time': now,
            'last_request': now(),
            'lock': threading.Lock(),
            'connections': set(),
            'stopping': False,
        }
        port = server.server_address[1]
        _ABSTREAM_PROXIES[port] = server
        _write_abstream_port_marker(port)
        thread = threading.Thread(target=server.serve_forever)
        thread.daemon = True
        thread.start()

        def monitor():
            import time
            playback_seen = False
            stopped_since = 0
            while time.time() - server.state.get('last_request', time.time()) < 45:
                time.sleep(0.5)
                if xbmc:
                    try:
                        if xbmc.Player().isPlayingVideo():
                            playback_seen = True
                            server.state['playback_seen'] = True
                            stopped_since = 0
                        elif playback_seen:
                            if not stopped_since:
                                stopped_since = time.time()
                            elif time.time() - stopped_since >= 1.0:
                                server.state['playback_done'] = True
                                logger.info('-> [LiveCamRips]: AbStream playback ended, closing proxy 127.0.0.1:%s' % port)
                                break
                    except Exception:
                        pass
            _close_abstream_proxy(server)

        monitor_thread = threading.Thread(target=monitor)
        monitor_thread.daemon = True
        monitor_thread.start()
        logger.info('-> [LiveCamRips]: AbStream proxy started on 127.0.0.1:%s for %s' % (port, stream_url))
        return server
    except Exception as e:
        logger.info('-> [LiveCamRips]: AbStream proxy start failed for %s: %s' % (stream_url, e))
        return None


def _start_abstream_proxy(stream_url, headers):
    server = _start_abstream_proxy_server(stream_url, headers)
    if server:
        port = server.server_address[1]
        return _proxy_url(port, stream_url, True)
    return ''


def _create_local_abstream_playlist(stream_url, headers):
    scraper = _get_scraper()
    if not scraper:
        return ''
    server = _start_abstream_proxy_server(stream_url, headers)
    if not server:
        return ''
    port = server.server_address[1]
    response = None
    try:
        response = scraper.get(stream_url, headers=headers, timeout=(2, 4))
        if response.status_code >= 400:
            logger.info('-> [LiveCamRips]: AbStream local playlist upstream %s for %s' % (response.status_code, stream_url))
            response.close()
            _close_abstream_proxy(server)
            return ''
        raw = response.text
        response.close()
        if '#EXTINF' not in raw:
            logger.info('-> [LiveCamRips]: AbStream local playlist is not a media playlist for %s' % stream_url)
            _close_abstream_proxy(server)
            return ''
        playlist = _rewrite_hls_manifest(raw, stream_url, port)
        filename = 'livecamrips_abstream_%s.m3u8' % port
        path = _kodi_temp_path(filename)
        with open(path, 'w', encoding='utf-8') as handle:
            handle.write(playlist)
        logger.info('-> [LiveCamRips]: AbStream local VOD playlist created %s' % path)
        return path
    except Exception as e:
        logger.info('-> [LiveCamRips]: AbStream local playlist failed for %s: %s' % (stream_url, e))
        if response is not None:
            try:
                response.close()
            except Exception:
                pass
        _close_abstream_proxy(server)
        return ''


def _probe_stream_url(stream_url, referer, origin='', headers=None):
    stream_url = str(stream_url or '')
    if not stream_url.startswith('http'):
        return False
    scraper = _get_scraper()
    if not scraper:
        return True
    headers = headers or _stream_request_headers(referer, origin)
    try:
        response = scraper.get(stream_url, headers=headers, timeout=7, stream=True)
        response.close()
        if response.status_code < 400:
            return True
        logger.info('-> [LiveCamRips]: stream probe failed %s for %s' % (response.status_code, stream_url.split('|', 1)[0]))
    except Exception as e:
        logger.info('-> [LiveCamRips]: stream probe error for %s: %s' % (stream_url.split('|', 1)[0], e))
    return False


def _stream_url_from_abstream(embed_url, source_url):
    html, _ = _request(embed_url, cache_hours=0, referer=source_url or REFERER)
    stream_url = _first_match(html, [
        r'sources\s*:\s*\[\s*\{\s*file\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
        r'file\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
        r'(https?://[^"\'<>\s]+\.(?:m3u8|mp4)(?:\?[^"\'<>\s]*)?)',
    ])
    if not stream_url:
        logger.info('-> [LiveCamRips]: AbStream direct stream not found for %s' % embed_url)
        return ''
    stream_url = _abs_url(stream_url, embed_url)
    origin = _origin_from_url(embed_url)
    headers = _stream_request_headers(embed_url, origin)
    if not _probe_stream_url(stream_url, embed_url, origin, headers):
        return ''
    if '.m3u8' in stream_url:
        stream_url = _select_hls_media_playlist(stream_url, headers)
        proxy_url = _start_abstream_proxy(stream_url, headers)
        if proxy_url:
            return proxy_url
    return stream_url + _stream_headers(embed_url, origin)


def _stream_url_from_vidara(embed_url):
    filecode = _first_match(embed_url, [
        r'/(?:e|v)/([A-Za-z0-9]+)',
    ])
    if not filecode:
        logger.info('-> [LiveCamRips]: Vidara filecode not found for %s' % embed_url)
        return ''
    api_url = (_origin_from_url(embed_url) or 'https://vidara.so') + '/api/stream'
    response, _ = _request(api_url, cache_hours=0, referer=embed_url, method='POST', json_data={'filecode': filecode, 'device': 'web'})
    stream_url = ''
    try:
        payload = json.loads(response or '{}')
        stream_url = payload.get('streaming_url') or payload.get('url') or ''
    except Exception:
        stream_url = _first_match(response, [
            r'"streaming_url"\s*:\s*"([^"]+)"',
            r'"url"\s*:\s*"([^"]+\.(?:m3u8|mp4)(?:\?[^"]*)?)"',
        ])
    if not stream_url:
        logger.info('-> [LiveCamRips]: Vidara direct stream not found for %s' % embed_url)
        return ''
    stream_url = stream_url.replace('\\/', '/')
    return stream_url + _stream_headers(embed_url, _origin_from_url(embed_url))


def _videosh_id(embed_url):
    fragment = urlsplit(str(embed_url or '')).fragment
    if fragment:
        return fragment.split('&', 1)[0]
    return _first_match(embed_url, [
        r'videosh\.[^/]+/(?:embed/)?([A-Za-z0-9]+)',
    ])


def _decrypt_videosh_payload(payload):
    if not pyaes:
        logger.info('-> [LiveCamRips]: pyaes missing, VideoSH cannot be decrypted')
        return ''
    hex_payload = ''.join(re.findall(r'[0-9a-fA-F]{2}', str(payload or '')))
    if not hex_payload:
        return ''
    encrypted = bytes.fromhex(hex_payload)
    cipher = pyaes.AESModeOfOperationCBC(b'kiemtienmua911ca', iv=b'1234567890oiuytr')
    decrypted = b''.join(cipher.decrypt(encrypted[i:i + 16]) for i in range(0, len(encrypted), 16))
    padding = decrypted[-1] if decrypted else 0
    if 0 < padding <= 16:
        decrypted = decrypted[:-padding]
    return decrypted.decode('utf-8', 'replace')


def _videosh_stream_with_token(stream_url, payload):
    stream_url = str(stream_url or '').replace('\\/', '/')
    if '/v4/' not in stream_url or 'k=' in stream_url:
        return stream_url
    token = payload.get('pk') or {}
    key = token.get('k')
    expire = token.get('kx')
    if not key:
        return stream_url
    separator = '&' if '?' in stream_url else '?'
    stream_url += separator + urlencode({'k': key, 'kx': expire or ''})
    return stream_url


def _stream_url_from_videosh(embed_url, source_url):
    video_id = _videosh_id(embed_url)
    if not video_id:
        logger.info('-> [LiveCamRips]: VideoSH id not found for %s' % embed_url)
        return ''
    ref_host = urlsplit(source_url or URL_MAIN).netloc or urlsplit(URL_MAIN).netloc
    api_url = (_origin_from_url(embed_url) or 'https://videosh.upns.live') + '/api/v1/video?' + urlencode({
        'id': video_id,
        'w': '1920',
        'h': '1080',
        'r': ref_host,
    })
    encrypted, _ = _request(api_url, cache_hours=0, referer=embed_url)
    plain = _decrypt_videosh_payload(encrypted)
    try:
        payload = json.loads(plain or '{}')
    except Exception:
        payload = {}
    stream_url = payload.get('cfNative') or payload.get('source') or ''
    if not stream_url:
        logger.info('-> [LiveCamRips]: VideoSH direct stream not found for %s' % embed_url)
        return ''
    stream_url = _videosh_stream_with_token(stream_url, payload)
    return stream_url + _stream_headers(embed_url, _origin_from_url(embed_url))


def _stream_url_from_embed(embed_url, source_url):
    embed_url = _abs_url(embed_url, source_url or URL_MAIN + '/')
    host = urlsplit(embed_url).netloc.lower()
    try:
        if 'abstream.to' in host:
            logger.info('-> [LiveCamRips]: AbStream playback format disabled for %s' % source_url)
            return ''
        if 'vidara.' in host:
            return _stream_url_from_vidara(embed_url)
        if 'videosh.' in host:
            return _stream_url_from_videosh(embed_url, source_url)
    except Exception as e:
        logger.info('-> [LiveCamRips]: direct stream resolve failed for %s: %s' % (embed_url, e))
    return ''


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html, _ = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    embed_url = _embed_url_from_page(html)
    if embed_url:
        if 'abstream.to' in urlsplit(embed_url).netloc.lower():
            logger.info('-> [LiveCamRips]: skipped unstable AbStream playback format for %s' % source_url)
            return []
        direct_url = _stream_url_from_embed(embed_url, source_url)
        if direct_url:
            logger.info('-> [LiveCamRips]: direct stream OK via %s for %s' % (_hoster_title(embed_url), source_url))
            return [{
                'streamUrl': direct_url,
                'resolved': True,
                'title': _hoster_title(embed_url),
            }]
        logger.info('-> [LiveCamRips]: fallback unresolved embed via %s for %s' % (_hoster_title(embed_url), source_url))
        if _host_needs_direct_resolve(embed_url):
            return []
        return [{
            'streamUrl': embed_url + _stream_headers(source_url),
            'resolved': False,
            'title': _hoster_title(embed_url),
        }]
    logger.info('-> [LiveCamRips]: no playable embed found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html, _ = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    embed_url = _embed_url_from_page(html)
    if not embed_url:
        return []
    if 'abstream.to' in urlsplit(embed_url).netloc.lower():
        logger.info('-> [LiveCamRips]: skipped unstable AbStream playback format for %s' % sUrl)
        return []
    direct_url = _stream_url_from_embed(embed_url, sUrl)
    if direct_url:
        return [{'streamUrl': direct_url, 'resolved': True}]
    return [{'streamUrl': embed_url + _stream_headers(sUrl), 'resolved': False}]
