# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_pornone'
SITE_NAME = 'PornOne'
SITE_ICON = 'cum_pornone.png'
DOMAIN = 'pornone.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'pornone.Search', 'search_url': 'https://pornone.com/search?q=', 'latest_mode': 'pornone.List', 'latest_url': 'https://pornone.com/newest/', 'categories_mode': 'pornone.Categories', 'categories_url': 'https://pornone.com/categories/'}
load, showSearch = build_site(_CONFIG)
