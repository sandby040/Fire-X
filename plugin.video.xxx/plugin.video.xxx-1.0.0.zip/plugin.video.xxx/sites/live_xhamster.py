# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_livecam_bridge import build_live_site

SITE_IDENTIFIER = 'live_xhamster'
SITE_NAME = 'XHamster Live'
SITE_ICON = 'live_xhamster.png'
DOMAIN = 'xhamsterlive.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {
    'key': 'xhamsterlive',
    'site_id': SITE_IDENTIFIER,
    'name': SITE_NAME,
    'base': 'https://xhamsterlive.com',
    'api': 'https://xhamsterlive.com/api/front/models',
    'stream_api': 'https://go.xhamsterlive.com/api/models',
    'referer': 'https://xhamsterlive.com/',
    'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
        'Accept': 'application/json,text/plain,*/*',
    },
    'categories': {
        'girls': {'title': 'Frauen'},
        'couples': {'title': 'Paare'},
        'men': {'title': 'Maenner'},
        'trans': {'title': 'Trans'},
    },
}

load, showSearch, showModelSearch, showTagSearch, showCategories, listCams, showHosters = build_live_site(_CONFIG)
