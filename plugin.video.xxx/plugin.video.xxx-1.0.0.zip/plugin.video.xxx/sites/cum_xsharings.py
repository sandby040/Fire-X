# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_xsharings'
SITE_NAME = 'XSharings'
SITE_ICON = 'cum_xsharings.png'
DOMAIN = 'xsharings.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'xsharings.Search', 'search_url': 'https://xsharings.com/?s=', 'latest_mode': 'xsharings.List', 'latest_url': 'https://xsharings.com/page/1?filter=latest', 'categories_mode': 'xsharings.Categories', 'categories_url': 'https://xsharings.com/categories/'}
load, showSearch = build_site(_CONFIG)
