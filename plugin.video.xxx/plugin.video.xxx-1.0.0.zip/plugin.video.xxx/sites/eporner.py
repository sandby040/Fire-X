# -*- coding: utf-8 -*-
# Python 3

import json
import re
from html import unescape
from urllib.parse import parse_qs, quote, quote_plus, urlencode, urljoin, urlparse, urlunparse

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger

SITE_IDENTIFIER = 'eporner'
SITE_NAME = 'Eporner'
SITE_ICON = 'eporner.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.eporner.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', USER_AGENT)
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
    return request.request()


def _stream_headers(referer=REFERER):
    return '|' + urlencode({
        'User-Agent': USER_AGENT,
        'Referer': referer or REFERER,
    })


def _b36(n):
    chars = '0123456789abcdefghijklmnopqrstuvwxyz'
    res = ''
    while n:
        res = chars[n % 36] + res
        n //= 36
    return res or '0'


def _encode_eporner_hash(h):
    chunks = [h[i:i + 8] for i in range(0, 32, 8)]
    return ''.join(_b36(int(c, 16)) for c in chunks)


def _parse_api_entries(json_text):
    entries = []
    try:
        data = json.loads(json_text)
    except Exception:
        return entries
    videos = data.get('videos', [])
    for v in videos:
        url = v.get('url')
        title = v.get('title')
        if not url or not title:
            continue
        thumb = v.get('default_thumb', {}).get('src') or ''
        dur = v.get('length_min') or ''
        entries.append({
            'url': url,
            'title': _clean_text(title),
            'thumbnail': thumb,
            'duration': dur,
        })
    return entries


def _parse_html_entries(html):
    entries = []
    seen = set()
    pattern = r'<div class="mb"[^>]*>[\s\S]*?<a href="(/video-[^"]+)"><img src="([^"]+)"[^>]*alt="([^"]+)"[\s\S]*?<span class="mbtim"[^>]*>([^<]+)</span>'
    for match in re.finditer(pattern, html or '', re.I):
        href, thumb, title, dur = match.groups()
        url = _abs_url(href)
        if url in seen:
            continue
        seen.add(url)
        entries.append({
            'url': url,
            'title': _clean_text(title),
            'thumbnail': thumb,
            'duration': _clean_text(dur),
        })
    return entries


def _filter_entries_by_keyword(entries, keyword, is_search_url=False):
    if not keyword or is_search_url:
        return entries
    words = [w.lower() for w in re.split(r'\s+', _clean_text(keyword)) if w]
    if not words:
        return entries
    matched = [e for e in entries if any(w in (e.get('title') or '').lower() for w in words)]
    return matched or entries


def _parse_categories(html):
    categories = []
    seen = set()
    pattern = r'<li><a data-nav-item="categories\.category" href="(/cat/[^"]+)" title="([^"]+)">([^<]+)</a></li>'
    for match in re.finditer(pattern, html or '', re.I):
        href, title, name = match.groups()
        url = _abs_url(href)
        if url in seen:
            continue
        seen.add(url)
        categories.append({
            'url': url,
            'title': _clean_text(name or title),
            'thumbnail': '',
        })
    return categories


def _next_page_url(current_url, html_or_json):
    if 'format=json' in current_url:
        parsed = urlparse(current_url)
        qs = parse_qs(parsed.query)
        current_page = int((qs.get('page') or ['1'])[0])
        qs['page'] = [str(current_page + 1)]
        new_query = urlencode(qs, doseq=True)
        return urlunparse(parsed._replace(query=new_query))
    
    # HTML pagination
    next_match = re.search(r'<a\s+[^>]*href=["\'](/cat/[^"\']+)["\'][^>]*>\s*<span>NEXT', html_or_json or '', re.I)
    if next_match:
        return _abs_url(next_match.group(1), current_url)
    next_match = re.search(r'<a\s+[^>]*href=["\'](/search/[^"\']+)["\'][^>]*>\s*<span>NEXT', html_or_json or '', re.I)
    if next_match:
        return _abs_url(next_match.group(1), current_url)
    return ''


def load():
    menu = [
        ('Suche', 'showSearch', ''),
        ('Kategorien', 'showCategories', URL_MAIN + '/categories/'),
        ('Neueste Videos', 'showEntries', URL_MAIN + '/api/v2/video/search/?order=latest&page=1&per_page=30&format=json'),
        ('Beliebte Videos', 'showEntries', URL_MAIN + '/api/v2/video/search/?order=top-weekly&page=1&per_page=30&format=json'),
        ('Top aller Zeiten', 'showEntries', URL_MAIN + '/api/v2/video/search/?order=top-all&page=1&per_page=30&format=json'),
    ]
    for title, function, url in menu:
        params = ParameterHandler()
        if url:
            params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    gui = cGui()
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/categories/'
    html = _request(source_url, cache_hours=6)
    categories = _parse_categories(html)
    total = len(categories)
    for cat in categories:
        cat_params = ParameterHandler()
        cat_params.setParam('sUrl', cat['url'])
        cat_params.setParam('sName', cat['title'])
        element = cGuiElement(cat['title'], SITE_IDENTIFIER, 'showEntries')
        gui.addFolder(element, cat_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text='', raw_response=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
            element.setIcon(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    next_url = _next_page_url(source_url, raw_response)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or (
        URL_MAIN + '/api/v2/video/search/?order=latest&page=1&per_page=30&format=json'
    )
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')

    raw = _request(source_url, cache_hours=2)
    if 'format=json' in source_url:
        entries = _parse_api_entries(raw)
    else:
        entries = _parse_html_entries(raw)

    is_search = 'query=' in source_url or '/search/' in source_url
    entries = _filter_entries_by_keyword(entries, sSearchText, is_search)
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
                element.setIcon(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '', raw)


def showSearch():
    search_text = cGui().showKeyBoard(sHeading='Suche')
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    search_url = URL_MAIN + '/api/v2/video/search/?query=' + quote_plus(sSearchText.strip()) + '&page=1&per_page=30&format=json'
    showEntries(search_url, sGui, sSearchText)


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    return getHosterUrl(source_url)


def getHosterUrl(sUrl=False):
    if not sUrl:
        params = ParameterHandler()
        sUrl = params.getValue('entryUrl') or params.getValue('sUrl')
    if not sUrl:
        return []

    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    vid_m = re.search(r'vid\s*=\s*[\'"]([^\'"]+)[\'"]', html or '')
    hash_m = re.search(r'hash\s*=\s*[\'"]([a-f0-9]{32})[\'"]', html or '')

    vid = vid_m.group(1) if vid_m else ''
    if not vid:
        id_from_url = re.search(r'/video-([A-Za-z0-9]+)/', sUrl)
        if id_from_url:
            vid = id_from_url.group(1)

    h = hash_m.group(1) if hash_m else None
    if vid and h:
        try:
            encoded_hash = _encode_eporner_hash(h)
            xhr_url = (
                URL_MAIN + '/xhr/video/' + vid +
                '?hash=' + encoded_hash +
                '&domain=' + DOMAIN +
                '&fallback=true&embed=false&supportedFormats=mp4'
            )
            xhr_json = _request(xhr_url, cache_hours=0, referer=sUrl)
            data = json.loads(xhr_json)
            sources = data.get('sources', {}).get('mp4', {})
            best_stream = None
            for res in ['1080p', '720p', '480p', '360p', '240p']:
                if res in sources and 'src' in sources[res]:
                    best_stream = sources[res]['src']
                    break
            if best_stream:
                return [{
                    'streamUrl': best_stream + _stream_headers(sUrl),
                    'resolved': True,
                    'title': SITE_NAME,
                }]
        except Exception as exc:
            logger.info('-> [Eporner]: stream extraction error for %s: %s' % (sUrl, exc))

    logger.info('-> [Eporner]: no playable stream found for %s' % sUrl)
    return []
