# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_wowxxx'
SITE_NAME = 'WOW.xxx'
SITE_ICON = 'cum_wowxxx.png'
DOMAIN = 'www.wow.xxx'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'wowxxx.Search', 'search_url': 'https://www.wow.xxx/search/{}/relevance/', 'latest_mode': 'wowxxx.List', 'latest_url': 'https://www.wow.xxx/latest-updates/', 'categories_mode': 'wowxxx.Categories', 'categories_url': 'https://www.wow.xxx/categories/'}
load, showSearch = build_site(_CONFIG)
