# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'thothd'
SITE_NAME = 'ThotHD'
SITE_ICON = 'thothd.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'thothd.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN + '/de'
REFERER = URL_MAIN + '/'


def _abs_url(url, base=REFERER):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', 'https://' + DOMAIN)
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s' % (quote_plus(cRequestHandler.RandomUA()), quote_plus(referer or REFERER))


def _parse_video_items(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<div[^>]+class=["\']item\s[^"\']*["\'][\s\S]*?</a>\s*</div>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'<a[^>]+href=["\']([^"\']*/de/videos/[^"\']+)["\']'])
        title = _first_match(block, [
            r'<a[^>]+title=["\']([^"\']+)["\']',
            r'<strong[^>]+class=["\']title["\'][^>]*>([\s\S]*?)</strong>',
        ])
        thumb = _first_match(block, [
            r'<img[^>]+data-original=["\'](https?://[^"\']+)["\']',
            r'<img[^>]+data-webp=["\'](https?://[^"\']+)["\']',
            r'<img[^>]+src=["\'](https?://[^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [r'<div[^>]+class=["\']duration["\'][^>]*>([\s\S]*?)</div>']))
        href = _abs_url(href)
        title = _clean_text(title)
        if not href or not title or href in seen:
            continue
        seen.add(href)
        entries.append({
            'title': title,
            'url': href,
            'thumbnail': _abs_url(thumb) if thumb and not thumb.startswith('data:') else '',
            'duration': duration,
        })
    return entries


def _parse_categories(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<a[^>]+class=["\']item["\'][^>]+href=["\']([^"\']+/de/categories/[^"\']+)["\'][\s\S]*?</a>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'href=["\']([^"\']+)["\']'])
        title = _first_match(block, [
            r'title=["\']([^"\']+)["\']',
            r'<strong[^>]+class=["\']title["\'][^>]*>([\s\S]*?)</strong>',
        ])
        thumb = _first_match(block, [r'<img[^>]+src=["\'](https?://[^"\']+)["\']'])
        url = _abs_url(href)
        title = _clean_text(title)
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': thumb})
    return entries


def _base_url_without_async(url):
    split = urlsplit(url)
    query = []
    for key, value in parse_qsl(split.query, keep_blank_values=True):
        if key not in ('mode', 'function', 'block_id', 'q', 'category_ids', 'sort_by', 'from_videos', 'from_albums'):
            query.append((key, value))
    return urlunsplit((split.scheme, split.netloc, split.path, urlencode(query), ''))


def _next_page_url(html, current_url):
    direct = _first_match(html, [
        r'<li[^>]+class=["\']next["\'][\s\S]*?<a[^>]+href=["\']([^"\']+)["\']',
    ])
    if direct and direct != '#search':
        return _abs_url(direct, current_url)

    ajax = re.search(
        r'<li[^>]+class=["\']next["\'][\s\S]*?<a[^>]+href=["\']#search["\'][^>]+data-block-id=["\']([^"\']+)["\'][^>]+data-parameters=["\']([^"\']+)["\']',
        html,
        re.I | re.S,
    )
    if ajax:
        block_id, raw_params = ajax.group(1), unescape(ajax.group(2))
        params = [('mode', 'async'), ('function', 'get_block'), ('block_id', block_id)]
        for part in raw_params.split(';'):
            if ':' not in part:
                continue
            key, value = part.split(':', 1)
            for key_part in key.split('+'):
                params.append((key_part, value))
        base = _base_url_without_async(current_url)
        return base + ('&' if '?' in base else '?') + urlencode(params)
    return ''


def load():
    params = ParameterHandler()
    menu = [
        ('Search', 'showSearch', URL_MAIN + '/'),
        ('Latest', 'showEntries', URL_MAIN + '/latest-updates/'),
        ('Most Popular', 'showEntries', URL_MAIN + '/most-popular/'),
        ('Top Rated', 'showEntries', URL_MAIN + '/top-rated/'),
        ('Categories', 'showCategories', URL_MAIN + '/categories/'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, source_html='', search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    if source_url and entries:
        html = source_html or _request(source_url, cache_hours=2)
        next_url = _next_page_url(html, source_url)
        if next_url and next_url != _abs_url(source_url):
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)

    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/latest-updates/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html = _request(source_url, cache_hours=2)
    entries = _parse_video_items(html)

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, params, False, total)
        return

    _add_video_entries(entries, source_url, 'showEntries', source_html=html, search_text=sSearchText or '')


def showCategories():
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/categories/'
    html = _request(source_url, cache_hours=12)
    entries = _parse_categories(html)
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        if entry.get('thumbnail'):
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, gui_params, True, total)
    gui.setEndOfDirectory()


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    sSearchText = _normalize_german_search_text(sSearchText)
    showEntries(URL_MAIN + '/search/' + quote_plus(sSearchText) + '/', sGui, sSearchText)


def _quality_value(label, url):
    label_match = re.search(r'(\d{3,4})', str(label or ''))
    url_match = re.search(r'_(\d{3,4})p\.', str(url or ''))
    if label_match:
        return int(label_match.group(1))
    if url_match:
        return int(url_match.group(1))
    return 0


def _video_sources(html):
    sources = []
    seen = set()
    for key in ('video_url', 'video_alt_url', 'video_alt_url2', 'video_alt_url3'):
        url = _first_match(html, [r'\b%s\s*:\s*["\']([^"\']+)["\']' % key])
        if not url or url in seen:
            continue
        seen.add(url)
        label = _first_match(html, [r'\b%s_text\s*:\s*["\']([^"\']+)["\']' % key])
        sources.append({'url': url, 'label': label, 'quality': _quality_value(label, url)})
    sources.sort(key=lambda item: item['quality'], reverse=True)
    return sources


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=1, referer=source_url or REFERER)
    sources = _video_sources(html)
    if sources:
        best = sources[0]
        return [{
            'streamUrl': best['url'] + _stream_headers(source_url),
            'resolved': True,
            'title': 'ThotHD %s' % (best['label'] or 'HD'),
        }]
    logger.info('-> [ThotHD]: no playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=1, referer=sUrl or REFERER)
    sources = _video_sources(html)
    return [{'streamUrl': sources[0]['url'] + _stream_headers(sUrl), 'resolved': True}] if sources else []
