# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_drtuber'
SITE_NAME = 'DrTuber'
SITE_ICON = 'cum_drtuber.png'
DOMAIN = 'www.drtuber.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'drtuber.Search', 'search_url': 'https://www.drtuber.com/search/videos/', 'latest_mode': 'drtuber.List', 'latest_url': 'https://www.drtuber.com/', 'categories_mode': 'drtuber.Cat', 'categories_url': 'https://www.drtuber.com/categories/'}
load, showSearch = build_site(_CONFIG)
