# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_youcrazyx'
SITE_NAME = 'YouCrazyX'
SITE_ICON = 'cum_youcrazyx.png'
DOMAIN = 'www.youcrazyx.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'youcrazyx.Search', 'search_url': 'https://www.youcrazyx.com/search/', 'latest_mode': 'youcrazyx.List', 'latest_url': 'https://www.youcrazyx.com/most-recent/', 'categories_mode': 'youcrazyx.Categories', 'categories_url': 'https://www.youcrazyx.com/channels/'}
load, showSearch = build_site(_CONFIG)
