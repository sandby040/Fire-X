# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'genteelflair'
SITE_NAME = 'GenteelFlair'
SITE_ICON = 'genteelflair.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'genteelflair.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s&Origin=%s' % (
        quote_plus(cRequestHandler.RandomUA()),
        quote_plus(referer or REFERER),
        quote_plus(URL_MAIN),
    )


def _with_query(url, **updates):
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(updates)
    return urlunsplit((split.scheme, split.netloc, split.path, urlencode(query), split.fragment))


def _category_thumbnails(html):
    thumbnails = {}
    for match in re.finditer(r'<div\s+class=fob\b[\s\S]*?</div></div>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'<a[^>]+href=["\']([^"\']+/)["\']'])
        title = _clean_text(_first_match(block, [r'<div\s+class=aim[^>]*>([\s\S]*?)</div>']))
        thumb = _first_match(block, [
            r'data-src=["\']([^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        if href and title and thumb:
            thumbnails[_abs_url(href)] = _abs_url(thumb)
    return thumbnails


def _parse_categories(html):
    block = _first_match(html, [r'<div\s+class=rcs[^>]*>([\s\S]*?)</div></div>'])
    if not block:
        return []
    thumbnails = _category_thumbnails(html)
    entries = []
    seen = set()
    for href, title in re.findall(r'<a[^>]+href=["\']([^"\']+/)["\'][^>]*>\s*<p>([\s\S]*?)</p>\s*</a>', block, re.I):
        url = _abs_url(href)
        clean_title = _clean_text(title)
        path = urlsplit(url).path.strip('/')
        if not clean_title or not path or path.startswith(('de/', 'fr/', 'es/', 'it/', 'ru/', 'zh/', 'hi/', 'fa/', 'pl/')):
            continue
        if url in seen:
            continue
        seen.add(url)
        entries.append({
            'title': clean_title,
            'url': url,
            'thumbnail': thumbnails.get(url, ''),
        })
    return entries


def _parse_video_items(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<div\s+class=fob\b[\s\S]*?(?=<div\s+class=fob\b|<div style=|<div\s+class=uie|$)', html, re.I):
        block = match.group(0)
        href = _first_match(block, [
            r'<a[^>]+href=["\']([^"\']*(?:/c/\?|[?&]video=)[^"\']*)["\']',
        ])
        title = _clean_text(_first_match(block, [
            r'<div\s+class=vcu[^>]*>([\s\S]*?)</div>',
            r'<div\s+class=aim[^>]*>([\s\S]*?)</div>',
        ]))
        thumb = _first_match(block, [
            r'data-src=["\']([^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [
            r'<span\s+class=uhe[^>]*>[\s\S]*?<div>([^<]+)</div>',
        ]))
        url = _abs_url(href)
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({
            'title': title,
            'url': url,
            'thumbnail': _abs_url(thumb) if thumb else '',
            'duration': duration,
        })
    return entries


def _next_page_url(current_url, entries):
    if not current_url or not entries:
        return ''
    split = urlsplit(current_url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    try:
        page = int(query.get('page', '1') or '1')
    except Exception:
        page = 1
    query['page'] = str(page + 1)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Kategorien', 'showCategories', URL_MAIN + '/'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/'
    entries = _parse_categories(_request(source_url, cache_hours=12))
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        if entry.get('thumbnail'):
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, gui_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    next_url = _next_page_url(source_url, entries)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    entries = _parse_video_items(_request(source_url, cache_hours=2))

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, params, False, total)
        return

    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    sSearchText = _normalize_german_search_text(sSearchText)
    search_url = _with_query(URL_MAIN + '/', keywords=sSearchText)
    showEntries(search_url, sGui, sSearchText)


def _stream_url_from_page(html):
    return _abs_url(_first_match(html, [
        r'<source[^>]+src=["\']([^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
        r'(https?://[^"\'<>\s]+\.(?:m3u8|mp4)(?:\?[^"\'<>\s]*)?)',
    ]))


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    stream_url = _stream_url_from_page(html)
    if stream_url:
        return [{
            'streamUrl': stream_url + _stream_headers(source_url),
            'resolved': True,
            'title': 'GenteelFlair',
        }]
    logger.info('-> [GenteelFlair]: no playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    stream_url = _stream_url_from_page(html)
    return [{'streamUrl': stream_url + _stream_headers(sUrl), 'resolved': True}] if stream_url else []
