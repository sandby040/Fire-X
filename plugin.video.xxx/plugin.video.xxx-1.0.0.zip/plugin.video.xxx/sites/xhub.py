# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'xhub'
SITE_NAME = 'XHub'
SITE_ICON = 'xhub.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'xhub.rip')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    headers = {
        'User-Agent': cRequestHandler.RandomUA(),
        'Referer': referer or REFERER,
        'Origin': URL_MAIN,
        'Cookie': 'play=1; quality=720p',
    }
    return '|' + urlencode(headers)


def _decode_js_url(value):
    return unescape(str(value or '')).replace('\\/', '/')


def _parse_video_items(html):
    entries = []
    seen = set()
    blocks = re.finditer(
        r'<div[^>]+class=["\']view["\'][^>]*>\s*<div[^>]+class=["\']image["\'][^>]*>([\s\S]*?)</div>\s*</div>',
        html,
        re.I,
    )
    for match in blocks:
        block = match.group(1)
        href = _first_match(block, [r'<a[^>]+href=["\']([^"\']*/watch/[^"\']+)["\']'])
        title = _first_match(block, [
            r'<span[^>]*>([\s\S]*?)</span>',
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ])
        thumbnail = _first_match(block, [r'<img[^>]+src=["\']([^"\']+)["\']'])
        duration = _clean_text(_first_match(block, [r'<div[^>]+class=["\']time["\'][^>]*>([\s\S]*?)</div>']))
        url = _abs_url(href)
        title = _clean_text(title)
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({
            'title': title,
            'url': url,
            'thumbnail': _abs_url(thumbnail) if thumbnail else '',
            'duration': duration,
        })
    return entries


def _current_page_number(url):
    split = urlsplit(str(url or ''))
    path = (split.path or '/').strip('/')
    if path.isdigit():
        return int(path)
    for key, value in parse_qsl(split.query, keep_blank_values=True):
        if key == 'page':
            try:
                return int(value)
            except Exception:
                return 1
    return 1


def _next_page_url(html, current_url):
    current = _current_page_number(current_url)
    candidates = []
    for href in re.findall(r'href=["\']([^"\']+)["\']', html, re.I):
        absolute = _abs_url(href)
        split = urlsplit(absolute)
        if split.netloc and split.netloc.lower().replace('www.', '') != DOMAIN:
            continue
        path = (split.path or '').strip('/')
        query = dict(parse_qsl(split.query, keep_blank_values=True))
        number = None
        if path.isdigit():
            number = int(path)
        elif query.get('page', '').isdigit():
            number = int(query['page'])
        if number and number > current:
            candidates.append((number, absolute))
    return sorted(candidates)[0][1] if candidates else ''


def _add_video_entries(entries, source_url, list_function, source_html='', search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    if source_url and entries:
        html = source_html or _request(source_url, cache_hours=2)
        next_url = _next_page_url(html, source_url)
        if next_url and next_url != _abs_url(source_url):
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)

    gui.setView('movies')
    gui.setEndOfDirectory()


def _with_query(url, **updates):
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(updates)
    return urlunsplit((split.scheme, split.netloc, split.path, urlencode(query), split.fragment))


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Neueste Uploads', 'showEntries', URL_MAIN + '/'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html = _request(source_url, cache_hours=2)
    entries = _parse_video_items(html)

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, params, False, total)
        return

    _add_video_entries(entries, source_url, 'showEntries', source_html=html, search_text=sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    sSearchText = _normalize_german_search_text(sSearchText)
    search_url = _with_query(URL_MAIN + '/search', q=sSearchText)
    showEntries(search_url, sGui, sSearchText)


def _play_url_from_page(html):
    play_url = _decode_js_url(_first_match(html, [
        r'\bvar\s+src\s*=\s*["\']([^"\']+)["\']',
        r'\bsrc\s*:\s*["\']([^"\']+/play\?[^"\']+)["\']',
        r'["\']([^"\']+/play\?[^"\']+)["\']',
    ]))
    return _abs_url(play_url) if play_url else ''


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    play_url = _play_url_from_page(html)
    if play_url:
        return [{
            'streamUrl': play_url + _stream_headers(source_url),
            'resolved': True,
            'title': 'XHub',
        }]
    logger.info('-> [XHub]: no playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    play_url = _play_url_from_page(html)
    return [{'streamUrl': play_url + _stream_headers(sUrl), 'resolved': True}] if play_url else []
