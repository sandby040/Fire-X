# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_porngo'
SITE_NAME = 'PornGO'
SITE_ICON = 'cum_porngo.png'
DOMAIN = 'www.porngo.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'porngo.Search', 'search_url': 'https://www.porngo.com/search/', 'latest_mode': 'porngo.List', 'latest_url': 'https://www.porngo.com/latest-updates/', 'categories_mode': 'porngo.Cat', 'categories_url': 'https://www.porngo.com/categories/'}
load, showSearch = build_site(_CONFIG)
