# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_homemoviestube'
SITE_NAME = 'HomeMovies Tube'
SITE_ICON = 'cum_homemoviestube.png'
DOMAIN = 'www.homemoviestube.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'homemoviestube.Search', 'search_url': 'https://www.homemoviestube.com/search/', 'latest_mode': 'homemoviestube.List', 'latest_url': 'https://www.homemoviestube.com/most-recent/', 'categories_mode': 'homemoviestube.Categories', 'categories_url': 'https://www.homemoviestube.com/channels/'}
load, showSearch = build_site(_CONFIG)
