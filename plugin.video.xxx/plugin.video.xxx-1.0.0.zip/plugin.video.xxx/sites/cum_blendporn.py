# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_blendporn'
SITE_NAME = 'Blendporn'
SITE_ICON = 'cum_blendporn.png'
DOMAIN = 'www.blendporn.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'blendporn.Search', 'search_url': 'https://www.blendporn.com/search/', 'latest_mode': 'blendporn.List', 'latest_url': 'https://www.blendporn.com/most-recent/', 'categories_mode': 'blendporn.Categories', 'categories_url': 'https://www.blendporn.com/channels/'}
load, showSearch = build_site(_CONFIG)
