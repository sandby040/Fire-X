# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_trendyporn'
SITE_NAME = 'TrendyPorn'
SITE_ICON = 'cum_trendyporn.png'
DOMAIN = 'www.trendyporn.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'trendyporn.Search', 'search_url': 'https://www.trendyporn.com/search/', 'latest_mode': 'trendyporn.List', 'latest_url': 'https://www.trendyporn.com/most-recent/', 'categories_mode': 'trendyporn.Categories', 'categories_url': 'https://www.trendyporn.com/channels/'}
load, showSearch = build_site(_CONFIG)
