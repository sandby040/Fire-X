# -*- coding: utf-8 -*-
# Python 3

import base64
import json
import os
import re
import sys
from html import unescape
from urllib.parse import parse_qs, parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'maturetube'
SITE_NAME = 'MatureTube'
SITE_ICON = 'maturetube.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.maturetube.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'
_SCRAPER = None

_ADDONS_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for _module_path in (
    os.path.join(_ADDONS_DIR, 'script.module.cloudrequest'),
    os.path.join(_ADDONS_DIR, 'script.module.cloudscraper', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.requests', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.urllib3', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.chardet', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.idna', 'lib'),
    os.path.join(_ADDONS_DIR, 'script.module.certifi', 'lib'),
):
    if os.path.exists(_module_path) and _module_path not in sys.path:
        sys.path.insert(0, _module_path)

try:
    import cloudscraper
except Exception:
    try:
        import cloudscraper2 as cloudscraper
    except Exception:
        cloudscraper = None


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _origin_from_url(url):
    parsed = urlsplit(str(url or ''))
    if parsed.scheme and parsed.netloc:
        return parsed.scheme + '://' + parsed.netloc
    return ''


def _browser_headers(referer=REFERER, origin=None):
    headers = {
        'User-Agent': cRequestHandler.RandomUA(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
        'Referer': referer or REFERER,
        'Upgrade-Insecure-Requests': '1',
    }
    origin = origin or _origin_from_url(referer) or URL_MAIN
    if origin:
        headers['Origin'] = origin
    return headers


def _get_scraper():
    global _SCRAPER
    if not cloudscraper:
        return None
    if _SCRAPER is None:
        _SCRAPER = cloudscraper.create_scraper()
    return _SCRAPER


def _request(url, cache_hours=3, referer=REFERER):
    absolute_url = _abs_url(url)
    scraper = _get_scraper()
    if scraper:
        try:
            response = scraper.get(absolute_url, headers=_browser_headers(referer), timeout=15)
            if response.status_code < 400:
                return response.text
            logger.info('-> [MatureTube]: cloudscraper status %s for %s' % (response.status_code, absolute_url))
        except Exception as e:
            logger.info('-> [MatureTube]: cloudscraper failed for %s: %s' % (absolute_url, e))

    request = cRequestHandler(absolute_url, caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', cRequestHandler.RandomUA())
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', _origin_from_url(referer) or URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    request.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    origin = _origin_from_url(referer) or URL_MAIN
    return '|' + urlencode({
        'User-Agent': cRequestHandler.RandomUA(),
        'Referer': referer or REFERER,
        'Origin': origin,
        'verifypeer': 'false',
    })


def _with_query(url, **updates):
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(updates)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def _parse_video_items(html):
    entries = []
    seen = set()
    pattern = r'<a[^>]+class=["\'][^"\']*item-link[^"\']*["\'][^>]+href=["\']([^"\']+)["\'][^>]*title=["\']([^"\']+)["\'][\s\S]*?</a>'
    for match in re.finditer(pattern, html, re.I):
        block = match.group(0)
        url = _abs_url(match.group(1))
        title = _clean_text(match.group(2))
        thumb = _first_match(block, [
            r'<img[^>]+src=["\']([^"\']+)["\']',
            r'data-src=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [
            r'<span[^>]+class=["\'][^"\']*badge[^"\']*["\'][^>]*>[\s\S]*?</span>\s*([^<]+)</span>',
            r'(\d{1,2}:\d{2}(?::\d{2})?)',
        ]))
        if not url or not title or url in seen:
            continue
        if '/out/' not in url and '/video/' not in url:
            continue
        seen.add(url)
        entries.append({
            'title': title,
            'url': url,
            'thumbnail': _abs_url(thumb) if thumb else '',
            'duration': duration,
        })
    return entries


def _filter_entries_by_keyword(entries, keyword):
    words = [word.lower() for word in re.split(r'\s+', _clean_text(str(keyword or ''))) if word]
    if not words:
        return entries
    matched = []
    for entry in entries:
        title = (entry.get('title') or '').lower()
        if all(word in title for word in words):
            matched.append(entry)
    return matched


def _parse_categories(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<a[^>]+href=["\']([^"\']*/category/[^"\']+)["\'][^>]*(?:title=["\']([^"\']*)["\'])?[^>]*>([\s\S]{0,900}?)</a>', html, re.I):
        url = _abs_url(match.group(1))
        title = _clean_text(match.group(2) or _first_match(match.group(3), [
            r'<img[^>]+alt=["\']([^"\']+)["\']',
            r'title=["\']([^"\']+)["\']',
        ]) or match.group(3))
        title = re.sub(r'\s+\d+(?:[.,]\d+)?[KMB]?\s*$', '', title, flags=re.I)
        thumb = _first_match(match.group(3), [
            r'<img[^>]+src=["\']([^"\']+)["\']',
            r'data-src=["\']([^"\']+)["\']',
        ])
        if not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else ''})
    return entries


def _next_page_url(current_url, entries):
    if not entries:
        return ''
    split = urlsplit(current_url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    try:
        page = int(query.get('page', '1') or '1')
    except Exception:
        page = 1
    query['page'] = str(page + 1)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Neueste Uploads', 'showEntries', URL_MAIN + '/new'),
        ('Kategorien', 'showCategories', URL_MAIN + '/'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    params = ParameterHandler()
    html = _request(params.getValue('sUrl') or URL_MAIN + '/', cache_hours=12)
    entries = _parse_categories(html)
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        if entry.get('thumbnail'):
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, gui_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    next_url = _next_page_url(source_url, entries)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/new'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    entries = _parse_video_items(_request(source_url, cache_hours=2))
    entries = _filter_entries_by_keyword(entries, sSearchText)
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    showEntries(_with_query(URL_MAIN + '/search', search=sSearchText), sGui, sSearchText)


def _target_url_from_out(url):
    try:
        token = (parse_qs(urlsplit(str(url or '')).query).get('l') or [''])[0]
        if not token:
            return ''
        token += '=' * ((4 - len(token) % 4) % 4)
        decoded = base64.b64decode(token)
        match = re.search(rb'https?://[-A-Za-z0-9._~:/?#\[\]@!$&()*+,;=%]+', decoded)
        if match:
            return match.group(0).decode('utf-8', 'ignore')
    except Exception as e:
        logger.info('-> [MatureTube]: failed to decode out link: %s' % e)
    return ''


def _quality_value(label, stream_url=''):
    label = str(label or '').lower()
    if label == '4k':
        return 2160
    if label == 'hq':
        return 720
    if label == 'lq':
        return 320
    match = re.search(r'(\d{3,4})p?', label) or re.search(r'(\d{3,4})p', stream_url)
    return int(match.group(1)) if match else 0


def _stream_url_from_viptube_config(html, page_url):
    vid = _first_match(html, [r'configData:\s*\{[\s\S]*?vid:\s*(\d+)', r'videoId:\s*(\d+)'])
    if not vid:
        return ''
    aid = _first_match(html, [r'configData:\s*\{[\s\S]*?aid:\s*(\d+)']) or '0'
    domain_id = _first_match(html, [r'configData:\s*\{[\s\S]*?domain_id:\s*(\d+)']) or '0'
    embed = _first_match(html, [r'configData:\s*\{[\s\S]*?embed:\s*(\d+)']) or '0'
    check_speed = _first_match(html, [r'configData:\s*\{[\s\S]*?check_speed:\s*(\d+)']) or '0'
    config_path = _first_match(html, [r"configUrl:\s*'([^']+)'"]) or '/player_config_json/'
    project = _first_match(html, [r"project:\s*\{[\s\S]*?name:\s*'([^']+)'"]) or 'viptube'
    config_url = 'https://www.%s.com%s?%s' % (project, config_path, urlencode({
        'vid': vid,
        'aid': aid,
        'domain_id': domain_id,
        'embed': embed,
        'ref': 'null',
        'check_speed': check_speed,
    }))
    try:
        data = json.loads(_request(config_url, cache_hours=0, referer=page_url) or '{}')
    except Exception as e:
        logger.info('-> [MatureTube]: player config failed for %s: %s' % (vid, e))
        return ''
    files = data.get('files') or {}
    candidates = []
    for label, stream_url in files.items():
        stream_url = unescape(str(stream_url or '')).replace('\\/', '/')
        if stream_url and '.mp4' in stream_url.lower():
            candidates.append((_quality_value(label, stream_url), stream_url))
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _stream_url_from_page(html, source_url=''):
    target_url = _target_url_from_out(source_url)
    page_url = target_url or source_url or REFERER
    page_html = _request(target_url, cache_hours=0, referer=source_url or REFERER) if target_url else html
    stream_url = _stream_url_from_viptube_config(page_html, page_url)
    if stream_url:
        return stream_url, page_url
    candidates = []
    for stream_url in re.findall(r'https?://[^"\'<>\s]+\.mp4(?:\?[^"\'<>\s]*)?', page_html or html, re.I):
        stream_url = unescape(stream_url).replace('\\/', '/')
        if '.jpg' in stream_url.lower() or '/tmb/' in stream_url.lower():
            continue
        candidates.append((_quality_value('', stream_url), stream_url))
    if candidates:
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1], page_url
    return '', page_url


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    stream_url, referer = _stream_url_from_page(html, source_url)
    if stream_url:
        return [{'streamUrl': stream_url + _stream_headers(referer), 'resolved': True, 'title': SITE_NAME}]
    logger.info('-> [MatureTube]: no playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    stream_url, referer = _stream_url_from_page(html, sUrl)
    return [{'streamUrl': stream_url + _stream_headers(referer), 'resolved': True}] if stream_url else []
