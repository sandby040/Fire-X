# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_6xtube'
SITE_NAME = '6XTube'
SITE_ICON = 'cum_6xtube.png'
DOMAIN = 'www.6xtube.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': '6xtube.Search', 'search_url': 'http://www.6xtube.com/search/', 'latest_mode': '6xtube.List', 'latest_url': 'http://www.6xtube.com/most-recent/', 'categories_mode': '6xtube.Categories', 'categories_url': 'http://www.6xtube.com/channels/'}
load, showSearch = build_site(_CONFIG)
