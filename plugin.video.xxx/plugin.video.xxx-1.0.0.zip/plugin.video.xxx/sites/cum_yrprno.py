# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_yrprno'
SITE_NAME = 'YrPrno'
SITE_ICON = 'cum_yrprno.png'
DOMAIN = 'www.yrprno.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'yrprno.Search', 'search_url': 'https://www.yrprno.com/search/', 'latest_mode': 'yrprno.List', 'latest_url': 'https://www.yrprno.com/most-recent/', 'categories_mode': 'yrprno.Categories', 'categories_url': 'https://www.yrprno.com/channels/'}
load, showSearch, _search = build_site(_CONFIG)
