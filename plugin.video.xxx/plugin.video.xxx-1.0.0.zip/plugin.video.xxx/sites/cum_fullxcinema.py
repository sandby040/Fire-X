# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_fullxcinema'
SITE_NAME = 'FullXCinema'
SITE_ICON = 'cum_fullxcinema.png'
DOMAIN = 'fullxcinema.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'fullxcinema.Search', 'search_url': 'https://fullxcinema.com/?s=', 'latest_mode': 'fullxcinema.List', 'latest_url': 'https://fullxcinema.com/?filter=latest', 'categories_mode': 'fullxcinema.Cat', 'categories_url': 'https://fullxcinema.com/'}
load, showSearch = build_site(_CONFIG)
