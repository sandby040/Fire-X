# -*- coding: utf-8 -*-
# Python 3

import json
import re
from html import unescape
from urllib.parse import quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'xfantazy'
SITE_NAME = 'XFantazy'
SITE_ICON = 'xfantazy.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'xfantazy.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', cRequestHandler.RandomUA())
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    return request.request()


def _api_request(path, referer=REFERER):
    url = path if str(path).startswith('http') else 'https://api.%s%s' % (DOMAIN, path)
    request = cRequestHandler(url, caching=False, ignoreErrors=True)
    request.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36')
    request.addHeaderEntry('Accept', 'application/json,text/plain,*/*')
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    request.addHeaderEntry('Sec-Fetch-Site', 'same-site')
    request.addHeaderEntry('Sec-Fetch-Mode', 'cors')
    request.addHeaderEntry('Sec-Fetch-Dest', 'empty')
    request.addHeaderEntry('sec-ch-ua', '"Chromium";v="128", "Not;A=Brand";v="24"')
    request.addHeaderEntry('sec-ch-ua-mobile', '?0')
    request.addHeaderEntry('sec-ch-ua-platform', '"Windows"')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s&Origin=%s' % (
        quote_plus(cRequestHandler.RandomUA()),
        quote_plus(referer or REFERER),
        quote_plus(URL_MAIN),
    )


def _parse_video_items(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<a[^>]+href=["\'](/video/[^"\']+)["\'][^>]*>([\s\S]{0,1600}?)</a>', html, re.I):
        block = match.group(2)
        url = _abs_url(match.group(1))
        title = _clean_text(_first_match(block, [
            r'<div[^>]+class=["\'][^"\']*truncate[^"\']*["\'][^>]*>([\s\S]*?)</div>',
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ]))
        thumb = _first_match(block, [
            r'<img[^>]+src=["\']([^"\']*s\.xfantazy\.com/thumbnail[^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [r'<div[^>]+class=["\'][^"\']*top-0 right-0[^"\']*["\'][^>]*>([\s\S]*?)</div>']))
        if not title:
            title = urlsplit(url).path.rsplit('/', 1)[-1].replace('-', ' ').title()
        if not url or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else '', 'duration': duration})
    return entries


def _parse_categories(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<a[^>]+href=["\'](/(?:category|tag)/[^"\']+)["\'][^>]*>([\s\S]{0,900}?)</a>', html, re.I):
        block = match.group(2)
        url = _abs_url(match.group(1))
        title = _clean_text(_first_match(block, [
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ]) or urlsplit(url).path.rsplit('/', 1)[-1].replace('-', ' '))
        thumb = _first_match(block, [
            r'<img[^>]+src=["\']([^"\']*s\.xfantazy\.com/thumbnail[^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        if not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else ''})
    return entries


def _next_page_url(current_url, entries):
    return ''


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Neueste Uploads', 'showEntries', URL_MAIN + '/top'),
        ('Kategorien', 'showCategories', URL_MAIN + '/categories'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    params = ParameterHandler()
    entries = _parse_categories(_request(params.getValue('sUrl') or URL_MAIN + '/categories', cache_hours=12))
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        if entry.get('thumbnail'):
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, gui_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/top'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    entries = _parse_video_items(_request(source_url, cache_hours=2))
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    showEntries(URL_MAIN + '/search/' + quote_plus(sSearchText), sGui, sSearchText)


def _video_id(html):
    return _first_match(html, [
        r'\\"videoInfo\\"\s*:\s*\{\\"id\\"\s*:\s*\\"([^\\"]+)\\"',
        r'"videoInfo"\s*:\s*\{\s*"id"\s*:\s*"([^"]+)"',
    ])


def _stream_url_from_sources(payload):
    try:
        data = json.loads(payload or '{}')
    except Exception:
        return ''
    sources = data.get('sources') or []
    candidates = []
    for source in sources:
        stream_url = source.get('src') or source.get('url') or ''
        if not stream_url or '.mp4' not in stream_url.lower():
            continue
        label = str(source.get('label') or '')
        match = re.search(r'(\d+)', label)
        quality = int(match.group(1)) if match else 0
        candidates.append((quality, stream_url))
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _direct_api_url(video_id, referer=REFERER):
    if not video_id:
        return ''
    _api_request('/pub/client-token', referer)
    response = _api_request('/pub/video-sources/%s' % video_id, referer)
    stream_url = _stream_url_from_sources(response)
    if not stream_url:
        logger.info('-> [XFantazy]: video-sources failed for %s: %s' % (video_id, response[:160] if response else ''))
    return stream_url


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    stream_url = _direct_api_url(_video_id(html), source_url or REFERER)
    if stream_url:
        return [{'streamUrl': stream_url + _stream_headers(source_url), 'resolved': True, 'title': SITE_NAME}]
    logger.info('-> [XFantazy]: no public playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    stream_url = _direct_api_url(_video_id(html), sUrl or REFERER)
    return [{'streamUrl': stream_url + _stream_headers(sUrl), 'resolved': True}] if stream_url else []
