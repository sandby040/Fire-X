# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_livecam_bridge import build_live_site

SITE_IDENTIFIER = 'live_cam4'
SITE_NAME = 'Cam4 Live'
SITE_ICON = 'live_cam4.png'
DOMAIN = 'www.cam4.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {
    'key': 'cam4',
    'site_id': SITE_IDENTIFIER,
    'name': SITE_NAME,
    'api': 'https://www.cam4.com/api/directoryCams',
    'stream_info': 'https://www.cam4.com/rest/v1.0/profile/{}/streamInfo',
    'referer': 'https://www.cam4.com/',
    'categories': {
        'female': {'title': 'Frauen', 'params': {'gender': 'female', 'broadcastType': ['female_group', 'solo', 'male_female_group']}},
        'couple': {'title': 'Paare', 'params': {'broadcastType': ['male_group', 'female_group', 'male_female_group']}},
        'male': {'title': 'Maenner', 'params': {'gender': 'male', 'broadcastType': ['male_group', 'solo', 'male_female_group']}},
        'trans': {'title': 'Trans', 'params': {'gender': 'transsexual'}},
    },
}

load, showSearch, showModelSearch, showTagSearch, showCategories, listCams, showHosters = build_live_site(_CONFIG)
