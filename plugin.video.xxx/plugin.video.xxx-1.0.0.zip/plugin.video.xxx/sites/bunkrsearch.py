# -*- coding: utf-8 -*-
# Python 3

import json
import re
from html import unescape
from urllib.parse import quote, quote_plus, urlencode, urljoin, urlsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'bunkrsearch'
SITE_NAME = 'Bunkr'
SITE_ICON = 'bunkrsearch.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'bunkrsearch.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
BUNKR_ALBUMS_URL = 'https://bunkr-albums.io'
BUNKR_HOSTS = ('https://bunkr.site', 'https://bunkr.si', 'https://bunkr.cr')
REFERER = URL_MAIN + '/'
VIDEO_EXTENSIONS = ('.mp4', '.m4v', '.mov', '.webm', '.mkv', '.avi')
KNOWN_ALBUM_ALIASES = (
    (('annewuensche', 'annewuesche', 'allewuensche', 'allewuesche'), ('ztSJRGm1',)),
)


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _known_search_aliases(text):
    aliases = []
    value = str(text or '')
    replaced = re.sub('wuesche', 'wuensche', value, flags=re.I)
    if replaced != value:
        aliases.append(replaced)
    return aliases


def _search_variants(text):
    values = []

    def add(value):
        value = re.sub(r'\s+', ' ', str(value or '').strip())
        if value and value not in values:
            values.append(value)

    add(text)
    add(_normalize_german_search_text(text))

    index = 0
    while index < len(values):
        value = values[index]
        for alias in _known_search_aliases(value):
            add(alias)
        add(re.sub(r'(?<=[a-zäöüß])(?=[A-ZÄÖÜ])', ' ', value))
        add(value.replace('_', ' '))
        add(value.replace('-', ' '))
        add(value.replace(' ', ''))
        index += 1
    return values


def _search_key(text):
    return re.sub(r'[^a-z0-9]+', '', _normalize_german_search_text(text).lower())


def _decode_js_url(value):
    return unescape(str(value or '')).replace('\\/', '/').replace('\\\\', '\\')


def _request(url, cache_hours=3, referer=REFERER, origin=URL_MAIN):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    if origin:
        request.addHeaderEntry('Origin', origin)
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s' % (quote_plus(cRequestHandler.RandomUA()), quote_plus(referer or REFERER))


def _parse_album_cards(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<article\b[\s\S]*?</article>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'href=["\'](/albums/[^"\']+)["\']'])
        title = _first_match(block, [
            r'aria-label=["\']([^"\']+)["\']',
            r'<a[^>]+href=["\']/albums/[^"\']+["\'][^>]*class=["\'][^"\']*line-clamp[^"\']*["\'][^>]*>([\s\S]*?)</a>',
        ])
        thumb = _first_match(block, [r'<img[^>]+src=["\'](https?://[^"\']+)["\']'])
        if not href or not title:
            continue
        url = _abs_url(href)
        if url in seen:
            continue
        seen.add(url)
        stats = re.findall(r'<span[^>]+class=["\']tabular-nums font-medium["\'][^>]*>\s*([^<]+)', block)
        suffix = ''
        if stats:
            suffix = ' [%s Dateien]' % stats[0]
        entries.append({
            'title': _clean_text(title) + suffix,
            'url': url,
            'thumbnail': _abs_url(thumb) if thumb else '',
        })
    return entries


def _album_entry_from_slug(slug):
    if not slug:
        return None
    url = URL_MAIN + '/albums/' + slug
    try:
        html = _request(url, cache_hours=2)
    except Exception:
        html = ''
    if not html or html in ('SEITE NICHT ERREICHBAR', 'URL FEHLER', 'TIMEOUT'):
        return None
    if slug not in html and ('/albums/' + slug) not in html:
        return None
    title = _clean_text(_first_match(html, [
        r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)',
        r'<title>([\s\S]*?)</title>',
    ]))
    title = re.sub(r'\s+—\s+.*$', '', title).strip() if title else 'Bunkr Album ' + slug
    description = _first_match(html, [r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']+)'])
    files = _first_match(description, [r'—\s*([^—]+?files?)\b'])
    if files:
        title += ' [%s]' % files
    thumb = _first_match(html, [r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)'])
    return {'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else ''}


def _direct_album_entries(search_text):
    entries = []
    seen = set()
    patterns = [
        r'bunkr\.(?:site|si|cr)/(?:a|albums)/([0-9A-Za-z]+)',
        r'bunkrsearch\.com/albums/([0-9A-Za-z]+)',
        r'\b(?=[0-9A-Za-z]*\d)[0-9A-Za-z]{8,16}\b',
    ]
    for pattern in patterns:
        for slug in re.findall(pattern, str(search_text or ''), re.I):
            if slug in seen:
                continue
            seen.add(slug)
            entry = _album_entry_from_slug(slug)
            if entry:
                entries.append(entry)
    key = _search_key(search_text)
    for aliases, slugs in KNOWN_ALBUM_ALIASES:
        if key not in aliases:
            continue
        for slug in slugs:
            if slug in seen:
                continue
            seen.add(slug)
            entry = _album_entry_from_slug(slug)
            if entry:
                entries.append(entry)
    if not entries and re.fullmatch(r'[0-9A-Za-z]{8,16}', str(search_text or '').strip()):
        entry = _album_entry_from_slug(str(search_text).strip())
        if entry:
            entries.append(entry)
    return entries


def _add_unique_entry(entries, seen, entry):
    if not entry or not entry.get('url'):
        return
    key = entry['url']
    if key in seen:
        return
    seen.add(key)
    entries.append(entry)


def _album_slug_from_url(url):
    match = re.search(r'(?:bunkr\.(?:site|si|cr)/(?:a|albums)|bunkrsearch\.com/albums|/(?:a|albums))/([0-9A-Za-z]+)', str(url or ''), re.I)
    return match.group(1) if match else ''


def _parse_album_link_entries(html, base_url):
    entries = []
    seen = set()
    links = re.findall(r'href=["\']([^"\']+)["\']', html, re.I)
    links += re.findall(r'https?://(?:www\.)?(?:bunkr\.(?:site|si|cr)/(?:a|albums)|bunkrsearch\.com/albums)/[0-9A-Za-z]+', html, re.I)
    for href in links:
        slug = _album_slug_from_url(_abs_url(href, base_url + '/'))
        if not slug or slug in seen:
            continue
        seen.add(slug)
        entry = _album_entry_from_slug(slug)
        if entry:
            entries.append(entry)
    return entries


def _search_bunkr_albums_index(search_text):
    entries = []
    seen = set()
    for variant in _search_variants(search_text):
        for parameter in ('search', 'q'):
            search_url = BUNKR_ALBUMS_URL + '/?' + urlencode({parameter: variant})
            try:
                html = _request(search_url, cache_hours=2, referer=BUNKR_ALBUMS_URL + '/', origin=BUNKR_ALBUMS_URL)
            except Exception as exc:
                logger.info('-> [Bunkr Search]: bunkr-albums lookup failed %s: %s' % (search_url, exc))
                html = ''
            if not html or html in ('SEITE NICHT ERREICHBAR', 'URL FEHLER', 'TIMEOUT'):
                continue
            for entry in _parse_album_link_entries(html, BUNKR_ALBUMS_URL):
                _add_unique_entry(entries, seen, entry)
    return entries


def _parse_category_links(html):
    entries = []
    seen = set()
    for href, title in re.findall(r'href=["\'](/category/[^"\']+)["\'][^>]*>\s*([^<]+)</a>', html, re.I | re.S):
        title = _clean_text(title)
        url = _abs_url(href)
        if not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': ''})
    return entries


def _next_page_url(html, current_url):
    if '?' in current_url:
        return ''
    current_path = urlsplit(current_url).path.strip('/')
    if current_path in ('',):
        match = re.search(r'href=["\'](/page/\d+)["\'][^>]*aria-label=["\']Next page["\']', html, re.I)
        if not match:
            match = re.search(r'aria-label=["\']Next page["\'][\s\S]{0,500}?href=["\'](/page/\d+)["\']', html, re.I)
        return _abs_url(match.group(1)) if match else ''
    return ''


def load():
    params = ParameterHandler()
    menu = [
        ('Search', 'showSearch', URL_MAIN + '/'),
        ('Latest', 'showEntries', URL_MAIN + '/'),
        ('Most Viewed', 'showEntries', URL_MAIN + '/most-viewed'),
        ('Trending', 'showEntries', URL_MAIN + '/trending'),
        ('Categories', 'showCategories', URL_MAIN + '/categories'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def _add_album_entries(entries, source_url, list_function, source_html='', search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showAlbum')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        gui.addFolder(element, params, True, total)

    if source_url and entries:
        html = source_html or _request(source_url, cache_hours=2)
        next_url = _next_page_url(html, source_url)
        if next_url and next_url != _abs_url(source_url):
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)

    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html = _request(source_url, cache_hours=2)
    entries = _parse_album_cards(html)

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showAlbum')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            sGui.addFolder(element, params, True, total)
        return

    _add_album_entries(entries, source_url, 'showEntries', source_html=html, search_text=sSearchText or '')


def showCategories():
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/categories'
    html = _request(source_url, cache_hours=12)
    entries = _parse_category_links(html)
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries')
        gui.addFolder(element, gui_params, True, total)
    gui.setEndOfDirectory()


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    entries = []
    seen = set()
    for entry in _direct_album_entries(sSearchText):
        _add_unique_entry(entries, seen, entry)
    for variant in _search_variants(sSearchText):
        search_url = URL_MAIN + '/search?' + urlencode({'q': variant})
        html = _request(search_url, cache_hours=2)
        for entry in _parse_album_cards(html):
            _add_unique_entry(entries, seen, entry)
    for entry in _search_bunkr_albums_index(sSearchText):
        _add_unique_entry(entries, seen, entry)

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showAlbum')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            sGui.addFolder(element, params, True, total)
        return

    _add_album_entries(entries, '', 'showEntries', search_text=sSearchText)


def _album_slug(url):
    match = re.search(r'/(?:albums|a)/([0-9A-Za-z]+)', str(url or ''))
    return match.group(1) if match else ''


def _host_album_url(slug, host):
    return host.rstrip('/') + '/a/' + slug


def _is_host_album_url(url):
    split = urlsplit(str(url or ''))
    return split.netloc.lower().replace('www.', '') in ('bunkr.site', 'bunkr.si', 'bunkr.cr') and '/a/' in split.path


def _album_next_page_url(html, album_url):
    pagination = _first_match(html, [r'<nav[^>]+class=["\'][^"\']*\bpagination\b[^"\']*["\'][\s\S]*?</nav>'])
    if not pagination:
        return ''
    active = _first_match(pagination, [r'<span[^>]+class=["\'][^"\']*\bactive\b[^"\']*["\'][^>]*>\s*(\d+)\s*</span>'])
    try:
        next_page = int(active) + 1
    except Exception:
        next_page = 2
    for href, label in re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*([^<]+)\s*</a>', pagination, re.I | re.S):
        if _clean_text(label) in (str(next_page), '»', '&raquo;'):
            return _abs_url(href, album_url)
    return ''


def _parse_album_files(html, album_url):
    files = []
    item_starts = [
        match.start()
        for match in re.finditer(r'<div[^>]+class=["\'][^"\']*\btheItem\b[^"\']*["\']', html, re.I)
    ]
    for index, start in enumerate(item_starts):
        end = item_starts[index + 1] if index + 1 < len(item_starts) else len(html)
        block = html[start:end]
        title = _clean_text(_first_match(block, [
            r'title=["\']([^"\']+)["\']',
            r'<p[^>]+class=["\'][^"\']*\btheName\b[^"\']*["\'][^>]*>([\s\S]*?)</p>',
        ]))
        file_href = _first_match(block, [r'href=["\'](/f/[0-9A-Za-z]+)["\']'])
        thumb = _first_match(block, [r'<img[^>]+class=["\'][^"\']*\bgrid-images_box-img\b[^"\']*["\'][^>]+src=["\']([^"\']+)["\']'])
        size = _clean_text(_first_match(block, [r'<p[^>]+class=["\'][^"\']*\btheSize\b[^"\']*["\'][^>]*>([\s\S]*?)</p>']))
        type_name = _first_match(block, [r'\btype-([A-Za-z]+)\b'])
        if not title or not file_href:
            continue
        is_video = type_name.lower() == 'video' or title.lower().endswith(VIDEO_EXTENSIONS)
        if not is_video:
            continue
        display_title = title + (' [%s]' % size if size else '')
        files.append({
            'title': display_title,
            'url': _abs_url(file_href, album_url),
            'thumbnail': _abs_url(thumb, album_url) if thumb else '',
        })
    return files


def showAlbum():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    slug = _album_slug(source_url)
    gui = cGui()
    gui_params = ParameterHandler()
    files = []
    album_url = ''
    album_html = ''
    if slug:
        hosts = (source_url,) if _is_host_album_url(source_url) else [_host_album_url(slug, host) for host in BUNKR_HOSTS]
        for album_url in hosts:
            try:
                album_html = _request(album_url, cache_hours=2, referer=source_url or REFERER)
                files = _parse_album_files(album_html, album_url)
            except Exception as exc:
                logger.info('-> [Bunkr Search]: album host failed %s: %s' % (album_url, exc))
                files = []
                album_html = ''
            if files:
                break

    total = len(files)
    for entry in files:
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        gui_params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        element.setMediaType('movie')
        gui.addFolder(element, gui_params, False, total)
    next_url = _album_next_page_url(album_html, album_url) if album_html and album_url else ''
    if next_url:
        next_params = ParameterHandler()
        next_params.setParam('sUrl', next_url)
        next_params.setParam('entryUrl', next_url)
        gui.addNextPage(SITE_IDENTIFIER, 'showAlbum', next_params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def _signed_stream_url(file_url):
    html = _request(file_url, cache_hours=0, referer=file_url)
    raw_url = _decode_js_url(_first_match(html, [r'var\s+jsCDN\s*=\s*["\']([^"\']+)["\']']))
    sign_url = _first_match(html, [r'var\s+signUrl\s*=\s*["\']([^"\']+)["\']'])
    if not raw_url:
        raw_url = _decode_js_url(_first_match(html, [r'<a[^>]+href=["\'](https?://get\.[^"\']+)["\']']))
    if not raw_url:
        return ''
    if sign_url:
        media_path = urlsplit(raw_url).path
        sign_request = cRequestHandler(sign_url + '?path=' + quote(media_path, safe=''), caching=False, ignoreErrors=True)
        sign_request.addHeaderEntry('Referer', file_url)
        sign_response = sign_request.request()
        try:
            signed = json.loads(sign_response)
            token = signed.get('token')
            expires = signed.get('ex')
            if token and expires:
                separator = '&' if '?' in raw_url else '?'
                raw_url = raw_url + separator + urlencode({'token': token, 'ex': expires})
        except Exception as exc:
            logger.info('-> [Bunkr Search]: signing failed for %s: %s' % (file_url, exc))
    return raw_url + _stream_headers(file_url)


def showHosters():
    params = ParameterHandler()
    file_url = params.getValue('entryUrl') or params.getValue('sUrl')
    stream_url = _signed_stream_url(file_url)
    if stream_url:
        return [{'streamUrl': stream_url, 'resolved': True, 'title': 'Bunkr'}]
    logger.info('-> [Bunkr Search]: no playable stream found for %s' % file_url)
    return []


def getHosterUrl(sUrl=False):
    stream_url = _signed_stream_url(sUrl)
    return [{'streamUrl': stream_url, 'resolved': True}] if stream_url else []
