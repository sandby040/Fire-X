# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_livecam_bridge import build_live_site

SITE_IDENTIFIER = 'live_bongacams'
SITE_NAME = 'BongaCams Live'
SITE_ICON = 'live_bongacams.png'
DOMAIN = 'bongacams.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {
    'key': 'bongacams',
    'site_id': SITE_IDENTIFIER,
    'name': SITE_NAME,
    'api': 'http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json',
    'room_api': 'https://bongacams.com/tools/amf.php',
    'referer': 'https://bongacams.com/',
    'categories': {
        'female': {'title': 'Frauen'},
        'couples': {'title': 'Paare'},
        'male': {'title': 'Maenner'},
        'shemale': {'title': 'Trans'},
    },
}

load, showSearch, showModelSearch, showTagSearch, showCategories, listCams, showHosters = build_live_site(_CONFIG)
