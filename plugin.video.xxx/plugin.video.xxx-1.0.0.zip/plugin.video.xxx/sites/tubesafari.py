# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import parse_qs, quote_plus, urlencode, urljoin, urlparse, urlunparse

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger

SITE_IDENTIFIER = 'tubesafari'
SITE_NAME = 'TubeSafari'
SITE_ICON = 'tubesafari.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'tubesafari.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', USER_AGENT)
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
    return request.request()


def _stream_headers(referer=REFERER):
    return '|' + urlencode({
        'User-Agent': USER_AGENT,
        'Referer': referer or REFERER,
    })


def _parse_video_items(html):
    entries = []
    seen = set()
    # Find all vid_li blocks
    blocks = re.findall(r'<div class="vid_li">([\s\S]*?)(?=<div class="vid_li">|<div class="more_videos"|<div class="footer"|$)', html or '', re.I)
    for block in blocks:
        url_match = re.search(r'href=["\'](/video\?id=[^"\']+)["\']', block)
        if not url_match:
            continue
        url = _abs_url(url_match.group(1))
        if url in seen:
            continue

        title_match = re.search(r'class=["\'][^"\']*vid_title[^"\']*["\'][^>]*>([^<]+)</a>', block)
        title = _clean_text(title_match.group(1)) if title_match else ''
        if not title:
            continue

        thumb = ''
        data_src = re.search(r'data-src=[\'"]([^\'"]+)[\'"]', block)
        if data_src:
            thumb = data_src.group(1)
        else:
            src = re.search(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', block)
            if src and not src.group(1).startswith('data:'):
                thumb = src.group(1)

        dur_match = re.search(r'<div class="video_length">([^<]+)</div>', block)
        dur = _clean_text(dur_match.group(1)) if dur_match else ''

        seen.add(url)
        entries.append({
            'url': url,
            'title': title,
            'thumbnail': _abs_url(thumb) if thumb else '',
            'duration': dur,
        })
    return entries


def _filter_entries_by_keyword(entries, keyword, is_search_url=False):
    if not keyword or is_search_url:
        return entries
    words = [w.lower() for w in re.split(r'\s+', _clean_text(keyword)) if w]
    if not words:
        return entries
    matched = [e for e in entries if any(w in (e.get('title') or '').lower() for w in words)]
    return matched or entries


def _parse_categories(html):
    categories = []
    seen = set()
    pattern = r'<a\b[^>]*href=["\'](/search/[^"\']+)["\'][^>]*>([^<]+)</a>'
    for match in re.finditer(pattern, html or '', re.I):
        href, title = match.groups()
        url = _abs_url(href)
        if url in seen:
            continue
        name = _clean_text(title)
        if not name or len(name) < 2:
            continue
        seen.add(url)
        categories.append({
            'url': url,
            'title': name,
            'thumbnail': '',
        })
    return categories


def _next_page_url(current_url, html):
    parsed = urlparse(current_url)
    qs = parse_qs(parsed.query)
    current_page = int((qs.get('page') or ['1'])[0])
    qs['page'] = [str(current_page + 1)]
    new_query = urlencode(qs, doseq=True)
    return urlunparse(parsed._replace(query=new_query))


def load():
    menu = [
        ('Suche', 'showSearch', ''),
        ('Kategorien', 'showCategories', URL_MAIN + '/categories'),
        ('Neueste Videos', 'showEntries', URL_MAIN + '/search/latest'),
        ('Beliebte Videos', 'showEntries', URL_MAIN + '/search/popular'),
        ('Trending Videos', 'showEntries', URL_MAIN + '/search/trending'),
    ]
    for title, function, url in menu:
        params = ParameterHandler()
        if url:
            params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    gui = cGui()
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/categories'
    html = _request(source_url, cache_hours=6)
    categories = _parse_categories(html)
    total = len(categories)
    for cat in categories:
        cat_params = ParameterHandler()
        cat_params.setParam('sUrl', cat['url'])
        cat_params.setParam('sName', cat['title'])
        element = cGuiElement(cat['title'], SITE_IDENTIFIER, 'showEntries')
        gui.addFolder(element, cat_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text='', html=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
            element.setIcon(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    if len(entries) >= 20:
        next_url = _next_page_url(source_url, html)
        if next_url:
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/search/latest'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')

    html = _request(source_url, cache_hours=2)
    entries = _parse_video_items(html)
    is_search = '/search/' in source_url or 'query=' in source_url
    entries = _filter_entries_by_keyword(entries, sSearchText, is_search)
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
                element.setIcon(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '', html)


def showSearch():
    search_text = cGui().showKeyBoard(sHeading='Suche')
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    search_url = URL_MAIN + '/search/' + quote_plus(sSearchText.strip())
    showEntries(search_url, sGui, sSearchText)


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    return getHosterUrl(source_url)


def getHosterUrl(sUrl=False):
    if not sUrl:
        params = ParameterHandler()
        sUrl = params.getValue('entryUrl') or params.getValue('sUrl')
    if not sUrl:
        return []

    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html or '')

    for iframe in iframes:
        iframe = unescape(iframe)

        # 1. Pornhub Embed
        if 'pornhub.com/embed/' in iframe:
            try:
                ph_html = _request(iframe, cache_hours=0, referer=sUrl)
                pos = ph_html.find('mediaDefinitions')
                if pos != -1:
                    m = re.findall(r'"format"\s*:\s*"hls"\s*,\s*"videoUrl"\s*:\s*"([^"]+)"', ph_html)
                    if m:
                        vurl = m[0].replace(r'\/', '/')
                        return [{
                            'streamUrl': vurl + _stream_headers('https://www.pornhub.com/'),
                            'resolved': True,
                            'title': 'Pornhub (TubeSafari)',
                        }]
                    m_mp4 = re.findall(r'"format"\s*:\s*"mp4"\s*,\s*"videoUrl"\s*:\s*"([^"]+)"', ph_html)
                    if m_mp4:
                        vurl = m_mp4[0].replace(r'\/', '/')
                        return [{
                            'streamUrl': vurl + _stream_headers('https://www.pornhub.com/'),
                            'resolved': True,
                            'title': 'Pornhub (TubeSafari)',
                        }]
            except Exception as e:
                logger.info('-> [TubeSafari]: PH embed error: %s' % e)

        # 2. XVideos Embed
        if 'xvideos.com/embedframe/' in iframe:
            try:
                xv_html = _request(iframe, cache_hours=0, referer=sUrl)
                hls = re.findall(r'html5player\.setVideoHLS\(["\']([^"\']+)["\']\)', xv_html)
                if hls:
                    return [{
                        'streamUrl': hls[0] + _stream_headers('https://www.xvideos.com/'),
                        'resolved': True,
                        'title': 'XVideos (TubeSafari)',
                    }]
                high = re.findall(r'html5player\.setVideoUrlHigh\(["\']([^"\']+)["\']\)', xv_html)
                if high:
                    return [{
                        'streamUrl': high[0] + _stream_headers('https://www.xvideos.com/'),
                        'resolved': True,
                        'title': 'XVideos (TubeSafari)',
                    }]
                mp4s = re.findall(r'https?://[^"\'<>\s]+\.mp4(?:\?[^"\'<>\s]*)?', xv_html)
                if mp4s:
                    return [{
                        'streamUrl': mp4s[0] + _stream_headers('https://www.xvideos.com/'),
                        'resolved': True,
                        'title': 'XVideos (TubeSafari)',
                    }]
            except Exception as e:
                logger.info('-> [TubeSafari]: XV embed error: %s' % e)

        # 3. Generic Embed
        try:
            gen_html = _request(iframe, cache_hours=0, referer=sUrl)
            m3u8 = re.findall(r'https?://[^"\'<>\s]+\.m3u8(?:\?[^"\'<>\s]*)?', gen_html)
            if m3u8:
                return [{
                    'streamUrl': m3u8[0] + _stream_headers(iframe),
                    'resolved': True,
                    'title': SITE_NAME,
                }]
            mp4 = re.findall(r'https?://[^"\'<>\s]+\.mp4(?:\?[^"\'<>\s]*)?', gen_html)
            if mp4:
                return [{
                    'streamUrl': mp4[0] + _stream_headers(iframe),
                    'resolved': True,
                    'title': SITE_NAME,
                }]
        except Exception:
            pass

    logger.info('-> [TubeSafari]: no playable stream found for %s' % sUrl)
    return []
