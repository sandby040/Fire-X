# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'xvideos_red'
SITE_NAME = 'XVideos'
SITE_ICON = 'xvideos.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.xvideos.red')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

SOURCE_DOMAIN = 'www.xvideos.com'
URL_MAIN = 'https://' + SOURCE_DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', cRequestHandler.RandomUA())
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s&Origin=%s' % (
        quote_plus(cRequestHandler.RandomUA()),
        quote_plus(referer or REFERER),
        quote_plus(URL_MAIN),
    )


def _with_query(url, **updates):
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(updates)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def _parse_video_items(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<div[^>]+class=["\'][^"\']*thumb-block[^"\']*["\'][\s\S]*?(?=<div[^>]+class=["\'][^"\']*thumb-block|$)', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'<a[^>]+href=["\']((?:https?://(?:[^/"\']+\.)?xvideos\.com)?/video[^/"\']+/[^"\']+)["\']'])
        title = _clean_text(_first_match(block, [
            r'<p[^>]+class=["\'][^"\']*title[^"\']*["\'][^>]*>([\s\S]*?)</p>',
            r'title=["\']([^"\']+)["\']',
        ]))
        thumb = _first_match(block, [
            r'data-src=["\']([^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [r'<span[^>]+class=["\'][^"\']*duration[^"\']*["\'][^>]*>([\s\S]*?)</span>']))
        url = _abs_url(href)
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else '', 'duration': duration})
    return entries


def _parse_categories(html):
    entries = []
    seen = set()
    for href, title in re.findall(r'<li[^>]*class=["\'][^"\']*(?:dyn|top-cat)[^"\']*["\'][^>]*>\s*<a[^>]+href=["\'](/(?:c|lang)/[^"\']+)["\'][^>]*>([\s\S]*?)</a>', html, re.I):
        url = _abs_url(href)
        title = _clean_text(title)
        if not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': ''})
    return entries


def _next_page_url(current_url, entries):
    if not entries:
        return ''
    split = urlsplit(current_url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    try:
        page = int(query.get('p', '0') or '0')
    except Exception:
        page = 0
    query['p'] = str(page + 1)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Neueste Uploads', 'showEntries', URL_MAIN + '/new/1'),
        ('Kategorien', 'showCategories', URL_MAIN + '/tags'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    params = ParameterHandler()
    entries = _parse_categories(_request(params.getValue('sUrl') or URL_MAIN + '/tags', cache_hours=12))
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        gui.addFolder(cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries'), gui_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    next_url = _next_page_url(source_url, entries)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    entries = _parse_video_items(_request(source_url, cache_hours=2))
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    showEntries(_with_query(URL_MAIN + '/', k=sSearchText), sGui, sSearchText)


def _stream_url_from_page(html):
    candidates = []
    for quality, stream_url in (
        (720, _first_match(html, [r'html5player\.setVideoUrlHigh\(["\']([^"\']+)["\']'])),
        (240, _first_match(html, [r'html5player\.setVideoUrlLow\(["\']([^"\']+)["\']'])),
        (9999, _first_match(html, [r'html5player\.setVideoHLS\(["\']([^"\']+)["\']'])),
    ):
        stream_url = unescape(stream_url).replace('\\/', '/')
        if stream_url:
            candidates.append((quality, stream_url))
    for stream_url in re.findall(r'https?://[^"\'<>\s]+\.mp4(?:\?[^"\'<>\s]*)?', html, re.I):
        stream_url = unescape(stream_url).replace('\\/', '/')
        match = re.search(r'(\d{3,4})p', stream_url)
        candidates.append((int(match.group(1)) if match else 0, stream_url))
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    stream_url = _stream_url_from_page(html)
    if stream_url:
        return [{'streamUrl': stream_url + _stream_headers(source_url), 'resolved': True, 'title': SITE_NAME}]
    logger.info('-> [XVideos]: no playable stream found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    stream_url = _stream_url_from_page(html)
    return [{'streamUrl': stream_url + _stream_headers(sUrl), 'resolved': True}] if stream_url else []
