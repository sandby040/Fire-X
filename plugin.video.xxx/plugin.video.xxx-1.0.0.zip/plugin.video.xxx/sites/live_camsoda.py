# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_livecam_bridge import build_live_site

SITE_IDENTIFIER = 'live_camsoda'
SITE_NAME = 'Camsoda Live'
SITE_ICON = 'live_camsoda.png'
DOMAIN = 'www.camsoda.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {
    'key': 'camsoda',
    'site_id': SITE_IDENTIFIER,
    'name': SITE_NAME,
    'base': 'https://www.camsoda.com',
    'api': 'https://www.camsoda.com/api/v1/browse/react?gender-hide=c,t,m',
    'chat_api': 'https://www.camsoda.com/api/v1/chat/react/{}',
    'referer': 'https://www.camsoda.com/',
    'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
        'Accept': 'application/json,text/plain,*/*',
        'X-Requested-With': 'XMLHttpRequest',
    },
    'categories': {
        'girls': {'title': 'Frauen', 'path': 'api/v1/browse/react?gender-hide=c,t,m'},
        'couple': {'title': 'Paare', 'path': 'api/v1/browse/react?gender-hide=f,t,m'},
        'men': {'title': 'Maenner', 'path': 'api/v1/browse/react?gender-hide=c,t,f'},
        'trans': {'title': 'Trans', 'path': 'api/v1/browse/react?gender-hide=c,f,m'},
    },
}

load, showSearch, showModelSearch, showTagSearch, showCategories, listCams, showHosters = build_live_site(_CONFIG)
