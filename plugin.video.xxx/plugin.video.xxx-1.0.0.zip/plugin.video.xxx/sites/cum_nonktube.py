# -*- coding: utf-8 -*-
from resources.lib.config import cConfig
from resources.lib.xxx_site_bridge import build_site

SITE_IDENTIFIER = 'cum_nonktube'
SITE_NAME = 'NonkTube'
SITE_ICON = 'cum_nonktube.png'
DOMAIN = 'www.nonktube.com'
STATUS = '200'
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = False

_CONFIG = {'site_id': SITE_IDENTIFIER, 'icon': SITE_ICON, 'search_mode': 'nonktube.Search', 'search_url': 'https://www.nonktube.com/?s=', 'latest_mode': 'nonktube.List', 'latest_url': 'https://www.nonktube.com/?sorting=latest', 'categories_mode': 'nonktube.Cat', 'categories_url': 'https://www.nonktube.com/categories/'}
load, showSearch = build_site(_CONFIG)
