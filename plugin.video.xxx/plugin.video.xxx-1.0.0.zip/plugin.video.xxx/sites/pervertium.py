# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import quote, quote_plus, urlencode, urljoin, urlsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger

SITE_IDENTIFIER = 'pervertium'
SITE_NAME = 'Pervertium'
SITE_ICON = 'pervertium.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.pervertium.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', USER_AGENT)
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
    return request.request()


def _stream_headers(referer=REFERER):
    return '|' + urlencode({
        'User-Agent': USER_AGENT,
        'Referer': referer or REFERER,
    })


def _parse_video_items(html):
    entries = []
    seen = set()
    pattern = r'<div class="item[^"]*">[\s\S]*?<a\s+href="([^"]+/videos/[^"]+)".*?title="([^"]+)"[\s\S]*?<img[^>]+(?:data-original|src)="([^"]+)"[\s\S]*?<div class="duration">([^<]+)</div>'
    for match in re.finditer(pattern, html or '', re.I):
        href, title, thumb, dur = match.groups()
        url = _abs_url(href)
        if url in seen:
            continue
        seen.add(url)
        entries.append({
            'url': url,
            'title': _clean_text(title),
            'thumbnail': _abs_url(thumb),
            'duration': _clean_text(dur),
        })
    return entries


def _filter_entries_by_keyword(entries, keyword, is_search_url=False):
    if not keyword or is_search_url:
        return entries
    words = [w.lower() for w in re.split(r'\s+', _clean_text(keyword)) if w]
    if not words:
        return entries
    matched = [e for e in entries if any(w in (e.get('title') or '').lower() for w in words)]
    return matched or entries


def _parse_categories(html):
    categories = []
    seen = set()
    pattern = r'<a\s+class=["\']drop_cats_item["\']\s+href="([^"]+)"\s+title="([^"]+)"[\s\S]*?<img[^>]+(?:data-original|src)="([^"]+)"'
    for match in re.finditer(pattern, html or '', re.I):
        href, title, thumb = match.groups()
        url = _abs_url(href)
        if url in seen:
            continue
        seen.add(url)
        categories.append({
            'url': url,
            'title': _clean_text(title),
            'thumbnail': _abs_url(thumb),
        })
    return categories


def _next_page_url(current_url, html):
    next_match = re.search(r'<li\s+class=["\']next["\'][^>]*>\s*<a\s+[^>]*href=["\']([^"\']+)["\']', html or '', re.I)
    if next_match:
        return _abs_url(next_match.group(1), current_url)
    next_link = re.search(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>\s*(?:Next|»|Weiter)', html or '', re.I)
    if next_link:
        return _abs_url(next_link.group(1), current_url)
    return ''


def load():
    menu = [
        ('Suche', 'showSearch', ''),
        ('Kategorien', 'showCategories', URL_MAIN + '/categories/'),
        ('Neueste Videos', 'showEntries', URL_MAIN + '/last-updates/'),
        ('Beliebte Videos', 'showEntries', URL_MAIN + '/most-popular/'),
        ('Top-Bewertungen', 'showEntries', URL_MAIN + '/top-rated/'),
    ]
    for title, function, url in menu:
        params = ParameterHandler()
        if url:
            params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    gui = cGui()
    params = ParameterHandler()
    source_url = params.getValue('sUrl') or URL_MAIN + '/categories/'
    html = _request(source_url, cache_hours=6)
    categories = _parse_categories(html)
    total = len(categories)
    for cat in categories:
        cat_params = ParameterHandler()
        cat_params.setParam('sUrl', cat['url'])
        cat_params.setParam('sName', cat['title'])
        cat_params.setParam('sThumbnail', cat['thumbnail'])
        element = cGuiElement(cat['title'], SITE_IDENTIFIER, 'showEntries')
        if cat['thumbnail']:
            element.setThumbnail(cat['thumbnail'])
            element.setIcon(cat['thumbnail'])
        gui.addFolder(element, cat_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text='', html=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
            element.setIcon(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)

    next_url = _next_page_url(source_url, html)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/last-updates/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html = _request(source_url, cache_hours=2)
    entries = _parse_video_items(html)
    is_search = '/search/' in source_url
    entries = _filter_entries_by_keyword(entries, sSearchText, is_search)
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
                element.setIcon(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '', html)


def showSearch():
    search_text = cGui().showKeyBoard(sHeading='Suche')
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    slug = quote(sSearchText.strip().replace(' ', '-'))
    search_url = URL_MAIN + '/search/' + slug + '/'
    showEntries(search_url, sGui, sSearchText)


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    return getHosterUrl(source_url)


def getHosterUrl(sUrl=False):
    if not sUrl:
        params = ParameterHandler()
        sUrl = params.getValue('entryUrl') or params.getValue('sUrl')
    if not sUrl:
        return []
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    m = re.search(r'video_url:\s*[\'"]([^\'"]+)[\'"]', html or '')
    if m:
        stream_url = _abs_url(m.group(1), sUrl)
        return [{
            'streamUrl': stream_url + _stream_headers(sUrl),
            'resolved': True,
            'title': SITE_NAME,
        }]
    logger.info('-> [Pervertium]: no playable stream found for %s' % sUrl)
    return []
