# -*- coding: utf-8 -*-
# Python 3

import re
from html import unescape
from urllib.parse import quote_plus, urljoin, urlsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import cParser, logger


SITE_IDENTIFIER = 'porncream'
SITE_NAME = 'PornCream'
SITE_ICON = 'porncream.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'porncream.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url):
    return urljoin(URL_MAIN + '/', unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _normalize_german_search_text(text):
    replacements = (
        ('Ä', 'Ae'), ('Ö', 'Oe'), ('Ü', 'Ue'),
        ('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'),
        ('ß', 'ss'),
    )
    result = str(text or '').strip()
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _request(url, cache_hours=6, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', URL_MAIN)
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _thumbnail_from_block(block):
    thumbnail = _first_match(block, [
        r'data-lazy-src=["\']([^"\']+)["\']',
        r'<img[^>]+src=["\'](https?://[^"\']+)["\']',
        r'<source[^>]+srcset=["\']([^"\']+)["\']',
        r'<source[^>]+data-lazy-srcset=["\']([^"\']+)["\']',
        r'<meta[^>]+itemprop=["\']thumbnailUrl["\'][^>]+content=["\']([^"\']+)["\']',
    ])
    if ' ' in thumbnail:
        thumbnail = thumbnail.split(' ', 1)[0]
    return _abs_url(thumbnail) if thumbnail else ''


def _duration_from_block(block):
    duration = _first_match(block, [
        r'<span[^>]+class=["\']duration["\'][^>]*>.*?</i>\s*([^<]+)</span>',
        r'<meta[^>]+itemprop=["\']duration["\'][^>]+content=["\']([^"\']+)["\']',
    ])
    return duration


def _parse_articles(html, folders=False):
    articles = []
    seen = set()
    for match in re.finditer(r'<article\b[\s\S]*?</article>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'<a[^>]+href=["\']([^"\']+)["\']'])
        title = _first_match(block, [
            r'<a[^>]+title=["\']([^"\']+)["\']',
            r'<header[^>]+class=["\']entry-header["\'][^>]*>\s*<span>([\s\S]*?)</span>',
            r'<img[^>]+alt=["\']([^"\']+)["\']',
        ])
        href = _abs_url(href)
        title = _clean_text(title)
        if not href or not title or href in seen:
            continue
        seen.add(href)
        articles.append({
            'title': title,
            'url': href,
            'thumbnail': _thumbnail_from_block(block),
            'duration': _duration_from_block(block),
            'folder': folders,
        })
    return articles


def _next_page_url(html):
    return _abs_url(_first_match(html, [
        r'<link[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        r'<a[^>]+class=["\'][^"\']*(?:next|nextpostslink)[^"\']*["\'][^>]+href=["\']([^"\']+)["\']',
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:Next|Next Page|Older)\s*</a>',
    ]))


def _is_search_url(url):
    url = str(url or '').lower()
    return '?s=' in url or '&s=' in url or '/search/' in url


def load():
    params = ParameterHandler()
    menu = [
        ('Search', 'showSearch', URL_MAIN + '/'),
        ('Home', 'showEntries', URL_MAIN + '/'),
        ('Categories', 'showCategories', URL_MAIN + '/categories/'),
        ('Actors', 'showActors', URL_MAIN + '/actors/'),
        ('Trending', 'showEntries', URL_MAIN + '/?filter=trending'),
        ('Random', 'showEntries', URL_MAIN + '/?filter=random'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def _add_listing_entries(entries, source_url, list_function, end=True, source_html='', search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries' if entry.get('folder') else 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        if entry.get('folder'):
            gui.addFolder(element, params, True, total)
        else:
            element.setMediaType('movie')
            gui.addFolder(element, params, False, total)
    if source_url and entries:
        html = source_html or _request(source_url, cache_hours=2)
        next_url = _next_page_url(html)
        if next_url and next_url != _abs_url(source_url):
            params.setParam('sUrl', next_url)
            if search_text:
                params.setParam('sSearchText', search_text)
            gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    if end:
        gui.setView('movies')
        gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    html = _request(source_url, cache_hours=2)
    entries = _parse_articles(html)

    if sSearchText and not _is_search_url(source_url):
        needle = sSearchText.lower()
        entries = [entry for entry in entries if needle in entry['title'].lower() or cParser.search(needle, entry['title'].lower())]

    if sGui:
        total = len(entries)
        params = ParameterHandler()
        for entry in entries:
            params.setParam('entryUrl', entry['url'])
            params.setParam('sUrl', entry['url'])
            params.setParam('sName', entry['title'])
            params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, params, False, total)
        return

    _add_listing_entries(entries, source_url, 'showEntries', source_html=html, search_text=sSearchText or '')


def _show_index(source_url, function):
    html = _request(source_url, cache_hours=24)
    entries = _parse_articles(html, folders=True)
    _add_listing_entries(entries, source_url, function)


def showCategories():
    params = ParameterHandler()
    _show_index(params.getValue('sUrl') or URL_MAIN + '/categories/', 'showCategories')


def showActors():
    params = ParameterHandler()
    _show_index(params.getValue('sUrl') or URL_MAIN + '/actors/', 'showActors')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    sSearchText = _normalize_german_search_text(sSearchText)
    search_url = URL_MAIN + '/?s=' + quote_plus(sSearchText)
    showEntries(search_url, sGui, sSearchText)


def _stream_headers(referer):
    return '|User-Agent=%s&Referer=%s' % (quote_plus(cRequestHandler.RandomUA()), quote_plus(referer or REFERER))


def _extract_direct_streams(embed_url, page_url):
    streams = []
    try:
        html = _request(embed_url, cache_hours=1, referer=page_url or REFERER)
    except Exception:
        return streams

    seen = set()
    patterns = [
        r'(?:file|source|src)\s*[:=]\s*["\'](https?://[^"\']+\.(?:mp4|m3u8|mpd)(?:\?[^"\']*)?)["\']',
        r'["\'](?:file|source|src)["\']\s*:\s*["\'](https?://[^"\']+\.(?:mp4|m3u8|mpd)(?:\?[^"\']*)?)["\']',
        r'(https?://[^"\'<>\s]+?\.(?:mp4|m3u8|mpd)(?:\?[^"\'<>\s]*)?)',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, html, re.I | re.S):
            stream_url = unescape(match.group(1)).replace('\\/', '/')
            if 'test-videos.co.uk' in stream_url.lower():
                continue
            if stream_url in seen:
                continue
            seen.add(stream_url)
            streams.append({
                'streamUrl': stream_url + _stream_headers(embed_url),
                'resolved': True,
                'title': cParser.urlparse(embed_url) or 'Stream',
            })
    return streams


def _voe_stream_entry(embed_url):
    try:
        split = urlsplit(embed_url)
        host = (split.netloc or '').lower().replace('www.', '')
        if host not in ('pornkrm.com', 'rebeccacostthousand.com', 'voe.sx'):
            return None
        match = re.search(r'/e/([0-9A-Za-z]+)', split.path or '')
        if not match:
            return None
        return {
            'host': 'voe.sx',
            'streamID': match.group(1),
            'streamUrl': '',
            'resolved': False,
            'title': 'Voe',
        }
    except Exception:
        return None


def showHosters():
    stream_candidates = []
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=4)
    seen = set()
    for match in re.finditer(r'data-embed=["\']([^"\']+)["\']', html, re.I):
        url = _abs_url(match.group(1))
        if not url or url in seen:
            continue
        seen.add(url)
        host_name = cParser.urlparse(url)
        if not host_name:
            host_name = 'Player'
        voe_entry = _voe_stream_entry(url)
        if voe_entry:
            stream_candidates.append(voe_entry)
        stream_candidates.extend(_extract_direct_streams(url, source_url))

    embed_url = _first_match(html, [r'<meta[^>]+itemprop=["\']embedUrl["\'][^>]+content=["\']([^"\']+)["\']'])
    if embed_url:
        embed_url = _abs_url(embed_url)
        if embed_url not in seen:
            voe_entry = _voe_stream_entry(embed_url)
            if voe_entry:
                stream_candidates.append(voe_entry)
            stream_candidates.extend(_extract_direct_streams(embed_url, source_url))

    if stream_candidates:
        unique_candidates = []
        seen_candidates = set()
        for candidate in stream_candidates:
            key = candidate.get('streamUrl') or (candidate.get('host', '') + ':' + candidate.get('streamID', ''))
            if key in seen_candidates:
                continue
            seen_candidates.add(key)
            unique_candidates.append(candidate)
        return unique_candidates

    logger.info('-> [PornCream]: no supported player embeds found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]
