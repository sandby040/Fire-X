# -*- coding: utf-8 -*-
# Python 3

import json
import re
from html import unescape
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger


SITE_IDENTIFIER = 'fuqqt'
SITE_NAME = 'Fuqqt'
SITE_ICON = 'fuqqt.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'fuqqt.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER, 'true')
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER, 'true') != 'false'

URL_MAIN = 'https://' + DOMAIN
REFERER = URL_MAIN + '/'


def _abs_url(url, base=URL_MAIN + '/'):
    return urljoin(base, unescape(str(url or '')).strip())


def _clean_text(text):
    text = re.sub(r'<[^>]+>', ' ', str(text or ''))
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _origin_from_url(url):
    parsed = urlsplit(str(url or ''))
    if parsed.scheme and parsed.netloc:
        return parsed.scheme + '://' + parsed.netloc
    return ''


def _request(url, cache_hours=3, referer=REFERER):
    request = cRequestHandler(_abs_url(url), caching=True, ignoreErrors=True)
    request.cacheTime = 60 * 60 * cache_hours
    request.addHeaderEntry('User-Agent', cRequestHandler.RandomUA())
    request.addHeaderEntry('Referer', referer or REFERER)
    request.addHeaderEntry('Origin', _origin_from_url(referer) or URL_MAIN)
    request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
    return request.request()


def _first_match(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.I | re.S)
        if match:
            return unescape(match.group(1)).strip()
    return ''


def _stream_headers(referer):
    origin = _origin_from_url(referer) or URL_MAIN
    return '|User-Agent=%s&Referer=%s&Origin=%s' % (
        quote_plus(cRequestHandler.RandomUA()),
        quote_plus(referer or REFERER),
        quote_plus(origin),
    )


def _with_query(url, **updates):
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(updates)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def _parse_video_items(html):
    entries = []
    seen = set()
    for match in re.finditer(r'<figure\b[\s\S]*?</figure>', html, re.I):
        block = match.group(0)
        href = _first_match(block, [r'<a[^>]+class=["\'][^"\']*video_link[^"\']*["\'][^>]+href=["\']([^"\']+)["\']'])
        title = _clean_text(_first_match(block, [r'<a[^>]+class=["\'][^"\']*vid_title[^"\']*["\'][^>]*>([\s\S]*?)</a>']))
        thumb = _first_match(block, [
            r'<img[^>]+data-src=["\']([^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+)["\']',
        ])
        duration = _clean_text(_first_match(block, [r'<div[^>]+class=["\']vid_len["\'][^>]*>([\s\S]*?)</div>']))
        url = _abs_url(href)
        if not url or not title or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': _abs_url(thumb) if thumb else '', 'duration': duration})
    return entries


def _filter_entries_by_keyword(entries, keyword):
    words = [word.lower() for word in re.split(r'\s+', _clean_text(str(keyword or ''))) if word]
    if not words:
        return entries
    matched = []
    for entry in entries:
        title = (entry.get('title') or '').lower()
        if all(word in title for word in words):
            matched.append(entry)
    return matched


def _filter_search_playable(entries):
    supported = []
    for entry in entries:
        thumb = (entry.get('thumbnail') or '').lower()
        if any(marker in thumb for marker in ('xvideos-cdn.com', 'others-cdn.com', '/xv_')):
            supported.append(entry)
    return supported or entries


def _parse_categories(html):
    entries = []
    seen = set()
    for href, title in re.findall(r'<a[^>]+href=["\'](/videos/[^"\']+)["\'][^>]*>([\s\S]*?)</a>', html, re.I):
        title = _clean_text(title)
        url = _abs_url(href)
        if not title or title.lower() in ('view all', 'best', 'new') or url in seen:
            continue
        seen.add(url)
        entries.append({'title': title, 'url': url, 'thumbnail': ''})
    return entries


def _next_page_url(current_url, entries):
    if not entries:
        return ''
    split = urlsplit(current_url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    try:
        page = int(query.get('page', '1') or '1')
    except Exception:
        page = 1
    query['page'] = str(page + 1)
    return urlunsplit((split.scheme, split.netloc, split.path or '/', urlencode(query), split.fragment))


def load():
    params = ParameterHandler()
    menu = [
        ('Suche', 'showSearch', URL_MAIN + '/'),
        ('Kategorien', 'showCategories', URL_MAIN + '/categories'),
    ]
    for title, function, url in menu:
        params.setParam('sUrl', url)
        cGui().addFolder(cGuiElement(title, SITE_IDENTIFIER, function), params)
    cGui().setEndOfDirectory()


def showCategories():
    params = ParameterHandler()
    entries = _parse_categories(_request(params.getValue('sUrl') or URL_MAIN + '/categories', cache_hours=12))
    gui = cGui()
    gui_params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        gui_params.setParam('sUrl', entry['url'])
        gui_params.setParam('entryUrl', entry['url'])
        gui_params.setParam('sName', entry['title'])
        gui.addFolder(cGuiElement(entry['title'], SITE_IDENTIFIER, 'showEntries'), gui_params, True, total)
    gui.setEndOfDirectory()


def _add_video_entries(entries, source_url, list_function, search_text=''):
    gui = cGui()
    params = ParameterHandler()
    total = len(entries)
    for entry in entries:
        params.setParam('entryUrl', entry['url'])
        params.setParam('sUrl', entry['url'])
        params.setParam('sName', entry['title'])
        params.setParam('sThumbnail', entry['thumbnail'])
        element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
        if entry['thumbnail']:
            element.setThumbnail(entry['thumbnail'])
        if entry.get('duration'):
            element.addItemValue('duration', entry['duration'])
        element.setMediaType('movie')
        gui.addFolder(element, params, False, total)
    next_url = _next_page_url(source_url, entries)
    if next_url:
        params.setParam('sUrl', next_url)
        if search_text:
            params.setParam('sSearchText', search_text)
        gui.addNextPage(SITE_IDENTIFIER, list_function, params)
    gui.setView('movies')
    gui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    params = ParameterHandler()
    source_url = entryUrl or params.getValue('sUrl') or params.getValue('entryUrl') or URL_MAIN + '/videos'
    if not sSearchText and params.getValue('sSearchText'):
        sSearchText = params.getValue('sSearchText')
    entries = _parse_video_items(_request(source_url, cache_hours=2))
    if sSearchText:
        entries = _filter_search_playable(_filter_entries_by_keyword(entries, sSearchText))
    if sGui:
        total = len(entries)
        gui_params = ParameterHandler()
        for entry in entries:
            gui_params.setParam('entryUrl', entry['url'])
            gui_params.setParam('sUrl', entry['url'])
            gui_params.setParam('sName', entry['title'])
            gui_params.setParam('sThumbnail', entry['thumbnail'])
            element = cGuiElement(entry['title'], SITE_IDENTIFIER, 'showHosters')
            if entry['thumbnail']:
                element.setThumbnail(entry['thumbnail'])
            element.setMediaType('movie')
            sGui.addFolder(element, gui_params, False, total)
        return
    _add_video_entries(entries, source_url, 'showEntries', sSearchText or '')


def showSearch():
    search_text = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not search_text:
        cGui().setEndOfDirectory()
        return
    _search(False, search_text)


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    if not sSearchText:
        return
    showEntries(_with_query(URL_MAIN + '/videos', query=sSearchText), sGui, sSearchText)


def _embed_url_from_page(html):
    return _first_match(html, [
        r'<iframe[^>]+src=["\']([^"\']+)["\']',
        r'(https?://[^"\'<>\s]+/embed/[^"\'<>\s]+)',
    ])


def _decode_js_url(url):
    url = unescape(str(url or '')).replace('\\/', '/')
    url = url.replace('\\u0026', '&').replace('\\u003d', '=').replace('\\u003f', '?')
    return url


def _stream_url_from_pornhub_embed(embed_url, source_url):
    embed_url = _abs_url(embed_url, source_url)
    if 'pornhub.com/embed/' not in embed_url:
        return ''
    html = _request(embed_url, cache_hours=0, referer=source_url or REFERER)
    candidates = []
    for block in re.findall(r'\{[^{}]*(?:videoUrl|defaultQuality)[^{}]*\}', html, re.I | re.S):
        stream_url = _first_match(block, [r'"videoUrl"\s*:\s*"([^"]+)"'])
        if not stream_url:
            continue
        quality = _first_match(block, [r'"quality"\s*:\s*"?(\d+)"?', r'"defaultQuality"\s*:\s*"?(\d+)"?'])
        try:
            quality_value = int(quality or 0)
        except Exception:
            quality_value = 0
        stream_url = _decode_js_url(stream_url)
        if 'pornhub.com/video/get_media' in stream_url:
            stream_url = _stream_url_from_pornhub_media(stream_url, embed_url)
        candidates.append((quality_value, stream_url))
    if not candidates:
        for stream_url in re.findall(r'https?:\\?/\\?/[^"\'<>\s]+?(?:\.mp4|\.m3u8)[^"\'<>\s]*', html, re.I):
            candidates.append((0, _decode_js_url(stream_url)))
    candidates = [(quality, url) for quality, url in candidates if url and ('.mp4' in url.lower() or '.m3u8' in url.lower())]
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _stream_url_from_pornhub_media(media_url, referer):
    payload = _request(media_url, cache_hours=0, referer=referer or REFERER)
    try:
        data = json.loads(payload or '[]')
    except Exception:
        return ''
    candidates = []
    for item in data if isinstance(data, list) else []:
        stream_url = _decode_js_url(item.get('videoUrl') or item.get('url') or '')
        if not stream_url or ('.mp4' not in stream_url.lower() and '.m3u8' not in stream_url.lower()):
            continue
        quality = item.get('quality') or item.get('height') or 0
        try:
            quality_value = int(quality)
        except Exception:
            quality_value = _quality_value(quality, stream_url)
        candidates.append((quality_value, stream_url))
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _quality_value(label, stream_url=''):
    label = str(label or '').lower()
    match = re.search(r'(\d{3,4})', label) or re.search(r'(\d{3,4})p', stream_url)
    return int(match.group(1)) if match else 0


def _stream_url_from_xvideos_embed(embed_url, source_url):
    embed_url = _abs_url(embed_url, source_url)
    if 'xvideos.com/embedframe/' not in embed_url:
        return ''
    html = _request(embed_url, cache_hours=0, referer=source_url or REFERER)
    candidates = []
    for label, stream_url in (
        ('high', _first_match(html, [r'html5player\.setVideoUrlHigh\(["\']([^"\']+)["\']'])),
        ('low', _first_match(html, [r'html5player\.setVideoUrlLow\(["\']([^"\']+)["\']'])),
    ):
        stream_url = unescape(stream_url).replace('\\/', '/')
        if stream_url:
            candidates.append((_quality_value(label, stream_url), stream_url))
    hls_url = _first_match(html, [r'html5player\.setVideoHLS\(["\']([^"\']+)["\']'])
    if hls_url:
        candidates.append((9999, unescape(hls_url).replace('\\/', '/')))
    if not candidates:
        return ''
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def showHosters():
    params = ParameterHandler()
    source_url = params.getValue('entryUrl') or params.getValue('sUrl')
    html = _request(source_url, cache_hours=0, referer=source_url or REFERER)
    embed_url = _embed_url_from_page(html)
    if embed_url:
        stream_url = _stream_url_from_pornhub_embed(embed_url, source_url)
        if not stream_url:
            stream_url = _stream_url_from_xvideos_embed(embed_url, source_url)
        if stream_url:
            return [{'streamUrl': stream_url + _stream_headers(_abs_url(embed_url, source_url)), 'resolved': True, 'title': SITE_NAME}]
        logger.info('-> [Fuqqt]: no direct playable stream found for %s' % source_url)
        return []
    logger.info('-> [Fuqqt]: no playable embed found for %s' % source_url)
    return []


def getHosterUrl(sUrl=False):
    html = _request(sUrl, cache_hours=0, referer=sUrl or REFERER)
    embed_url = _embed_url_from_page(html)
    if embed_url:
        stream_url = _stream_url_from_pornhub_embed(embed_url, sUrl)
        if not stream_url:
            stream_url = _stream_url_from_xvideos_embed(embed_url, sUrl)
        if stream_url:
            return [{'streamUrl': stream_url + _stream_headers(_abs_url(embed_url, sUrl)), 'resolved': True}]
        return []
    return []
