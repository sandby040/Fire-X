# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import io
import json
import os
import time

try:
    from urllib.parse import quote
except Exception:
    from urllib import quote

import xbmc
import xbmcgui
import xbmcvfs


ADDON_ID = "script.codex.livetv.handshake"
MAX_ATTEMPTS = 4
RETRY_DELAY_SECONDS = 5
ATTEMPT_TIMEOUT_SECONDS = 45


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Codex LiveTV Handshake] %s" % message, level)
    except Exception:
        pass


def _profile_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        try:
            xbmcvfs.mkdirs(path)
        except Exception:
            pass
    return path


def _read_status(path):
    try:
        if not os.path.exists(path):
            return None
        with io.open(path, "r", encoding="utf-8") as fh:
            return json.loads(fh.read() or "{}")
    except Exception as exc:
        _log("status read failed: %s" % exc, xbmc.LOGWARNING)
        return {"ok": False, "error": "status read failed: %s" % exc}


def _wait_countdown(progress, percent, label):
    for remaining in range(RETRY_DELAY_SECONDS, 0, -1):
        if progress and progress.iscanceled():
            return False
        if progress:
            progress.update(percent, "%s fehlgeschlagen. Neuer Versuch in %d Sekunden..." % (label, remaining))
        xbmc.sleep(1000)
    return True


def _run_handshake_group(progress, label, base_percent, plugin_url_base, display_label=None, start_message=None):
    display_label = display_label or label
    start_message = start_message or ("%s Handshake wird ausgefuehrt" % display_label)
    status_dir = _profile_dir()
    last_status = None
    span = 48
    _log("%s start max_attempts=%d retry_delay=%ds" % (display_label, MAX_ATTEMPTS, RETRY_DELAY_SECONDS))

    for attempt in range(1, MAX_ATTEMPTS + 1):
        if progress and progress.iscanceled():
            _log("%s cancelled before attempt %d" % (display_label, attempt), xbmc.LOGWARNING)
            return False

        status_path = os.path.join(status_dir, "%s_attempt_%d_%d.json" % (
            label.lower().replace(" ", "_"),
            attempt,
            int(time.time() * 1000),
        ))
        try:
            if os.path.exists(status_path):
                os.remove(status_path)
        except Exception:
            pass

        percent = base_percent + int((attempt - 1) * (span / float(MAX_ATTEMPTS)))
        if progress:
            progress.update(percent, "%s\nVersuch %d von %d..." % (start_message, attempt, MAX_ATTEMPTS))

        url = "%s&quiet=1&codex_status_file=%s" % (plugin_url_base, quote(status_path, safe=""))
        _log("%s attempt=%d runplugin" % (display_label, attempt))
        try:
            xbmc.executebuiltin("RunPlugin(%s)" % url)
        except Exception as exc:
            last_status = {"ok": False, "error": "RunPlugin failed: %s" % exc}
            _log("%s attempt=%d runplugin failed: %s" % (display_label, attempt, exc), xbmc.LOGWARNING)
        else:
            started = time.time()
            while time.time() - started < ATTEMPT_TIMEOUT_SECONDS:
                if progress and progress.iscanceled():
                    _log("%s cancelled during attempt %d" % (label, attempt), xbmc.LOGWARNING)
                    return False
                last_status = _read_status(status_path)
                if last_status is not None:
                    break
                elapsed = int(time.time() - started)
                wait_percent = min(base_percent + span - 1, percent + max(1, int(elapsed / 3)))
                if progress:
                    progress.update(wait_percent, "%s\nAntwort wird abgewartet..." % start_message)
                xbmc.sleep(500)

        if last_status and last_status.get("ok"):
            if progress:
                progress.update(base_percent + span, "%s erfolgreich" % display_label)
            _log("%s ok attempt=%d mac=%s" % (display_label, attempt, last_status.get("mac", "<none>")))
            xbmc.sleep(350)
            return True

        error = ""
        try:
            error = str((last_status or {}).get("error") or "keine Antwort")
        except Exception:
            error = "keine Antwort"
        _log("%s failed attempt=%d error=%s" % (display_label, attempt, error), xbmc.LOGWARNING)
        if attempt < MAX_ATTEMPTS:
            if not _wait_countdown(progress, base_percent + span - 2, label):
                return False

    if progress:
        progress.update(base_percent + span, "%s nach %d Versuchen fehlgeschlagen" % (display_label, MAX_ATTEMPTS))
    return False


def main():
    progress = xbmcgui.DialogProgress()
    progress.create("Handshake", "Vorbereitung...")
    ok3 = False
    ok2 = False
    try:
        ok2 = _run_handshake_group(
            progress,
            "Live TV 2",
            0,
            "plugin://plugin.video.stalker.macsimum.talker3/?action=codex_talker3_handshake&force_new=1",
            display_label="Live TV 2 Handshake",
            start_message="Live TV 2 Handshake wird ausgefuehrt",
        )
        if progress and not progress.iscanceled():
            progress.update(50, "Live TV 3 / Stalker Portal wird vorbereitet...")
            xbmc.sleep(400)
        ok3 = _run_handshake_group(
            progress,
            "Live TV 3",
            50,
            "plugin://plugin.video.stalker.macsimum/?action=codex_macsimum_handshake&scope=live&verify_live=1",
            display_label="Live TV 3 / Stalker Portal Handshake",
            start_message="Live TV 3 / Stalker Portal Handshake wird ausgefuehrt",
        )
        if progress and not progress.iscanceled():
            if ok3 and ok2:
                progress.update(100, "Live TV 2 & Live TV 3 / Stalker Portal erfolgreich")
                xbmc.sleep(800)
                xbmcgui.Dialog().notification("Handshake", "Live TV 2 & Live TV 3 / Stalker Portal erfolgreich", time=2500)
            elif ok3 or ok2:
                if ok2:
                    message = "Live TV 2 erfolgreich, Live TV 3 / Stalker Portal fehlgeschlagen"
                else:
                    message = "Live TV 3 / Stalker Portal erfolgreich, Live TV 2 fehlgeschlagen"
                progress.update(100, message)
                xbmc.sleep(1000)
                xbmcgui.Dialog().notification("Handshake", message, xbmcgui.NOTIFICATION_WARNING, 3500)
            else:
                progress.update(100, "Live TV 2 & Live TV 3 / Stalker Portal fehlgeschlagen")
                xbmc.sleep(1000)
                xbmcgui.Dialog().notification("Handshake", "Live TV 2 & Live TV 3 / Stalker Portal fehlgeschlagen", xbmcgui.NOTIFICATION_ERROR, 4000)
    finally:
        try:
            progress.close()
        except Exception:
            pass
    _log("finished live_tv3=%s live_tv2=%s" % (ok3, ok2))


if __name__ == "__main__":
    main()
