# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import io
import json
import os
import sys
import threading
import time

try:
    from urllib.parse import quote
except Exception:
    from urllib import quote

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR and SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from probe import resolve_portal_urls, probe_stalker_domain


def _resolve_addon_path():
    try:
        path = xbmcvfs.translatePath(
            xbmcaddon.Addon("script.codex.livetv.handshake").getAddonInfo("path")
        )
        if path and os.path.exists(path):
            return path
    except Exception:
        pass
    try:
        path = xbmcvfs.translatePath("special://home/addons/script.codex.livetv.handshake")
        if path and os.path.exists(path):
            return path
    except Exception:
        pass
    return SCRIPT_DIR


ADDON_ID = "script.codex.livetv.handshake"
ADDON_PATH = _resolve_addon_path()

MAX_ATTEMPTS = 10
RETRY_DELAY_SECONDS = 5
RETRY_DELAY_LIVETV3_SECONDS = 12
ATTEMPT_TIMEOUT_SECONDS = 40

BTN_ACTION = 101  # Left button (Abbrechen / Neu starten)
BTN_OK = 102      # Right button (Schließen / OK)
CLOSE_ACTIONS = {9, 10, 13, 92, 110}  # Back, PreviousMenu, Stop, NavBack, Backspace


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Codex LiveTV Handshake] %s" % message, level)
    except Exception:
        pass


def _profile_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        try:
            xbmcvfs.mkdirs(path)
        except Exception:
            pass
    return path


def _read_status(path):
    try:
        if not os.path.exists(path):
            return None
        with io.open(path, "r", encoding="utf-8") as fh:
            raw = fh.read()
        if not raw or not raw.strip():
            return None
        return json.loads(raw)
    except Exception as exc:
        _log("status read failed: %s" % exc, xbmc.LOGWARNING)
        return None


def _format_mac(mac):
    if not mac or mac == "<none>":
        return ""
    parts = mac.split(":")
    if len(parts) == 6 and not any("*" in p for p in parts):
        return "%s:%s:%s:***" % (parts[0], parts[1], parts[2])
    return mac


class HandshakeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, xml_file, addon_path, default_skin, default_res, mode="all", caller="", scope="live"):
        super(HandshakeDialog, self).__init__(xml_file, addon_path, default_skin, default_res)
        self.mode = mode
        self.caller = caller
        self.scope = scope
        self._lock = threading.Lock()
        self._running = False
        self._closed = False
        self._run_id = 0
        self._current_status_path = ""
        self._portal_urls = {}

    def onInit(self):
        try:
            self._portal_urls = resolve_portal_urls()
        except Exception:
            self._portal_urls = {
                2: "http://nom-koenig.org:8080/c/",
                3: "http://focus.viptveu.com:8080/c/",
            }

        if self.mode == "livetv2":
            if self.caller in ("stalker2", "talker3"):
                title = "STALKER PORTAL 2 HANDSHAKE"
                card_t = "[B]Stalker Portal 2[/B]"
                card_logo = "stalker2.png"
                label = "Stalker Portal 2"
            else:
                title = "LIVE TV 2 HANDSHAKE"
                card_t = "[B]Live TV 2[/B]"
                card_logo = "tv2.png"
                label = "Live TV 2"

            self.setProperty("HeaderTitle", title)
            self.setProperty("SubtitleText", "Prüfe %s Server-Erreichbarkeit vorab..." % label)
            self.setProperty("CardLogo", card_logo)
            self.setProperty("CardTitle", card_t)
            self.setProperty("CardStatus", "checking")
            self.setProperty("CardStep", "[COLOR #FBBF24]Vorab-Serverprüfung...[/COLOR]")
            self.setProperty("CardDetail", "")
            self.setProperty("SummaryText", "Server wird vorab geprüft...")
        elif self.mode == "livetv3":
            if self.caller == "stalker":
                title = "STALKER PORTAL 1 HANDSHAKE"
                card_t = "[B]Stalker Portal 1[/B]"
                card_logo = "stalker.png"
                label = "Stalker Portal 1"
            else:
                title = "LIVE TV 3 HANDSHAKE"
                card_t = "[B]Live TV 3[/B]"
                card_logo = "tv3.png"
                label = "Live TV 3"

            self.setProperty("HeaderTitle", title)
            self.setProperty("SubtitleText", "Prüfe %s Server-Erreichbarkeit vorab..." % label)
            self.setProperty("CardLogo", card_logo)
            self.setProperty("CardTitle", card_t)
            self.setProperty("CardStatus", "checking")
            self.setProperty("CardStep", "[COLOR #FBBF24]Vorab-Serverprüfung...[/COLOR]")
            self.setProperty("CardDetail", "")
            self.setProperty("SummaryText", "Server wird vorab geprüft...")
        else:
            self.setProperty("SubtitleText", "Prüfe Server-Erreichbarkeit vorab...")
            self.setProperty("Status2", "checking")
            self.setProperty("Step2", "[COLOR #FBBF24]Vorab-Serverprüfung...[/COLOR]")
            self.setProperty("Detail2", "")
            self.setProperty("Status3", "checking")
            self.setProperty("Step3", "[COLOR #FBBF24]Vorab-Serverprüfung...[/COLOR]")
            self.setProperty("Detail3", "")
            self.setProperty("SummaryText", "Server werden vorab geprüft...")

        self.setProperty("Button101Label", "[B]Abbrechen[/B]")
        self.setProperty("Button102Label", "[B]Schließen[/B]")

        self._start_handshake()

    def _start_handshake(self):
        with self._lock:
            if self._running or self._closed:
                return
            self._running = True
            self._run_id += 1
            run_id = self._run_id

        self.setProperty("Button101Label", "[B]Abbrechen[/B]")
        self.setProperty("Button102Label", "[B]Schließen[/B]")
        try:
            self.setFocusId(BTN_OK)
        except Exception:
            pass

        worker = threading.Thread(
            target=self._worker,
            args=(run_id,),
            name="HandshakeWorker-%d" % run_id,
            daemon=True,
        )
        worker.start()

    def _worker(self, run_id):
        _log("Worker started (mode=%s, run_id=%d)" % (self.mode, run_id))
        url2 = self._portal_urls.get(2, "http://nom-koenig.org:8080/c/")
        url3 = self._portal_urls.get(3, "http://focus.viptveu.com:8080/c/")
        status_dir = _profile_dir()

        if self.mode == "livetv2":
            self._worker_livetv2(run_id, url2, status_dir)
        elif self.mode == "livetv3":
            self._worker_livetv3(run_id, url3, status_dir)
        else:
            self._worker_all(run_id, url2, url3, status_dir)

    def _worker_livetv2(self, run_id, url2, status_dir):
        if not self._check_active(run_id):
            return

        portal_label = "Stalker Portal 2" if self.caller in ("stalker2", "talker3") else "Live TV 2"

        self.setProperty("SubtitleText", "Prüfe %s Server-Erreichbarkeit..." % portal_label)
        self.setProperty("CardStatus", "checking")
        self.setProperty("CardStep", "[COLOR #FBBF24]Vorab-Serverprüfung läuft...[/COLOR]")
        self.setProperty("CardDetail", "")
        self.setProperty("SummaryText", "Server wird vorab geprüft...")

        probe2 = probe_stalker_domain(url2, timeout=3.5)
        _log("Vorab-Prüfung %s: %s" % (portal_label, probe2))

        if not self._check_active(run_id):
            return

        online2 = bool(probe2.get("online"))
        if not online2:
            self.setProperty("CardStatus", "offline")
            self.setProperty("CardStep", "[COLOR #EF4444][B]Server zurzeit offline[/B][/COLOR]")
            self.setProperty("CardDetail", "")
            self.setProperty("SummaryText", "[COLOR #EF4444][B]%s Server zurzeit offline.[/B] Drücke OK zum Schließen.[/COLOR]" % portal_label)
            self.setProperty("Button101Label", "[B]Neu starten[/B]")
            self.setProperty("Button102Label", "[B]OK[/B]")
            with self._lock:
                self._running = False
            try:
                self.setFocusId(BTN_OK)
            except Exception:
                pass
            xbmcgui.Dialog().notification("Handshake", "%s Server offline" % portal_label, xbmcgui.NOTIFICATION_WARNING, 3500)
            return

        self.setProperty("CardStatus", "checking")
        self.setProperty("CardStep", "[COLOR #38BDF8]Server erreichbar[/COLOR] • Bereit für Handshake...")
        time.sleep(0.4)

        self.setProperty("SubtitleText", "Führe Handshake für %s durch..." % portal_label)
        plugin_base2 = "plugin://plugin.video.stalker.macsimum.talker3/?action=codex_talker3_handshake&force_new=1"

        ok2 = False
        for attempt in range(1, MAX_ATTEMPTS + 1):
            if not self._check_active(run_id):
                return

            self.setProperty("CardStatus", "checking")
            self.setProperty("CardStep", "[COLOR #FBBF24]Handshake läuft... Versuch %d/%d[/COLOR]" % (attempt, MAX_ATTEMPTS))
            self.setProperty("CardDetail", "Sende Autorisierung an Portal...")
            self.setProperty("SummaryText", "%s Handshake: Versuch %d von %d..." % (portal_label, attempt, MAX_ATTEMPTS))

            status_path = os.path.join(status_dir, "livetv2_attempt_%d_%d.json" % (attempt, int(time.time() * 1000)))
            with self._lock:
                self._current_status_path = status_path
            try:
                if os.path.exists(status_path):
                    os.remove(status_path)
            except Exception:
                pass

            url = "%s&quiet=1&codex_status_file=%s" % (plugin_base2, quote(status_path, safe=""))
            _log("%s attempt=%d RunPlugin" % (portal_label, attempt))
            try:
                xbmc.executebuiltin("RunPlugin(%s)" % url)
            except Exception as exc:
                _log("%s RunPlugin failed: %s" % (portal_label, exc), xbmc.LOGWARNING)

            started = time.time()
            last_status = None
            while time.time() - started < ATTEMPT_TIMEOUT_SECONDS:
                if not self._check_active(run_id):
                    xbmcgui.Window(10000).setProperty("Nova.Handshake.Cancel." + status_path, "1")
                    return
                last_status = _read_status(status_path)
                if last_status is not None:
                    break
                time.sleep(0.3)

            if last_status and last_status.get("ok"):
                ok2 = True
                mac = _format_mac(last_status.get("mac") or "")
                self.setProperty("CardStatus", "online")
                self.setProperty("CardStep", "[COLOR #4ADE80][B]Erfolgreich autorisiert[/B][/COLOR]")
                self.setProperty("CardDetail", ("MAC: %s" % mac) if mac else "")
                _log("%s Handshake SUCCESS with MAC %s" % (portal_label, mac))
                if self.caller not in ("stalker2", "talker3"):
                    try:
                        xbmc.executebuiltin("StartPVRManager")
                    except Exception:
                        pass
                time.sleep(0.4)
                break

            if last_status and last_status.get("server_wait"):
                err_txt = str(last_status.get("error") or "")
                is_ip_ban = bool(last_status.get("ip_blocked") or "403" in err_txt)
                self.setProperty("CardStatus", "offline")
                fail_title = "IP-Sperre aktiv" if is_ip_ban else "Zugriff blockiert"
                self.setProperty("CardStep", "[COLOR #EF4444][B]%s[/B][/COLOR]" % fail_title)
                self.setProperty("CardDetail", "Server blockiert IP (Router neu starten)")
                ok2 = False
                break

            if attempt < MAX_ATTEMPTS:
                for s in range(RETRY_DELAY_SECONDS, 0, -1):
                    if not self._check_active(run_id):
                        return
                    self.setProperty("CardDetail", "Versuch %d fehlgeschlagen • Nächster Versuch in %ds..." % (attempt, s))
                    time.sleep(1.0)
            else:
                self.setProperty("CardStatus", "offline")
                self.setProperty("CardStep", "[COLOR #EF4444][B]Handshake fehlgeschlagen[/B][/COLOR]")
                self.setProperty("CardDetail", "Keine gültige MAC nach %d Versuchen gefunden" % MAX_ATTEMPTS)
                ok2 = False

        if not self._check_active(run_id):
            return

        with self._lock:
            self._running = False

        self.setProperty("SubtitleText", "Handshake-Vorgang abgeschlossen")
        if ok2:
            self.setProperty("SummaryText", "[COLOR #4ADE80][B]%s erfolgreich autorisiert.[/B] Drücke OK zum Beenden.[/COLOR]" % portal_label)
            xbmcgui.Dialog().notification("Handshake", "%s erfolgreich" % portal_label, time=3500)
        else:
            self.setProperty("SummaryText", "[COLOR #EF4444][B]%s Handshake fehlgeschlagen.[/B] Drücke OK zum Schließen.[/COLOR]" % portal_label)
            xbmcgui.Dialog().notification("Handshake", "%s fehlgeschlagen" % portal_label, xbmcgui.NOTIFICATION_ERROR, 4000)

        self.setProperty("Button101Label", "[B]Neu starten[/B]")
        self.setProperty("Button102Label", "[B]OK[/B]")
        try:
            self.setFocusId(BTN_OK)
        except Exception:
            pass

    def _worker_livetv3(self, run_id, url3, status_dir):
        if not self._check_active(run_id):
            return

        portal_label = "Stalker Portal 1" if self.caller == "stalker" else "Live TV 3"
        self.setProperty("SubtitleText", "Prüfe %s Server-Erreichbarkeit..." % portal_label)
        self.setProperty("CardStatus", "checking")
        self.setProperty("CardStep", "[COLOR #FBBF24]Vorab-Serverprüfung läuft...[/COLOR]")
        self.setProperty("CardDetail", "")
        self.setProperty("SummaryText", "Server wird vorab geprüft...")

        probe3 = probe_stalker_domain(url3, timeout=3.5)
        _log("Vorab-Prüfung %s: %s" % (portal_label, probe3))

        if not self._check_active(run_id):
            return

        online3 = bool(probe3.get("online"))
        if not online3:
            self.setProperty("CardStatus", "offline")
            self.setProperty("CardStep", "[COLOR #EF4444][B]Server zurzeit offline[/B][/COLOR]")
            err_code = str(probe3.get("reason") or "")
            detail = "Zugriff blockiert (HTTP 403)" if "403" in err_code else ""
            self.setProperty("CardDetail", detail)
            self.setProperty("SummaryText", "[COLOR #EF4444][B]%s Server zurzeit offline.[/B] Drücke OK zum Schließen.[/COLOR]" % portal_label)
            self.setProperty("Button101Label", "[B]Neu starten[/B]")
            self.setProperty("Button102Label", "[B]OK[/B]")
            with self._lock:
                self._running = False
            try:
                self.setFocusId(BTN_OK)
            except Exception:
                pass
            xbmcgui.Dialog().notification("Handshake", "%s Server offline" % portal_label, xbmcgui.NOTIFICATION_WARNING, 3500)
            return

        self.setProperty("CardStatus", "checking")
        self.setProperty("CardStep", "[COLOR #38BDF8]Server erreichbar[/COLOR] • Bereit für Handshake...")
        time.sleep(0.4)

        self.setProperty("SubtitleText", "Führe Handshake für %s durch..." % portal_label)
        scope_val = self.scope or "live"
        plugin_base3 = "plugin://plugin.video.stalker.macsimum/?action=codex_macsimum_handshake&scope=%s&verify_live=1" % scope_val

        ok3 = False
        for attempt in range(1, MAX_ATTEMPTS + 1):
            if not self._check_active(run_id):
                return

            self.setProperty("CardStatus", "checking")
            self.setProperty("CardStep", "[COLOR #FBBF24]Handshake läuft... Versuch %d/%d[/COLOR]" % (attempt, MAX_ATTEMPTS))
            self.setProperty("CardDetail", "Sende Autorisierung an Portal...")
            self.setProperty("SummaryText", "%s Handshake: Versuch %d von %d..." % (portal_label, attempt, MAX_ATTEMPTS))

            status_path = os.path.join(status_dir, "livetv3_attempt_%d_%d.json" % (attempt, int(time.time() * 1000)))
            with self._lock:
                self._current_status_path = status_path
            try:
                if os.path.exists(status_path):
                    os.remove(status_path)
            except Exception:
                pass

            url = "%s&quiet=1&codex_status_file=%s" % (plugin_base3, quote(status_path, safe=""))
            _log("Live TV 3 attempt=%d RunPlugin" % attempt)
            try:
                xbmc.executebuiltin("RunPlugin(%s)" % url)
            except Exception as exc:
                _log("Live TV 3 RunPlugin failed: %s" % exc, xbmc.LOGWARNING)

            started = time.time()
            last_status = None
            while time.time() - started < ATTEMPT_TIMEOUT_SECONDS:
                if not self._check_active(run_id):
                    xbmcgui.Window(10000).setProperty("Nova.Handshake.Cancel." + status_path, "1")
                    return
                last_status = _read_status(status_path)
                if last_status is not None:
                    break
                time.sleep(0.3)

            if last_status and last_status.get("ok"):
                ok3 = True
                mac = _format_mac(last_status.get("mac") or "")
                self.setProperty("CardStatus", "online")
                self.setProperty("CardStep", "[COLOR #4ADE80][B]Erfolgreich autorisiert[/B][/COLOR]")
                self.setProperty("CardDetail", ("MAC: %s" % mac) if mac else "")
                _log("Live TV 3 Handshake SUCCESS with MAC %s" % mac)
                time.sleep(0.4)
                break

            if last_status and last_status.get("server_wait"):
                err_txt = str(last_status.get("error") or "")
                is_ip_ban = bool(last_status.get("ip_blocked") or "403" in err_txt)
                self.setProperty("CardStatus", "offline")
                fail_title = "IP-Sperre aktiv" if is_ip_ban else "Zugriff blockiert"
                self.setProperty("CardStep", "[COLOR #EF4444][B]%s[/B][/COLOR]" % fail_title)
                self.setProperty("CardDetail", "Server blockiert IP (Router neu starten)")
                ok3 = False
                break

            if attempt < MAX_ATTEMPTS:
                for s in range(RETRY_DELAY_LIVETV3_SECONDS, 0, -1):
                    if not self._check_active(run_id):
                        return
                    self.setProperty("CardDetail", "Versuch %d fehlgeschlagen • Nächster Versuch in %ds..." % (attempt, s))
                    time.sleep(1.0)
            else:
                self.setProperty("CardStatus", "offline")
                self.setProperty("CardStep", "[COLOR #EF4444][B]Handshake fehlgeschlagen[/B][/COLOR]")
                self.setProperty("CardDetail", "Keine gültige MAC nach %d Versuchen gefunden" % MAX_ATTEMPTS)
                ok3 = False

        if not self._check_active(run_id):
            return

        with self._lock:
            self._running = False

        self.setProperty("SubtitleText", "Handshake-Vorgang abgeschlossen")
        if ok3:
            self.setProperty("SummaryText", "[COLOR #4ADE80][B]%s erfolgreich autorisiert.[/B] Drücke OK zum Beenden.[/COLOR]" % portal_label)
            xbmcgui.Dialog().notification("Handshake", "%s erfolgreich" % portal_label, time=3500)
        else:
            self.setProperty("SummaryText", "[COLOR #EF4444][B]%s Handshake fehlgeschlagen.[/B] Drücke OK zum Schließen.[/COLOR]" % portal_label)
            xbmcgui.Dialog().notification("Handshake", "%s fehlgeschlagen" % portal_label, xbmcgui.NOTIFICATION_ERROR, 4000)

        self.setProperty("Button101Label", "[B]Neu starten[/B]")
        self.setProperty("Button102Label", "[B]OK[/B]")
        try:
            self.setFocusId(BTN_OK)
        except Exception:
            pass

    def _worker_all(self, run_id, url2, url3, status_dir):
        if not self._check_active(run_id):
            return

        self.setProperty("SubtitleText", "Prüfe Server-Erreichbarkeit vorab...")
        self.setProperty("Status2", "checking")
        self.setProperty("Step2", "[COLOR #FBBF24]Vorab-Serverprüfung läuft...[/COLOR]")
        self.setProperty("Detail2", "")

        self.setProperty("Status3", "checking")
        self.setProperty("Step3", "[COLOR #FBBF24]Vorab-Serverprüfung läuft...[/COLOR]")
        self.setProperty("Detail3", "")

        self.setProperty("SummaryText", "Server werden vorab geprüft...")

        probe2 = probe_stalker_domain(url2, timeout=3.5)
        probe3 = probe_stalker_domain(url3, timeout=3.5)
        _log("Vorab-Prüfung Kombi: LTV2=%s, LTV3=%s" % (probe2, probe3))

        if not self._check_active(run_id):
            return

        online2 = bool(probe2.get("online"))
        online3 = bool(probe3.get("online"))

        if not online3:
            self.setProperty("Status3", "offline")
            self.setProperty("Step3", "[COLOR #EF4444][B]Server zurzeit offline[/B][/COLOR]")
            self.setProperty("Detail3", "")
        else:
            self.setProperty("Status3", "checking")
            self.setProperty("Step3", "[COLOR #38BDF8]Server erreichbar[/COLOR]")
            self.setProperty("Detail3", "")

        if not online2:
            self.setProperty("Status2", "offline")
            self.setProperty("Step2", "[COLOR #EF4444][B]Server zurzeit offline[/B][/COLOR]")
            self.setProperty("Detail2", "")
        else:
            self.setProperty("Status2", "checking")
            self.setProperty("Step2", "[COLOR #38BDF8]Server erreichbar[/COLOR] • Bereit für Handshake...")
            self.setProperty("Detail2", "")

        time.sleep(0.5)

        ok2 = False
        if online2:
            self.setProperty("SubtitleText", "Führe Handshake für Live TV 2 durch...")
            plugin_base2 = "plugin://plugin.video.stalker.macsimum.talker3/?action=codex_talker3_handshake&force_new=1"

            for attempt in range(1, MAX_ATTEMPTS + 1):
                if not self._check_active(run_id):
                    return

                self.setProperty("Status2", "checking")
                self.setProperty("Step2", "[COLOR #FBBF24]Handshake läuft... Versuch %d/%d[/COLOR]" % (attempt, MAX_ATTEMPTS))
                self.setProperty("Detail2", "Sende Autorisierung an Portal...")
                self.setProperty("SummaryText", "Live TV 2 Handshake: Versuch %d von %d..." % (attempt, MAX_ATTEMPTS))

                status_path = os.path.join(status_dir, "livetv2_attempt_%d_%d.json" % (attempt, int(time.time() * 1000)))
                with self._lock:
                    self._current_status_path = status_path
                try:
                    if os.path.exists(status_path):
                        os.remove(status_path)
                except Exception:
                    pass

                url = "%s&quiet=1&codex_status_file=%s" % (plugin_base2, quote(status_path, safe=""))
                _log("Live TV 2 attempt=%d RunPlugin" % attempt)
                try:
                    xbmc.executebuiltin("RunPlugin(%s)" % url)
                except Exception as exc:
                    _log("Live TV 2 RunPlugin failed: %s" % exc, xbmc.LOGWARNING)

                started = time.time()
                last_status = None
                while time.time() - started < ATTEMPT_TIMEOUT_SECONDS:
                    if not self._check_active(run_id):
                        xbmcgui.Window(10000).setProperty("Nova.Handshake.Cancel." + status_path, "1")
                        return
                    last_status = _read_status(status_path)
                    if last_status is not None:
                        break
                    time.sleep(0.3)

                if last_status and last_status.get("ok"):
                    ok2 = True
                    mac = _format_mac(last_status.get("mac") or "")
                    self.setProperty("Status2", "online")
                    self.setProperty("Step2", "[COLOR #4ADE80][B]Erfolgreich autorisiert[/B][/COLOR]")
                    self.setProperty("Detail2", ("MAC: %s" % mac) if mac else "")
                    _log("Live TV 2 Handshake SUCCESS with MAC %s" % mac)
                    try:
                        xbmc.executebuiltin("StartPVRManager")
                    except Exception:
                        pass
                    time.sleep(0.4)
                    break

                if last_status and last_status.get("server_wait"):
                    err_txt = str(last_status.get("error") or "")
                    is_ip_ban = bool(last_status.get("ip_blocked") or "403" in err_txt)
                    self.setProperty("Status2", "offline")
                    fail_title = "IP-Sperre aktiv" if is_ip_ban else "Zugriff blockiert"
                    self.setProperty("Step2", "[COLOR #EF4444][B]%s[/B][/COLOR]" % fail_title)
                    self.setProperty("Detail2", "Server blockiert IP (Router neu starten)")
                    ok2 = False
                    break

                if attempt < MAX_ATTEMPTS:
                    for s in range(RETRY_DELAY_SECONDS, 0, -1):
                        if not self._check_active(run_id):
                            return
                        self.setProperty("Detail2", "Versuch %d fehlgeschlagen • Nächster Versuch in %ds..." % (attempt, s))
                        time.sleep(1.0)
                else:
                    self.setProperty("Status2", "offline")
                    self.setProperty("Step2", "[COLOR #EF4444][B]Handshake fehlgeschlagen[/B][/COLOR]")
                    self.setProperty("Detail2", "Keine gültige MAC nach %d Versuchen gefunden" % MAX_ATTEMPTS)
                    ok2 = False

        ok3 = False
        if online3:
            self.setProperty("SubtitleText", "Führe Handshake für Live TV 3 durch...")
            plugin_base3 = "plugin://plugin.video.stalker.macsimum/?action=codex_macsimum_handshake&scope=live&verify_live=1"

            for attempt in range(1, MAX_ATTEMPTS + 1):
                if not self._check_active(run_id):
                    return

                self.setProperty("Status3", "checking")
                self.setProperty("Step3", "[COLOR #FBBF24]Handshake läuft... Versuch %d/%d[/COLOR]" % (attempt, MAX_ATTEMPTS))
                self.setProperty("Detail3", "Sende Autorisierung an Portal...")
                self.setProperty("SummaryText", "Live TV 3 Handshake: Versuch %d von %d..." % (attempt, MAX_ATTEMPTS))

                status_path = os.path.join(status_dir, "livetv3_attempt_%d_%d.json" % (attempt, int(time.time() * 1000)))
                with self._lock:
                    self._current_status_path = status_path
                try:
                    if os.path.exists(status_path):
                        os.remove(status_path)
                except Exception:
                    pass

                url = "%s&quiet=1&codex_status_file=%s" % (plugin_base3, quote(status_path, safe=""))
                _log("Live TV 3 attempt=%d RunPlugin" % attempt)
                try:
                    xbmc.executebuiltin("RunPlugin(%s)" % url)
                except Exception as exc:
                    _log("Live TV 3 RunPlugin failed: %s" % exc, xbmc.LOGWARNING)

                started = time.time()
                last_status = None
                while time.time() - started < ATTEMPT_TIMEOUT_SECONDS:
                    if not self._check_active(run_id):
                        xbmcgui.Window(10000).setProperty("Nova.Handshake.Cancel." + status_path, "1")
                        return
                    last_status = _read_status(status_path)
                    if last_status is not None:
                        break
                    time.sleep(0.3)

                if last_status and last_status.get("ok"):
                    ok3 = True
                    mac = _format_mac(last_status.get("mac") or "")
                    self.setProperty("Status3", "online")
                    self.setProperty("Step3", "[COLOR #4ADE80][B]Erfolgreich autorisiert[/B][/COLOR]")
                    self.setProperty("Detail3", ("MAC: %s" % mac) if mac else "")
                    _log("Live TV 3 Handshake SUCCESS with MAC %s" % mac)
                    time.sleep(0.4)
                    break

                if last_status and last_status.get("server_wait"):
                    err_txt = str(last_status.get("error") or "")
                    is_ip_ban = bool(last_status.get("ip_blocked") or "403" in err_txt)
                    self.setProperty("Status3", "offline")
                    fail_title = "IP-Sperre aktiv" if is_ip_ban else "Zugriff blockiert"
                    self.setProperty("Step3", "[COLOR #EF4444][B]%s[/B][/COLOR]" % fail_title)
                    self.setProperty("Detail3", "Server blockiert IP (Router neu starten)")
                    ok3 = False
                    break

                if attempt < MAX_ATTEMPTS:
                    for s in range(RETRY_DELAY_LIVETV3_SECONDS, 0, -1):
                        if not self._check_active(run_id):
                            return
                        self.setProperty("Detail3", "Versuch %d fehlgeschlagen • Nächster Versuch in %ds..." % (attempt, s))
                        time.sleep(1.0)
                else:
                    self.setProperty("Status3", "offline")
                    self.setProperty("Step3", "[COLOR #EF4444][B]Handshake fehlgeschlagen[/B][/COLOR]")
                    self.setProperty("Detail3", "Keine gültige MAC nach %d Versuchen gefunden" % MAX_ATTEMPTS)
                    ok3 = False
        else:
            self.setProperty("Status3", "offline")
            self.setProperty("Step3", "[COLOR #EF4444][B]Server zurzeit offline[/B][/COLOR]")
            self.setProperty("Detail3", "")

        if not self._check_active(run_id):
            return

        with self._lock:
            self._running = False

        self.setProperty("SubtitleText", "Handshake-Vorgang abgeschlossen")

        if ok2 and ok3:
            summary = "[COLOR #4ADE80][B]Alle Portale erfolgreich autorisiert.[/B] Drücke OK zum Beenden.[/COLOR]"
            xbmcgui.Dialog().notification("Handshake", "Live TV 2 & 3 erfolgreich", time=3500)
        elif ok2 and not ok3:
            summary = "[COLOR #38BDF8][B]Live TV 2 erfolgreich[/B][/COLOR]  •  [COLOR #EF4444][B]Live TV 3 Server zurzeit offline[/B][/COLOR]"
            xbmcgui.Dialog().notification("Handshake", "Live TV 2 erfolgreich, Live TV 3 offline", xbmcgui.NOTIFICATION_WARNING, 4000)
        elif not ok2 and ok3:
            summary = "[COLOR #EF4444][B]Live TV 2 fehlgeschlagen[/B][/COLOR]  •  [COLOR #4ADE80][B]Live TV 3 erfolgreich[/B][/COLOR]"
            xbmcgui.Dialog().notification("Handshake", "Live TV 3 erfolgreich, Live TV 2 Fehler", xbmcgui.NOTIFICATION_WARNING, 4000)
        else:
            summary = "[COLOR #EF4444][B]Handshake nicht erfolgreich abgeschlossen.[/B] Drücke OK zum Schließen.[/COLOR]"
            xbmcgui.Dialog().notification("Handshake", "Handshake fehlgeschlagen", xbmcgui.NOTIFICATION_ERROR, 4000)

        self.setProperty("SummaryText", summary)
        self.setProperty("Button101Label", "[B]Neu starten[/B]")
        self.setProperty("Button102Label", "[B]OK[/B]")

        try:
            self.setFocusId(BTN_OK)
        except Exception:
            pass

    def _check_active(self, run_id):
        with self._lock:
            return not self._closed and run_id == self._run_id

    def onClick(self, control_id):
        if control_id == BTN_ACTION:  # 101: Abbrechen / Neu starten
            with self._lock:
                is_run = self._running
            if is_run:
                self._safe_close()
            else:
                self._start_handshake()
        elif control_id == BTN_OK:  # 102: OK / Schließen
            self._safe_close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = -1
        if action_id in CLOSE_ACTIONS:
            self._safe_close()
            return
        super(HandshakeDialog, self).onAction(action)

    def _safe_close(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._running = False
            cur_path = self._current_status_path

        if cur_path:
            try:
                xbmcgui.Window(10000).setProperty("Nova.Handshake.Cancel." + cur_path, "1")
            except Exception:
                pass

        try:
            self.close()
        except Exception:
            pass



def main():
    try:
        xbmc.executebuiltin("Dialog.Close(shutdownmenu,true)")

        mode = "all"
        caller = ""
        scope = "live"

        for arg in sys.argv[1:]:
            arg_str = str(arg or "").strip().lower()
            if "=" in arg_str:
                k, v = arg_str.split("=", 1)
                k, v = k.strip(), v.strip()
                if k == "mode":
                    mode = v
                elif k == "caller":
                    caller = v
                elif k == "scope":
                    scope = v
            else:
                if arg_str in ("2", "live2", "livetv2", "pvr"):
                    mode = "livetv2"
                elif arg_str in ("stalker2", "talker3"):
                    mode = "livetv2"
                    caller = "stalker2"
                elif arg_str in ("3", "live3", "livetv3", "stalker", "macsimum"):
                    mode = "livetv3"
                    if "stalker" in arg_str:
                        caller = "stalker"
                elif arg_str in ("series", "serien"):
                    scope = "series"
                elif arg_str in ("favorites", "favoriten"):
                    scope = "favorites"

        if not caller:
            try:
                folder = xbmc.getInfoLabel("Container.FolderPath") or ""
                if "plugin.video.stalker.macsimum.talker3" in folder or "talker3" in folder:
                    mode = "livetv2"
                    caller = "stalker2"
                elif mode == "livetv2":
                    caller = "livetv2"
                elif mode == "livetv3":
                    if any(x in folder for x in ("action=series", "action=ser_listing", "action=seasons", "action=episodes")):
                        caller = "stalker"
                        scope = "series"
                    elif "codex_macsimum_favorites" in folder or "action=vod" in folder:
                        caller = "stalker"
                    else:
                        caller = "livetv3"
            except Exception:
                if mode == "livetv2":
                    caller = "livetv2"
                elif mode == "livetv3":
                    caller = "livetv3"

        xml_name = "script-codex-single-handshake.xml" if mode in ("livetv2", "livetv3") else "script-codex-livetv-handshake.xml"
        _log("Launching HandshakeDialog (xml=%s, mode=%s, caller=%s, scope=%s)" % (xml_name, mode, caller, scope))

        dialog = HandshakeDialog(
            xml_name,
            ADDON_PATH,
            "Default",
            "1080i",
            mode=mode,
            caller=caller,
            scope=scope,
        )
        dialog.doModal()
        del dialog
    except Exception as exc:
        _log("Dialog error: %s" % exc, xbmc.LOGERROR)


if __name__ == "__main__":
    main()
