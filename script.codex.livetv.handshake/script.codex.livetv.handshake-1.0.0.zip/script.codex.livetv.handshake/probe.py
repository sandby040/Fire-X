# -*- coding: utf-8 -*-
import os
import re
import socket
import time
from urllib.parse import urlsplit
import urllib.request
import urllib.error

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

DEFAULT_LIVETV2_URL = "http://nom-koenig.org:8080/c/"
DEFAULT_LIVETV3_URL = "http://focus.viptveu.com:8080/c/"

BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


def _read_regex_from_file(file_path, pattern, fallback):
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read(65536)
            match = re.search(pattern, content)
            if match and match.group(1).strip():
                return match.group(1).strip()
        except OSError:
            pass
    return fallback


def resolve_portal_urls():
    if xbmcvfs:
        addons_root = xbmcvfs.translatePath("special://home/addons")
    else:
        addons_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    talker3_file = os.path.join(addons_root, "plugin.video.stalker.macsimum.talker3", "lib", "config.py")
    macsimum_file = os.path.join(addons_root, "plugin.video.stalker.macsimum", "lib", "config.py")

    ltv2_url = _read_regex_from_file(
        talker3_file,
        r"""custom_address\s*=\s*['"]([^'"]+)['"]""",
        DEFAULT_LIVETV2_URL,
    )
    ltv3_url = _read_regex_from_file(
        macsimum_file,
        r"""custom_address\s*=\s*['"]([^'"]+)['"]""",
        DEFAULT_LIVETV3_URL,
    )

    if not ltv2_url.endswith("/"):
        ltv2_url += "/"
    if not ltv3_url.endswith("/"):
        ltv3_url += "/"

    return {
        2: ltv2_url,
        3: ltv3_url,
    }


def get_domain_name(url):
    try:
        parsed = urlsplit(url)
        return parsed.netloc or parsed.hostname or url
    except Exception:
        return url


def probe_stalker_domain(url, timeout=3.5):
    t0 = time.monotonic()
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": BROWSER_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            ms = max(1, int((time.monotonic() - t0) * 1000))
            code = resp.status
            if 200 <= code < 400:
                return {"online": True, "detail": "Server erreichbar (%d ms)" % ms, "ms": ms, "code": code}
            return {"online": False, "detail": "Server-Code %d (%d ms)" % (code, ms), "ms": ms, "code": code}
    except urllib.error.HTTPError as exc:
        ms = max(1, int((time.monotonic() - t0) * 1000))
        code = exc.code
        body = ""
        try:
            body = (exc.read(1024) or b"").decode("utf-8", errors="ignore").lower()
        except Exception:
            pass

        if code == 403:
            if "forbidden by administrative rules" in body:
                return {"online": False, "detail": "IP-Sperre aktiv (HTTP 403)", "is_ip_ban": True, "ms": ms, "code": code}
            if "cloudflare" in body or "attention required" in body:
                return {"online": False, "detail": "Server blockiert (HTTP 403 / Cloudflare)", "is_ip_ban": False, "ms": ms, "code": code}
            return {"online": False, "detail": "Zugriff verweigert (HTTP 403)", "is_ip_ban": False, "ms": ms, "code": code}
        if code >= 500:
            return {"online": False, "detail": "Server offline (HTTP %d)" % code, "ms": ms, "code": code}
        return {"online": False, "detail": "Nicht verfügbar (HTTP %d)" % code, "ms": ms, "code": code}
    except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
        err_msg = str(exc)
        if "timed out" in err_msg.lower():
            return {"online": False, "detail": "Server-Timeout (keine Antwort)", "ms": 0}
        return {"online": False, "detail": "Server nicht erreichbar (Offline)", "ms": 0}
    except Exception as exc:
        return {"online": False, "detail": "Server nicht erreichbar (%s)" % exc, "ms": 0}
