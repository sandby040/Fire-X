import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob, math, time
import shutil
import urllib
import re
import os
import sqlite3
from resources.lib.modules.backtothefuture import PY2

# Code to map the old translatePath
if PY2:
    translatePath = xbmc.translatePath
    loglevel = xbmc.LOGNOTICE
else:
    translatePath = xbmcvfs.translatePath
    loglevel = xbmc.LOGINFO

thumbnailPath = translatePath('special://thumbnails');
cachePath = os.path.join(translatePath('special://home'), 'cache')
tempPath = translatePath('special://temp')
logPath = translatePath('special://logpath')
addonPath = os.path.join(os.path.join(translatePath('special://home'), 'addons'),'script.ezmaintenance')

mediaPath = os.path.join(addonPath, 'media')
databasePath = translatePath('special://database')
THUMBS    =  translatePath(os.path.join('special://home/userdata/Thumbnails',''))

addon_id = 'script.ezmaintenanceplus'
fanart = translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
iconpath = translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))

userdataPath = translatePath('special://userdata')
addonDataPath = os.path.join(userdataPath, 'addon_data')
archivNavigatorDataPath = os.path.join(addonDataPath, 'plugin.video.archiv.navigator')
streamingArchivDataPath = os.path.join(addonDataPath, 'plugin.video.streaming.archiv')
xxxDataPath = os.path.join(addonDataPath, 'plugin.video.xxx')
cuminationDataPath = os.path.join(addonDataPath, 'plugin.video.cumination')
stalkerDataPath = os.path.join(addonDataPath, 'plugin.video.stalker')
kodiboxtvDataPath = os.path.join(addonDataPath, 'plugin.video.kodiboxtv')
tmdbHelperDataPath = os.path.join(addonDataPath, 'plugin.video.themoviedb.helper')
vavootoDataPath = os.path.join(addonDataPath, 'plugin.video.vavooto')
vodkoolDataPath = os.path.join(addonDataPath, 'plugin.video.vodkool')
youtubeDataPath = os.path.join(addonDataPath, 'plugin.video.youtube')
playlistLoaderDataPath = os.path.join(addonDataPath, 'plugin.video.playlistloader')
playForFunDataPath = os.path.join(addonDataPath, 'plugin.video.PlayForFun')
playForFunVodDataPath = os.path.join(addonDataPath, 'plugin.video.PlayForFun.vod')
playForFunRadioDataPath = os.path.join(addonDataPath, 'plugin.audio.playforfun.radio')
kodiFavouritesPath = os.path.join(userdataPath, 'favourites.xml')
videoDatabasePath = os.path.join(databasePath, 'MyVideos131.db')

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi


def _log(message):
    try:
        xbmc.log("ezmaintenanceplus: %s" % message, level=loglevel)
    except:
        pass


def _notify(title, message, milliseconds=3000):
    try:
        xbmcgui.Dialog().notification(title, message, iconpath, milliseconds, sound=False)
    except:
        pass


def _safe_remove_path(path):
    if not path or not os.path.exists(path):
        return False
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.unlink(path)
        return True
    except Exception as exc:
        _log("Could not remove %s: %s" % (path, exc))
        return False


def _ensure_directory(path):
    if not path:
        return
    try:
        if not os.path.exists(path):
            os.makedirs(path)
    except Exception as exc:
        _log("Could not create %s: %s" % (path, exc))


def _clean_named_entries(base_path, directory_names=None, file_names=None, recreate_directories=None):
    removed = []
    if not os.path.exists(base_path):
        return removed

    directory_names = directory_names or []
    file_names = file_names or []
    recreate_directories = recreate_directories or []

    for name in directory_names:
        target = os.path.join(base_path, name)
        if _safe_remove_path(target):
            removed.append(target)

    for name in file_names:
        target = os.path.join(base_path, name)
        if _safe_remove_path(target):
            removed.append(target)

    for name in recreate_directories:
        _ensure_directory(os.path.join(base_path, name))

    return removed


def _clean_file_variants(base_path, file_names=None):
    removed = []
    if not os.path.exists(base_path):
        return removed

    for name in file_names or []:
        for suffix in ['', '-wal', '-shm', '-journal']:
            target = os.path.join(base_path, '%s%s' % (name, suffix))
            if _safe_remove_path(target):
                removed.append(target)

    return removed


def _clear_resume_bookmarks(plugin_id):
    if not os.path.exists(videoDatabasePath):
        _log("MyVideos database not found while cleaning resume data for %s" % plugin_id)
        return 0

    connection = None
    deleted_rows = 0
    plugin_like = '%%%s%%' % plugin_id
    try:
        connection = sqlite3.connect(videoDatabasePath, timeout=10)
        cursor = connection.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='bookmark'")
        if cursor.fetchone() is None:
            return 0

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='files'")
        if cursor.fetchone() is None:
            return 0

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='path'")
        if cursor.fetchone() is None:
            return 0

        cursor.execute(
            """
            DELETE FROM bookmark
            WHERE idFile IN (
                SELECT DISTINCT files.idFile
                FROM files
                LEFT JOIN path ON files.idPath = path.idPath
                WHERE (path.strPath LIKE ? OR files.strFilename LIKE ?)
            )
            """,
            (plugin_like, plugin_like)
        )
        deleted_rows = cursor.rowcount
        connection.commit()
        _log("Resume entries cleared for %s: %s" % (plugin_id, deleted_rows))
    except Exception as exc:
        _log("Could not clear resume entries for %s: %s" % (plugin_id, exc))
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_rows


def _clear_video_playback_state(plugin_id):
    if not os.path.exists(videoDatabasePath):
        _log("MyVideos database not found while clearing playback state for %s" % plugin_id)
        return 0, 0

    connection = None
    deleted_bookmarks = 0
    deleted_files = 0
    plugin_like = '%%%s%%' % plugin_id
    try:
        connection = sqlite3.connect(videoDatabasePath, timeout=10)
        cursor = connection.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='bookmark'")
        has_bookmark = cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='files'")
        has_files = cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='path'")
        has_path = cursor.fetchone() is not None

        if not has_files or not has_path:
            return 0, 0

        file_match_sql = """
            SELECT DISTINCT files.idFile
            FROM files
            LEFT JOIN path ON files.idPath = path.idPath
            WHERE (path.strPath LIKE ? OR files.strFilename LIKE ?)
        """

        if has_bookmark:
            cursor.execute(
                "DELETE FROM bookmark WHERE idFile IN (%s)" % file_match_sql,
                (plugin_like, plugin_like)
            )
            deleted_bookmarks = cursor.rowcount

        cursor.execute(
            "DELETE FROM files WHERE idFile IN (%s)" % file_match_sql,
            (plugin_like, plugin_like)
        )
        deleted_files = cursor.rowcount

        connection.commit()
        _log("Playback state cleared for %s: %s bookmarks, %s files" % (
            plugin_id,
            deleted_bookmarks,
            deleted_files,
        ))
    except Exception as exc:
        _log("Could not clear playback state for %s: %s" % (plugin_id, exc))
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_bookmarks, deleted_files


def _clear_stalker_portal_playback_state():
    if not os.path.exists(videoDatabasePath):
        _log("MyVideos database not found while clearing Stalker Portal playback state")
        return 0, 0

    # Be exact here: plugin.video.stalker.macsimum is a prefix of
    # plugin.video.stalker.macsimum.talker3, so a generic LIKE on the addon id
    # would accidentally mix Portal 1 and Portal 2.
    plugin_roots = (
        'plugin://plugin.video.stalker.macsimum/',
        'plugin://plugin.video.stalker.macsimum.talker3/',
    )

    connection = None
    deleted_bookmarks = 0
    deleted_files = 0
    try:
        connection = sqlite3.connect(videoDatabasePath, timeout=10)
        cursor = connection.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='bookmark'")
        has_bookmark = cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='files'")
        has_files = cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='path'")
        has_path = cursor.fetchone() is not None

        if not has_files or not has_path:
            return 0, 0

        clauses = []
        params = []
        for root in plugin_roots:
            clauses.append("path.strPath LIKE ?")
            params.append(root + '%')
            clauses.append("files.strFilename LIKE ?")
            params.append(root + '%')

        file_match_sql = """
            SELECT DISTINCT files.idFile
            FROM files
            LEFT JOIN path ON files.idPath = path.idPath
            WHERE %s
        """ % " OR ".join(clauses)

        if has_bookmark:
            cursor.execute(
                "DELETE FROM bookmark WHERE idFile IN (%s)" % file_match_sql,
                params
            )
            deleted_bookmarks = cursor.rowcount

        cursor.execute(
            "DELETE FROM files WHERE idFile IN (%s)" % file_match_sql,
            params
        )
        deleted_files = cursor.rowcount

        connection.commit()
        _log("Stalker Portal playback state cleared: %s bookmarks, %s files" % (
            deleted_bookmarks,
            deleted_files,
        ))
    except Exception as exc:
        _log("Could not clear Stalker Portal playback state: %s" % exc)
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_bookmarks, deleted_files


def _clear_cumination_keywords():
    favorites_db = os.path.join(cuminationDataPath, 'favorites.db')
    if not os.path.exists(favorites_db):
        return 0

    connection = None
    deleted_rows = 0
    try:
        connection = sqlite3.connect(favorites_db, timeout=10)
        cursor = connection.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='keywords'")
        if cursor.fetchone() is None:
            return 0
        cursor.execute("DELETE FROM keywords")
        deleted_rows = cursor.rowcount
        connection.commit()
        _log("Cumination keywords cleared: %s" % deleted_rows)
    except Exception as exc:
        _log("Could not clear Cumination keywords: %s" % exc)
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_rows


def _clear_cumination_storage_cache():
    commoncache_db = os.path.join(tempPath, 'commoncache.db')
    if not os.path.exists(commoncache_db):
        return 0

    connection = None
    deleted_rows = 0
    try:
        connection = sqlite3.connect(commoncache_db, timeout=10)
        cursor = connection.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cumination'")
        if cursor.fetchone() is None:
            return 0
        cursor.execute("DELETE FROM cumination WHERE name LIKE ?", ('cache%get%',))
        deleted_rows = cursor.rowcount
        connection.commit()
        _log("Cumination storage cache cleared: %s" % deleted_rows)
    except Exception as exc:
        _log("Could not clear Cumination storage cache: %s" % exc)
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_rows


def _clear_kodi_favourites():
    if not kodiFavouritesPath:
        return False

    try:
        with open(kodiFavouritesPath, 'w') as handle:
            handle.write('<favourites>\n</favourites>\n')
        _log("Kodi favourites cleared")
        return True
    except Exception as exc:
        _log("Could not clear Kodi favourites: %s" % exc)
        return False


def _clear_cumination_favourites():
    favorites_db = os.path.join(cuminationDataPath, 'favorites.db')
    if not os.path.exists(favorites_db):
        return 0

    connection = None
    deleted_rows = 0
    try:
        connection = sqlite3.connect(favorites_db, timeout=10)
        cursor = connection.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='favorites'")
        if cursor.fetchone() is None:
            return 0
        cursor.execute("DELETE FROM favorites")
        deleted_rows = cursor.rowcount
        connection.commit()
        _log("Cumination favourites cleared: %s" % deleted_rows)
    except Exception as exc:
        _log("Could not clear Cumination favourites: %s" % exc)
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

    return deleted_rows


def _clear_stalker_cache():
    if not os.path.exists(stalkerDataPath):
        return 0

    removed = 0
    try:
        for entry in os.listdir(stalkerDataPath):
            target = os.path.join(stalkerDataPath, entry)
            if entry.lower().endswith('.xml'):
                continue
            if _safe_remove_path(target):
                removed += 1
        _log("Stalker cache cleared: %s entries removed" % removed)
    except Exception as exc:
        _log("Could not clear Stalker cache: %s" % exc)

    return removed


def _clear_archiv_navigator_data():
    removed = _clean_named_entries(
        archivNavigatorDataPath,
        file_names=[
            'bookmarks.pcl',
            'playcount.db',
            'watchedsignfile',
            'bookmarks.db'
        ]
    )
    bookmark_rows, playback_rows = _clear_video_playback_state('plugin.video.archiv.navigator')
    old_bookmark_rows, old_playback_rows = _clear_video_playback_state('plugin.video.lastship.reborn')
    bookmark_rows += old_bookmark_rows
    playback_rows += old_playback_rows
    _log("Archiv Navigator cleaned: %s paths removed, %s bookmarks, %s playback files cleared" % (len(removed), bookmark_rows, playback_rows))
    return len(removed), bookmark_rows, playback_rows


def _clear_streaming_archiv_data():
    removed = _clean_named_entries(
        streamingArchivDataPath,
        directory_names=['cookies', 'htmlcache'],
        file_names=['pluginDB'],
        recreate_directories=['cookies', 'htmlcache']
    )
    bookmark_rows, playback_rows = _clear_video_playback_state('plugin.video.streaming.archiv')
    old_bookmark_rows, old_playback_rows = _clear_video_playback_state('plugin.video.xstream')
    bookmark_rows += old_bookmark_rows
    playback_rows += old_playback_rows
    _log("Streaming Archiv cleaned: %s paths removed, %s bookmarks, %s playback files cleared" % (len(removed), bookmark_rows, playback_rows))
    return len(removed), bookmark_rows, playback_rows


def _clear_xxx_data():
    removed = _clean_named_entries(
        xxxDataPath,
        directory_names=['cookies', 'htmlcache'],
        file_names=['pluginDB'],
        recreate_directories=['cookies', 'htmlcache']
    )
    bookmark_rows, playback_rows = _clear_video_playback_state('plugin.video.xxx')
    _log("XXX cleaned: %s paths removed, %s bookmarks, %s playback files cleared" % (len(removed), bookmark_rows, playback_rows))
    return len(removed), bookmark_rows, playback_rows


def _clear_cumination_data():
    removed = _clean_named_entries(
        cuminationDataPath,
        directory_names=['temp'],
        file_names=['cookies.lwp'],
        recreate_directories=['temp']
    )
    favourites_rows = _clear_cumination_favourites()
    keyword_rows = _clear_cumination_keywords()
    cache_rows = _clear_cumination_storage_cache()
    bookmark_rows, playback_rows = _clear_video_playback_state('plugin.video.cumination')
    _log("Cumination cleaned: %s paths removed, %s favourites cleared, %s keywords cleared, %s storage cache rows cleared, %s bookmarks, %s playback files cleared" % (len(removed), favourites_rows, keyword_rows, cache_rows, bookmark_rows, playback_rows))
    return len(removed), favourites_rows, keyword_rows, cache_rows, bookmark_rows, playback_rows


def _clear_kodiboxtv_data():
    removed = _clean_named_entries(
        kodiboxtvDataPath,
        directory_names=['cache'],
        recreate_directories=['cache']
    )
    _log("KodiboxTV cleaned: %s cache paths removed" % len(removed))
    return len(removed)


def _clear_vodkool_data():
    if not os.path.isdir(vodkoolDataPath):
        return 0

    removed = 0
    try:
        for entry in os.listdir(vodkoolDataPath):
            if entry.lower().endswith('.xml'):
                continue
            if _safe_remove_path(os.path.join(vodkoolDataPath, entry)):
                removed += 1
        _log("VODkool/kool.to cleaned: %s cache entries removed" % removed)
    except Exception as exc:
        _log("Could not clear VODkool/kool.to cache: %s" % exc)

    return removed


def _clear_playlistloader_cache():
    cache_dir = os.path.join(playlistLoaderDataPath, 'cache')
    if not os.path.isdir(cache_dir):
        return 0

    removed = 0
    try:
        for entry in os.listdir(cache_dir):
            if _safe_remove_path(os.path.join(cache_dir, entry)):
                removed += 1
        _log("Playlist Loader cache cleaned: %s entries removed" % removed)
    except Exception as exc:
        _log("Could not clear Playlist Loader cache: %s" % exc)

    return removed


def _clear_playforfun_cache_paths(addon_data_paths, label):
    removed = 0
    preserved_extensions = ('.xml', '.json')

    for addon_data_path in addon_data_paths:
        if not os.path.isdir(addon_data_path):
            continue
        try:
            for entry in os.listdir(addon_data_path):
                if entry.lower().endswith(preserved_extensions):
                    continue
                if _safe_remove_path(os.path.join(addon_data_path, entry)):
                    removed += 1
        except Exception as exc:
            _log("Could not clear %s cache in %s: %s" % (label, addon_data_path, exc))

    _log("%s cache cleaned: %s entries removed" % (label, removed))
    return removed


def _clear_playforfun_cache():
    return _clear_playforfun_cache_paths(
        (playForFunDataPath, playForFunRadioDataPath),
        'PlayForFun'
    )


def _clear_playforfun_vod_cache():
    return _clear_playforfun_cache_paths(
        (playForFunVodDataPath,),
        'PlayForFun VOD'
    )


def _clear_playforfun_live_cache():
    return _clear_playforfun_cache_paths(
        (playForFunDataPath, playForFunRadioDataPath),
        'PlayForFun live'
    )


def _clear_tmdb_helper_data():
    removed = _clean_named_entries(
        tmdbHelperDataPath,
        directory_names=[
            'database',
            'database_v2',
            'database_v3',
            'database_v4',
            'database_v5',
            'database_v6',
            'pickle',
            'blur',
            'crop',
            'desaturate',
            'colors'
        ],
        recreate_directories=['database_v6']
    )
    _log("TMDb Helper cleaned: %s cache paths removed" % len(removed))
    return len(removed)


def _clear_vavooto_data():
    removed = _clean_named_entries(
        vavootoDataPath,
        directory_names=['cache'],
        recreate_directories=['cache']
    )
    _log("Vavooto cleaned: %s cache paths removed" % len(removed))
    return len(removed)


def _clear_youtube_data():
    removed = []
    removable_databases = [
        'cache.sqlite',
        'data_cache.sqlite',
        'requests_cache.sqlite',
        'feeds.sqlite',
        'history.sqlite',
        'search.sqlite'
    ]

    if not os.path.exists(youtubeDataPath):
        return 0

    try:
        for entry in os.listdir(youtubeDataPath):
            subdir = os.path.join(youtubeDataPath, entry)
            if not os.path.isdir(subdir):
                continue
            removed.extend(_clean_file_variants(subdir, removable_databases))
    except Exception as exc:
        _log("Could not clear YouTube cache data: %s" % exc)

    _log("YouTube cleaned: %s cache/history files removed" % len(removed))
    return len(removed)

def _clear_textures_database():
    text13 = os.path.join(databasePath, "Textures13.db")
    if not os.path.exists(text13):
        return

    connection = None
    try:
        connection = sqlite3.connect(text13, timeout=10)
        cursor = connection.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='texture'")
        has_texture = cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sizes'")
        has_sizes = cursor.fetchone() is not None

        if has_texture:
            cursor.execute("DELETE FROM texture")
        if has_sizes:
            cursor.execute("DELETE FROM sizes")

        connection.commit()
    except Exception as exc:
        try:
            xbmc.log("ezmaintenanceplus: Could not clear Textures13.db contents: %s" % exc, level=loglevel)
        except:
            pass
    finally:
        try:
            if connection is not None:
                connection.close()
        except:
            pass

def clearCache(mode='verbose'):
    if os.path.exists(cachePath)==True:
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            if (d == "archive_cache" or d == "temp"): continue
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass

            else:
                pass
    if os.path.exists(tempPath)==True:
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    try:
                        if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        if (d == "archive_cache" or d == "temp"): continue
                        shutil.rmtree(os.path.join(root, d))
                    except:
                        pass

            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')

        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')

        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            else:
                pass

    cacheEntries = []

    for entry in cacheEntries:
        clear_cache_path = translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                else:
                    pass

    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Completed' , '3000', iconpath))

def clearLogs(mode='verbose'):
    removed = 0
    log_directories = set([path for path in [logPath, tempPath] if path])
    log_files = [
        'kodi.log',
        'kodi.old.log',
        'xbmc.log',
        'xbmc.old.log'
    ]

    for directory in log_directories:
        if not os.path.exists(directory):
            continue
        for file_name in log_files:
            target = os.path.join(directory, file_name)
            if _safe_remove_path(target):
                removed += 1
            elif os.path.exists(target):
                try:
                    with open(target, 'w'):
                        pass
                    removed += 1
                except Exception as exc:
                    _log("Could not truncate log %s: %s" % (target, exc))

    _log("Logs cleared: %s files removed" % removed)
    if mode == 'verbose':
        xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Logs Completed' , '3000', iconpath))

def deleteThumbnails(mode='verbose'):
    if os.path.exists(thumbnailPath)==True:
        for root, dirs, files in os.walk(thumbnailPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                    except:
                        pass

    if os.path.exists(THUMBS):
        try:
            for root, dirs, files in os.walk(THUMBS):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
        except:
            pass

    _clear_textures_database()
    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Thumbs Completed' , '3000', iconpath))

def deleteThumbnailsFilesOnly(mode='verbose'):
    removed = 0

    if os.path.exists(thumbnailPath) == True:
        for root, dirs, files in os.walk(thumbnailPath):
            for f in files:
                try:
                    os.unlink(os.path.join(root, f))
                    removed += 1
                except Exception as exc:
                    _log("Could not remove thumbnail %s: %s" % (os.path.join(root, f), exc))

    if os.path.exists(THUMBS):
        try:
            for root, dirs, files in os.walk(THUMBS):
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                        removed += 1
                    except Exception as exc:
                        _log("Could not remove thumbnail %s: %s" % (os.path.join(root, f), exc))
                for d in dirs:
                    try:
                        shutil.rmtree(os.path.join(root, d))
                    except Exception as exc:
                        _log("Could not remove thumbnail directory %s: %s" % (os.path.join(root, d), exc))
        except Exception as exc:
            _log("Could not walk thumbnail directories: %s" % exc)

    _log("Thumbnail files cleared without database cleanup: %s files removed" % removed)
    if mode == 'verbose':
        xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Thumbs Completed' , '3000', iconpath))

def purgePackages(mode='verbose'):

    purgePath = translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
    # if dialog.yesno("Delete Package Cache Files", "%d packages found."%file_count + '\n' + "Delete Them?"):
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
            # dialog = xbmcgui.Dialog()
            # dialog.ok("Maintenance", "Deleting Packages all done")
    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Packages Completed' , '3000', iconpath))

def runAutoClean(mode='silent'):
    try:
        clearCache(mode='silent')
    except Exception as exc:
        _log("AutoClean: clearCache failed: %s" % exc)
    try:
        purgePackages(mode='silent')
    except Exception as exc:
        _log("AutoClean: purgePackages failed: %s" % exc)
    try:
        deleteThumbnails(mode='silent')
    except Exception as exc:
        _log("AutoClean: deleteThumbnails failed: %s" % exc)
    stalker_removed = _clear_stalker_cache()
    playlistloader_removed = _clear_playlistloader_cache()
    playforfun_removed = _clear_playforfun_cache()
    playforfun_vod_removed = _clear_playforfun_vod_cache()
    kodiboxtv_removed = _clear_kodiboxtv_data()
    vodkool_removed = _clear_vodkool_data()
    _log("AutoClean: Stalker cache files removed: %s" % stalker_removed)
    _log("AutoClean: Playlist Loader cache entries removed: %s" % playlistloader_removed)
    _log("AutoClean: PlayForFun cache entries removed: %s" % playforfun_removed)
    _log("AutoClean: PlayForFun VOD cache entries removed: %s" % playforfun_vod_removed)
    _log("AutoClean: KodiboxTV cache paths removed: %s" % kodiboxtv_removed)
    _log("AutoClean: VODkool/kool.to cache entries removed: %s" % vodkool_removed)
    if mode == 'verbose':
        xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Auto Clean Completed' , '3000', iconpath))

def runLowStorageClean(mode='silent'):
    clearCache(mode='silent')
    purgePackages(mode='silent')
    clearLogs(mode='silent')
    deleteThumbnailsFilesOnly(mode='silent')
    stalker_removed = _clear_stalker_cache()
    playlistloader_removed = _clear_playlistloader_cache()
    playforfun_live_removed = _clear_playforfun_live_cache()
    kodiboxtv_removed = _clear_kodiboxtv_data()
    vodkool_removed = _clear_vodkool_data()
    _log(
        "Low storage clean completed | "
        "Stalker: %s cache files | "
        "Playlist Loader: %s cache entries | "
        "PlayForFun live/radio: %s cache entries | "
        "KodiboxTV: %s paths | "
        "VODkool/kool.to: %s cache entries"
        % (
            stalker_removed,
            playlistloader_removed,
            playforfun_live_removed,
            kodiboxtv_removed,
            vodkool_removed
        )
    )
    if mode == 'verbose':
        xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Low Storage Clean Completed' , '3000', iconpath))


def runTotalClean(mode='silent', quit_kodi=False):
    _log("Total Clean started")
    clearCache(mode='silent')
    _log("Total Clean: Kodi cache cleared")
    purgePackages(mode='silent')
    _log("Total Clean: packages cleared")
    deleteThumbnails(mode='silent')
    _log("Total Clean: thumbnails cleared")

    kodi_favourites_cleared = _clear_kodi_favourites()
    stalker_portal_bookmarks, stalker_portal_playback = _clear_stalker_portal_playback_state()
    stalker_removed = _clear_stalker_cache()
    archiv_navigator_removed, archiv_navigator_bookmarks, archiv_navigator_playback = _clear_archiv_navigator_data()
    streaming_archiv_removed, streaming_archiv_bookmarks, streaming_archiv_playback = _clear_streaming_archiv_data()
    xxx_removed, xxx_bookmarks, xxx_playback = _clear_xxx_data()
    cumination_removed, cumination_favourites, cumination_keywords, cumination_cache_rows, cumination_bookmarks, cumination_playback = _clear_cumination_data()
    kodiboxtv_removed = _clear_kodiboxtv_data()
    tmdb_helper_removed = _clear_tmdb_helper_data()
    vavooto_removed = _clear_vavooto_data()
    vodkool_removed = _clear_vodkool_data()
    youtube_removed = _clear_youtube_data()
    playforfun_removed = _clear_playforfun_cache()
    playforfun_vod_removed = _clear_playforfun_vod_cache()

    summary = (
        "Total Clean complete | "
        "Kodi favourites: %s | "
        "Stalker Portal resume: %s bookmarks, %s playback files | "
        "Stalker: %s cache files | "
        "Archiv Navigator: %s paths, %s bookmarks, %s playback files | "
        "Streaming Archiv: %s paths, %s bookmarks, %s playback files | "
        "XXX: %s paths, %s bookmarks, %s playback files | "
        "Cumination: %s paths, %s favourites, %s keywords, %s cache rows, %s bookmarks, %s playback files | "
        "KodiboxTV: %s paths | "
        "TMDb Helper: %s paths | "
        "Vavooto: %s paths | "
        "VODkool/kool.to: %s cache entries | "
        "YouTube: %s files | "
        "PlayForFun: %s cache entries | "
        "PlayForFun VOD: %s cache entries"
        % (
            'cleared' if kodi_favourites_cleared else 'unchanged',
            stalker_portal_bookmarks,
            stalker_portal_playback,
            stalker_removed,
            archiv_navigator_removed,
            archiv_navigator_bookmarks,
            archiv_navigator_playback,
            streaming_archiv_removed,
            streaming_archiv_bookmarks,
            streaming_archiv_playback,
            xxx_removed,
            xxx_bookmarks,
            xxx_playback,
            cumination_removed,
            cumination_favourites,
            cumination_keywords,
            cumination_cache_rows,
            cumination_bookmarks,
            cumination_playback,
            kodiboxtv_removed,
            tmdb_helper_removed,
            vavooto_removed,
            vodkool_removed,
            youtube_removed,
            playforfun_removed,
            playforfun_vod_removed
        )
    )
    _log(summary)

    if mode == 'verbose':
        _notify('Reinigung', 'Total Clean abgeschlossen', 2500)

    if quit_kodi:
        _log("Total Clean finished, quitting Kodi")
        xbmc.sleep(2000)
        xbmc.executebuiltin('Quit()')

def determineNextMaintenance():
    getSetting = xbmcaddon.Addon().getSetting

    autoCleanDays = getSetting('autoCleanDays')
    if not autoCleanDays:
        days = 0
    else:
        try:
            days = int(autoCleanDays)
        except ValueError:
            days = 0

    t1 = 0

    if days > 0:
        autoCleanHour = getSetting('autoCleanHour')
        if not autoCleanHour:
            hour = 0
        else:
            try:
                hour = int(autoCleanHour)
            except ValueError:
                hour = 0

        t0 = int(math.floor(time.time()))

        t1 = t0 + (days * 24 * 60 * 60)  # days * 24h * 60m * 60s

        x = time.localtime(t1)

        t1 += (hour - x.tm_hour) * 60 * 60 - x.tm_min * 60 - x.tm_sec
        while (t1 <= t0):
            t1 += 24 * 60 * 60 # add days until we are in the future

        #t1 = t0 + 1 * 60 # for testing - every minute

    win = xbmcgui.Window(10000)
    win.setProperty("ezmaintenance.nextMaintenanceTime", str(t1))

    logMaintenance("setNextMaintenance: %s" % str(t1))


def getNextMaintenance():
    win = xbmcgui.Window(10000)
    raw_next_maintenance = win.getProperty("ezmaintenance.nextMaintenanceTime")
    try:
        t1 = int(raw_next_maintenance)
    except (TypeError, ValueError):
        _log("Invalid next maintenance time '%s', resetting schedule" % raw_next_maintenance)
        determineNextMaintenance()
        raw_next_maintenance = win.getProperty("ezmaintenance.nextMaintenanceTime")
        try:
            t1 = int(raw_next_maintenance)
        except (TypeError, ValueError):
            t1 = 0

    logMaintenance("getNextMaintenance: %s" % str(t1))

    return t1

def logMaintenance(message):
    return

