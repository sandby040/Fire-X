import os
import sys

import xbmc
import xbmcgui
import xbmcvfs


ADDON_ID = 'script.ezmaintenanceplus'
ADDON_PATH = xbmcvfs.translatePath('special://home/addons/%s' % ADDON_ID)

if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)


def main():
    try:
        from resources.lib.modules import maintenance
        maintenance.runTotalClean(mode='verbose', quit_kodi=True)
    except Exception as exc:
        try:
            xbmc.log('ezmaintenanceplus: Total Clean launcher failed: %s' % exc, level=xbmc.LOGINFO)
        except:
            pass
        try:
            xbmcgui.Dialog().notification('Reinigung', 'Total Clean Fehler', '', 3000, False)
        except:
            pass


if __name__ == '__main__':
    main()
