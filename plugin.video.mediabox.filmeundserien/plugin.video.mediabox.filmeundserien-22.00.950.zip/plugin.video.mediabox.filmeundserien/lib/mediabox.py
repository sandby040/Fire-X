# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import json
import os
import sys
import xml.etree.ElementTree as ET
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if sys.argv else "plugin://%s/" % ADDON_ID


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


def _profile_dir():
    path = _translate(ADDON.getAddonInfo("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def _data_file():
    return os.path.join(_profile_dir(), "addons.json")


def _load_entries():
    path = _data_file()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except Exception as exc:
        xbmc.log("[mediabox] Could not read addons.json: %s" % exc, xbmc.LOGWARNING)
        return []


def _save_entries(entries):
    with open(_data_file(), "w", encoding="utf-8") as fh:
        json.dump(entries, fh, ensure_ascii=False, indent=2)


def _plugin_url(action, **params):
    query = {"action": action}
    query.update(params)
    return "%s?%s" % (BASE_URL, urlencode(query))


def _art_for_addon(addon_id):
    try:
        addon = xbmcaddon.Addon(id=addon_id)
        icon = addon.getAddonInfo("icon")
        fanart = addon.getAddonInfo("fanart")
        return icon or fanart, fanart or icon
    except Exception:
        return "", ""


def _entry_url(entry):
    if entry.get("path"):
        return entry.get("path")
    addon_id = entry.get("addonid")
    if addon_id:
        return "plugin://%s/" % addon_id
    return ""


def _entry_key(entry):
    return entry.get("path") or entry.get("addonid") or entry.get("name")


def _append_unique(entries, new_entry):
    key = _entry_key(new_entry)
    if not key:
        return False
    if any(_entry_key(entry) == key for entry in entries):
        return False
    entries.append(new_entry)
    return True


def _add_directory(label, url, icon="", fanart="", info="", is_folder=True):
    item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art["icon"] = icon
        art["thumb"] = icon
    if fanart:
        art["fanart"] = fanart
    if art:
        item.setArt(art)
    if info:
        item.setInfo("video", {"plot": info})
    xbmcplugin.addDirectoryItem(HANDLE, url, item, is_folder)


def _installed_video_addons():
    addons_dir = _translate("special://home/addons")
    result = []
    try:
        names = sorted(os.listdir(addons_dir))
    except Exception:
        names = []
    for folder in names:
        addon_xml = os.path.join(addons_dir, folder, "addon.xml")
        if not os.path.exists(addon_xml):
            continue
        try:
            root = ET.parse(addon_xml).getroot()
            addon_id = root.attrib.get("id", "")
            name = root.attrib.get("name", addon_id)
            has_video = False
            for ext in root.findall("extension"):
                if ext.attrib.get("point") == "xbmc.python.pluginsource":
                    provides = (ext.findtext("provides") or "").lower()
                    if "video" in provides:
                        has_video = True
                        break
            if not has_video or addon_id == ADDON_ID:
                continue
            icon, fanart = _art_for_addon(addon_id)
            result.append({
                "addonid": addon_id,
                "name": name,
                "icon": icon,
                "fanart": fanart,
            })
        except Exception:
            continue
    return result


def _parse_favourite_target(text):
    text = (text or "").strip()
    lower = text.lower()
    if lower.startswith("activatewindow"):
        first = text.find('"')
        last = text.rfind('"')
        if first >= 0 and last > first:
            return text[first + 1:last]
    if lower.startswith("playmedia"):
        start = text.find("(")
        end = text.rfind(")")
        if start >= 0 and end > start:
            return text[start + 1:end].strip().strip('"')
    if text.startswith("plugin://"):
        return text
    return ""


def _kodi_favourites():
    fav_file = _translate("special://profile/favourites.xml")
    if not os.path.exists(fav_file):
        return []
    result = []
    try:
        root = ET.parse(fav_file).getroot()
        for fav in root.findall("favourite"):
            target = _parse_favourite_target(fav.text)
            if not target.startswith("plugin://"):
                continue
            result.append({
                "name": fav.attrib.get("name", target),
                "path": target,
                "icon": fav.attrib.get("thumb", ""),
                "fanart": fav.attrib.get("thumb", ""),
            })
    except Exception as exc:
        xbmc.log("[mediabox] Could not read favourites.xml: %s" % exc, xbmc.LOGWARNING)
    return result


def _refresh():
    xbmc.executebuiltin("Container.Refresh")


def _add_installed_addons():
    candidates = _installed_video_addons()
    labels = [entry["name"] for entry in candidates]
    selected = xbmcgui.Dialog().multiselect("Add-ons hinzufügen", labels)
    if selected is None:
        return
    entries = _load_entries()
    added = 0
    for index in selected:
        if _append_unique(entries, candidates[index]):
            added += 1
    _save_entries(entries)
    xbmcgui.Dialog().notification(ADDON_NAME, "%d Add-on(s) hinzugefügt" % added, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh()


def _add_from_favourites():
    candidates = _kodi_favourites()
    if not candidates:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine passenden Kodi-Favoriten gefunden.")
        return
    labels = [entry["name"] for entry in candidates]
    selected = xbmcgui.Dialog().multiselect("Favoriten importieren", labels)
    if selected is None:
        return
    entries = _load_entries()
    added = 0
    for index in selected:
        if _append_unique(entries, candidates[index]):
            added += 1
    _save_entries(entries)
    xbmcgui.Dialog().notification(ADDON_NAME, "%d Favorit(en) hinzugefügt" % added, xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh()


def _remove_entries():
    entries = _load_entries()
    if not entries:
        xbmcgui.Dialog().notification(ADDON_NAME, "Keine Einträge vorhanden", xbmcgui.NOTIFICATION_INFO, 2000)
        return
    labels = [entry.get("name") or entry.get("addonid") or entry.get("path") for entry in entries]
    selected = xbmcgui.Dialog().multiselect("Einträge entfernen", labels)
    if selected is None:
        return
    remove = set(selected)
    entries = [entry for index, entry in enumerate(entries) if index not in remove]
    _save_entries(entries)
    xbmcgui.Dialog().notification(ADDON_NAME, "Einträge entfernt", xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh()


def _clear_entries():
    if xbmcgui.Dialog().yesno(ADDON_NAME, "Alle Einträge aus dieser Mediabox entfernen?"):
        _save_entries([])
        _refresh()


def _show_manager():
    _add_directory("Video-Add-ons hinzufügen", _plugin_url("add_addons"))
    _add_directory("Aus Kodi-Favoriten importieren", _plugin_url("add_favourites"))
    _add_directory("Einträge entfernen", _plugin_url("remove"))
    _add_directory("Diese Mediabox leeren", _plugin_url("clear"))
    xbmcplugin.endOfDirectory(HANDLE)


def _show_root():
    entries = _load_entries()
    # Hidden by default; keep the manager action available for later reactivation.
    # _add_directory("[B]+ Hinzufügen / Bearbeiten[/B]", _plugin_url("manage"))
    for entry in entries:
        name = entry.get("name") or entry.get("addonid") or entry.get("path") or "Eintrag"
        url = _entry_url(entry)
        if not url:
            continue
        _add_directory(name, url, entry.get("icon", ""), entry.get("fanart", ""))
    xbmcplugin.setContent(HANDLE, "addons")
    xbmcplugin.endOfDirectory(HANDLE)
    xbmc.log("[mediabox] Added %d entries from JSON" % len(entries), xbmc.LOGINFO)


def index():
    query = parse_qs(sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else "")
    action = (query.get("action") or ["root"])[0]
    if action == "manage":
        _show_manager()
    elif action == "add_addons":
        _add_installed_addons()
    elif action == "add_favourites":
        _add_from_favourites()
    elif action == "remove":
        _remove_entries()
    elif action == "clear":
        _clear_entries()
    else:
        _show_root()
