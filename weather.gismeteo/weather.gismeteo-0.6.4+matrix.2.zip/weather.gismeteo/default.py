# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
HOME_WINDOW = xbmcgui.Window(10000)
WEATHER_WINDOW = xbmcgui.Window(12600)

VERSION_ICON = 'special://home/addons/weather.gismeteo/resources/media/Version.png'
DEFAULT_VERSION_TEXT = '1.01'

CURRENT_PROPS = (
    'Location',
    'Condition',
    'Temperature',
    'Wind',
    'WindDirection',
    'Humidity',
    'FeelsLike',
    'DewPoint',
    'OutlookIcon',
    'FanartCode',
    'Pressure',
    'Precipitation',
    'ProviderIcon',
)

DESCRIPTION_PROPS = (
    'WeatherProvider',
    'WeatherProviderLogo',
    'Forecast.IsFetched',
    'Current.IsFetched',
    'Today.IsFetched',
    'Daily.IsFetched',
    'Weekend.IsFetched',
    '36Hour.IsFetched',
    'Hourly.IsFetched',
    'Alerts.IsFetched',
    'Map.IsFetched',
)


def setting(setting_id, default=''):
    value = ADDON.getSetting(setting_id)
    value = value.strip() if value else ''
    return value or default


def version_text():
    return setting('VersionText', DEFAULT_VERSION_TEXT)


def set_property(window, name, value):
    window.setProperty(name, str(value))


def clear_weather_properties():
    for name in DESCRIPTION_PROPS:
        set_property(WEATHER_WINDOW, name, '')

    for name in CURRENT_PROPS:
        set_property(WEATHER_WINDOW, 'Current.{0}'.format(name), '')


def apply_version_overlay():
    text = version_text()

    HOME_WINDOW.setProperty('Version.Text', text)
    HOME_WINDOW.setProperty('Version.Icon', VERSION_ICON)

    clear_weather_properties()

    set_property(WEATHER_WINDOW, 'WeatherProvider', 'Version')
    set_property(WEATHER_WINDOW, 'WeatherProviderLogo', VERSION_ICON)
    set_property(WEATHER_WINDOW, 'Forecast.IsFetched', 'true')
    set_property(WEATHER_WINDOW, 'Current.IsFetched', 'true')
    set_property(WEATHER_WINDOW, 'Today.IsFetched', 'true')
    set_property(WEATHER_WINDOW, 'Daily.IsFetched', 'true')
    set_property(WEATHER_WINDOW, 'Weekend.IsFetched', 'true')
    set_property(WEATHER_WINDOW, '36Hour.IsFetched', 'true')
    set_property(WEATHER_WINDOW, 'Hourly.IsFetched', 'true')

    set_property(WEATHER_WINDOW, 'Current.Location', 'Version')
    set_property(WEATHER_WINDOW, 'Current.Condition', 'Version')
    set_property(WEATHER_WINDOW, 'Current.Temperature', text)
    set_property(WEATHER_WINDOW, 'Current.OutlookIcon', VERSION_ICON)

    xbmc.log('[weather.gismeteo] Local version display set to {0}'.format(text), xbmc.LOGINFO)


if __name__ == '__main__':
    apply_version_overlay()
