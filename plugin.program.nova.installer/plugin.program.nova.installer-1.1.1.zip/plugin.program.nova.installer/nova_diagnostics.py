# -*- coding: utf-8 -*-
"""Persistent, bounded installer trace; independent of Wizard configuration."""
import functools
import json
import os
import re
import sys
import threading
import time
import traceback
import uuid
from urllib.parse import parse_qsl, urlsplit, urlunsplit

import xbmc
import xbmcaddon
import xbmcvfs

_path = None
_started = time.monotonic()
_lock = threading.RLock()
_requests = 0
_limited = False
MAX_REPORT_BYTES = 4 * 1024 * 1024


def _clean(value):
    text = str(value)
    # Never persist URL credentials, query tokens, or settings/password dumps.
    def clean_url(match):
        try:
            parts = urlsplit(match.group(0))
            host = parts.netloc.rsplit('@', 1)[-1]
            return urlunsplit((parts.scheme, host, parts.path,
                               '[redacted]' if parts.query else '', ''))
        except Exception:
            return '[url]'
    text = re.sub(r'(?:https?|plugin)://[^\s\"\'<>]+', clean_url, text)
    return text[:12000]


def event(name, **fields):
    global _limited
    if not _path:
        return
    try:
        row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'),
               'elapsed_s': round(time.monotonic() - _started, 3),
               'event': name}
        row.update({key: value if isinstance(value, (int, float, bool))
                    or value is None else _clean(value)
                    for key, value in fields.items()})
        with _lock:
            if _limited or not _path or not os.path.exists(_path):
                return
            if os.path.getsize(_path) >= MAX_REPORT_BYTES:
                row = {'event': 'report_size_limit', 'limit': MAX_REPORT_BYTES}
                _limited = True
            with open(_path, 'a', encoding='utf-8') as handle:
                handle.write(json.dumps(row, ensure_ascii=False) + '\n')
                handle.flush()
    except Exception as exc:
        # A diagnostic failure must never prevent the installation.
        try:
            xbmc.log('[N3 TRACE] Write failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
        except Exception:
            pass


def failure(name):
    event(name, traceback=traceback.format_exc())


def start(argv):
    global _path, _started, _limited, _requests
    try:
        _started = time.monotonic()
        _limited = False
        _requests = 0
        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.program.nova.installer/diagnostics')
        os.makedirs(folder, exist_ok=True)
        # Keep at most three N3 reports. Only files with our exact report prefix
        # inside this directory are eligible; no Kodi logs/backups are touched.
        reports = sorted(name for name in os.listdir(folder)
                         if name.startswith('nova-installer-report-') and name.endswith('.jsonl'))
        now = time.time()
        for name in reports[:-2]:
            filepath = os.path.join(folder, name)
            try:
                if now - os.path.getmtime(filepath) > 60:
                    os.remove(filepath)
            except Exception:
                pass
        run_id = time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
        _path = os.path.join(folder, 'nova-installer-report-%s.jsonl' % run_id)
        with open(_path, 'x', encoding='utf-8'):
            pass
        params = dict(parse_qsl(argv[2].lstrip('?'))) if len(argv) > 2 else {}
        addon = xbmcaddon.Addon('plugin.program.nova.installer')
        event('invocation_start', version=addon.getAddonInfo('version'),
              addon_path=addon.getAddonInfo('path'), python=sys.version,
              kodi=xbmc.getInfoLabel('System.BuildVersion'),
              memory=xbmc.getInfoLabel('System.Memory(total)'),
              skin=xbmc.getSkinDir(),
              openwizard_installed=xbmc.getCondVisibility('System.HasAddon(plugin.program.openwizard)'),
              openwizard_enabled=xbmc.getCondVisibility('System.AddonIsEnabled(plugin.program.openwizard)'),
              handle=argv[1] if len(argv) > 1 else '',
              mode=params.get('mode'), action=params.get('action'),
              build=params.get('name'))
        xbmc.log('[N3 TRACE] Report: %s' % _path, xbmc.LOGINFO)
    except Exception as exc:
        _path = None
        xbmc.log('[N3 TRACE] Startup failed: %s' % type(exc).__name__, xbmc.LOGWARNING)


def step(name):
    def decorate(func):
        @functools.wraps(func)
        def wrapped(*args, **kwargs):
            started = time.monotonic()
            event(name + '_start')
            try:
                result = func(*args, **kwargs)
            except BaseException:
                failure(name + '_exception')
                raise
            event(name + '_end', duration_s=round(time.monotonic() - started, 3),
                  result=result if isinstance(result, (bool, int, float)) else None)
            return result
        return wrapped
    return decorate


def finish(status):
    event('invocation_end', status=status, http_requests=_requests,
          skin=xbmc.getSkinDir())
