# SPDX-License-Identifier: GPL-2.0-or-later
"""N3 has exactly one operation: install the Nova build, after confirmation."""
import sys
import nova_diagnostics as trace

trace.start(sys.argv)
try:
    from nova_installer import run
    run(sys.argv)
except Exception:
    trace.failure('entry_exception')
    trace.finish('failed')
    import xbmcgui
    xbmcgui.Dialog().ok('Nova Updater', 'N3 konnte nicht gestartet werden\nDer Fehler wurde im N3-Diagnosebericht gespeichert')
