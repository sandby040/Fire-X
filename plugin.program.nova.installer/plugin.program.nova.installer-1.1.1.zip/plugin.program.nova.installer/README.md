# N3 – Nova Updater 1.0.1

Eigenständiger Build-Installer mit Kodi-ID `plugin.program.nova.installer`.
Keine N2-/OpenWizard-Python-Importe, keine gemeinsamen Daten-/Diagnose-/Lock-Pfade.
Kein Startdienst. Nur Build-Installation; keine Wartungs- oder Login-Funktionen.
Das bisherige Nova-Update-Icon bleibt unverändert.
Auch das eigene App-Startbild unter media/splash.jpg oder media/splash.png
wird geprüft und atomar übertragen. Der Skin-Abschluss bleibt unverändert.

Eigener Einstieg:
https://raw.githubusercontent.com/sandby040/N2026/main/nova-installer-build.json
Die JSON muss die neue Installer-ID enthalten. Build-Datei ist NOVA3.zip.
N2/OpenWizard und ihre alten Links bleiben eigenständig und werden nicht gelöscht.

Nach manueller ZIP-Installation einmal N3 selbst öffnen. Dadurch werden nur
die alten N2-Build-Update-Verknüpfungen auf N3 gestellt. Auch beim Einspielen des
Builds werden solche Update-Verknüpfungen angepasst, damit ein altes Build den
Service-Update-Button nicht wieder an den alten N2 bindet. Clean/Handshake/Live TV
werden nicht umgestellt. N3 schützt sich sowie vorhandene N2/OpenWizard-Ordner
vor Überschreiben durch die Build-ZIP. Alte Installer sind danach noch vorhanden.

Sicherheitsweg unverändert von der geprüften N2-2.0.8-Grundlage: geprüfter HTTPS-
Download, sichere ZIP-Pfade/CRC/Platzprüfung vor Übertragung, keine flächige Löschung,
laufende Kodi-Datenbanken nicht ersetzen, globale fremde Updates gesperrt, eigener
temporärer Pfad, atomare Einzeldateien, komplett vorbereiteter Ziel-Skin mit finalem
Estuary-Wechsel und lokaler Abhängigkeitsregistrierung. Deutscher Abschlussdialog.
Gesamt-Build ist nicht transaktional; Schreibfehler müssen durch erneute Installation
behoben werden. Fehler hinterlassen einen Diagnosebericht/Marker, keinen Erfolg.

Diagnose: special://profile/addon_data/plugin.program.nova.installer/diagnostics
Maximal drei Berichte à 4 MiB. Eigener User-Agent, CA-Datei und Modulnamen.
Temporäre Dateien nur unter dieser Add-on-ID. Keine automatischen Clean-Aktionen.

Der Nutzer-Test vom 02.10.2026 galt dem diagnostizierten N2 2.0.7.6 auf Shield.
Offline-Tests und ZIP-Prüfungen sind kein Nachweis einer echten N3-Installation
auf Shield/Fire TV. Erst manuell auf Shield prüfen, dann Fire TV testen.
Lizenz GPL-2.0-or-later (OpenWizard-abgeleitete Skin-Schritte), siehe LICENSE;
mitgeliefertes CA-Bundle siehe resources/certifi-LICENSE.txt.
