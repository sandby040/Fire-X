# SPDX-License-Identifier: GPL-2.0-or-later
"""Standalone installer. No cleaning, repo scans, startup, auth or login tools.

Use an independent plugin ID/data/module namespace. Transfer via stdlib HTTPS, stream
and CRC-check the ZIP before writing build files. Protect the running installer and
live databases. Stage the target skin and swap only while Estuary is active.
The final gui settings write happens immediately before the confirmed exit.
"""
import json
import os
import re
import shutil
import stat
import time
import uuid
import zipfile
import sqlite3
import ssl
import xml.etree.ElementTree as ET
from pathlib import PurePosixPath
from urllib.parse import parse_qsl, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import nova_diagnostics as trace

ADDON_ID = 'plugin.program.nova.installer'
TITLE = 'Nova Update'
COLOR = 'FFB38A00'
# Own manifest, independent from N2 and OpenWizard.
# N3 has its own manifest filename, not a renamed GitHub repository.
MANIFEST_URL = 'https://raw.githubusercontent.com/sandby040/N2026/main/nova-installer-build.json'
# Registration policy stays unchanged; only file-transfer exclusions are relaxed.
PROTECTED = {'plugin.program.nova.installer', 'plugin.program.n2', 'plugin.program.openwizard'}
TRANSFER_PROTECTED = {ADDON_ID}
# Reload/OpenWizard's explicit disposable-file list, not a program/asset filter.
# No blanket .pyc, __pycache__, media, Thumbnails or other-wizard exclusions.
# No blanket .csv exclusion: a build may use CSV files for channel mappings.
DISPOSABLE_FILES = {
    'log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log',
    'onechannelcache.db', 'saltscache.db', 'saltscache.db-shm', 'saltscache.db-wal',
    'saltshd.lite.db', 'saltshd.lite.db-shm', 'saltshd.lite.db-wal', 'queue.db',
    'commoncache.db', 'access.log', 'trakt.db', 'video_cache.db', '.gitignore',
    '.ds_store', 'textures13.db', 'thumbs.db',
}
# OpenWizard's active keep defaults from the recorded reference installation.
PERSONAL_FILES = {'userdata/favourites.xml', 'userdata/sources.xml',
                  'userdata/advancedsettings.xml'}
RUNTIME_SUPPORT = {'script.module.bottle', 'script.module.certifi',
                   'script.module.chardet', 'script.module.idna',
                   'script.module.requests', 'script.module.six',
                   'script.module.urllib3', 'script.module.web-pdb'}
FIREX_MANAGED_ADDONS = {
    'repository.stube.nova',
    'plugin.video.kodiboxtv',
    'plugin.video.iptvmaster',
    'plugin.video.vodkool',
    'pvr.iptvsimple',
    'pvr.stalker',
    'script.module.pvr',
    'plugin.video.playlistloader.macsimum',
    'plugin.video.stalker.macsimum',
    'plugin.video.stalker.macsimum.talker3',
    'plugin.video.mediabox.filmeundserien',
    'plugin.video.mediabox.livetv',
    'plugin.video.mediabox.stalker',
    'plugin.video.mediabox.xxx',
    'script.mediabox',
    'plugin.video.streaming.archiv',
    'plugin.video.archiv.navigator',
    'script.codex.livetv.handshake',
    'service.talker3.autobridge',
    'service.stube.guard',
    'service.firex.updater',
    'service.stube.livetv.data',
    'script.ezmaintenanceplus',
    'script.speedtester',
    'plugin.video.tools',
    'plugin.video.xxx',
    'script.module.resolveurl.xxx',
    'script.nova.xxx.toggle',
    'plugin.video.youtube',
    'weather.gismeteo',
    'plugin.program.nova.installer',
}
FIREX_REPO_BASE = 'https://sandby040.github.io/Fire-X/'
FIREX_ADDONS_XML = FIREX_REPO_BASE + 'addons.xml'
CHUNK = 256 * 1024
RESERVE = 128 * 1024 * 1024
COMPLETION = (
    '[COLOR FFB38A00][B]Installation erfolgreich[/B][/COLOR]\n\n'
    '1. Nach 3 Sekunden neu starten.\n'
    '2. 2 Minuten in der App bleiben und über EXIT wieder verlassen.\n'
    '3. Nach 3 Sekunden erneut starten und Timer abwarten.\n\n'
    'NOVA ist anschließend vollständig bereit.'
)


class Cancelled(Exception):
    pass


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in reply:
        raise RuntimeError('%s: %s' % (method, reply['error'].get('message', 'Fehler')))
    return reply.get('result')


def setting(name):
    return rpc('Settings.GetSettingValue', setting=name)['value']


def https_url(url):
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
        raise ValueError('N3 benötigt einen gültigen HTTPS-Link ohne Zugangsdaten')
    return url


def fetch(url, timeout=30):
    """One GET, no preflight HEAD and no silent retry/fallback."""
    https_url(url)
    trace._requests += 1
    trace.event('http_start', method='GET', url=url, timeout=timeout)
    try:
        # Android Kodi's stdlib need not find system CA paths. Bundle the same
        # CA file that the existing Requests/certifi installation used, never
        # disable certificate verification and never depend on OpenWizard imports.
        context = ssl.create_default_context(cafile=os.path.join(
            os.path.dirname(__file__), 'resources', 'cacert.pem'))
        response = urlopen(Request(url, headers={'User-Agent': 'Nova-N3/1.0.8'}), timeout=timeout, context=context)
        try:
            https_url(response.geturl())
        except Exception:
            response.close()
            raise
        trace.event('http_end', status=response.status, final_url=response.geturl())
        return response
    except Exception:
        trace.failure('http_exception')
        raise


def manifest():
    with fetch(MANIFEST_URL) as response:
        payload = response.read(65537)
    if len(payload) > 65536:
        raise ValueError('N3-Buildinformationen sind zu groß')
    result = json.loads(payload.decode('utf-8-sig'))
    if (result.get('schema') != 1 or result.get('name') != 'NOVA'
            or result.get('installer_id') != ADDON_ID):
        raise ValueError('Ungültige N3-Buildinformationen')
    https_url(result['url'])
    major = re.match(r'\d+', xbmc.getInfoLabel('System.BuildVersion'))
    if not major or int(major.group()) != int(result['kodi_major']):
        raise ValueError('Dieses Nova Build benötigt Kodi %s' % result['kodi_major'])
    return result


def safe_name(name):
    """No absolute/parent/drive paths, Windows alias names or symlinks."""
    name = name.replace('\\', '/')
    parts = PurePosixPath(name).parts
    if (not parts or name.startswith('/') or '\x00' in name
            or any(p in ('.', '..') or ':' in p or p.rstrip(' .') != p for p in parts)):
        raise ValueError('Unsicherer ZIP-Pfad')
    return '/'.join(parts)


def skip_reason(name):
    parts = name.lower().split('/')
    if len(parts) > 1 and parts[0] == 'addons' and parts[1] in TRANSFER_PROTECTED:
        return 'running_installer'
    if (len(parts) > 2 and parts[:2] == ['userdata', 'addon_data']
            and parts[2] in TRANSFER_PROTECTED):
        return 'running_installer_data'
    # Keep N3's established local registration/bootstrap unchanged. Replacing
    # open Kodi SQLite databases would conflict with that mechanism; Addons.db
    # enable flags are imported separately by local_addon_states(). Non-DB
    # files in Database/ are not excluded merely because of their directory.
    if (parts[:2] == ['userdata', 'database']
            and re.search(r'\.db(?:-(?:wal|shm|journal))?$', parts[-1])):
        return 'live_kodi_database'
    if parts[-1] in DISPOSABLE_FILES:
        return 'reload_disposable_file'
    return None


def skipped(name):
    return skip_reason(name) is not None


def inventory(archive):
    entries = []
    names = set()
    exclusions = {}
    for info in archive.infolist():
        name = safe_name(info.filename)
        kind = (info.external_attr >> 16) & 0o170000
        if kind == stat.S_IFLNK:
            raise ValueError('Verknüpfungen sind im Build nicht erlaubt')
        if info.is_dir():
            continue
        if name.casefold() in names:
            raise ValueError('Doppelter ZIP-Pfad: %s' % name)
        names.add(name.casefold())
        reason = skip_reason(name)
        if reason is None:
            entries.append((info, name))
        else:
            exclusions[reason] = exclusions.get(reason, 0) + 1
            trace.event('archive_entry_preserved', file=name, reason=reason)
    if not any(name.startswith('addons/') and name.endswith('/addon.xml') for _, name in entries):
        raise ValueError('Das Archiv enthält kein Kodi Build')
    trace.event('archive_transfer_policy', accepted=len(entries), excluded=exclusions)
    return entries


def skin_id(archive, entries, preferred):
    available = {name.split('/')[1] for _, name in entries
                 if name.startswith('addons/skin.') and name.endswith('/addon.xml')}
    gui = next((info for info, name in entries if name == 'userdata/guisettings.xml'), None)
    if gui:
        root = ET.fromstring(archive.read(gui))
        item = root.find(".//setting[@id='lookandfeel.skin']")
        if item is not None and item.text in available:
            return item.text
    if preferred in available:
        return preferred
    custom = sorted(available - {'skin.estuary', 'skin.estouchy'})
    if len(custom) != 1:
        raise ValueError('Der Ziel-Skin konnte nicht eindeutig bestimmt werden')
    return custom[0]


def skin_payload(name, target):
    return name.startswith('addons/%s/' % target) or name.startswith('userdata/addon_data/%s/' % target)


def atomic_file(source, target):
    """Do not truncate a live file if ZIP CRC/read/write fails halfway."""
    os.makedirs(os.path.dirname(target), exist_ok=True)
    temporary = target + '.nova-installer-tmp-' + uuid.uuid4().hex[:8]
    try:
        with open(temporary, 'xb') as output:
            shutil.copyfileobj(source, output, CHUNK)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def replace_directory(source, target):
    """Complete skin directory swap, with rollback of this directory on failure."""
    backup = target + '.nova-installer-old'
    if os.path.exists(backup):
        # A prior failed install may have left the only good copy here.
        raise RuntimeError('Vorherige Skin-Sicherung muss zuerst geprüft werden: %s' % backup)
    moved = False
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if os.path.exists(target):
            os.rename(target, backup)
            moved = True
        os.rename(source, target)
    except Exception:
        if moved:
            os.rename(backup, target)
        raise
    if moved:
        shutil.rmtree(backup)


def rewrite_update_links(payload):
    """Change only N2 BUILD actions and their icon siblings, never Clean etc.

    The source build still contains the old installer ID. Without this migration
    its Service/Update action would point back to N2 after every installation.
    Also modernizes PlayMedia to RunPlugin for instant non-player plugin invocation.
    XML is only reserialized if such a build route really exists; comments stay.
    """
    if b'plugin.program.n2' not in payload and b'PlayMedia' not in payload:
        return payload
    root = ET.fromstring(payload, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
    parents = {child: parent for parent in root.iter() for child in parent}
    changed = False
    old = 'plugin://plugin.program.n2/'
    old_icon = 'special://home/addons/plugin.program.n2/icon.png'
    new_icon = 'special://home/addons/%s/icon.png' % ADDON_ID
    for node in root.iter():
        if node.tag is ET.Comment:
            continue
        value = node.text or ''
        match = re.search(r'plugin://(?:plugin\.program\.n2|plugin\.program\.nova\.installer)/\?([^"\s<>)]*)', value)
        if not match:
            continue
        params = dict(parse_qsl(match.group(1)))
        if params.get('mode') != 'install' or params.get('action') != 'build':
            continue
        new_val = value
        if old in new_val:
            new_val = new_val.replace(old, 'plugin://%s/' % ADDON_ID)
        if new_val.startswith('PlayMedia(') and new_val.endswith(')'):
            new_val = 'RunPlugin(' + new_val[10:]
        if new_val != value:
            node.text = new_val
            changed = True
        parent = parents.get(node, root)
        # In favourites the command is on the favourite itself and its icon is
        # an attribute. In shortcut/compiled skin entries it has icon siblings.
        if node.get('thumb') == old_icon:
            node.set('thumb', new_icon)
            changed = True
        for sibling in parent:
            if sibling.tag in ('icon', 'thumb', 'texture') and sibling.text == old_icon:
                sibling.text = new_icon
                changed = True
    if not changed:
        return payload
    trace.event('update_links_migrated')
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def sanitize_estuary_home_xml(payload):
    """Clean Home.xml: eliminate red boxes during install, keep [REPARIEREN] for emergencies."""
    payload = rewrite_update_links(payload)
    try:
        text = payload.decode('utf-8')
    except UnicodeDecodeError:
        return payload
    lines = text.splitlines(keepends=True)
    start_idx = None
    end_idx = None
    for i, line in enumerate(lines):
        if start_idx is None and '!String.IsEmpty(Window(10000).Property(NovaBuild.InstallActive))' in line:
            for k in range(i, -1, -1):
                if '<control' in lines[k]:
                    start_idx = k
                    break
            if start_idx is not None:
                depth = 0
                for j in range(start_idx, len(lines)):
                    cur = lines[j]
                    for match in re.finditer(r'<control\b', cur):
                        end_tag = cur.find('>', match.start())
                        if end_tag != -1 and cur[end_tag - 1:end_tag] == '/':
                            continue
                        depth += 1
                    depth -= cur.count('</control>')
                    if depth <= 0:
                        end_idx = j
                        break
            break
    if start_idx is not None and end_idx is not None:
        replacement = [
            '\t\t\t<control type="group">\n',
            '\t\t\t\t<depth>DepthMax</depth>\n',
            '\t\t\t\t<visible>!String.IsEmpty(Window(10000).Property(NovaBuild.InstallActive))</visible>\n',
            '\t\t\t\t<animation effect="fade" time="0">VisibleChange</animation>\n',
            '\t\t\t\t<control type="image">\n',
            '\t\t\t\t\t<include>FullScreenDimensions</include>\n',
            '\t\t\t\t\t<aspectratio>scale</aspectratio>\n',
            '\t\t\t\t\t<texture>colors/black.png</texture>\n',
            '\t\t\t\t</control>\n',
            '\t\t\t</control>\n'
        ]
        new_lines = lines[:start_idx] + replacement + lines[end_idx + 1:]
        new_text = ''.join(new_lines)
        return new_text.encode('utf-8')
    return payload


def update_shortcut_xml(name):
    name = name.replace('\\', '/').lower()
    return name.endswith('.xml') and (
        name.startswith('userdata/addon_data/script.skinshortcuts/')
        or name.startswith('userdata/gui_settings/script.skinshortcuts/')
        or name.startswith('userdata/addon_data/plugin.program.super.favourites/super favourites/update/')
        or name.startswith('addons/skin.'))


def migrate_existing_update_links(home):
    """Scoped migration of shortcut/menu update links only.

    Fast path: checks marker so repeated clicks on 'Update' take < 1ms.
    Only checks specific shortcut files, never scans large skin directories.
    """
    marker = os.path.join(home, 'userdata', 'addon_data', ADDON_ID, 'links_migrated_v106')
    if os.path.isfile(marker):
        return 0
    import io
    roots = [
        os.path.join(home, 'userdata', 'favourites.xml'),
        os.path.join(home, 'userdata', 'addon_data', 'script.skinshortcuts'),
        os.path.join(home, 'userdata', 'gui_settings', 'script.skinshortcuts'),
        os.path.join(home, 'userdata', 'addon_data', 'plugin.program.super.favourites', 'Super Favourites', 'Update'),
        os.path.join(home, 'addons', 'skin.estuary', 'xml', 'Home.xml'),
    ]
    changed = 0
    for entry in roots:
        if os.path.isfile(entry):
            candidates = [entry]
        elif os.path.isdir(entry):
            candidates = []
            for parent, dirs, files in os.walk(entry):
                dirs[:] = [name for name in dirs if not os.path.islink(os.path.join(parent, name))]
                for name in files:
                    if name.endswith('.xml'):
                        candidates.append(os.path.join(parent, name))
        else:
            continue
        for path in candidates:
            if os.path.islink(path):
                continue
            with open(path, 'rb') as source:
                before = source.read()
            try:
                if path.replace('\\', '/').lower().endswith('skin.estuary/xml/home.xml'):
                    after = sanitize_estuary_home_xml(before)
                else:
                    after = rewrite_update_links(before)
            except ET.ParseError:
                trace.event('shortcut_xml_skipped', file=path)
                continue
            if after != before:
                atomic_file(io.BytesIO(after), path)
                changed += 1
    try:
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with open(marker, 'w', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S'))
    except Exception:
        pass
    trace.event('existing_update_links_checked', changed_files=changed)
    return changed


def dependency_order(home, addon_id):
    ordered, visited = [], set()
    def walk(current):
        if current in visited or current.startswith(('xbmc.', 'kodi.')):
            return
        visited.add(current)
        path = os.path.join(home, 'addons', current, 'addon.xml')
        if not os.path.isfile(path):
            # Bundled Kodi system resources live outside special://home/addons.
            try:
                system = xbmcaddon.Addon(current)
                path = os.path.join(xbmcvfs.translatePath(system.getAddonInfo('path')), 'addon.xml')
            except RuntimeError:
                raise RuntimeError('Skin-Abhängigkeit fehlt im Build: %s' % current)
        root = ET.parse(path).getroot()
        if root.get('id') != current:
            raise RuntimeError('Ungültige Add-on-Zuordnung: %s' % current)
        for dep in root.findall('./requires/import'):
            if dep.get('optional') != 'true':
                walk(dep.get('addon', ''))
        ordered.append(current)
    walk(addon_id)
    return ordered


def validate_skin_dependencies(archive, entries, home, target):
    """Check the complete required graph before starting the write phase."""
    bundled = {name: info for info, name in entries}
    visited = set()
    def walk(addon_id):
        if addon_id in visited or addon_id.startswith(('xbmc.', 'kodi.')):
            return
        visited.add(addon_id)
        info = bundled.get('addons/%s/addon.xml' % addon_id)
        if info:
            root = ET.fromstring(archive.read(info))
        else:
            path = os.path.join(home, 'addons', addon_id, 'addon.xml')
            if not os.path.isfile(path):
                try:
                    path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path')), 'addon.xml')
                except RuntimeError:
                    raise RuntimeError('Skin-Abhängigkeit fehlt im Build: %s' % addon_id)
            root = ET.parse(path).getroot()
        if root.get('id') != addon_id:
            raise RuntimeError('Ungültige Skin-Abhängigkeit: %s' % addon_id)
        for node in root.findall('./requires/import'):
            if node.get('optional') != 'true':
                walk(node.get('addon', ''))
    walk(target)
    trace.event('skin_dependencies_verified', addons=','.join(sorted(visited)))
    return visited


def cleanup_path(home, relative):
    """Verify EVERY delete target stays below Kodi, without following aliases."""
    root = os.path.abspath(home)
    path = os.path.abspath(os.path.join(root, *safe_name(relative).split('/')))
    if os.path.commonpath((root, path)) != root or path == root:
        raise ValueError('Unsicheres Bereinigungsziel')
    parent = path
    while True:
        if os.path.islink(parent):
            raise ValueError('Verknüpftes Bereinigungsziel ist nicht erlaubt')
        if parent == root:
            break
        parent = os.path.dirname(parent)
    return path


def build_cleanup_plan(home, entries, skin_dependencies):
    """Diff against verified build, not a blind wipe of a running installation.

    Same desired final file coverage as wipe+extract, but old files stay until
    replacement data has been written successfully. All old skin files wait
    until Estuary is active. Live SQLite state remains N3's existing exception.
    """
    accepted = {name.casefold() for _, name in entries}
    build_ids = {name.split('/')[1] for _, name in entries
                 if name.startswith('addons/') and name.endswith('/addon.xml')}
    support = RUNTIME_SUPPORT | (set(skin_dependencies) - build_ids) | {ADDON_ID} | FIREX_MANAGED_ADDONS
    prefixes = {'addons/' + value for value in support}
    prefixes |= {'userdata/addon_data/' + value for value in support}
    prefixes |= {'userdata/database', 'my_builds'}
    files, deferred, directories = [], [], []
    def protected(name):
        lower = name.casefold()
        return (lower in PERSONAL_FILES
                or any(lower == p or lower.startswith(p + '/') for p in prefixes)
                or lower.startswith('temp/') and lower.rsplit('/', 1)[-1] in
                {'kodi.log', 'kodi.old.log', 'xbmc.log', 'xbmc.old.log'})
    for parent, dirs, names in os.walk(home, topdown=True, followlinks=False):
        relative_parent = os.path.relpath(parent, home).replace('\\', '/')
        retained_dirs = []
        for name in dirs:
            relative = name if relative_parent == '.' else relative_parent + '/' + name
            if protected(relative):
                continue
            if os.path.islink(os.path.join(parent, name)):
                raise ValueError('Verknüpfter Build-Ordner ist nicht erlaubt: ' + relative)
            cleanup_path(home, relative)
            directories.append(relative)
            retained_dirs.append(name)
        dirs[:] = retained_dirs
        for name in names:
            relative = name if relative_parent == '.' else relative_parent + '/' + name
            if protected(relative) or relative.casefold() in accepted:
                continue
            cleanup_path(home, relative)  # Reject unsafe old targets BEFORE any writes.
            lower = relative.casefold()
            delayed = lower.startswith(('addons/skin.', 'userdata/addon_data/skin.'))
            (deferred if delayed else files).append(relative)
    obsolete = []
    addon_root = os.path.join(home, 'addons')
    if os.path.isdir(addon_root):
        obsolete = sorted(name for name in os.listdir(addon_root)
                          if re.fullmatch(r'[a-zA-Z0-9_.-]+', name)
                          and os.path.isfile(os.path.join(addon_root, name, 'addon.xml'))
                          and name not in build_ids | support)
    trace.event('build_cleanup_plan', files=len(files), deferred_skin_files=len(deferred),
                obsolete_addons=','.join(obsolete), keep='favourites,sources,advancedsettings,live databases,N3,My_Builds,runtime support')
    return {'files': files, 'deferred': deferred, 'directories': directories, 'obsolete': obsolete}


def stop_obsolete_services(home, plan):
    """Stop only services of add-ons absent from build; no repo/update scans."""
    for addon_id in plan['obsolete']:
        path = cleanup_path(home, 'addons/' + addon_id + '/addon.xml')
        root = ET.parse(path).getroot()
        for node in root.findall("extension[@point='xbmc.service']"):
            library = node.get('library')
            if library:
                script = cleanup_path(home, 'addons/' + addon_id + '/' + library)
                # Quoted built-in argument prevents spaces in external home paths.
                xbmc.executebuiltin('StopScript("%s")' % script.replace('"', ''))
                trace.event('obsolete_service_stop_requested', addon=addon_id, library=library)


def apply_build_cleanup(home, plan, deferred, progress):
    paths = plan['deferred'] if deferred else plan['files']
    deleted = 0
    for index, relative in enumerate(paths):
        progress(index, len(paths))
        path = cleanup_path(home, relative)
        try:
            os.remove(path)
        except FileNotFoundError:
            continue  # Target skin directory may already have been replaced atomically.
        except Exception:
            trace.failure('build_cleanup_failed')
            raise
        deleted += 1
        trace.event('build_file_removed', file=relative, deferred_skin=deferred)
    if deferred:
        # Nonrecursive rmdir: never erase newly written files or a protected child.
        import errno
        for relative in sorted(plan['directories'], key=lambda p: p.count('/'), reverse=True):
            if relative.casefold() in {'addons', 'userdata', 'userdata/addon_data', 'temp',
                                       'media', 'addons/skin.estuary', 'addons/skin.estuary/16x9'}:
                continue  # Core roots and N3's required Estuary bootstrap folder.
            path = cleanup_path(home, relative)
            try:
                os.rmdir(path)
            except OSError as exc:
                if exc.errno not in (errno.ENOENT, errno.ENOTEMPTY, errno.EEXIST):
                    raise
        if plan['obsolete']:
            connection = sqlite3.connect(addon_database(home), timeout=5)
            try:
                with connection:
                    connection.executemany('UPDATE installed SET enabled=0 WHERE addonID=?',
                                           [(addon_id,) for addon_id in plan['obsolete']])
            finally:
                connection.close()
        trace.event('obsolete_addons_removed', addons=','.join(plan['obsolete']))
    trace.event('build_cleanup_complete', deleted_files=deleted, deferred_skin=deferred)


def local_addon_states(archive, entries, work):
    """Read build enable flags without installing its database on this device."""
    ids = set()
    for info, name in entries:
        parts = name.split('/')
        if len(parts) == 3 and parts[0] == 'addons' and parts[2] == 'addon.xml':
            root = ET.fromstring(archive.read(info))
            if root.get('id') != parts[1]:
                raise ValueError('Ungültige Add-on-Zuordnung im Build: %s' % parts[1])
            ids.add(parts[1])
    candidates = []
    for info in archive.infolist():
        match = re.fullmatch(r'userdata/Database/Addons(\d+)\.db', info.filename)
        if match:
            candidates.append((int(match.group(1)), info))
    states = {addon_id: 1 for addon_id in ids}
    if candidates:
        path = os.path.join(work, 'build_addon_flags.db')
        with archive.open(max(candidates, key=lambda item: item[0])[1]) as source:
            atomic_file(source, path)
        connection = sqlite3.connect(path)
        try:
            connection.execute('PRAGMA query_only=ON')
            for addon_id, enabled in connection.execute('SELECT addonID,enabled FROM installed'):
                if addon_id in states:
                    states[addon_id] = 1 if enabled else 0
        finally:
            connection.close()
    trace.event('build_addon_flags', total=len(states), enabled=sum(states.values()))
    return states


def addon_database(home):
    folder = os.path.join(home, 'userdata', 'Database')
    candidates = []
    if os.path.isdir(folder):
        for name in os.listdir(folder):
            match = re.fullmatch(r'Addons(\d+)\.db', name)
            if match:
                candidates.append((int(match.group(1)), os.path.join(folder, name)))
    if not candidates:
        raise RuntimeError('Kodi Add-on-Datenbank wurde nicht gefunden')
    return max(candidates)[1]


def seed_new_addons(home, states):
    """Register copied build add-ons, preserving this device's existing flags.

    Existing disabled add-ons stay disabled. New ones receive the build's own
    enabled flag, not an unconditional 'enable all'. Neither installer changes.
    No repository data/update rules are imported and no DB is replaced/purged.
    """
    connection = sqlite3.connect(addon_database(home), timeout=5)
    try:
        with connection:
            for addon_id, enabled in states.items():
                if addon_id not in PROTECTED:
                    connection.execute('INSERT OR IGNORE INTO installed (addonID,enabled,installDate) VALUES (?,?,?)',
                                       (addon_id, enabled, time.strftime('%Y-%m-%d %H:%M:%S')))
    finally:
        connection.close()
    trace.event('local_addons_seeded', candidates=len(states))


def sync_missing_firex_addons(home, work_dir, progress_fn=None):
    """Ensure all Fire-X repository add-ons are installed and enabled on this device.
    Downloads any missing add-on packages directly from the Fire-X repository.
    """
    installed_new = []
    try:
        response = fetch(FIREX_ADDONS_XML, timeout=20)
        xml_data = response.read()
        response.close()
        root = ET.fromstring(xml_data)
        repo_addons = {}
        for node in root.findall('addon'):
            aid = node.get('id')
            aver = node.get('version')
            if aid and aver and aid in FIREX_MANAGED_ADDONS:
                repo_addons[aid] = aver

        addons_dir = os.path.join(home, 'addons')
        for index, (addon_id, version) in enumerate(sorted(repo_addons.items())):
            target_xml = os.path.join(addons_dir, addon_id, 'addon.xml')
            if not os.path.isfile(target_xml):
                if progress_fn:
                    progress_fn(index, len(repo_addons), 'Fire-X Add-on wird geladen: %s' % addon_id)
                pkg_url = '%s%s/%s-%s.zip' % (FIREX_REPO_BASE, addon_id, addon_id, version)
                zip_target = os.path.join(work_dir, '%s-%s.zip' % (addon_id, version))
                try:
                    with fetch(pkg_url, timeout=30) as resp, open(zip_target, 'wb') as out:
                        shutil.copyfileobj(resp, out, CHUNK)
                    with zipfile.ZipFile(zip_target, 'r') as zf:
                        for item in zf.infolist():
                            if item.is_dir():
                                continue
                            name = safe_name(item.filename)
                            parts = name.split('/')
                            if parts[0] == addon_id:
                                dest_path = os.path.join(addons_dir, *parts)
                                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                                with zf.open(item) as src, open(dest_path, 'wb') as dst:
                                    shutil.copyfileobj(src, dst, CHUNK)
                    installed_new.append(addon_id)
                    trace.event('firex_addon_synced', addon=addon_id, version=version)
                except Exception as dl_exc:
                    trace.event('firex_download_failed', addon=addon_id, error=str(dl_exc))
    except Exception as exc:
        trace.event('firex_sync_warning', error=str(exc))

    for stalker_id in ('plugin.video.stalker.macsimum', 'plugin.video.stalker.macsimum.talker3'):
        res_epg = os.path.join(home, 'addons', stalker_id, 'resources', 'epg')
        os.makedirs(res_epg, exist_ok=True)
    root_epg = os.path.join(home, 'addons', 'plugin.video.stalker.macsimum', 'epg.json')
    res_epg_file = os.path.join(home, 'addons', 'plugin.video.stalker.macsimum', 'resources', 'epg', 'epg.json')
    if os.path.isfile(root_epg) and not os.path.isfile(res_epg_file):
        try:
            shutil.copyfile(root_epg, res_epg_file)
        except Exception:
            pass
    talker_epg_file = os.path.join(home, 'addons', 'plugin.video.stalker.macsimum.talker3', 'resources', 'epg', 'epg.json')
    if os.path.isfile(res_epg_file) and not os.path.isfile(talker_epg_file):
        try:
            shutil.copyfile(res_epg_file, talker_epg_file)
        except Exception:
            pass

    if installed_new:
        try:
            connection = sqlite3.connect(addon_database(home), timeout=5)
            with connection:
                for aid in installed_new:
                    connection.execute('INSERT OR IGNORE INTO installed (addonID,enabled,installDate) VALUES (?,1,?)',
                                       (aid, time.strftime('%Y-%m-%d %H:%M:%S')))
                    connection.execute('UPDATE installed SET enabled=1 WHERE addonID=?', (aid,))
            connection.close()
            trace.event('firex_addons_registered', count=len(installed_new))
        except Exception as db_exc:
            trace.event('firex_db_register_warning', error=str(db_exc))


def register_skin(home, target, monitor):
    """Local registration only. No downloads or UpdateAddonRepos."""
    ids = dependency_order(home, target)
    # Retain the established clean-install bootstrap used in N3 2.0.7.5.
    # Only local target-skin dependencies; never purge/replace a database.
    connection = sqlite3.connect(addon_database(home), timeout=5)
    try:
        with connection:
            for addon_id in ids:
                # System dependencies are handled by Kodi, not imported into its user DB.
                if not os.path.isfile(os.path.join(home, 'addons', addon_id, 'addon.xml')):
                    continue
                connection.execute('INSERT OR IGNORE INTO installed (addonID, enabled, installDate) VALUES (?,1,?)',
                                   (addon_id, time.strftime('%Y-%m-%d %H:%M:%S')))
                connection.execute('UPDATE installed SET enabled=1 WHERE addonID=?', (addon_id,))
    finally:
        connection.close()
    xbmc.executebuiltin('UpdateLocalAddons')
    for _ in range(40):
        try:
            if xbmcaddon.Addon(target).getAddonInfo('id') == target:
                break
        except RuntimeError:
            pass
        if monitor.waitForAbort(0.5):
            raise Cancelled()
    else:
        raise RuntimeError('Nova-Skin wurde von Kodi nicht registriert')
    for addon_id in ids:
        if addon_id != target:
            rpc('Addons.SetAddonEnabled', addonid=addon_id, enabled=True)
    trace.event('skin_registered', target=target, dependencies=','.join(ids))


def switch_skin(target, monitor):
    if setting('lookandfeel.skin') == target:
        return
    import threading
    errors = []
    def change():
        try:
            rpc('Settings.SetSettingValue', setting='lookandfeel.skin', value=target)
        except Exception as exc:
            errors.append(exc)
    worker = threading.Thread(target=change, daemon=True)
    worker.start()
    deadline = time.monotonic() + 20
    while worker.is_alive() and time.monotonic() < deadline:
        if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
            xbmc.executebuiltin('SendClick(yesnodialog,11)')
        if monitor.waitForAbort(0.02):
            raise Cancelled()
    worker.join(timeout=5)
    if errors:
        raise errors[0]
    for _ in range(15):
        if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
            xbmc.executebuiltin('SendClick(yesnodialog,11)')
        if setting('lookandfeel.skin') == target:
            break
        if monitor.waitForAbort(0.05):
            raise Cancelled()
    if setting('lookandfeel.skin') != target:
        raise RuntimeError('Nova-Skin konnte nicht aktiviert werden')
    trace.event('skin_switch', target=target)


class Installer:
    def __init__(self):
        self.home = xbmcvfs.translatePath('special://home/')
        self.data = xbmcvfs.translatePath('special://profile/addon_data/' + ADDON_ID)
        self.work = os.path.join(self.data, 'work')
        self.marker = os.path.join(self.data, 'install_in_progress')
        self.monitor = xbmc.Monitor()
        self.dialog = xbmcgui.Dialog()
        self.dp = None
        self.writing = False
        self.last_progress = 0.0
        self.last_percent = -1

    def progress(self, percent, text, allow_cancel=True):
        if self.monitor.abortRequested() or allow_cancel and self.dp.iscanceled():
            raise Cancelled()
        now = time.monotonic()
        if percent != self.last_percent or now - self.last_progress >= 0.2:
            self.dp.update(percent, '[COLOR %s][B]%s[/B][/COLOR]' % (COLOR, text))
            self.last_percent = percent
            self.last_progress = now

    def record_marker(self, phase):
        with open(self.marker, 'w', encoding='utf-8') as output:
            json.dump({'version': '1.0.8', 'phase': phase, 'time': time.time()}, output)
        trace.event('install_phase', phase=phase)

    def download(self, url, path):
        with fetch(url) as response, open(path, 'xb') as output:
            total = int(response.headers.get('Content-Length') or 0)
            free = shutil.disk_usage(self.home).free
            if total and free < total + RESERVE:
                raise RuntimeError('Nicht genügend Speicher für den Build-Download')
            downloaded = 0
            while True:
                block = response.read(CHUNK)
                if not block:
                    break
                output.write(block)
                downloaded += len(block)
                if not total and downloaded + RESERVE > free:
                    raise RuntimeError('Nicht genügend Speicher für den Build-Download')
                self.progress(int(downloaded * 20 / total) if total else 0, 'Nova Update wird heruntergeladen')
            if downloaded == 0 or total and downloaded != total:
                raise RuntimeError('Der Build-Download ist unvollständig')
        trace.event('download_complete', bytes=downloaded)

    def verify(self, archive, entries):
        # Stream CRC verification before modifying ANY existing Kodi content.
        for index, (info, _) in enumerate(entries):
            with archive.open(info) as source:
                while source.read(CHUNK):
                    self.progress(20 + int(10 * index / len(entries)), 'Nova Update wird überprüft')
        trace.event('archive_verified', files=len(entries))

    def extract(self, archive, entries, target, stage):
        gui = None
        for index, (info, name) in enumerate(entries):
            self.progress(30 + int(60 * index / len(entries)), 'Nova Update wird installiert', allow_cancel=False)
            if name == 'userdata/guisettings.xml':
                gui = archive.read(info)
                continue
            if name.casefold() in PERSONAL_FILES:
                existing_personal = os.path.join(self.home, *name.split('/'))
                if os.path.isfile(existing_personal):
                    trace.event('favourites_preserved' if name.casefold() == 'userdata/favourites.xml'
                                else 'personal_settings_preserved', path=existing_personal)
                    continue
            destination = stage if skin_payload(name, target) else self.home
            path = os.path.join(destination, *name.split('/'))
            # Also reject pre-existing parent symlinks; lexical ZIP validation alone
            # cannot protect a destination which was redirected outside Kodi.
            parent = path
            while parent != os.path.dirname(destination):
                if os.path.islink(parent):
                    raise ValueError('Verknüpftes Installationsziel ist nicht erlaubt')
                if parent == destination:
                    break
                parent = os.path.dirname(parent)
            with archive.open(info) as source:
                if name.replace('\\', '/').lower() == 'addons/skin.estuary/xml/home.xml':
                    import io
                    payload = sanitize_estuary_home_xml(source.read())
                    atomic_file(io.BytesIO(payload), path)
                elif update_shortcut_xml(name):
                    import io
                    # Only matching old build-action URLs are changed. XML in
                    # Stalker, other video add-ons, Clean/Handshake etc. is untouched.
                    payload = source.read()
                    atomic_file(io.BytesIO(rewrite_update_links(payload)), path)
                else:
                    atomic_file(source, path)
            if name.lower() in ('media/splash.jpg', 'media/splash.png'):
                trace.event('startup_image_written', file=name, bytes=info.file_size)
            if index % 200 == 0:
                trace.event('extract_progress', file=name, entry=index, total=len(entries))
        trace.event('extract_complete', files=len(entries))
        return gui

    def finalize_gui(self, gui, target):
        if gui is None:
            existing = os.path.join(self.home, 'userdata', 'guisettings.xml')
            if os.path.isfile(existing):
                with open(existing, 'rb') as f:
                    gui = f.read()
            else:
                return
        root = ET.fromstring(gui)
        for key, value in [('lookandfeel.skin', target), ('general.addonupdates', '2')]:
            node = root.find(".//setting[@id='%s']" % key)
            if node is None:
                node = ET.SubElement(root, 'setting', {'id': key})
            node.text = value
        import io
        atomic_file(io.BytesIO(ET.tostring(root, encoding='utf-8', xml_declaration=True)),
                    os.path.join(self.home, 'userdata', 'guisettings.xml'))
        trace.event('gui_settings_finalized', skin=target)

    def install(self):
        # Immediate UI reaction: ask confirmation before performing network calls.
        if not self.dialog.yesno(TITLE,
                '[COLOR springgreen]Möchtest du das neue Nova Update installieren?[/COLOR]',
                nolabel='[COLOR red]Abbrechen[/COLOR]', yeslabel='[COLOR springgreen]Installieren[/COLOR]'):
            trace.finish('cancelled_before_download')
            return
        if setting('general.addonupdates') != 2:
            rpc('Settings.SetSettingValue', setting='general.addonupdates', value=2)
            trace.event('global_updates_locked')
        if os.path.isfile(self.marker):
            if not self.dialog.yesno(TITLE, 'Die letzte Installation wurde nicht vollständig abgeschlossen\nNova Update erneut installieren?',
                                    nolabel='Abbrechen', yeslabel='Installieren'):
                return
        os.makedirs(self.data, exist_ok=True)
        if os.path.isdir(self.work):
            shutil.rmtree(self.work)  # This installer's own temporary files only.
        os.makedirs(self.work)
        self.dp = xbmcgui.DialogProgress()
        self.dp.create(TITLE, 'Nova Update wird vorbereitet...')
        self.progress(0, 'Build-Informationen werden geladen')
        info = manifest()
        path = os.path.join(self.work, 'nova.zip')
        self.progress(5, 'Nova Update wird heruntergeladen')
        self.download(info['url'], path)
        with zipfile.ZipFile(path) as archive:
            entries = inventory(archive)
            target = skin_id(archive, entries, xbmc.getSkinDir())
            skin_dependencies = validate_skin_dependencies(archive, entries, self.home, target)
            required = sum(i.file_size for i, _ in entries) + RESERVE
            free = shutil.disk_usage(self.home).free
            trace.event('space_check', free_bytes=free, required_bytes=required)
            if free < required:
                raise RuntimeError('Nicht genügend Speicher für die sichere Installation\nBenötigt: %s MB, frei: %s MB' %
                                   ((required + 1048575) // 1048576, free // 1048576))
            self.verify(archive, entries)
            states = local_addon_states(archive, entries, self.work)
            cleanup = build_cleanup_plan(self.home, entries, skin_dependencies)
            # Cancel is safe up to here, then a partial install must not be presented
            # as an intact build. Abort/shutdown is still honoured and recorded.
            self.progress(30, 'Nova Update wird installiert')
            self.writing = True
            self.record_marker('installing')
            stop_obsolete_services(self.home, cleanup)
            stage = os.path.join(self.work, 'skin')
            gui = self.extract(archive, entries, target, stage)
        self.progress(90, 'Nova-Skin wird vorbereitet', allow_cancel=False)
        self.record_marker('skin_staged')
        xbmcgui.Window(10000).setProperty('NovaBuild.InstallActive', 'True')
        # Provide a 16x9 folder in Estuary so script.skinshortcuts will never
        # encounter a FileNotFoundError if triggered while parked on Estuary.
        os.makedirs(os.path.join(self.home, 'addons', 'skin.estuary', '16x9'), exist_ok=True)
        # Keep active skin throughout transfer; only final directory swap runs on Estuary.
        switch_skin('skin.estuary', self.monitor)
        apply_build_cleanup(self.home, cleanup, False,
                            lambda i, n: self.progress(92, 'Alte Build-Dateien werden bereinigt', allow_cancel=False))
        for relative in ('userdata/addon_data/' + target, 'addons/' + target):
            source = os.path.join(stage, *relative.split('/'))
            if os.path.isdir(source):
                replace_directory(source, os.path.join(self.home, *relative.split('/')))
        apply_build_cleanup(self.home, cleanup, True,
                            lambda i, n: self.progress(94, 'Skin-Abschluss und Bereinigung', allow_cancel=False))
        self.record_marker('skin_committed')
        self.progress(95, 'Fire-X Add-ons werden geprüft', allow_cancel=False)
        seed_new_addons(self.home, states)
        sync_missing_firex_addons(self.home, self.work,
                                  lambda i, n, msg: self.progress(95 + int(i / max(n, 1)), msg, allow_cancel=False))
        self.progress(97, 'Nova-Skin wird registriert', allow_cancel=False)
        register_skin(self.home, target, self.monitor)
        # Finalize guisettings.xml with target skin before closing progress and showing completion
        self.finalize_gui(gui, target)
        self.progress(100, 'Nova Update wurde installiert', allow_cancel=False)
        if self.dp:
            self.dp.close()
            self.dp = None
        # PURE BUILD INSTALLER ARCHITECTURE:
        # Kodi remains safely parked on the clean Estuary canvas during the shutdown prompt.
        # This completely avoids loading heavy skin startup scripts, widgets, and ReplaceWindow
        # transitions in a dying process, guaranteeing the completion dialog NEVER closes
        # on its own and no widgets or banners flash before force close.
        self.dialog.ok(TITLE, COMPLETION)
        # Re-commit guisettings immediately after OK as an atomic guarantee
        self.finalize_gui(gui, target)
        self.record_marker('complete')
        if os.path.exists(self.marker):
            os.remove(self.marker)
        shutil.rmtree(self.work, ignore_errors=True)
        self.writing = False
        trace.finish('installation_success_force_close')
        os._exit(1)  # Established Android build installer shutdown, after the user's OK.


def run(argv):
    params = dict(parse_qsl(argv[2].lstrip('?'))) if len(argv) > 2 else {}
    mode = params.get('mode', '')
    action = params.get('action', '')
    if mode not in ('', 'install') or action not in ('', 'build'):
        xbmcgui.Dialog().ok(TITLE, 'N3 ist jetzt ausschließlich der Nova Build-Installer\nReinigung erfolgt weiterhin über EZ Maintenance')
        trace.finish('unsupported_legacy_action')
        return
    installer = Installer()
    # Scoped migration of shortcut/menu update links if needed (never reloads skin on click).
    migrate_existing_update_links(installer.home)
    # Cross-invocation lock: Kodi plugin interpreters share a process but not globals.
    os.makedirs(installer.data, exist_ok=True)
    lock = os.path.join(installer.data, 'install_lock')
    if os.path.isfile(lock):
        try:
            with open(lock, encoding='utf-8') as source:
                owner = json.load(source)
            if owner['pid'] == os.getpid() and (
                    xbmcgui.Window(10000).getProperty('NovaInstaller.InstallRunning') == owner.get('token')
                    or time.time() - owner.get('time', 0) < 10):
                xbmcgui.Dialog().ok(TITLE, 'Nova Update wird bereits ausgeführt')
                return
            os.remove(lock)  # Stale previous process/invocation, including recycled PIDs.
        except (ValueError, KeyError):
            raise RuntimeError('N3-Installationssperre ist ungültig')
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return
    token = uuid.uuid4().hex
    with os.fdopen(fd, 'w', encoding='utf-8') as output:
        json.dump({'pid': os.getpid(), 'time': time.time(), 'token': token}, output)
    xbmcgui.Window(10000).setProperty('NovaInstaller.InstallRunning', token)
    try:
        installer.install()
    except Cancelled:
        trace.finish('interrupted' if installer.writing else 'cancelled_before_install')
        if installer.writing:
            installer.dialog.ok(TITLE, 'Installation unterbrochen\nDas Build muss erneut vollständig installiert werden')
    except Exception as exc:
        trace.failure('installer_exception')
        trace.finish('failed')
        if installer.dp:
            installer.dp.close()
            installer.dp = None
        installer.dialog.ok(TITLE, 'Nova Update konnte nicht abgeschlossen werden\n%s\nDer Fehler wurde im N3-Diagnosebericht gespeichert' % trace._clean(exc))
    finally:
        if installer.dp:
            installer.dp.close()
        if os.path.exists(lock):
            os.remove(lock)
        xbmcgui.Window(10000).clearProperty('NovaInstaller.InstallRunning')
        xbmcgui.Window(10000).clearProperty('NovaBuild.InstallActive')
        if not installer.writing and os.path.isdir(installer.work):
            shutil.rmtree(installer.work)
        # Preserve work/marker after a write-phase error for diagnosis/recovery.
        if len(argv) > 1 and argv[1].lstrip('-').isdigit() and int(argv[1]) >= 0:
            xbmcplugin.endOfDirectory(int(argv[1]), succeeded=False, cacheToDisc=False)
