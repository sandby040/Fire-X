"""Optional Live TV 1 worker. Native menus/signature formats are unchanged."""
if __name__ == '__main__':
    import sys
    import xbmcvfs
    sys.path.insert(0, xbmcvfs.translatePath('special://home/addons/plugin.video.iptvmaster/resources/lib'))
    from livetv1_native_worker import run
    run(sys.argv[1], 'plugin.video.kodiboxtv')
