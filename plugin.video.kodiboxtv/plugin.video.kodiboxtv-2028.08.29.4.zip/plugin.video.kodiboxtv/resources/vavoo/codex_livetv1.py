"""Country-scoped Live TV 1 entry: keep the native signature/player path.

No signed playback URL, token or ID is persisted by this bridge. The raw
catalog name identifies one variant; native resolve_link obtains its token.
Normal Kodibox menus and filter settings are not changed.
"""
import re
import unicodedata


def normalize(name):
    name = unicodedata.normalize('NFKD', name.replace('\u00df', 'ss')).encode('ascii', 'ignore').decode().upper()
    name = re.sub(r'\s+\.[A-Z]$', '', name)
    name = re.sub(r'^(?:DE|AT|CH|FR|IT|NL|UK|GB|ES|PT|PL|TR|RU|RO|BG|AL)\s*[:|]\s*', '', name)
    name = re.sub(r'\([^)]*\)|\[[^]]*\]', ' ', name)
    name = re.sub(r'\b(?:FHD|UHD|QHD|HD|SD)\+(?!\d)', ' ', name)
    name = re.sub(r'\b(?:FHD|UHD|QHD|HD|SD|HEVC|H[.]?26[45]|RAW|4K|8K|720P|1080P|2160P)\b', ' ', name)
    return re.sub(r'[^A-Z0-9+]', '', name)


ALIASES_DE = {
    'PROSIEBEN': 'PRO7', 'PROSIEBENMAXX': 'PRO7MAXX', 'PROSIEBENFUN': 'PRO7FUN',
    'KABELEINS': 'KABEL1', 'KABELEINSDOKU': 'KABEL1DOKU',
    'KABELEINSCLASSICS': 'KABEL1CLASSICS', 'RTLZWEI': 'RTL2', 'RTLII': 'RTL2',
    'DASERSTE': 'ARD', 'RTLPLUS': 'RTLUP', 'NICK': 'NICKELODEON',
    'NICKJR': 'NICKJUNIOR', 'TNTFILM': 'WARNERTVFILM', 'TNTSERIE': 'WARNERTVSERIE',
    'TNTCOMEDY': 'WARNERTVCOMEDY', 'SONYAXN': 'AXNWHITE', 'SONYCHANNEL': 'AXNBLACK',
    'SPIEGELTVWISSEN': 'CURIOSITYCHANNEL', 'SPIEGELWISSEN': 'CURIOSITYCHANNEL',
    'DISCOVERYCHANNEL': 'DISCOVERY', 'HISTORYCHANNEL': 'HISTORY',
    'TAGESSCHAU24': 'TAGESSCHAU24', 'ARTEDEUTSCH': 'ARTE',
    'BRFERNSEHEN': 'BR', 'BRTV': 'BR', 'MDRFERNSEHEN': 'MDR',
    'RBBFERNSEHEN': 'RBB', 'WDRFERNSEHEN': 'WDR', 'ATVII': 'ATV2',
    'AUTOMOTORUNDSPORTCHANNEL': 'AUTOMOTORSPORT',
    'SERVUSTVOSTERREICH': 'SERVUSTVOESTERREICH',
    'SPORTDIGITALLFUSSBALL': 'SPORTDIGITALFUSSBALL',
}


def identity(name, country):
    key = normalize(name)
    if country == 'Germany':
        key = re.sub(r'^SKYSPORTBUNDESLIGA(\d*)$', r'SKYBUNDESLIGA\1', key)
    return ALIASES_DE.get(key, key) if country == 'Germany' else key


def select_variant(rows, country, raw_name, slot):
    """Exact name/country only; never fall through to another channel."""
    if not country or not raw_name or slot < 0:
        return []
    matches = []
    for row in rows:
        if row.get('group') == country and row.get('name') == raw_name:
            url = row.get('url')
            if url and url not in matches:
                matches.append(url)
    return matches[slot:slot + 1]


def play(params, started=None):
    from vavoo import utils, vavoo_tv, vjlive
    import xbmc
    import xbmcgui
    import xbmcplugin
    import sys
    import time
    from vavoo import codex_catalog_cache
    country = params.get('group', '')
    raw_name = params.get('codex_raw', '')
    name = params.get('name') or raw_name
    completed = []
    started = time.monotonic() if started is None else started
    xbmc.log('[Live TV 1] Kodibox TV start request: country=%s name=%s' % (country, name), xbmc.LOGINFO)
    xbmc.log('[Live TV 1] Kodibox TV imports ready: elapsed_ms=%d'
             % int((time.monotonic() - started) * 1000), xbmc.LOGINFO)
    try:
        slot = int(params.get('codex_slot', '0'))
        if not country or not raw_name or slot < 0:
            raise ValueError('invalid source parameters')
        rows, mode = codex_catalog_cache.catalog_rows(utils, vavoo_tv, country, raw_name, slot, select_variant)
        xbmc.log('[Live TV 1] Kodibox TV catalog: mode=%s elapsed_ms=%d'
                 % (mode, int((time.monotonic() - started) * 1000)), xbmc.LOGINFO)
        selected = select_variant(rows, country, raw_name, slot)
        xbmc.log('[Live TV 1] Kodibox TV native source: country=%s name=%s variants=%d'
                 % (country, name, len(selected)), xbmc.LOGINFO)
        if not selected:
            raise ValueError('catalog variant not present')
        # Scope to this plugin invocation, and restore even after an exception.
        # A single variant means native livePlay makes at most one resolve attempt.
        original = vjlive.getchannels
        original_resolved = vjlive.set_resolved
        original_resolver = vjlive.resolve_link
        def resolved(item):
            xbmc.log('[Live TV 1] Kodibox TV ready for player: elapsed_ms=%d'
                     % int((time.monotonic() - started) * 1000), xbmc.LOGINFO)
            original_resolved(item)
            completed.append(True)
        try:
            vjlive.getchannels = lambda type=None, group=None: {name: selected}
            vjlive.set_resolved = resolved
            # Selected variants are opened once by the actual player, not by
            # a redundant probe followed by a second connection to the same URL.
            vjlive.resolve_link = lambda link: original_resolver(link, precheck=False)
            vjlive.livePlay(name, 'vavoo', country)
        finally:
            vjlive.getchannels = original
            vjlive.set_resolved = original_resolved
            vjlive.resolve_link = original_resolver
        if not completed:
            raise ValueError('native resolver returned no stream')
    except Exception as exc:
        xbmc.log('[Live TV 1] Kodibox TV source unavailable: %s' % type(exc).__name__, xbmc.LOGWARNING)
        if completed:
            return
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('Kodibox TV', 'Quelle nicht erreichbar',
                                      utils.addonInfo('icon'), 3500)
