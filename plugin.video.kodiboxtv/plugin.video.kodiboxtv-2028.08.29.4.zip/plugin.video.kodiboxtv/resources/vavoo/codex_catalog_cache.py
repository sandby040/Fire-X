"""Short-lived public catalog cache, separate from authentication/session data.

AutoClean removes the native cache at startup. A single compressed snapshot
keeps only catalog names/groups/source identifiers for at most 30 minutes.
It never contains a resolved stream URL or an authentication signature.
"""
import json
import os
import tempfile
import time
from urllib.parse import parse_qsl, urlsplit
import zlib

MAX_AGE = 30 * 60
MAX_BYTES = 8 * 1024 * 1024
PRIVATE_KEYS = {'token', 'sig', 'signature', 'mediahubmx-signature', 'auth', 'authorization'}


def public_rows(rows):
    result = []
    if not isinstance(rows, list):
        return result
    for row in rows:
        if not isinstance(row, dict):
            continue
        name, country, url = row.get('name'), row.get('group'), row.get('url')
        if not all(isinstance(v, str) and v for v in (name, country, url)):
            continue
        parsed = urlsplit(url)
        # Only stable native VAVOO catalog handles, not signed media URLs.
        if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('vavoo.to', 'www.vavoo.to'):
            continue
        if parsed.username or parsed.password or parsed.fragment:
            continue
        if PRIVATE_KEYS & {k.lower() for k, _ in parse_qsl(parsed.query)}:
            continue
        result.append({'name': name, 'group': country, 'url': url})
    return result


def read(path, now=None):
    now = time.time() if now is None else now
    try:
        with open(path, 'rb') as file:
            packed = file.read(MAX_BYTES + 1)
        if len(packed) > MAX_BYTES:
            return []
        decoder = zlib.decompressobj()
        raw = decoder.decompress(packed, MAX_BYTES + 1)
        if len(raw) > MAX_BYTES or not decoder.eof:
            return []
        data = json.loads(raw.decode('utf-8'))
        stamp = float(data['checked_at'])
        if data.get('schema') != 1 or not 0 <= now - stamp < MAX_AGE:
            return []
        return public_rows(data.get('channels'))
    except (OSError, ValueError, TypeError, KeyError, zlib.error):
        return []


def write(path, rows, checked_at=None):
    rows = public_rows(rows)
    if not rows:
        return False
    data = {'schema': 1, 'checked_at': time.time() if checked_at is None else checked_at, 'channels': rows}
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    if len(raw) > MAX_BYTES:
        return False
    directory = os.path.dirname(path)
    temporary = None
    try:
        os.makedirs(directory, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='catalog-', suffix='.tmp', dir=directory)
        with os.fdopen(fd, 'wb') as file:
            file.write(zlib.compress(raw))
        os.replace(temporary, path)
        return True
    except OSError:
        return False
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)


def catalog_rows(utils, vavoo_tv, country, raw_name, slot, select_variant):
    """Use a recent exact match; one native refresh only if it is absent/stale."""
    snapshot = os.path.join(utils.addonprofile, 'catalog', 'livetv1_catalog.zlib')
    rows = read(snapshot)
    if select_variant(rows, country, raw_name, slot):
        return rows, 'snapshot'

    # The native disk file's age is evidence of when that catalog was obtained.
    # Never renew the age merely because cached data was read.
    native_path = os.path.join(utils.cachepath, 'vav_channels')
    try:
        stamp = os.path.getmtime(native_path)
    except OSError:
        stamp = 0
    if 0 <= time.time() - stamp < MAX_AGE:
        valid, data = utils.get_cache('vav_channels')
        rows = public_rows(data.get('channels')) if valid and isinstance(data, dict) else []
        if select_variant(rows, country, raw_name, slot):
            write(snapshot, rows, checked_at=stamp)
            return rows, 'native-cache'

    # Preserve the existing native catalog/signature refresh. No retry loop here.
    if not vavoo_tv.get_vav_channels([country]):
        raise ValueError('native catalog unavailable')
    valid, data = utils.get_cache('vav_channels')
    rows = public_rows(data.get('channels')) if valid and isinstance(data, dict) else []
    if rows:
        write(snapshot, rows)
    return rows, 'native-refresh'
