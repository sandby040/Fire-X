# -*- coding: utf-8 -*-
import os
import json
import re
import shutil
import tempfile
import zipfile
from xml.etree import ElementTree as ET
from firex_packages import package_stage, commit_stage, reconcile_legacy_overlay

import xbmc
import xbmcgui
import xbmcvfs

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


ADDON_ID = "service.firex.updater"
BASE_URL = "https://sandby040.github.io/Fire-X/"
ADDONS_XML_URL = BASE_URL + "addons.xml"
TAXI_YELLOW = "FFC58A00"
EMPTY_NOTICE_HEADING = " "
STARTUP_DELAY_MS = 1500
HTTP_TIMEOUT = 20

# Nur diese Add-ons duerfen von diesem eigenen Updater angefasst werden.
# Fremde Repos und beliebige Kodi-Updates bleiben ausgeschlossen.
MANAGED_ADDONS = {
    "repository.stube.nova",
    "plugin.video.mediabox.filmeundserien",
    "plugin.video.mediabox.livetv",
    "plugin.video.mediabox.stalker",
    "plugin.video.mediabox.xxx",
    "script.mediabox",
    "plugin.video.streaming.archiv",
    "plugin.video.archiv.navigator",
    "pvr.iptvsimple",
    "pvr.stalker",
    "script.module.pvr",
    "plugin.video.iptvmaster",
    "plugin.video.vodkool",
    "plugin.video.kodiboxtv",
    "plugin.video.playlistloader.macsimum",
    "script.codex.livetv.handshake",
    "service.talker3.autobridge",
    "service.stube.guard",
    "service.firex.updater",
    "script.ezmaintenanceplus",
    "script.speedtester",
    "plugin.video.tools",
    "plugin.video.xxx",
    "script.module.resolveurl.xxx",
    "script.nova.xxx.toggle",
    # Eigene, lokal angepasste Trailer-Basis. Nur die von uns gebaute
    # Fire-X-Fassung wird aktualisiert; fremde Kodi-Repos bleiben gesperrt.
    "plugin.video.youtube",
    # Lokal angepasste Wetter-/Versionsanzeige. Persoenliche Ortsdaten und
    # userdata-Einstellungen werden nicht ueber das Repository verteilt.
    "weather.gismeteo",
    # M3U-, EPG- und Bridge-Daten fuer Live TV 1/2/3. Eine neue Version wird
    # nur beim bewusst ausgefuehrten Repo-Build erzeugt.
    "service.stube.livetv.data",
    "plugin.program.nova.installer",
}


def log(message, level=xbmc.LOGINFO):
    xbmc.log("%s: %s" % (ADDON_ID, message), level)


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:
        return xbmc.translatePath(path)


# Das eigene Nova-Update-Icon ersetzt bei allen sichtbaren Meldungen Kodis
# generisches Info-Symbol. Die spaete Initialisierung ist noetig, weil der
# Pfadhelfer oberhalb erst definiert werden muss.
UPDATE_ICON = translate("special://home/addons/service.firex.updater/icon.png")


def color(text):
    return "[COLOR %s][B]%s[/B][/COLOR]" % (TAXI_YELLOW, text)


def notify(message, duration=10000):
    try:
        xbmcgui.Dialog().notification(EMPTY_NOTICE_HEADING, message, UPDATE_ICON, duration, False)
    except Exception:
        xbmc.executebuiltin("Notification( ,%s,%d,%s)" % (message, duration, UPDATE_ICON))


def early_notice_was_shown():
    try:
        return xbmcgui.Window(10000).getProperty("FireXUpdater.EarlyNotice") == "1"
    except Exception:
        return False


def version_key(version):
    parts = []
    for part in re.split(r"([0-9]+)", version or ""):
        if part == "":
            continue
        if part.isdigit():
            parts.append((1, int(part)))
        else:
            parts.append((0, part.lower()))
    return parts


def version_newer(remote, local, addon_id=None):
    # Explicit user-authorized version reset for Streaming Archiv only.
    # Existing 99.99.99.x clients move to the new 1.x series on the next check.
    # No general downgrade permission and no change for other addons.
    if (addon_id == 'plugin.video.streaming.archiv'
            and re.fullmatch(r'99\.99\.99\.\d+', local or '')
            and re.fullmatch(r'1\.\d+\.\d+', remote or '')):
        return True
    if not local:
        return True
    return version_key(remote) > version_key(local)


def local_addon_version(addon_id):
    addon_xml = os.path.join(translate("special://home/addons"), addon_id, "addon.xml")
    if not os.path.exists(addon_xml):
        return ""
    try:
        root = ET.parse(addon_xml).getroot()
        return root.attrib.get("version", "")
    except Exception as exc:
        log("Lokale Version konnte nicht gelesen werden: %s (%s)" % (addon_id, exc), xbmc.LOGWARNING)
        return ""


def http_get(url):
    req = Request(url, headers={"User-Agent": "Fire-X-Kodi-Updater/1.0"})
    with urlopen(req, timeout=HTTP_TIMEOUT) as response:
        return response.read()


def load_remote_addons():
    data = http_get(ADDONS_XML_URL)
    root = ET.fromstring(data)
    remote = {}
    for addon in root.findall("addon"):
        addon_id = addon.attrib.get("id", "")
        if addon_id not in MANAGED_ADDONS:
            continue
        version = addon.attrib.get("version", "")
        if not version:
            continue
        remote[addon_id] = version
    return remote


def package_url(addon_id, version):
    return "%s%s/%s-%s.zip" % (BASE_URL, addon_id, addon_id, version)


def install_package(addon_id, version, progress=None, index=1, total=1):
    if addon_id not in MANAGED_ADDONS or not re.match(r'^[A-Za-z0-9.+_-]+$', version):
        raise ValueError('Nicht freigegebenes Fire-X-Paket')
    url = package_url(addon_id, version)
    if progress:
        progress.update(int((index - 1) * 100 / max(total, 1)),
                        color("%s wird geladen" % addon_id))
    log("Update download: %s %s %s" % (addon_id, version, url))

    temp_root = os.path.join(translate("special://temp"), "firex_updater")
    if not os.path.exists(temp_root):
        os.makedirs(temp_root)
    tmp_dir = tempfile.mkdtemp(prefix="firex_update_", dir=temp_root)
    zip_path = os.path.join(tmp_dir, "%s-%s.zip" % (addon_id, version))
    try:
        data = http_get(url)
        with open(zip_path, "wb") as fh:
            fh.write(data)
        if not zipfile.is_zipfile(zip_path):
            raise RuntimeError("Download ist kein gueltiges ZIP")

        if progress:
            progress.update(int((index - 0.35) * 100 / max(total, 1)),
                            color("%s wird installiert" % addon_id))
        addons_root = translate("special://home/addons")
        stage = os.path.join(tmp_dir, 'payload')
        os.makedirs(stage)
        with zipfile.ZipFile(zip_path, "r") as zf:
            package_stage(zf, addon_id, version, stage)
        mode = commit_stage(stage, os.path.join(addons_root, addon_id), addon_id)
        log("Update installiert: %s %s (%s)" % (addon_id, version, mode))
        return True
    except Exception as exc:
        log("Update fehlgeschlagen: %s %s (%s)" % (addon_id, version, exc), xbmc.LOGERROR)
        return False
    finally:
        try:
            if not any(name.startswith('rollback-') for name in os.listdir(tmp_dir)):
                shutil.rmtree(tmp_dir)
            else:
                log('Rollback-Sicherung bleibt zur Wiederherstellung erhalten', xbmc.LOGERROR)
        except Exception:
            pass


def run_update_check():
    log("Nova Updates werden geprueft: %s" % ADDONS_XML_URL)
    if xbmc.Player().isPlaying():
        log('Update-Prüfung ohne Installation: aktive Wiedergabe, nächster Start')
        return
    try:
        reconcile_legacy_overlay(translate('special://home/addons'), MANAGED_ADDONS,
            translate('special://profile/addon_data/service.firex.updater/full_packages.json'), log)
    except Exception as exc:
        log('Vollpaket-Migration nicht abgeschlossen: %s' % exc, xbmc.LOGWARNING)

    try:
        remote = load_remote_addons()
    except Exception as exc:
        log("Fire-X Repo konnte nicht geprueft werden: %s" % exc, xbmc.LOGERROR)
        return

    updates = []
    for addon_id in sorted(remote):
        local = local_addon_version(addon_id)
        remote_version = remote[addon_id]
        if version_newer(remote_version, local, addon_id):
            updates.append((addon_id, local, remote_version))

    if not updates:
        log("Keine Nova Updates gefunden")
        return

    installed = 0
    new_addons = []
    total = len(updates)
    for index, (addon_id, local, remote_version) in enumerate(updates, 1):
        if xbmc.Monitor().abortRequested():
            break
        log("Update geplant: %s %s -> %s" % (addon_id, local or "nicht installiert", remote_version))
        if install_package(addon_id, remote_version, None, index, total):
            installed += 1
            if not local:
                new_addons.append(addon_id)

    if installed:
        xbmc.executebuiltin("UpdateLocalAddons")
        if new_addons:
            xbmc.Monitor().waitForAbort(1)
            for addon_id in new_addons:
                reply = xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,
                    'method':'Addons.SetAddonEnabled','params':{'addonid':addon_id,'enabled':True}}))
                log('Neues freigegebenes Add-on aktiviert: %s %s' % (addon_id, reply))
        update_word = "Update" if installed == 1 else "Updates"
        msg = (
            "[B][COLOR white]%d [/COLOR]"
            "[COLOR %s]NOVA[/COLOR]"
            "[COLOR white] %s installiert. [/COLOR]"
            "[COLOR %s]NOVA[/COLOR]"
            "[COLOR white] auf [/COLOR]"
            "[COLOR springgreen]Exit[/COLOR]"
            "[COLOR white] verlassen und neu starten.[/COLOR][/B]"
            % (installed, TAXI_YELLOW, update_word, TAXI_YELLOW)
        )
        notify(msg, 10000)


def main():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(STARTUP_DELAY_MS / 1000.0):
        return
    run_update_check()


if __name__ == "__main__":
    main()
