"""Validated Fire-X package transfer. Never writes to userdata or other addons."""
import hashlib
import json
import os
import shutil
import stat
import uuid
import zipfile
from xml.etree import ElementTree as ET

OVERLAY_IDS = {'plugin.video.stalker.macsimum', 'plugin.video.stalker.macsimum.talker3'}


def package_stage(archive, addon_id, version, stage):
    seen = set()
    for item in archive.infolist():
        name = item.filename.replace('\\', '/')
        parts = name.rstrip('/').split('/')
        if (not parts or parts[0] != addon_id or any(p in ('', '.', '..') or ':' in p for p in parts)
                or name.startswith('/') or '\x00' in name
                or (item.external_attr >> 16) & 0o170000 == stat.S_IFLNK):
            raise ValueError('Unsafe package path')
        key = name.casefold().rstrip('/')
        if key in seen:
            raise ValueError('Duplicate package path')
        seen.add(key)
        if item.is_dir():
            continue
        path = os.path.join(stage, *parts[1:])
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with archive.open(item) as source, open(path, 'xb') as target:
            shutil.copyfileobj(source, target, 256 * 1024)
    root = ET.parse(os.path.join(stage, 'addon.xml')).getroot()
    if root.get('id') != addon_id or root.get('version') != version:
        raise ValueError('Package identity/version mismatch')
    for extension in root.findall('extension'):
        library = extension.get('library')
        if library and library.endswith('.py'):
            path = os.path.join(stage, *library.replace('\\', '/').split('/'))
            if not os.path.isfile(path) and not os.path.isfile(path + 'c'):
                raise ValueError('Package entry point missing: ' + library)


def commit_stage(stage, target, addon_id):
    if os.path.islink(target):
        raise ValueError('Linked addon target')
    parent = os.path.dirname(target)
    if os.stat(stage).st_dev != os.stat(parent).st_dev:
        raise ValueError('Update staging must be on the same filesystem')
    backup = os.path.join(os.path.dirname(stage), 'rollback-' + uuid.uuid4().hex)
    existed = os.path.isdir(target)
    if addon_id in OVERLAY_IDS and existed:
        # Existing Stalker/Talker policy: only overwrite supplied files, no
        # deletion of extra code, and absolutely no profile/MAC/session writes.
        for folder, _, files in os.walk(stage):
            for name in files:
                source = os.path.join(folder, name)
                rel = os.path.relpath(source, stage)
                dest = os.path.join(target, rel)
                real = os.path.realpath(os.path.dirname(dest))
                if os.path.commonpath([os.path.realpath(target), real]) != os.path.realpath(target):
                    raise ValueError('Linked overlay destination')
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                temporary = dest + '.firex-tmp-' + uuid.uuid4().hex
                shutil.copyfile(source, temporary)
                os.replace(temporary, dest)
        return 'overlay'
    if existed:
        os.rename(target, backup)
    try:
        os.rename(stage, target)
    except Exception:
        if existed:
            os.rename(backup, target)
        raise
    if existed:
        shutil.rmtree(backup)  # Only the exact old managed-addon directory.
    return 'full'


def file_hash(path):
    with open(path, 'rb') as stream:
        h = hashlib.sha256()
        for chunk in iter(lambda: stream.read(256 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def reconcile_legacy_overlay(addons_root, managed, receipts_path, log):
    """Old updater clients extract overlays once. Remove leftovers only after
    EVERY supplied code file matches the new package; don't revert local edits.
    Run once per descriptor digest. This migrates those clients on next start.
    """
    try:
        with open(receipts_path, encoding='utf-8') as stream:
            receipts = json.load(stream)
    except (OSError, ValueError):
        receipts = {}
    for addon_id in sorted(set(managed) - OVERLAY_IDS):
        root = os.path.join(addons_root, addon_id)
        descriptor = os.path.join(root, 'firex-package.json')
        if not os.path.isfile(descriptor) or os.path.islink(root):
            continue
        digest = file_hash(descriptor)
        if receipts.get(addon_id) == digest:
            continue
        with open(descriptor, encoding='utf-8') as stream:
            meta = json.load(stream)
        if meta.get('id') != addon_id or meta.get('mode') != 'full':
            continue
        files = meta['files']
        if not isinstance(files, dict) or not files or any(
                not isinstance(name, str) or '\\' in name or '\x00' in name
                or any(part in ('', '.', '..') or ':' in part for part in name.split('/'))
                for name in files):
            raise ValueError('Invalid full-package manifest')
        if any(not os.path.isfile(os.path.join(root, name)) or file_hash(os.path.join(root, name)) != value
               for name, value in files.items()):
            log('Lokale Änderungen bleiben erhalten: ' + addon_id)
            continue
        removed = 0
        for folder, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(folder, d))]
            for name in names:
                path = os.path.join(folder, name)
                rel = os.path.relpath(path, root).replace(os.sep, '/')
                if rel not in files and rel != 'firex-package.json' and not os.path.islink(path):
                    os.remove(path)
                    removed += 1
        receipts[addon_id] = digest
        log('Vollpaket-Migration: %s, alte Dateien entfernt: %d' % (addon_id, removed))
    os.makedirs(os.path.dirname(receipts_path), exist_ok=True)
    with open(receipts_path + '.tmp', 'w', encoding='utf-8') as stream:
        json.dump(receipts, stream)
    os.replace(receipts_path + '.tmp', receipts_path)
