# -*- coding: utf-8 -*-
import os
import re
import shutil
import tempfile
import zipfile
from xml.etree import ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


ADDON_ID = "service.firex.updater"
BASE_URL = "https://sandby040.github.io/Fire-X/"
ADDONS_XML_URL = BASE_URL + "addons.xml"
TAXI_YELLOW = "FFC58A00"
STARTUP_DELAY_MS = 1500
HTTP_TIMEOUT = 20

# Nur diese Add-ons duerfen von diesem eigenen Updater angefasst werden.
# Fremde Repos und beliebige Kodi-Updates bleiben ausgeschlossen.
MANAGED_ADDONS = {
    "repository.stube.nova",
    "plugin.video.mediabox.filmeundserien",
    "plugin.video.mediabox.livetv",
    "plugin.video.mediabox.stalker",
    "plugin.video.mediabox.xxx",
    "script.mediabox",
    "plugin.video.streaming.archiv",
    "plugin.video.archiv.navigator",
    "pvr.iptvsimple",
    "pvr.stalker",
    "script.module.pvr",
    "plugin.video.iptvmaster",
    "plugin.video.vodkool",
    "plugin.video.playlistloader.macsimum",
    "plugin.video.stalker.macsimum",
    "plugin.video.stalker.macsimum.talker3",
    "script.codex.livetv.handshake",
    "service.talker3.autobridge",
    "service.stube.guard",
    "service.firex.updater",
    "script.ezmaintenanceplus",
    "script.speedtester",
    "plugin.video.tools",
    "plugin.video.xxx",
    "script.module.resolveurl.xxx",
    "script.nova.xxx.toggle",
    # Eigene, lokal angepasste Trailer-Basis. Nur die von uns gebaute
    # Fire-X-Fassung wird aktualisiert; fremde Kodi-Repos bleiben gesperrt.
    "plugin.video.youtube",
    # M3U-, EPG- und Bridge-Daten fuer Live TV 1/2/3. Eine neue Version wird
    # nur beim bewusst ausgefuehrten Repo-Build erzeugt.
    "service.stube.livetv.data",
}


def log(message, level=xbmc.LOGINFO):
    xbmc.log("%s: %s" % (ADDON_ID, message), level)


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:
        return xbmc.translatePath(path)


def color(text):
    return "[COLOR %s][B]%s[/B][/COLOR]" % (TAXI_YELLOW, text)


def notify(message, duration=3500):
    try:
        xbmcgui.Dialog().notification("Nova Updates", color(message), xbmcgui.NOTIFICATION_INFO, duration, False)
    except Exception:
        xbmc.executebuiltin("Notification(Nova Updates,%s,%d)" % (message, duration))


def early_notice_was_shown():
    try:
        return xbmcgui.Window(10000).getProperty("FireXUpdater.EarlyNotice") == "1"
    except Exception:
        return False


def version_key(version):
    parts = []
    for part in re.split(r"([0-9]+)", version or ""):
        if part == "":
            continue
        if part.isdigit():
            parts.append((1, int(part)))
        else:
            parts.append((0, part.lower()))
    return parts


def version_newer(remote, local):
    if not local:
        return True
    return version_key(remote) > version_key(local)


def local_addon_version(addon_id):
    addon_xml = os.path.join(translate("special://home/addons"), addon_id, "addon.xml")
    if not os.path.exists(addon_xml):
        return ""
    try:
        root = ET.parse(addon_xml).getroot()
        return root.attrib.get("version", "")
    except Exception as exc:
        log("Lokale Version konnte nicht gelesen werden: %s (%s)" % (addon_id, exc), xbmc.LOGWARNING)
        return ""


def http_get(url):
    req = Request(url, headers={"User-Agent": "Fire-X-Kodi-Updater/1.0"})
    with urlopen(req, timeout=HTTP_TIMEOUT) as response:
        return response.read()


def load_remote_addons():
    data = http_get(ADDONS_XML_URL)
    root = ET.fromstring(data)
    remote = {}
    for addon in root.findall("addon"):
        addon_id = addon.attrib.get("id", "")
        if addon_id not in MANAGED_ADDONS:
            continue
        version = addon.attrib.get("version", "")
        if not version:
            continue
        remote[addon_id] = version
    return remote


def package_url(addon_id, version):
    return "%s%s/%s-%s.zip" % (BASE_URL, addon_id, addon_id, version)


def install_package(addon_id, version, progress, index, total):
    url = package_url(addon_id, version)
    progress.update(int((index - 1) * 100 / max(total, 1)), color("%s wird geladen..." % addon_id))
    log("Update download: %s %s %s" % (addon_id, version, url))

    temp_root = os.path.join(translate("special://temp"), "firex_updater")
    if not os.path.exists(temp_root):
        os.makedirs(temp_root)
    tmp_dir = tempfile.mkdtemp(prefix="firex_update_", dir=temp_root)
    zip_path = os.path.join(tmp_dir, "%s-%s.zip" % (addon_id, version))
    try:
        data = http_get(url)
        with open(zip_path, "wb") as fh:
            fh.write(data)
        if not zipfile.is_zipfile(zip_path):
            raise RuntimeError("Download ist kein gueltiges ZIP")

        progress.update(int((index - 0.35) * 100 / max(total, 1)), color("%s wird installiert..." % addon_id))
        addons_root = translate("special://home/addons")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(addons_root)
        log("Update installiert: %s %s" % (addon_id, version))
        return True
    except Exception as exc:
        log("Update fehlgeschlagen: %s %s (%s)" % (addon_id, version, exc), xbmc.LOGERROR)
        notify("Update fehlgeschlagen: %s" % addon_id, 5000)
        return False
    finally:
        try:
            shutil.rmtree(tmp_dir)
        except Exception:
            pass


def run_update_check():
    if not early_notice_was_shown():
        notify("Nova Updates werden geprüft.", 7000)
    log("Nova Updates werden geprueft: %s" % ADDONS_XML_URL)

    check_progress = xbmcgui.DialogProgressBG()
    try:
        check_progress.create("Nova Updates", color("Nova Updates werden geprüft."))
    except Exception:
        check_progress = None

    try:
        remote = load_remote_addons()
    except Exception as exc:
        log("Fire-X Repo konnte nicht geprueft werden: %s" % exc, xbmc.LOGERROR)
        if check_progress:
            try:
                check_progress.close()
            except Exception:
                pass
        notify("Nova Updates konnten nicht geprüft werden.", 4500)
        return

    updates = []
    for addon_id in sorted(remote):
        local = local_addon_version(addon_id)
        remote_version = remote[addon_id]
        if version_newer(remote_version, local):
            updates.append((addon_id, local, remote_version))

    if not updates:
        log("Keine Nova Updates gefunden")
        if check_progress:
            try:
                check_progress.update(100, color("Nova Updates aktuell."))
                xbmc.sleep(900)
                check_progress.close()
            except Exception:
                pass
        notify("Nova Updates aktuell.", 2500)
        return

    if check_progress:
        try:
            check_progress.close()
        except Exception:
            pass

    notify("%d Nova Update(s) gefunden." % len(updates), 3500)
    progress = xbmcgui.DialogProgressBG()
    installed = 0
    try:
        progress.create(color("Nova Updates"), color("Updates werden heruntergeladen..."))
        total = len(updates)
        for index, (addon_id, local, remote_version) in enumerate(updates, 1):
            if xbmc.Monitor().abortRequested():
                break
            log("Update geplant: %s %s -> %s" % (addon_id, local or "nicht installiert", remote_version))
            if install_package(addon_id, remote_version, progress, index, total):
                installed += 1
        progress.update(100, color("Nova Updates abgeschlossen."))
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if installed:
        xbmc.executebuiltin("UpdateLocalAddons")
        notify("%d Nova Update(s) installiert." % installed, 5000)
    else:
        notify("Keine Nova Updates installiert.", 3500)


def main():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(STARTUP_DELAY_MS / 1000.0):
        return
    run_update_check()


if __name__ == "__main__":
    main()
