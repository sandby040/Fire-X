import re
import sys
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs


ICON = xbmcvfs.translatePath("special://home/addons/plugin.video.cumination/icon.png")
HOME_WINDOW = xbmcgui.Window(10000)
DATA_FILE = xbmcvfs.translatePath("special://profile/addon_data/script.skinshortcuts/mainmenu.DATA.xml")
REBUILD_COMMAND = "RunScript(script.skinshortcuts,type=buildxml&mainmenuID=9000&levels=2&group=mainmenu|buttonmenu)"


def parse_mode():
    mode = "toggle"
    for arg in sys.argv[1:]:
        if "=" not in arg:
            continue
        key, value = arg.split("=", 1)
        if key.lower() == "mode":
            value = value.strip().lower()
            if value in ("toggle", "on", "off"):
                mode = value
    return mode


def strip_kodi_markup(value):
    if not value:
        return ""
    return re.sub(r"\[[^\]]+\]", "", value).strip()


def is_xxx_shortcut(shortcut):
    default_id = (shortcut.findtext("defaultID") or "").strip().lower()
    action = (shortcut.findtext("action") or "").strip().lower()
    label = strip_kodi_markup(shortcut.findtext("label") or "").lower()

    if "plugin.video.cumination" in action:
        return True
    if "plugin.program.super.favourites" in action and ("label=xxx" in action or "%2fxxx" in action):
        return True
    if default_id == "weather" and label == "xxx":
        return True
    return False


def shortcut_disabled(shortcut):
    disabled = shortcut.find("disabled")
    if disabled is None or disabled.text is None:
        return False
    return disabled.text.strip().lower() == "true"


def set_shortcut_disabled(shortcut, disabled):
    disabled_node = shortcut.find("disabled")
    if disabled:
        if disabled_node is None:
            disabled_node = ET.SubElement(shortcut, "disabled")
        disabled_node.text = "True"
    elif disabled_node is not None:
        shortcut.remove(disabled_node)


def indent(elem, level=0):
    indent_text = "\n" + level * "\t"
    child_indent = "\n" + (level + 1) * "\t"
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = child_indent
        for child in elem:
            indent(child, level + 1)
        if not elem[-1].tail or not elem[-1].tail.strip():
            elem[-1].tail = indent_text
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = indent_text


def write_xml(tree, path):
    root = tree.getroot()
    indent(root)
    tree.write(path, encoding="UTF-8", xml_declaration=False)


def load_current_state():
    if not xbmcvfs.exists(DATA_FILE):
        return False
    try:
        root = ET.parse(DATA_FILE).getroot()
    except Exception:
        return False
    for shortcut in root.findall("shortcut"):
        if is_xxx_shortcut(shortcut):
            return shortcut_disabled(shortcut)
    return False


def apply_state(target_disabled):
    if not xbmcvfs.exists(DATA_FILE):
        return False

    tree = ET.parse(DATA_FILE)
    root = tree.getroot()
    matched = False
    file_changed = False

    for shortcut in root.findall("shortcut"):
        if is_xxx_shortcut(shortcut):
            matched = True
            if shortcut_disabled(shortcut) != target_disabled:
                set_shortcut_disabled(shortcut, target_disabled)
                file_changed = True

    if file_changed:
        write_xml(tree, DATA_FILE)

    return matched


def notify(message):
    try:
        xbmcgui.Dialog().notification("XXX Menu", message, ICON, 2500, sound=False)
    except Exception:
        pass


def main():
    mode = parse_mode()
    xbmc.log("script.nova.xxx.toggle: started with mode=%s" % mode, xbmc.LOGINFO)

    current_disabled = load_current_state()
    if mode == "on":
        target_disabled = False
    elif mode == "off":
        target_disabled = True
    else:
        target_disabled = not current_disabled

    try:
        matched = apply_state(target_disabled)
    except Exception as exc:
        xbmc.log("script.nova.xxx.toggle: failed: %s" % exc, xbmc.LOGERROR)
        notify("Fehler beim Umschalten")
        return

    if not matched:
        xbmc.log("script.nova.xxx.toggle: XXX shortcut not found", xbmc.LOGWARNING)
        notify("XXX nicht gefunden")
        return

    HOME_WINDOW.setProperty("skinshortcuts-reloadmainmenu", "True")
    xbmc.executebuiltin(REBUILD_COMMAND)
    xbmc.log("script.nova.xxx.toggle: XXX now %s" % ("disabled" if target_disabled else "enabled"), xbmc.LOGINFO)
    notify("XXX deaktiviert" if target_disabled else "XXX aktiviert")


if __name__ == "__main__":
    main()
