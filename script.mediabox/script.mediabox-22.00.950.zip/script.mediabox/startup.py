# startup.py
import xbmc
import xbmcgui

CURRENT_PACKAGE = "stube.box.legacy"
EXPECTED_PACKAGE = "stubebox.legacy.org"


def _install_mediabox_runtime_patch():
    try:
        import builtins
        import os
        import sys
        import time
        import xbmcaddon
        import xbmcvfs
    except Exception:
        return

    state = {"package_warning_at": 0.0}

    def _blocked_exit(*args, **kwargs):
        try:
            xbmc.log("[mediabox.helper] blocked forced addon exit", xbmc.LOGWARNING)
        except Exception:
            pass
        return None

    try:
        builtins.exit = _blocked_exit
        builtins.quit = _blocked_exit
        sys.exit = _blocked_exit
        os._exit = _blocked_exit
    except Exception:
        pass

    try:
        _orig_builtin = xbmc.executebuiltin

        def _safe_builtin(command, *args, **kwargs):
            cmd = str(command or "").lower()
            if "quit" in cmd or "shutdown" in cmd or "restartapp" in cmd or "system.exit" in cmd:
                try:
                    xbmc.log("[mediabox.helper] blocked builtin: %s" % command, xbmc.LOGWARNING)
                except Exception:
                    pass
                return None
            return _orig_builtin(command, *args, **kwargs)

        xbmc.executebuiltin = _safe_builtin
    except Exception:
        pass

    try:
        _orig_sleep = xbmc.sleep

        def _safe_sleep(milliseconds):
            try:
                delay = int(milliseconds)
            except Exception:
                delay = 0
            if delay >= 9000 and time.monotonic() - state.get("package_warning_at", 0.0) < 2.0:
                try:
                    xbmc.log("[mediabox.helper] skipped package guard delay: %sms" % delay, xbmc.LOGWARNING)
                except Exception:
                    pass
                return None
            return _orig_sleep(milliseconds)

        xbmc.sleep = _safe_sleep
    except Exception:
        pass

    def _masked_path(value, path):
        path_text = str(path or "").lower()
        if (
            isinstance(value, str)
            and CURRENT_PACKAGE in value
            and (
                path_text.startswith("special://xbmc")
                or path_text.startswith("special://xbmcbin")
                or path_text.startswith("special://envhome")
            )
        ):
            return value.replace(CURRENT_PACKAGE, EXPECTED_PACKAGE)
        return value

    try:
        _orig_info_label = xbmc.getInfoLabel

        def _safe_info_label(label):
            value = _orig_info_label(label)
            if isinstance(value, str) and CURRENT_PACKAGE in value:
                return value.replace(CURRENT_PACKAGE, EXPECTED_PACKAGE)
            return value

        xbmc.getInfoLabel = _safe_info_label
    except Exception:
        pass

    try:
        _orig_translate = getattr(xbmc, "translatePath", None)
        if _orig_translate:
            xbmc.translatePath = lambda path: _masked_path(_orig_translate(path), path)
    except Exception:
        pass

    try:
        _orig_vfs_translate = getattr(xbmcvfs, "translatePath", None)
        if _orig_vfs_translate:
            xbmcvfs.translatePath = lambda path: _masked_path(_orig_vfs_translate(path), path)
    except Exception:
        pass

    try:
        _orig_dialog = xbmcgui.Dialog

        def _is_package_warning(*parts):
            text = " ".join(str(part or "") for part in parts).lower()
            return (
                ("wrong" in text and "application" in text)
                or ("studio box" in text and "apk" in text)
                or ("original" in text and "studio" in text)
                or ("shutting down kodi" in text)
            )

        class _SafeDialog(object):
            def __init__(self, *args, **kwargs):
                self._dialog = _orig_dialog(*args, **kwargs)

            def __getattr__(self, name):
                return getattr(self._dialog, name)

            def ok(self, heading, message="", *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state["package_warning_at"] = time.monotonic()
                    try:
                        xbmc.log("[mediabox.helper] suppressed package warning dialog", xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return True
                return self._dialog.ok(heading, message, *args, **kwargs)

            def yesno(self, heading, message="", *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state["package_warning_at"] = time.monotonic()
                    return False
                return self._dialog.yesno(heading, message, *args, **kwargs)

            def notification(self, heading, message="", *args, **kwargs):
                if _is_package_warning(heading, message, *args):
                    state["package_warning_at"] = time.monotonic()
                    return None
                return self._dialog.notification(heading, message, *args, **kwargs)

        xbmcgui.Dialog = _SafeDialog
    except Exception:
        pass


_install_mediabox_runtime_patch()

from lib.mediaselect import show_addon_picker

if __name__ == "__main__":
    show_addon_picker()
else:
    # auch direkt ausführen, falls Kodi importiert statt als __main__
    show_addon_picker()
