import hashlib
import json
import os
import threading
import re
import unicodedata
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcvfs
from dateutil import parser, tz

import resources.lib.common as common
from resources.lib import codex_epg_bridge


ADDON_ID = 'plugin.video.playlistloader.macsimum'
ADDON = xbmcaddon.Addon(ADDON_ID)
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
PLAYLISTS_FILE = os.path.join(PROFILE, 'playLists.txt')
M3U_CACHE_DIR = os.path.join(PROFILE, 'codex_m3u_cache')
EPG_NOW_CACHE_DIR = os.path.join(PROFILE, 'codex_epg_now_cache')
RENDER_CACHE_DIR = os.path.join(PROFILE, 'codex_render_cache')
SHARED_EPG_PATH = os.path.join(PROFILE, 'epg', 'macsimum_epg_subset.xml')
SHARED_EPG_META = os.path.join(PROFILE, 'epg', 'codex_epg_bridge_meta.json')
PVR_LIVETV2_M3U = xbmcvfs.translatePath('special://userdata/addon_data/pvr.iptvsimple/providers/playlist.m3u')
IPTVMASTER_LIVETV1_M3U = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.iptvmaster/playlists/livetv1_vodkool_bridge.m3u')
MACSIMUM_LIVETV3_M3U = os.path.join(PROFILE, 'playlists', 'stalker_macsimum_live_tv.m3u')

for _path in (M3U_CACHE_DIR, EPG_NOW_CACHE_DIR, RENDER_CACHE_DIR):
    try:
        xbmcvfs.mkdirs(_path)
    except Exception:
        try:
            os.makedirs(_path, exist_ok=True)
        except Exception:
            pass


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('[playlistloader.macsimum.service] %s' % message, level)


def _normalize_local_path(path):
    try:
        return common._codex_normalize_local_path(path)
    except Exception:
        return str(path or '').replace('\\', '/')


def _is_macsimum_m3u(url):
    text = str(url or '').replace('\\', '/').lower()
    return '/playlists/stalker_macsimum_' in text and text.endswith('.m3u')


def _file_signature(path):
    path = _normalize_local_path(path)
    try:
        st = os.stat(path)
        return {'mtime': int(st.st_mtime), 'size': int(st.st_size)}
    except Exception:
        pass
    try:
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            try:
                size = int(f.size())
            finally:
                f.close()
            return {'mtime': 0, 'size': size}
    except Exception:
        pass
    return None


def _parsed_m3u_cache_file(url):
    norm = _normalize_local_path(url)
    key = hashlib.md5(norm.encode('utf-8')).hexdigest()
    return os.path.join(M3U_CACHE_DIR, key + '.json')


def _m3u2list_cached(url, cache_minutes):
    norm_url = _normalize_local_path(url)
    signature = _file_signature(norm_url)
    if not signature:
        return common.m3u2list(url, cache_minutes)

    cache_file = _parsed_m3u_cache_file(norm_url)
    try:
        with open(cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            return payload.get('channels') or []
    except Exception:
        pass

    channels = common.m3u2list(norm_url, cache_minutes)
    try:
        with open(cache_file, 'w', encoding='utf-8') as handle:
            json.dump({'signature': signature, 'channels': channels}, handle, ensure_ascii=False)
    except Exception as ex:
        _log('M3U cache save failed: %s' % ex, xbmc.LOGWARNING)
    return channels


def _epg_now_cache_file(norm_epg, minute_key):
    key = hashlib.md5(('%s:%s' % (norm_epg, minute_key)).encode('utf-8')).hexdigest()
    return os.path.join(EPG_NOW_CACHE_DIR, key + '.json')


def _render_cache_file(url, mode, group_index):
    norm = _normalize_local_path(url)
    key = hashlib.md5(('%s:%s:%s' % (norm, mode, group_index)).encode('utf-8')).hexdigest()
    return os.path.join(RENDER_CACHE_DIR, key + '.json')


def _use_epg_for_playlist(url, epg, mode):
    return bool((mode == 2 or mode == 10) and epg and 'stalker_macsimum_live_tv.m3u' in str(url or '').lower())


def _render_signature(url, epg, mode, group_index):
    use_epg = _use_epg_for_playlist(url, epg, mode)
    epg_sig = None
    bucket = 'static'
    if use_epg:
        epg_sig = _file_signature(_normalize_local_path(epg))
        bucket = int(datetime.now().timestamp() // (15 * 60))
    return {
        'm3u': _file_signature(url),
        'epg': epg_sig,
        'bucket': bucket,
        'mode': mode,
        'group': group_index,
        'makeGroups': False,
    }


def _epg_norm(value):
    text = unicodedata.normalize('NFKC', str(value or ''))
    text = text.replace('&', ' UND ')
    text = re.sub(r'\b(FHD|FULLHD|HD|RAW|HEVC|UHD|QHD|4K|2K|SD|HDR)\b', ' ', text, flags=re.I)
    text = re.sub(r'\.DE$', ' ', text, flags=re.I)
    text = re.sub(r'[^A-Za-z0-9ÄÖÜäöüß]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip().upper()


def _build_epg_index(epg_dict):
    index = {}
    try:
        for idx, epg_name in enumerate(epg_dict.get(u'name') or []):
            for value in (epg_name,):
                key = _epg_norm(value)
                if key and key not in index:
                    index[key] = idx
        for idx, row in enumerate(epg_dict.get(u'data') or []):
            try:
                channel_id = row[0]
            except Exception:
                channel_id = ''
            for value in (channel_id, str(channel_id).replace('.', ' ')):
                key = _epg_norm(value)
                if key and key not in index:
                    index[key] = idx
    except Exception:
        pass
    return index


def _find_epg_idx(name, channel, epg_dict, epg_index):
    try:
        names = epg_dict.get(u'name') or []
        if name in names:
            return names.index(name)
        for candidate in (
            name,
            channel.get('tvg_name', ''),
            channel.get('tvg_id', ''),
            channel.get('display_name', ''),
        ):
            key = _epg_norm(candidate)
            if key in epg_index:
                return epg_index[key]
    except Exception:
        pass
    return None


def _serialize_epg_now(epg_now):
    payload = {}
    for idx, programmes in (epg_now or {}).items():
        rows = []
        for stime, etime, title, desc in programmes:
            try:
                rows.append([stime.isoformat(), etime.isoformat(), title, desc])
            except Exception:
                pass
        if rows:
            payload[str(idx)] = rows
    return payload


def _build_epg_now_index(epg_dict, dnow, to_zone):
    now_index = {}
    try:
        data = epg_dict.get(u'data') or []
        programmes = epg_dict.get('prg') or {}
        for idx, item in enumerate(data):
            try:
                channel_id = item[0]
            except Exception:
                continue
            channel_programmes = programmes.get(channel_id) or []
            found = []
            take_next = False
            for programme in channel_programmes:
                try:
                    start, stop, title = programme[0], programme[1], programme[2]
                    desc = programme[3] if len(programme) > 3 else ''
                    stime = parser.parse(start)
                    etime = parser.parse(stop)
                except Exception:
                    continue
                if stime <= dnow <= etime or take_next:
                    found.append((stime, etime, title, desc))
                    if len(found) >= 2:
                        break
                    take_next = True
                elif dnow < stime and not take_next:
                    break
            if found:
                now_index[idx] = found
    except Exception as ex:
        _log('EPG now-index failed: %s' % ex, xbmc.LOGWARNING)
    return now_index


def _prewarm_epg_now(epg):
    if not epg:
        return 0
    norm_epg = _normalize_local_path(epg)
    signature = _file_signature(norm_epg) if not str(norm_epg).startswith('http') else None
    if signature is None and not str(norm_epg).startswith('http'):
        return 0

    dnow = datetime.now(tz.UTC)
    minute_key = dnow.strftime('%Y%m%d%H%M')
    cache_file = _epg_now_cache_file(norm_epg, minute_key)
    try:
        with open(cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            return len(payload.get('epgNow') or {})
    except Exception:
        pass

    epg_dict = common.epg2dict(norm_epg, cache=720)
    epg_now = _build_epg_now_index(epg_dict, dnow, tz.tzlocal())
    try:
        with open(cache_file, 'w', encoding='utf-8') as handle:
            json.dump({'signature': signature, 'epgNow': _serialize_epg_now(epg_now)}, handle, ensure_ascii=False)
    except Exception as ex:
        _log('EPG now cache save failed: %s' % ex, xbmc.LOGWARNING)
    return len(epg_now)


def _epg_context(epg):
    if not epg:
        return {}, {}, {}, datetime.now(tz.UTC), tz.tzlocal()
    norm_epg = _normalize_local_path(epg)
    epg_dict = common.epg2dict(norm_epg, cache=720)
    epg_index = _build_epg_index(epg_dict)
    dnow = datetime.now(tz.UTC)
    to_zone = tz.tzlocal()
    epg_now = _build_epg_now_index(epg_dict, dnow, to_zone)
    return epg_dict, epg_index, epg_now, dnow, to_zone


def _build_render_entry(channel, epg, cache_minutes, epg_dict, epg_index, epg_now, to_zone):
    name = common.GetEncodeString(channel.get('display_name', ''))
    image = channel.get('tvg_logo', channel.get('logo', '')) or ''
    ch_url = common.GetEncodeString(channel.get('url', ''))
    plot = ''

    if epg_dict:
        idx = _find_epg_idx(name, channel, epg_dict, epg_index)
        if image == '' and idx is not None:
            try:
                image = epg_dict[u'data'][idx][1]
            except Exception:
                pass
        if idx is not None:
            title2nd = ''
            t2len = 0
            next_item = False
            for stime, etime, title, desc in epg_now.get(idx, []):
                ebgn = stime.astimezone(to_zone).strftime('%H:%M')
                eend = etime.astimezone(to_zone).strftime('%H:%M')
                stmp = '%s-%s' % (ebgn, eend)
                t2len += (len(stmp) + 1)
                if not next_item:
                    title2nd += ' [COLOR FF00BB66]%s[/COLOR]' % stmp
                else:
                    title2nd += ' %s' % stmp
                title2nd += ' %s' % title
                t2len += (len(title) + 1)
                title2nd = title2nd.replace('&quot;', '`').replace('&amp;', ' & ')
                desc = common.GetEncodeString(desc).replace('&quot;', '`').replace('&amp;', ' & ').strip()
                if not t2len:
                    t2len = len(name)
                if not next_item:
                    plot += '[B][COLOR FF0084FF]%s-%s[/COLOR]\n[COLOR FFFFFFFF]%s[/COLOR][/B]' % (ebgn, eend, title)
                    if desc:
                        plot += '\n\n[COLOR FFFFFF00]%s[/COLOR]' % desc
                    name = '[B]%s[/B]\n%s' % (name.ljust(int(t2len * 1.65)), title2nd)
                    next_item = True
                else:
                    plot += '\n\n[B][COLOR FF0084FF]%s-%s[/COLOR]\n%s[/B]' % (ebgn, eend, title)
                    if desc:
                        plot += '\n[COLOR FFFFFF00]%s[/COLOR]' % desc
                    break

    entry = {
        'name': name,
        'url': ch_url,
        'mode': 3,
        'iconimage': image,
        'logos': '',
        'epg': epg,
        'index': -1,
        'move': 0,
        'uuid': '0',
        'isFolder': False,
        'IsPlayable': True,
        'background': None,
        'cacheMin': str(cache_minutes),
        'plot': plot,
        'fanart': '',
        'addToVdir': True,
    }
    tmp = {'url': ch_url, 'image': image, 'name': name}
    return entry, tmp


def _prewarm_render_cache(item, channels):
    url = item.get('url', '')
    epg = item.get('epg', '')
    cache_minutes = int(item.get('cache', '0') or 0)
    mode = 2
    group_index = -1
    signature = _render_signature(url, epg, mode, group_index)
    if not signature.get('m3u'):
        return 0

    cache_file = _render_cache_file(url, mode, group_index)
    try:
        with open(cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            return len(payload.get('entries') or [])
    except Exception:
        pass

    if _use_epg_for_playlist(url, epg, mode):
        epg_dict, epg_index, epg_now, _dnow, to_zone = _epg_context(epg)
    else:
        epg_dict, epg_index, epg_now, to_zone = {}, {}, {}, tz.tzlocal()

    entries = []
    tmp_list = []
    for channel in channels or []:
        try:
            entry, tmp = _build_render_entry(channel, epg, cache_minutes, epg_dict, epg_index, epg_now, to_zone)
            entries.append(entry)
            tmp_list.append(tmp)
        except Exception:
            pass
    if not entries:
        return 0
    try:
        with open(cache_file, 'w', encoding='utf-8') as handle:
            json.dump({'signature': signature, 'entries': entries, 'tmpList': tmp_list}, handle, ensure_ascii=False)
    except Exception as ex:
        _log('render cache save failed: %s' % ex, xbmc.LOGWARNING)
    return len(entries)


def _priority(item):
    name = str(item.get('name') or '').lower()
    url = str(item.get('url') or '').lower()
    if 'stalker_macsimum_live_tv.m3u' in url or 'deutschland' in name:
        return 0
    if 'adult' in url or 'adult' in name:
        return 1
    return 2


def _warmup_once():
    try:
        result = codex_epg_bridge.refresh(
            SHARED_EPG_PATH,
            [IPTVMASTER_LIVETV1_M3U, PVR_LIVETV2_M3U, MACSIMUM_LIVETV3_M3U],
            meta_path=SHARED_EPG_META,
            force=False,
            min_age_hours=12,
            cache_dirs=[EPG_NOW_CACHE_DIR, RENDER_CACHE_DIR],
            logo_source_paths=[PVR_LIVETV2_M3U, IPTVMASTER_LIVETV1_M3U, MACSIMUM_LIVETV3_M3U],
            logo_target_paths=[MACSIMUM_LIVETV3_M3U],
        )
        if result:
            _log('shared DE EPG ready: %s channels, %s programmes, skipped=%s' % (
                result.get('filtered_epg', {}).get('channels', result.get('wanted_channels', '?')),
                result.get('filtered_epg', {}).get('programmes', '?'),
                result.get('skipped', False),
            ))
    except Exception as ex:
        _log('shared DE EPG refresh failed: %s' % ex, xbmc.LOGWARNING)

    playlists = common.ReadList(PLAYLISTS_FILE)
    candidates = []
    for item in playlists or []:
        try:
            url = item.get('url', '')
            if _is_macsimum_m3u(url):
                candidates.append(item)
        except Exception:
            pass
    if not candidates:
        _log('no Macsimum playlists found', xbmc.LOGDEBUG)
        return False

    candidates.sort(key=_priority)
    warmed = 0
    total_channels = 0
    epg_channels = 0
    rendered = 0
    for item in candidates:
        try:
            url = item.get('url', '')
            cache_minutes = int(item.get('cache', '0') or 0)
            channels = _m3u2list_cached(url, cache_minutes)
            warmed += 1
            total_channels += len(channels)
            if _priority(item) == 0:
                epg_channels = max(epg_channels, _prewarm_epg_now(item.get('epg', '')))
            rendered += _prewarm_render_cache(item, channels)
        except Exception as ex:
            _log('warmup failed for %s: %s' % (item.get('name', '?'), ex), xbmc.LOGWARNING)
    _log('startup warmup complete: %d playlists, %d channels, EPG-now %d channels, render %d items' %
         (warmed, total_channels, epg_channels, rendered))
    return True


class PlaylistLoaderMacsimumService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._last_refresh = time.time()
        _log('service started')
        self._start_warmup()

    def _start_warmup(self):
        def worker():
            # Erst kurz warten, damit der IPTV-Master-Service seine kompakte
            # EPG-Datei bei Kodi-Start erzeugen/aktualisieren kann.
            for delay in (6000, 7000, 10000):
                if self.abortRequested():
                    return
                xbmc.sleep(delay)
                if _warmup_once():
                    return

        t = threading.Thread(target=worker, name='playlistloader_macsimum_startup_warmup', daemon=True)
        t.start()

    def run(self):
        while not self.abortRequested():
            self.waitForAbort(300)
            if self.abortRequested():
                break
            if time.time() - self._last_refresh > 15 * 60:
                self._last_refresh = time.time()
                self._start_warmup()
        _log('service stopped')


if __name__ == '__main__':
    PlaylistLoaderMacsimumService().run()
