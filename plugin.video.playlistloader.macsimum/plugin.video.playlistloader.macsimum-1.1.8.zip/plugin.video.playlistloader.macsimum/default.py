﻿import hashlib
import os
import json
import re
import sys
import threading
import unicodedata
import urllib.error
import urllib.parse
import urllib.parse
import urllib.request
import uuid as random
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import resources.lib.common as common
from datetime import datetime
from dateutil import parser
from dateutil import tz

AddonID = 'plugin.video.playlistloader.macsimum'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
addonDir = Addon.getAddonInfo('path')
iconsDir = os.path.join(addonDir, "resources", "images")


addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
if not os.path.exists(cacheDir):
    os.makedirs(cacheDir)
parsedM3uCacheDir = os.path.join(addon_data_dir, "codex_m3u_cache")
if not os.path.exists(parsedM3uCacheDir):
    os.makedirs(parsedM3uCacheDir)
epgNowCacheDir = os.path.join(addon_data_dir, "codex_epg_now_cache")
if not os.path.exists(epgNowCacheDir):
    os.makedirs(epgNowCacheDir)
renderListCacheDir = os.path.join(addon_data_dir, "codex_render_cache")
if not os.path.exists(renderListCacheDir):
    os.makedirs(renderListCacheDir)
logoCacheDir = os.path.join(addon_data_dir, "codex_logo_cache")
if not os.path.exists(logoCacheDir):
    os.makedirs(logoCacheDir)
    
playlistsFile = os.path.join(addon_data_dir, "playLists.txt")
vDirectoriesFile = os.path.join(addon_data_dir, "virtual_directoriesLists.txt")
tmpListFile = os.path.join(addon_data_dir, 'tempList.txt')
favoritesFile = os.path.join(addon_data_dir, 'favorites.txt')
_CODEX_M3U_SESSION_CACHE = {}
_CODEX_EPG_SESSION_CACHE = {}
_CODEX_PENDING_DIR_ITEMS = None
_CODEX_RENDER_CAPTURE = None
_CODEX_PLAYURL_HANDLED = False

def _codex_normalize_local_path(path):
    try:
        return common._codex_normalize_local_path(path)
    except Exception:
        try:
            return str(path or '').replace('\\', '/')
        except Exception:
            return path

def _codex_is_http_url(value):
    return isinstance(value, str) and (value.startswith('http://') or value.startswith('https://'))

def _codex_logo_cache_path(url):
    parsed = urllib.parse.urlparse(str(url or ''))
    ext = os.path.splitext(parsed.path)[1].lower()
    if ext not in ('.png', '.jpg', '.jpeg', '.webp', '.gif'):
        ext = '.png'
    key = hashlib.md5(str(url or '').encode('utf-8')).hexdigest()
    return os.path.join(logoCacheDir, key + ext)

def _codex_logo_local_path(url):
    if _codex_is_http_url(url):
        return url
    return url

def _codex_download_logo(url):
    if not _codex_is_http_url(url):
        return False
    out = _codex_logo_cache_path(url)
    try:
        if os.path.exists(out) and os.path.getsize(out) > 100:
            return True
    except Exception:
        pass
    tmp = out + '.tmp'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as response, open(tmp, 'wb') as handle:
            handle.write(response.read(512000))
        if os.path.exists(tmp) and os.path.getsize(tmp) > 100:
            if os.path.exists(out):
                os.unlink(out)
            os.rename(tmp, out)
            return True
    except Exception as ex:
        xbmc.log('[playlistloader.macsimum] Logo prefetch failed: %s -> %s' % (url, ex), xbmc.LOGDEBUG)
    try:
        if os.path.exists(tmp):
            os.unlink(tmp)
    except Exception:
        pass
    return False

def _codex_cleanup_logo_cache(max_mb=80):
    try:
        files = []
        total = 0
        for name in os.listdir(logoCacheDir):
            path = os.path.join(logoCacheDir, name)
            if not os.path.isfile(path):
                continue
            try:
                size = os.path.getsize(path)
                total += size
                files.append((os.path.getmtime(path), size, path))
            except Exception:
                pass
        limit = max_mb * 1024 * 1024
        if total <= limit:
            return
        for _mtime, size, path in sorted(files):
            try:
                os.unlink(path)
                total -= size
                if total <= limit:
                    break
            except Exception:
                pass
    except Exception:
        pass

def _codex_prefetch_channel_logos(chList, scope):
    # Nicht selbst herunterladen: Kodi/TextureCache soll die Online-Logos laden.
    # Ein eigener Python-Prefetch konkurriert sonst mit Kodis Bildloader und kann
    # genau das verzögern, was sichtbar schneller werden soll.
    return
    urls = []
    seen = set()
    for channel in chList or []:
        logo = channel.get('tvg_logo', channel.get('logo', channel.get('iconimage', '')))
        if _codex_is_http_url(logo) and logo not in seen:
            seen.add(logo)
            urls.append(logo)
    if not urls:
        return
    window = xbmcgui.Window(10000)
    prop = 'MacsimumLogoPrefetch_%s' % scope
    if window.getProperty(prop) == 'true':
        return

    def worker():
        ok = 0
        try:
            window.setProperty(prop, 'true')
            # Erst die ersten sichtbaren/obersten Logos priorisieren, danach den Rest.
            for logo in urls:
                if _codex_download_logo(logo):
                    ok += 1
            _codex_cleanup_logo_cache()
            xbmc.log('[playlistloader.macsimum] Logo prefetch complete %s: %d/%d' % (scope, ok, len(urls)), xbmc.LOGINFO)
        finally:
            window.clearProperty(prop)

    try:
        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()
    except Exception:
        worker()

def _codex_is_macsimum_m3u(url):
    text = str(url or '').replace('\\', '/').lower()
    return '/playlists/stalker_macsimum_' in text and text.endswith('.m3u')

def _codex_file_signature(path):
    path = _codex_normalize_local_path(path)
    try:
        st = os.stat(path)
        return {'mtime': int(st.st_mtime), 'size': int(st.st_size)}
    except Exception:
        pass
    try:
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            try:
                size = int(f.size())
            finally:
                f.close()
            return {'mtime': 0, 'size': size}
    except Exception:
        pass
    return None

def _codex_parsed_m3u_cache_file(url):
    norm = _codex_normalize_local_path(url)
    key = hashlib.md5(norm.encode('utf-8')).hexdigest()
    return os.path.join(parsedM3uCacheDir, key + '.json')

def _codex_m3u_version_token(url):
    signature = _codex_file_signature(url)
    if not signature:
        return ''
    return '%s_%s' % (signature.get('mtime', 0), signature.get('size', 0))

def _codex_m3u2list_cached(url, cache):
    if not _codex_is_macsimum_m3u(url):
        return common.m3u2list(url, cache)

    norm_url = _codex_normalize_local_path(url)
    signature = _codex_file_signature(norm_url)
    if not signature:
        xbmc.log('[playlistloader.macsimum] M3U cache skipped; no file signature: %s' % norm_url, xbmc.LOGINFO)
        return common.m3u2list(url, cache)

    session_item = _CODEX_M3U_SESSION_CACHE.get(norm_url)
    if session_item and session_item.get('signature') == signature:
        channels = session_item.get('channels') or []
        xbmc.log('[playlistloader.macsimum] M3U session-cache hit: %s (%d)' % (os.path.basename(norm_url), len(channels)), xbmc.LOGINFO)
        return channels

    cache_file = _codex_parsed_m3u_cache_file(norm_url)
    try:
        with open(cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            channels = payload.get('channels') or []
            _CODEX_M3U_SESSION_CACHE[norm_url] = {'signature': signature, 'channels': channels}
            xbmc.log('[playlistloader.macsimum] M3U disk-cache hit: %s (%d)' % (os.path.basename(norm_url), len(channels)), xbmc.LOGINFO)
            return channels
    except Exception:
        pass

    channels = common.m3u2list(url, cache)
    _CODEX_M3U_SESSION_CACHE[norm_url] = {'signature': signature, 'channels': channels}
    try:
        with open(cache_file, 'w', encoding='utf-8') as handle:
            json.dump({'signature': signature, 'channels': channels}, handle, ensure_ascii=False)
    except Exception as ex:
        xbmc.log('[playlistloader.macsimum] M3U disk-cache save failed: %s' % ex, xbmc.LOGWARNING)
    xbmc.log('[playlistloader.macsimum] M3U cache refreshed: %s (%d)' % (os.path.basename(norm_url), len(channels)), xbmc.LOGINFO)
    return channels

def _codex_epg_now_cache_file(norm_epg, minute_key):
    key = hashlib.md5(('%s:%s' % (norm_epg, minute_key)).encode('utf-8')).hexdigest()
    return os.path.join(epgNowCacheDir, key + '.json')

def _codex_serialize_epg_now(epgNow):
    payload = {}
    for idx, programmes in (epgNow or {}).items():
        rows = []
        for stime, etime, title, desc in programmes:
            try:
                rows.append([stime.isoformat(), etime.isoformat(), title, desc])
            except Exception:
                pass
        if rows:
            payload[str(idx)] = rows
    return payload

def _codex_deserialize_epg_now(payload):
    epgNow = {}
    for idx, rows in (payload or {}).items():
        try:
            int_idx = int(idx)
        except Exception:
            continue
        restored = []
        for row in rows or []:
            try:
                restored.append((parser.parse(row[0]), parser.parse(row[1]), row[2], row[3]))
            except Exception:
                pass
        if restored:
            epgNow[int_idx] = restored
    return epgNow

def _codex_cleanup_epg_now_cache(max_age_seconds=7200):
    try:
        now_ts = datetime.now().timestamp()
        for name in os.listdir(epgNowCacheDir):
            path = os.path.join(epgNowCacheDir, name)
            try:
                if os.path.isfile(path) and now_ts - os.path.getmtime(path) > max_age_seconds:
                    os.unlink(path)
            except Exception:
                pass
    except Exception:
        pass

def _codex_epg_context_cached(epg, cache=720):
    norm_epg = _codex_normalize_local_path(epg)
    signature = None
    if isinstance(norm_epg, str) and not norm_epg.startswith('http'):
        signature = _codex_file_signature(norm_epg)
    dnow = datetime.now(tz.UTC)
    minute_key = dnow.strftime('%Y%m%d%H%M')
    key = hashlib.md5(str(norm_epg or '').encode('utf-8')).hexdigest()
    cache_key = '%s:%s' % (key, minute_key)
    cached = _CODEX_EPG_SESSION_CACHE.get(cache_key)
    if cached and cached.get('signature') == signature:
        return cached.get('epgDict') or {}, cached.get('epgIndex') or {}, cached.get('epgNow') or {}, dnow, tz.tzlocal()

    epgDict = common.epg2dict(epg, cache=cache)
    epgIndex = _codex_build_epg_index(epgDict)
    to_zone = tz.tzlocal()
    epg_now_cache_file = _codex_epg_now_cache_file(norm_epg, minute_key)
    epgNow = {}
    try:
        with open(epg_now_cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            epgNow = _codex_deserialize_epg_now(payload.get('epgNow') or {})
            xbmc.log('[playlistloader.macsimum] EPG now disk-cache hit: %d channels' % len(epgNow), xbmc.LOGINFO)
    except Exception:
        epgNow = {}
    if not epgNow:
        epgNow = _codex_build_epg_now_index(epgDict, dnow, to_zone)
        try:
            with open(epg_now_cache_file, 'w', encoding='utf-8') as handle:
                json.dump({'signature': signature, 'epgNow': _codex_serialize_epg_now(epgNow)}, handle, ensure_ascii=False)
            _codex_cleanup_epg_now_cache()
        except Exception as ex:
            xbmc.log('[playlistloader.macsimum] EPG now disk-cache save failed: %s' % ex, xbmc.LOGWARNING)
    _CODEX_EPG_SESSION_CACHE.clear()
    _CODEX_EPG_SESSION_CACHE[cache_key] = {
        'signature': signature,
        'epgDict': epgDict,
        'epgIndex': epgIndex,
        'epgNow': epgNow,
    }
    xbmc.log('[playlistloader.macsimum] EPG session-cache refreshed: %d channels' % len(epgDict.get(u'name') or []), xbmc.LOGINFO)
    return epgDict, epgIndex, epgNow, dnow, to_zone

def _codex_prewarm_macsimum_playlists(playlists):
    candidates = []
    for item in playlists or []:
        try:
            url = item.get('url', '')
            if _codex_is_macsimum_m3u(url):
                candidates.append((url, item.get('cache', '0')))
        except Exception:
            pass
    if not candidates:
        return

    window = xbmcgui.Window(10000)
    if window.getProperty('MacsimumM3uPrewarmRunning') == 'true':
        return

    def worker():
        try:
            window.setProperty('MacsimumM3uPrewarmRunning', 'true')
            warmed = 0
            for url, cache_min in candidates:
                try:
                    _codex_m3u2list_cached(url, int(cache_min or 0))
                    warmed += 1
                except Exception as ex:
                    xbmc.log('[playlistloader.macsimum] M3U prewarm failed: %s' % ex, xbmc.LOGWARNING)
            xbmc.log('[playlistloader.macsimum] M3U prewarm complete: %d/%d lists' % (warmed, len(candidates)), xbmc.LOGINFO)
        finally:
            window.clearProperty('MacsimumM3uPrewarmRunning')

    try:
        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()
    except Exception:
        worker()

def _codex_macsimum_scope_from_playlist_url(url):
    text = str(url or '').lower()
    mapping = (
        ('stalker_macsimum_live_tv.m3u', 'de'),
        ('stalker_macsimum_international_sport.m3u', 'international_sport'),
        ('stalker_macsimum_at.m3u', 'at'), ('stalker_macsimum_ch.m3u', 'ch'), ('stalker_macsimum_nl.m3u', 'nl'),
        ('stalker_macsimum_be.m3u', 'be'), ('stalker_macsimum_england.m3u', 'england'),
        ('stalker_macsimum_us.m3u', 'us'), ('stalker_macsimum_ca.m3u', 'ca'), ('stalker_macsimum_fr.m3u', 'fr'),
        ('stalker_macsimum_it.m3u', 'it'), ('stalker_macsimum_es.m3u', 'es'), ('stalker_macsimum_pt.m3u', 'pt'),
        ('stalker_macsimum_pl.m3u', 'pl'), ('stalker_macsimum_al.m3u', 'al'), ('stalker_macsimum_rs.m3u', 'rs'),
        ('stalker_macsimum_me.m3u', 'me'), ('stalker_macsimum_hr.m3u', 'hr'), ('stalker_macsimum_si.m3u', 'si'),
        ('stalker_macsimum_mk.m3u', 'mk'), ('stalker_macsimum_ba.m3u', 'ba'),
        ('stalker_macsimum_exyu_allgemein.m3u', 'exyu_allgemein'),
        ('stalker_macsimum_gr.m3u', 'gr'), ('stalker_macsimum_ro.m3u', 'ro'), ('stalker_macsimum_bg.m3u', 'bg'),
        ('stalker_macsimum_hu.m3u', 'hu'), ('stalker_macsimum_cz.m3u', 'cz'), ('stalker_macsimum_sk.m3u', 'sk'),
        ('stalker_macsimum_dk.m3u', 'dk'), ('stalker_macsimum_se.m3u', 'se'), ('stalker_macsimum_no.m3u', 'no'), ('stalker_macsimum_fi.m3u', 'fi'),
        ('stalker_macsimum_ru.m3u', 'ru'), ('stalker_macsimum_ua.m3u', 'ua'), ('stalker_macsimum_ge.m3u', 'ge'),
        ('stalker_macsimum_az.m3u', 'az'), ('stalker_macsimum_am.m3u', 'am'), ('stalker_macsimum_au.m3u', 'au'),
        ('stalker_macsimum_br.m3u', 'br'), ('stalker_macsimum_co.m3u', 'co'), ('stalker_macsimum_pe.m3u', 'pe'),
        ('stalker_macsimum_arabic_general.m3u', 'arabic_general'), ('stalker_macsimum_ma.m3u', 'ma'),
        ('stalker_macsimum_dz.m3u', 'dz'), ('stalker_macsimum_sa.m3u', 'sa'), ('stalker_macsimum_lb.m3u', 'lb'),
        ('stalker_macsimum_tn.m3u', 'tn'), ('stalker_macsimum_kw.m3u', 'kw'), ('stalker_macsimum_sd.m3u', 'sd'),
        ('stalker_macsimum_eg.m3u', 'eg'), ('stalker_macsimum_ps.m3u', 'ps'), ('stalker_macsimum_ae.m3u', 'ae'),
        ('stalker_macsimum_bh.m3u', 'bh'), ('stalker_macsimum_iq.m3u', 'iq'), ('stalker_macsimum_jo.m3u', 'jo'),
        ('stalker_macsimum_qa.m3u', 'qa'), ('stalker_macsimum_sy.m3u', 'sy'), ('stalker_macsimum_kurdish.m3u', 'kurdish'),
        ('stalker_macsimum_suryoyo.m3u', 'suryoyo'), ('stalker_macsimum_ir.m3u', 'ir'),
        ('stalker_macsimum_in.m3u', 'in'), ('stalker_macsimum_pk.m3u', 'pk'),
        ('stalker_macsimum_africa.m3u', 'africa'), ('stalker_macsimum_dstv.m3u', 'dstv'),
        ('stalker_macsimum_thailand.m3u', 'th'), ('stalker_macsimum_adult.m3u', 'adult'),
    )
    for marker, scope in mapping:
        if marker in text:
            return scope
    return 'de'

def _codex_use_epg_for_playlist(url, epg, mode):
    if not ((mode == 2 or mode == 10) and epg != None and epg != ''):
        return False
    # Die hinterlegte EPG-Datei ist der deutsche Macsimum-Subset.
    # Für ausländische Listen kostet sie viel Zeit und liefert kaum Treffer.
    return _codex_macsimum_scope_from_playlist_url(url) == 'de'

def _codex_render_cache_file(url, mode, gListIndex):
    norm = _codex_normalize_local_path(url)
    key = hashlib.md5(('%s:%s:%s' % (norm, mode, gListIndex)).encode('utf-8')).hexdigest()
    return os.path.join(renderListCacheDir, key + '.json')

def _codex_render_signature(url, epg, mode, gListIndex):
    use_epg = _codex_use_epg_for_playlist(url, epg, mode)
    epg_sig = None
    bucket = 'static'
    if use_epg:
        epg_norm = _codex_normalize_local_path(epg)
        epg_sig = _codex_file_signature(epg_norm)
        # Die EPG-Datei selbst ändert sich selten; die Anzeige "jetzt läuft"
        # muss trotzdem gelegentlich weiterwandern. 15 Minuten ist hier der
        # schnelle, praktische Kompromiss für diese Listenansicht.
        bucket = int(datetime.now().timestamp() // (15 * 60))
    return {
        'm3u': _codex_file_signature(url),
        'epg': epg_sig,
        'bucket': bucket,
        'mode': mode,
        'group': gListIndex,
        'makeGroups': bool(makeGroups),
    }

def _codex_load_render_cache(url, epg, mode, gListIndex):
    if not _codex_is_macsimum_m3u(url) or makeGroups:
        return None
    signature = _codex_render_signature(url, epg, mode, gListIndex)
    if not signature.get('m3u'):
        return None
    cache_file = _codex_render_cache_file(url, mode, gListIndex)
    try:
        with open(cache_file, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if payload.get('signature') == signature:
            return payload
    except Exception:
        pass
    return None

def _codex_save_render_cache(url, epg, mode, gListIndex, entries, tmpList):
    if not _codex_is_macsimum_m3u(url) or makeGroups:
        return
    signature = _codex_render_signature(url, epg, mode, gListIndex)
    if not signature.get('m3u'):
        return
    try:
        with open(_codex_render_cache_file(url, mode, gListIndex), 'w', encoding='utf-8') as handle:
            json.dump({'signature': signature, 'entries': entries, 'tmpList': tmpList}, handle, ensure_ascii=False)
        xbmc.log('[playlistloader.macsimum] Render cache saved: %s (%d)' % (os.path.basename(str(url)), len(entries)), xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log('[playlistloader.macsimum] Render cache save failed: %s' % ex, xbmc.LOGWARNING)

def _codex_set_macsimum_playlist_scope(url):
    try:
        scope = _codex_macsimum_scope_from_playlist_url(url)
        xbmcgui.Window(10000).setProperty('MacsimumPlaylistScope', scope)
        xbmc.log('[playlistloader.macsimum] MacsimumPlaylistScope=%s url=%s' % (scope, url), xbmc.LOGINFO)
    except Exception:
        pass

def _codex_clean_search_text(value):
    text = str(value or '')
    try:
        text = re.sub(r'\[/?(?:B|I|COLOR[^\]]*)\]', ' ', text, flags=re.I)
        text = re.sub(r'\[[^\]]+\]', ' ', text)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = unicodedata.normalize('NFKD', text)
        text = ''.join(ch for ch in text if not unicodedata.combining(ch))
        text = re.sub(r'[^0-9a-zA-ZäöüÄÖÜß]+', ' ', text)
        return ' '.join(text.lower().split())
    except Exception:
        return text.lower()

def _codex_matches_search(value, query):
    q = _codex_clean_search_text(query)
    if not q:
        return True
    hay = _codex_clean_search_text(value)
    if not hay:
        return False
    return all(token in hay for token in q.split())

def _codex_filter_cached_render_entries(entries, tmp_list, query):
    if not query:
        return entries, tmp_list
    keep_entries = []
    keep_tmp = []
    try:
        for entry in entries or []:
            if _codex_matches_search(entry.get('name', ''), query):
                keep_entries.append(entry)
        for item in tmp_list or []:
            if _codex_matches_search(item.get('name', ''), query):
                keep_tmp.append(item)
    except Exception:
        return entries, tmp_list
    return keep_entries, keep_tmp

def _codex_current_container_params():
    current = ''
    try:
        current = xbmc.getInfoLabel('Container.FolderPath') or ''
    except Exception:
        current = ''
    try:
        if '?' in current:
            return dict(urllib.parse.parse_qsl(current.split('?', 1)[1], keep_blank_values=True))
    except Exception:
        pass
    return {}

def _codex_plugin_url_from_params(params_dict):
    clean = {}
    for key, value in (params_dict or {}).items():
        if value is None:
            continue
        clean[str(key)] = str(value)
    return 'plugin://%s/?%s' % (AddonID, urllib.parse.urlencode(clean))

def QuickMacsimumSearch():
    current_params = _codex_current_container_params()
    try:
        current_mode = int(current_params.get('mode', '0') or '0')
    except Exception:
        current_mode = 0
    if current_mode not in (2, 10) or not current_params.get('url'):
        try:
            xbmcgui.Dialog().notification(AddonName, 'Keine Senderliste aktiv', icon, 1800)
        except Exception:
            pass
        return

    if (current_params.get('q') or '').strip():
        current_params.pop('q', None)
        xbmc.executebuiltin('Container.Update(%s,replace)' % _codex_plugin_url_from_params(current_params))
        return

    keyboard = xbmc.Keyboard('', 'Sender suchen')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    query = (keyboard.getText() or '').strip()
    if query:
        current_params['q'] = query
        xbmc.executebuiltin('Container.Update(%s)' % _codex_plugin_url_from_params(current_params))
    else:
        current_params.pop('q', None)
        xbmc.executebuiltin('Container.Update(%s,replace)' % _codex_plugin_url_from_params(current_params))

def _codex_epg_norm(value):
    text = unicodedata.normalize('NFKC', str(value or ''))
    text = text.replace('&', ' UND ')
    text = re.sub(r'\b(FHD|FULLHD|HD|RAW|HEVC|UHD|QHD|4K|2K|SD|HDR)\b', ' ', text, flags=re.I)
    text = re.sub(r'\.DE$', ' ', text, flags=re.I)
    text = re.sub(r'[^A-Za-z0-9ÄÖÜäöüß]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip().upper()

def _codex_build_epg_index(epgDict):
    index = {}
    try:
        for idx, epg_name in enumerate(epgDict.get(u'name') or []):
            for value in (epg_name,):
                key = _codex_epg_norm(value)
                if key and key not in index:
                    index[key] = idx
        for idx, row in enumerate(epgDict.get(u'data') or []):
            try:
                channel_id = row[0]
            except Exception:
                channel_id = ''
            for value in (channel_id, str(channel_id).replace('.', ' ')):
                key = _codex_epg_norm(value)
                if key and key not in index:
                    index[key] = idx
    except Exception:
        pass
    return index

def _codex_find_epg_idx(name, channel, epgDict, epgIndex):
    try:
        names = epgDict.get(u'name') or []
        if name in names:
            return names.index(name)
        candidates = [
            name,
            channel.get('tvg_name', ''),
            channel.get('tvg_id', ''),
            channel.get('display_name', ''),
        ]
        for candidate in candidates:
            key = _codex_epg_norm(candidate)
            if key in epgIndex:
                return epgIndex[key]
    except Exception:
        pass
    return None

def _codex_build_epg_now_index(epgDict, dnow, to_zone):
    now_index = {}
    try:
        data = epgDict.get(u'data') or []
        programmes = epgDict.get('prg') or {}
        for idx, item in enumerate(data):
            try:
                channel_id = item[0]
            except Exception:
                continue
            channel_programmes = programmes.get(channel_id) or []
            found = []
            take_next = False
            for programme in channel_programmes:
                try:
                    start, stop, title = programme[0], programme[1], programme[2]
                    desc = programme[3] if len(programme) > 3 else ''
                    stime = parser.parse(start)
                    etime = parser.parse(stop)
                except Exception:
                    continue
                if stime <= dnow <= etime or take_next:
                    found.append((stime, etime, title, desc))
                    if len(found) >= 2:
                        break
                    take_next = True
                elif dnow < stime and not take_next:
                    break
            if found:
                now_index[idx] = found
    except Exception as ex:
        xbmc.log('--- EPG now-index failed: {0}'.format(ex), 3)
    return now_index

if not (os.path.isfile(favoritesFile)):
    common.SaveList(favoritesFile, [])

if not (os.path.isfile(vDirectoriesFile)):
    common.SaveList(vDirectoriesFile, [])
        
makeGroups = False

    
def getLocaleString(id):
    return Addon.getLocalizedString(id)


def AddListItems(chList, addToVdir=True):
        
    cacheList = []
    i = 0

    for item in chList:
        mode = 1 if '.plx' in item["url"] else 2
        name = common.GetEncodeString(item["name"])
        
        image = item.get('image', '')
        uuid4 = item["uuid"]
        
        if image == "" or image is None:
            image = os.path.join(iconsDir, "default-list-image.png")
        
        logos = item.get('logos', '')
        epg = item.get('epg', '')
        cacheMin = item.get('cache', '0')
        if item["url"].startswith('http'):
            cacheList.append(hashlib.md5(item["url"].encode()).hexdigest())
        AddDir("{0}".format(name), item["url"], mode, image, logos, epg, index=i, uuid=uuid4, cacheMin=cacheMin, addToVdir=addToVdir)
        i += 1

    for the_file in os.listdir(cacheDir):
        file_path = os.path.join(cacheDir, the_file)
        try:
            if os.path.isfile(file_path) and the_file not in cacheList:
                os.unlink(file_path)
        except Exception as ex:
            xbmc.log("{0}".format(ex), 3)

    
def Categories():
    AddDir("[B]{0}: {1}[/B] - {2} ".format(getLocaleString(30036), getLocaleString(30037) if makeGroups else getLocaleString(30038), getLocaleString(30039)), "setting", 50, os.path.join(iconsDir, "setting.png"), isFolder=False)
    AddDir("[COLOR white][B][{0}][/B][/COLOR]".format(getLocaleString(30003)), "favorites", 30, os.path.join(iconsDir, "bright_yellow_star.png"))
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30001)), "newList", 20, os.path.join(iconsDir, "NewList.ico"), isFolder=False)
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30040)), "newDirectory", 43, os.path.join(iconsDir, "New-folder.png"), isFolder=False)

    # Displaying virtual directories.
    vDirs = common.ReadList(vDirectoriesFile)
    y = 0
    for vDir in vDirs:
        dir_icon = vDir["icon"] if not vDir["icon"] == "" else os.path.join(iconsDir, "default-folder-image.png")
        AddDir("[COLOR green][B]{0}[/B][/COLOR]".format(vDir["name"]), "{0}".format(y), 44, dir_icon, uuid=vDir["uuid"], isFolder=True)
        y += 1
    
    ignored = []
    for vdir in vDirs:
        if len(vdir["data"]) > 0:
            ignored += vdir["data"]
    
    i = 0
    chList = common.ReadList(playlistsFile) 
    addList = []
    try:	
        for uitem in chList:
            if "uuid" in uitem and not uitem["uuid"] in ignored:
                addList.append(chList[i])
            i += 1
    except:
        addList = chList

    AddListItems(addList)


def AddNewList():
    listName = GetKeyboardText(getLocaleString(30004)).strip()
    if len(listName) < 1:
        return
    listUrl = GetChoice(30002, 30005, 30006, 30016, 30017, fileType=1, fileMask='.plx|.m3u|.m3u8')
    if len(listUrl) < 1:
        return
    image = GetChoice(30022, 30022, 30022, 30024, 30025, 30021, fileType=2)
    logosUrl = '' if listUrl.endswith('.plx') else GetChoice(30018, 30019, 30020, 30019, 30020, 30021, fileType=0)
    if logosUrl.startswith('http') and not logosUrl.endswith('/'):
        logosUrl += '/'
    epgUrl = '' if listUrl.endswith('.plx') else GetChoice(30046, 30047, 30048, 30047, 30048, 30021, fileType=1, fileMask='.xml')
#    if epgUrl.startswith('http') and not epgUrl.endswith('/'):
#        epgUrl += '/'
    cacheInMinutes = GetNumFromUser(getLocaleString(30034), '0') if listUrl.startswith('http') else 0
    if cacheInMinutes is None:
        cacheInMinutes = 0
    chList = common.ReadList(playlistsFile)
    for item in chList:
        if item["url"].lower() == listUrl.lower():
            xbmc.executebuiltin('Notification({0}, "{1}" {2}, 5000, {3})'.format(AddonName, item["name"], getLocaleString(30007), icon))
            return
    chList.append({"name": listName, "url": listUrl, "image": image, "logos": logosUrl, "epg": epgUrl, "cache": cacheInMinutes, "uuid": str(random.uuid4())})
    if common.SaveList(playlistsFile, chList):
        xbmc.executebuiltin("Container.Refresh()")


def GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, defaultText=""):
    choice = ''
    choiceList = [getLocaleString(choiceFile), getLocaleString(choiceUrl)]
    if choiceNone is not None:
        choiceList = [getLocaleString(choiceNone)] + choiceList
    method = GetSourceLocation(getLocaleString(choiceTitle), choiceList)    
    if choiceNone is None and method == 0 or choiceNone is not None and method == 1:
        if not defaultText.startswith('http'):
            defaultText = ""
        choice = GetKeyboardText(getLocaleString(fileTitle), defaultText).strip()
    elif choiceNone is None and method == 1 or choiceNone is not None and method == 2:
        if defaultText.startswith('http'):
            defaultText = ""
        choice = xbmcgui.Dialog().browse(fileType, getLocaleString(urlTitle), 'files', fileMask, False, False, defaultText)
    return choice

    
def RemoveFromLists(iuuid, listFile):

    chList = common.ReadList(listFile) 
    vDirsList = common.ReadList(vDirectoriesFile)
    
    i = 0
    for playlist in chList:
        if playlist["uuid"] == iuuid:
            del chList[i]
        i += 1
    
    # Removing from vdir lists.
    for vDir in vDirsList:
        i = 0
        for uuid4 in vDir["data"]:
            if iuuid in uuid4:
                del vDir["data"][i]
            i += 1
            
    common.SaveList(listFile, chList)
    common.SaveList(vDirectoriesFile, vDirsList)
    
    xbmc.executebuiltin("Container.Refresh()")

        
def RemoveFromFavourites(index):
    
    favList = common.ReadList(favoritesFile)
    if index < 0 or index >= len(favList):
        return
    del favList[index]
    common.SaveList(favoritesFile, favList)
    xbmc.executebuiltin("Container.Refresh()")

            
def PlxCategory(url, cache):
    tmpList = []
    chList = common.plx2list(url, cache)
    background = chList[0]["background"]
    for channel in chList[1:]:
        iconimage = "" if "thumb" not in channel else common.GetEncodeString(channel["thumb"])
        name = common.GetEncodeString(channel["name"])
        if channel["type"] == 'playlist':
            AddDir("[{0}]".format(name), channel["url"], 1, iconimage, background=background)
        else:
            AddDir(name, channel["url"], 3, iconimage, isFolder=False, IsPlayable=True, background=background)
            tmpList.append({"url": channel["url"], "image": iconimage, "name": name})
            
    common.SaveList(tmpListFile, tmpList)

            
def m3uCategory(url, logos, epg, cache, mode, gListIndex=-1, searchQuery=""): 
      
    _codex_set_macsimum_playlist_scope(url)

    meta = None

    global _CODEX_PENDING_DIR_ITEMS, _CODEX_RENDER_CAPTURE
    cached_render = _codex_load_render_cache(url, epg, mode, gListIndex)
    if cached_render:
        cached_entries, cached_tmp = _codex_filter_cached_render_entries(
            cached_render.get('entries') or [],
            cached_render.get('tmpList') or [],
            searchQuery,
        )
        _codex_prefetch_channel_logos(cached_entries, _codex_macsimum_scope_from_playlist_url(url))
        previous_pending_dir_items = _CODEX_PENDING_DIR_ITEMS
        previous_render_capture = _CODEX_RENDER_CAPTURE
        _CODEX_PENDING_DIR_ITEMS = []
        _CODEX_RENDER_CAPTURE = None
        try:
            for entry in cached_entries:
                AddDir(**entry)
            if _CODEX_PENDING_DIR_ITEMS:
                xbmcplugin.addDirectoryItems(int(sys.argv[1]), _CODEX_PENDING_DIR_ITEMS, len(_CODEX_PENDING_DIR_ITEMS))
            common.SaveList(tmpListFile, cached_tmp)
            xbmc.log('[playlistloader.macsimum] Render cache hit: %s (%d%s)' % (os.path.basename(str(url)), len(cached_entries), (', search=%s' % searchQuery) if searchQuery else ''), xbmc.LOGINFO)
        finally:
            _CODEX_PENDING_DIR_ITEMS = previous_pending_dir_items
            _CODEX_RENDER_CAPTURE = previous_render_capture
        return

    previous_pending_dir_items = _CODEX_PENDING_DIR_ITEMS
    previous_render_capture = _CODEX_RENDER_CAPTURE
    _CODEX_PENDING_DIR_ITEMS = []
    _CODEX_RENDER_CAPTURE = []
    tmpList = []
    try:
      chList = _codex_m3u2list_cached(url, cache)
      if searchQuery:
          chList = [channel for channel in chList if _codex_matches_search(channel.get("display_name", "") or channel.get("group_title", ""), searchQuery)]
      _codex_prefetch_channel_logos(chList, _codex_macsimum_scope_from_playlist_url(url))
      if _codex_use_epg_for_playlist(url, epg, mode):
        epgDict, epgIndex, epgNow, dnow, to_zone = _codex_epg_context_cached(epg, cache=720)
        use_percent = 'true'
        use_time = 'true'
      else:
        epgDict = {}
        epgIndex = {}
        epgNow = {}
    
      #xbmc.log('EPGDICT')
      #xbmc.log(str(epgDict))
      groupChannels = []
      
      for channel in chList:
          if makeGroups:
              matches = [groupChannels.index(x) for x in groupChannels if len(x) > 0 and x[0].get("group_title", x[0]["display_name"]) == channel.get("group_title", channel["display_name"])]
          
          if makeGroups and len(matches) == 1:
              groupChannels[matches[0]].append(channel)
          else:
              groupChannels.append([channel])
          
      for channels in groupChannels:
          idx = groupChannels.index(channels)
          if gListIndex > -1 and gListIndex != idx:
              continue
          isGroupChannel = gListIndex < 0 and len(channels) > 1
          chs = [channels[0]] if isGroupChannel else channels
          
          for channel in chs:
              name = common.GetEncodeString(channel["display_name"]) if not isGroupChannel else common.GetEncodeString(channel.get("group_title", channel["display_name"]))
              plot = "" if meta is None else meta[channel["group_title"]]["overview"] if channel["group_title"] in meta else ""
              fanart = "" if meta is None else meta[channel["group_title"]]["fanarts"][0] if (channel["group_title"] in meta and len(meta[channel["group_title"]]["fanarts"]) > 0) else ""

              if isGroupChannel:
                  name = '{0}'.format(name)
                  chUrl = url
                  try:
                      image = channel['tvg_logo'] if meta is None else meta[channel["group_title"]]["poster"] if channel["group_title"] in meta else channel['tvg_logo']
                  except KeyError:
                      image = "DefaultTVShows.png"
                  AddDir(name ,url, 10, epg=epg, index=idx, iconimage=image, cacheMin=cache, plot=plot, fanart=fanart)
              else:
                  chUrl = common.GetEncodeString(channel["url"])
                  image = channel.get("tvg_logo", channel.get("logo", ""))

                  if epgDict:
                      idx = None
                      id = None
                      if epgDict.get(u'name'):
                          idx = _codex_find_epg_idx(name, channel, epgDict, epgIndex)
                          if image == "" and idx is not None:
                                  image = epgDict[u'data'][idx][1]
                                  
                          t2len = 0
                          title2nd = ''
                          edescr = ''
                          next = False

                          if idx is not None:
                              for stime, etime, title, desc in epgNow.get(idx, []):
                                  ebgn = stime.astimezone(to_zone).strftime('%H:%M')
                                  eend = etime.astimezone(to_zone).strftime('%H:%M')
                                  if use_time == 'true':
                                      stmp = '%s-%s' % (ebgn, eend)
                                      t2len += (len(stmp) + 1)
                                      if not next: title2nd += ' [COLOR FF00BB66]%s[/COLOR]' % stmp
                                      else:  title2nd += ' %s' % stmp
                                  title2nd += ' %s' % title
                                  t2len += (len(title) + 1)

                                  title2nd = title2nd.replace('&quot;','`').replace('&amp;',' & ')
                                  desc = common.GetEncodeString(desc).replace('&quot;','`').replace('&amp;',' & ').strip()
                                  if not t2len: t2len = len(name)
                                  if not next:
                                      plot += '[B][COLOR FF0084FF]%s-%s[/COLOR]\n[COLOR FFFFFFFF]%s[/COLOR][/B]' % (ebgn, eend, title)
                                      if desc:
                                          plot += '\n\n[COLOR FFFFFF00]%s[/COLOR]' % desc
                                      name = '[B]%s[/B]\n%s' % (name.ljust(int(t2len * 1.65)), title2nd)
                                      next = True
                                  else:
                                      plot += '\n\n[B][COLOR FF0084FF]%s-%s[/COLOR]\n%s[/B]' % (ebgn, eend, title)
                                      if desc:
                                          plot += '\n[COLOR FFFFFF00]%s[/COLOR]' % desc
                                      next = False
                                      break
                                      

                  
                  if logos is not None and logos != ''  and image != "" and not image.startswith('http'):
                      image = logos + image
                  image = _codex_logo_local_path(image)
                  AddDir(name, chUrl, 3, image, epg=epg, index=-1, isFolder=False, IsPlayable=True, plot=plot, fanart=fanart)
              tmpList.append({"url": chUrl, "image": image, "name": name})
      
      if _CODEX_PENDING_DIR_ITEMS:
          xbmcplugin.addDirectoryItems(int(sys.argv[1]), _CODEX_PENDING_DIR_ITEMS, len(_CODEX_PENDING_DIR_ITEMS))
      common.SaveList(tmpListFile, tmpList)
      _codex_save_render_cache(url, epg, mode, gListIndex, _CODEX_RENDER_CAPTURE or [], tmpList)
    finally:
      _CODEX_PENDING_DIR_ITEMS = previous_pending_dir_items
      _CODEX_RENDER_CAPTURE = previous_render_capture

        
def _codex_abort_playurl_busy_state(reason=""):
    try:
        xbmc.log('CODEX-PLAYLISTLOADER-ABORT cleanup: {0}'.format(reason or "-"), 3)
    except Exception:
        pass
    try:
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
    except Exception:
        pass
    try:
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
    except Exception:
        pass
    try:
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass

def PlayUrl(name, url, iconimage=None):
    global _CODEX_PLAYURL_HANDLED
    _CODEX_PLAYURL_HANDLED = True
    url = common.getFinalUrl(url)
    xbmc.log('--- Playing "{0}". {1}'.format(name, url), 2)
    if isinstance(url, str) and url.startswith('plugin://'):
        # Codex bridge: hand the bridged source plugin to Kodi as the resolved
        # playable item. Returning False here tears down playback as soon as the
        # user jumps back from fullscreen to the channel list.
        listitem = xbmcgui.ListItem(name or "Live TV", path=url)
        listitem.setProperty('IsPlayable', 'true')
        listitem.setInfo(type="Video", infoLabels={"mediatype": "movie", "Title": name or "Live TV"})
        try:
            if iconimage is not None:
                listitem.setArt({'icon': iconimage, 'thumb': iconimage})
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        return
    if not IsStreamReachable(url):
        xbmc.log('--- Stream not reachable, skipping "{0}". {1}'.format(name, url), 3)
        _codex_abort_playurl_busy_state('unreachable: {0}'.format(name))
        try:
            xbmcgui.Dialog().notification(AddonName, 'Kanal nicht erreichbar', icon, 2500)
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        _codex_abort_playurl_busy_state('resolved false: {0}'.format(name))
        return
    listitem = xbmcgui.ListItem(path=url)
    if ".mpd" in url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    if ".m3u8" in url:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    listitem.setInfo(type="Video", infoLabels={"mediatype": "movie"})
        
    if iconimage is not None:
        try:
            listitem.setArt({'thumb' : iconimage})
        except:
            listitem.setThumbnailImage(iconimage)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def IsStreamReachable(url, timeout=4):
    if not url or not url.startswith(('http://', 'https://')):
        return True
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', common.UA)
        req.add_header('Range', 'bytes=0-1023')
        with urllib.request.urlopen(req, timeout=timeout) as response:
            status = response.getcode()
            if status is not None and status >= 400:
                return False
            response.read(1024)
            return True
    except Exception as ex:
        xbmc.log('--- Stream reachability check failed: {0}'.format(ex), 3)
        return False


def AddDir(name, url, mode, iconimage='', logos='', epg='', index=-1, move=0, uuid='0', isFolder=True, IsPlayable=False,
           background=None, cacheMin='0', plot="", fanart="", addToVdir=True):
    iconimage = _codex_logo_local_path(iconimage)
    if _CODEX_RENDER_CAPTURE is not None:
        try:
            _CODEX_RENDER_CAPTURE.append({
                'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage,
                'logos': logos, 'epg': epg, 'index': index, 'move': move,
                'uuid': uuid, 'isFolder': isFolder, 'IsPlayable': IsPlayable,
                'background': background, 'cacheMin': cacheMin, 'plot': plot,
                'fanart': fanart, 'addToVdir': addToVdir,
            })
        except Exception:
            pass
    urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'epg': epg, 'cache': cacheMin, 'uuid': uuid}
    if mode == 2 and _codex_is_macsimum_m3u(url):
        version_token = _codex_m3u_version_token(url)
        if version_token:
            urlParams['codex_v'] = version_token
    
    liz = xbmcgui.ListItem(name, iconimage, iconimage)
    liz.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage, 'landscape': iconimage})
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": plot, "plot": plot, "PlotOutline": plot, "plotoutline": plot, "tagline": ''})
    liz.setProperty("fanart_image", fanart)
    items = []
    
    listMode = 21  # Lists
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if background != None:
        liz.setProperty('fanart_image', background)
    
    if mode == 1 or mode == 2:
        items = [
            (getLocaleString(30008), 'RunPlugin({0}?index={1}&mode=22&uuid={2})'.format(sys.argv[0], index, uuid)),
            (getLocaleString(30026), 'RunPlugin({0}?index={1}&mode=23&uuid={2})'.format(sys.argv[0], index, uuid)),
            (getLocaleString(30027), 'RunPlugin({0}?index={1}&mode=24&uuid={2})'.format(sys.argv[0], index, uuid)),
            (getLocaleString(30028), 'RunPlugin({0}?index={1}&mode=25&uuid={2})'.format(sys.argv[0], index, uuid))
        ]
        
        if mode == 2 and not url.endswith('.plx'):
            items.append((getLocaleString(30029), 'RunPlugin({0}?index={1}&mode=26&uuid={2})'.format(sys.argv[0], index, uuid)))
            items.append((getLocaleString(30045), 'RunPlugin({0}?index={1}&mode=29&uuid={2})'.format(sys.argv[0], index, uuid)))
        if url.startswith('http'):
            items.append((getLocaleString(30035), 'RunPlugin({0}?index={1}&mode=28&uuid={2})'.format(sys.argv[0], index, uuid)))
                    
    elif mode == 3:
        items = [
            (getLocaleString(30009), 'RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3}&uuid={4})'.format(sys.argv[0], urllib.parse.quote_plus(url), iconimage, name, uuid))
        ]
    
    elif mode == 32:
        items = [
            (getLocaleString(30010), 'RunPlugin({0}?index={1}&mode=33)'.format(sys.argv[0], index)),
            (getLocaleString(30026), 'RunPlugin({0}?index={1}&mode=35)'.format(sys.argv[0], index)),
            (getLocaleString(30027), 'RunPlugin({0}?index={1}&mode=36)'.format(sys.argv[0], index)),
            (getLocaleString(30028), 'RunPlugin({0}?index={1}&mode=37)'.format(sys.argv[0], index))
        ]
        listMode = 38 # Favourits
    
    elif mode == 44:
        items = [
            (getLocaleString(30043), 'RunPlugin({0}?index={1}&mode=46&uuid={2})'.format(sys.argv[0], index, uuid)),
            (getLocaleString(30044), 'RunPlugin({0}?index={1}&mode=47&uuid={2})'.format(sys.argv[0], index, uuid))
        ]
    
    if mode == 1 or mode == 2 or mode == 32:
        items += [
            (getLocaleString(30030), 'RunPlugin({0}?index={1}&mode={2}&move=-1&uuid={3})'.format(sys.argv[0], index, listMode, uuid)),
            (getLocaleString(30031), 'RunPlugin({0}?index={1}&mode={2}&move=1&uuid={3})'.format(sys.argv[0], index, listMode, uuid))
            #(getLocaleString(30032), 'RunPlugin({0}?index={1}&mode={2}&move=0&uuid={3})'.format(sys.argv[0], index, listMode, uuid))
        ]
        
        if addToVdir:
            items += [
                (getLocaleString(30041), 'RunPlugin({0}?index={1}&mode=45&move=-1&uuid={2})'.format(sys.argv[0], index, uuid)),
        ]
    
    if mode == 10:
        urlParams['index'] = index
        
    liz.addContextMenuItems(items)
        
    u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
    if _CODEX_PENDING_DIR_ITEMS is not None:
        _CODEX_PENDING_DIR_ITEMS.append((u, liz, isFolder))
    else:
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


def GetKeyboardText(title="", defaultText=""):
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text = "" if not keyboard.isConfirmed() else keyboard.getText()
    return text


def GetSourceLocation(title, chList):
    dialog = xbmcgui.Dialog()
    answer = dialog.select(title, chList)
    return answer


def AddFavorites(url, iconimage, name):
    # Checking if url already in list.
    favList = common.ReadList(favoritesFile)
    for item in favList:
        if item["url"].lower() == url.lower():
            xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, getLocaleString(30011), icon))
            return
    
    chList = common.ReadList(tmpListFile)    
    for channel in chList:
        if channel["name"].lower() == name.lower():
            url = channel["url"]
            iconimage = channel["image"]
            break
    if not iconimage:
        iconimage = ""
        
    data = {"url": url, "image": iconimage, "name": name}
    favList.append(data)
    common.SaveList(favoritesFile, favList)
    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, getLocaleString(30012), icon))


def AddNewDirectory():
    dir_name = GetKeyboardText(getLocaleString(30040), "My new directory name")
    dir_icon = xbmcgui.Dialog().browse(1, getLocaleString(30042), 'files')
    
    if dir_name != "":
        vDirs = common.ReadList(vDirectoriesFile)
        vDirs.append({"name": dir_name, "data": [], "icon": dir_icon, "uuid": str(random.uuid4())})
        
        common.SaveList(vDirectoriesFile, vDirs)
        xbmc.executebuiltin("Container.Refresh()")


def AddToDirectory(playlist_uuid):
    # if vdir is none, ask to choose one
    vdirs = common.ReadList(vDirectoriesFile)
        
    dialog = xbmcgui.Dialog()
    svdir = dialog.select("Choose the directory were to attach this playlist", [item["name"] for item in vdirs])
    vdirs[svdir]["data"].append(playlist_uuid)
    common.SaveList(vDirectoriesFile, vdirs)
    xbmc.executebuiltin("Container.Refresh()")


def DeleteDirectory(iuuid, with_contents=False):
    vDirs = common.ReadList(vDirectoriesFile)
    y = 0
    for vdir in vDirs:
        if vdir["uuid"] == iuuid:
            if with_contents:
                contents = common.ReadList(playlistsFile)
                i = 0
                uuids = vdir["data"]
                uuids = [uuid4 for uuid4 in uuids]
                for content in contents:
                    if content["uuid"] in uuids:
                        del contents[i]
                    i += 1
                common.SaveList(playlistsFile, contents)
            del vDirs[y]
            common.SaveList(vDirectoriesFile, vDirs)
            xbmc.executebuiltin("Container.Refresh()")
        y += 1   
    

def ShowDirectoryContents(directory_uuid):
    vDirs = common.ReadList(vDirectoriesFile)
    dirFiles = lsDir(directory_uuid)
    
    if dirFiles is None:
        return
    
    chList = common.ReadList(playlistsFile)
    lPlaylists = []
    
    for pUuid in dirFiles:
        for playlist in chList:
            if pUuid == playlist["uuid"]:
                lPlaylists.append(playlist) 
        
    _codex_prewarm_macsimum_playlists(lPlaylists)
    AddListItems(lPlaylists, addToVdir=False)


def ListFavorites():
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(getLocaleString(30013)), "favorites", 34, os.path.join(iconsDir, "bright_yellow_star.png"), isFolder=False)
    chList = common.ReadList(favoritesFile)
    i = 0
    for channel in chList:
        AddDir(channel["name"], channel["url"], 32, channel["image"], index=i, isFolder=False, IsPlayable=True)
        i += 1
      

def AddNewFavorite():
    chName = GetKeyboardText(getLocaleString(30014))
    if len(chName) < 1:
        return
    chUrl = GetKeyboardText(getLocaleString(30015))
    if len(chUrl) < 1:
        return
    image = GetChoice(30023, 30023, 30023, 30024, 30025, 30021, fileType=2)
        
    favList = common.ReadList(favoritesFile)
    for item in favList:
        if item["url"].lower() == chUrl.lower():
            xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, getLocaleString(30011), icon))
            return
            
    data = {"url": chUrl, "image": image, "name": chName}
    
    favList.append(data)
    if common.SaveList(favoritesFile, favList):
        xbmc.executebuiltin("Container.Refresh()")


def GetPlaylistIndex(iuuid, listFile):
    chList = common.ReadList(listFile)
    
    i = 0
    for playlist in chList:
        if playlist["uuid"] == iuuid:
            return i
        i += 1
       

def lsDir(iuuid):
    chDirs = common.ReadList(vDirectoriesFile)
    for vdir in chDirs:
        if vdir["uuid"] == iuuid:
            return vdir["data"]
    return None


def ChangeKey(iuuid, listFile, key, title, favourites=False):
    chList = common.ReadList(listFile)
    index = GetPlaylistIndex(iuuid, listFile) if not favourites else iuuid
    
    str = GetKeyboardText(getLocaleString(title), chList[index][key])
    if len(str) < 1:
        return
        
    chList[index][key] = str
    if common.SaveList(listFile, chList):
        xbmc.executebuiltin("Container.Refresh()")
        

def ChangeChoice(iuuid, listFile, key, choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, favourites=False):
    index = GetPlaylistIndex(iuuid, listFile) if not favourites else iuuid
    chList = common.ReadList(listFile)
    defaultText = chList[index].get(key, "")
    str = GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone, fileType, fileMask, defaultText)
    if key == "url" and len(str) < 1:
        return
    elif key == "logos" and str.startswith('http') and not str.endswith('/'):
        str += '/'
    chList[index][key] = str
    if common.SaveList(listFile, chList):
        xbmc.executebuiltin("Container.Refresh()")
    

def MoveInFavourites(index, step):
    
    theList = common.ReadList(favoritesFile)

    if index + step >= len(theList) or index + step < 0:
        return
    if step == 0:
        step = GetIndexFromUser(len(theList), index)
    
    if step < 0:
        tempList = theList[0:index + step] + [theList[index]] + theList[index + step:index] + theList[index + 1:]
    elif step > 0:
        tempList = theList[0:index] + theList[index +  1:index + 1 + step] + [theList[index]] + theList[index + 1 + step:]
    else:
        return
    common.SaveList(favoritesFile, tempList)
    xbmc.executebuiltin("Container.Refresh()")


def MoveInList(iuuid, step, listFile):
    
    def moveOnPlaylist(index, step, tList):
        tempList = None
        if index + step >= len(tList) or index + step < 0:
            return None
        
        if step == 0:
            step = GetIndexFromUser(len(tList), index)
    
        if step < 0:
            tempList = tList[0:index + step] + [tList[index]] + tList[index + step:index] + tList[index + 1:]
    
        elif step > 0:
            tempList = tList[0:index] + tList[index +  1:index + 1 + step] + [tList[index]] + tList[index + 1 + step:]
        
        else:
            return None
        
        return tempList
   
    theList = common.ReadList(listFile)
    
    # Checking that playlist is not in a directory.
    dir = False
    vdirs = common.ReadList(vDirectoriesFile)
    for vdir in vdirs:
        uuids4 = [uuid4 for uuid4 in vdir["data"]]
        if iuuid in uuids4:
            dir = vdir
    
    if not dir is False:
        # Moving two sides, directories and global list ( in case of directory removal )
        dirFiles = lsDir(dir["uuid"])
        
        ffiles = [tfile for tfile in theList if tfile["uuid"] in dirFiles]
        rfiles = [tfile for tfile in theList if tfile["uuid"] not in dirFiles]
        
        ffiles = moveOnPlaylist(dirFiles.index(iuuid), step, ffiles)
        
        if not ffiles is None:
            common.SaveList(listFile, rfiles + ffiles)
        
        # Movin it directory side.
        idx = vdirs.index(vdir)
        vdir["data"] = [item["uuid"] for item in ffiles]
        vdirs[idx] = vdir
        common.SaveList(vDirectoriesFile, vdirs)
            
    else:
        dirFiles = [item for data in vdirs for item in lsDir(data["uuid"])]
        dirItems    = [playlist for playlist in common.ReadList(listFile) if playlist["uuid"] in dirFiles]
        notDirFiles = [playlist for playlist in common.ReadList(listFile) if not playlist["uuid"] in dirFiles]
        
        idx = 0
        for playlist in notDirFiles:
            if playlist["uuid"] == iuuid:
                break
            idx += 1
        
        ffiles = moveOnPlaylist(idx, step, notDirFiles)
    
        if not ffiles is None:
            common.SaveList(listFile, dirItems + ffiles)
        
    xbmc.executebuiltin("Container.Refresh()")


def GetNumFromUser(title, defaultt=''):
    dialog = xbmcgui.Dialog()
    choice = dialog.input(title, defaultt=defaultt, type=xbmcgui.INPUT_NUMERIC)
    return None if choice == '' else int(choice)


def GetIndexFromUser(listLen, index):
    dialog = xbmcgui.Dialog()
    location = GetNumFromUser('{0} (1-{1})'.format(getLocaleString(30033), listLen))
    return 0 if location is None or location > listLen or location <= 0 else location - 1 - index


def ChangeCache(iuuid, listFile):
    index = GetPlaylistIndex(iuuid, listFile)
    chList = common.ReadList(listFile)
    defaultText = chList[index].get('cache', 0)
    cacheInMinutes = GetNumFromUser(getLocaleString(30034), str(defaultText)) if chList[index].get('url', '0').startswith('http') else 0
    if cacheInMinutes is None:
        return
    chList[index]['cache'] = cacheInMinutes
    if common.SaveList(listFile, chList):
        xbmc.executebuiltin("Container.Refresh()")


def ToggleGroups():
    notMakeGroups = "false" if makeGroups else "true"
    Addon.setSetting("makeGroups", notMakeGroups)
    xbmc.executebuiltin("Container.Refresh()")

params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?','')))
url = params.get('url')
logos = params.get('logos', '')
epg = params.get('epg', '')
name = params.get('name')
iconimage = params.get('iconimage')
cache = int(params.get('cache', '0'))
index = int(params.get('index', '-1'))
move = int(params.get('move', '0'))
mode = int(params.get('mode', '0'))
uuid = params.get('uuid', '0')
searchQuery = params.get('q', '')

if mode == 0:
    Categories()

elif mode == 1:
    PlxCategory(url, cache)
    
elif mode == 2 or mode == 10:
    m3uCategory(url, logos, epg, cache, mode, index, searchQuery)

elif mode == 3 or mode == 32:
    PlayUrl(name, url, iconimage)

elif mode == 20:
    AddNewList()
    
elif mode == 21:
    MoveInList(uuid, move, playlistsFile)

elif mode == 22:
    RemoveFromLists(uuid, playlistsFile)

elif mode == 23:
    ChangeKey(uuid, playlistsFile, "name", 30004)
    
elif mode == 24:
    ChangeChoice(uuid, playlistsFile, "url", 30002, 30005, 30006, 30016, 30017, None, 1, '.plx|.m3u|.m3u8')
    
elif mode == 25:
    ChangeChoice(uuid, playlistsFile, "image", 30022, 30022, 30022, 30024, 30025, 30021, 2)
    
elif mode == 26:
    ChangeChoice(uuid, playlistsFile, "logos", 30018, 30019, 30020, 30019, 30020, 30021, 0)
    
elif mode == 27:
    common.DelFile(playlistsFile)
    sys.exit()

elif mode == 28:
    ChangeCache(uuid, playlistsFile)
    
elif mode == 29:
    ChangeChoice(uuid, playlistsFile, "epg", 30046, 30047, 30048, 30047, 30048, 30021, 0)    

elif mode == 30:
    ListFavorites() 

elif mode == 31: 
    AddFavorites(url, iconimage, name)

elif mode == 33:
    RemoveFromFavourites(index)
    
elif mode == 34:
    AddNewFavorite()
    
elif mode == 35:
    ChangeKey(index, favoritesFile, "name", 30014, favourites=True)
    
elif mode == 36:
    ChangeKey(index, favoritesFile, "url", 30015, favourites=True)  

elif mode == 37:
    ChangeChoice(index, favoritesFile, "image", 30023, 30023, 30023, 30024, 30025, 30021, 2, favourites=True)

elif mode == 38:
    MoveInFavourites(index, move)
     
elif mode == 39:
    common.DelFile(favoritesFile)
    sys.exit()      
        
elif mode == 43:
    AddNewDirectory()

elif mode == 44:
    ShowDirectoryContents(uuid)

elif mode == 45:
    AddToDirectory(uuid)

elif mode == 46:
    DeleteDirectory(uuid, with_contents=True)

elif mode == 47:
    DeleteDirectory(uuid)

elif mode == 50:
    ToggleGroups()

elif mode == 51:
    QuickMacsimumSearch()

try:
    if mode in (2, 3, 10):
        xbmcplugin.setContent(int(sys.argv[1]), 'videos')
    if mode in (2, 10):
        xbmc.executebuiltin('Container.SetViewMode(50)')
except Exception:
    pass

cache_to_disc = False
try:
    cache_to_disc = mode in (2, 10) and _codex_is_macsimum_m3u(url)
except Exception:
    cache_to_disc = False

if not _CODEX_PLAYURL_HANDLED:
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=cache_to_disc)
