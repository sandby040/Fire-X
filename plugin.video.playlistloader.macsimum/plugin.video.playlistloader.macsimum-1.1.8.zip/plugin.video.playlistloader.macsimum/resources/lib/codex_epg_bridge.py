import gzip
import json
import os
import re
import time
import unicodedata
from datetime import datetime
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET


SOURCE_URL = 'https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz'
USER_AGENT = 'Mozilla/5.0 (Kodi EPG Bridge)'
QUALITY_RE = re.compile(r'\b(FHD|FULLHD|HD|RAW|HEVC|UHD|QHD|4K|2K|SD|HDR|H265|H\.265|X265)\b', re.I)
ATTR_RE = re.compile(r'([A-Za-z0-9_-]+)="([^"]*)"')


def _norm(value):
    text = unicodedata.normalize('NFKC', str(value or ''))
    text = text.replace('&', ' UND ')
    text = text.replace('+', ' PLUS ')
    text = re.sub(r'\[[^\]]*\]', ' ', text)
    text = re.sub(r'\([^)]*\)', ' ', text)
    text = QUALITY_RE.sub(' ', text)
    text = re.sub(r'\b(DE|GER|GERMANY|DEUTSCHLAND|VIP|RAW)\b', ' ', text, flags=re.I)
    text = re.sub(r'\.DE$', ' ', text, flags=re.I)
    text = re.sub(r'[^A-Za-z0-9ÄÖÜäöüß]+', ' ', text)
    text = text.replace('Ä', 'AE').replace('Ö', 'OE').replace('Ü', 'UE').replace('ẞ', 'SS')
    text = text.replace('ä', 'AE').replace('ö', 'OE').replace('ü', 'UE').replace('ß', 'SS')
    return re.sub(r'\s+', ' ', text).strip().upper()


ALIASES = {
    'ARD': 'Das.Erste.de',
    'DAS ERSTE': 'Das.Erste.de',
    'ERSTE': 'Das.Erste.de',
    'ZDF NEO': 'ZDFneo.de',
    'ZDFNEO': 'ZDFneo.de',
    'ZDF INFO': 'ZDFinfo.de',
    'ZDFINFO': 'ZDFinfo.de',
    'RTL2': 'RTLZWEI.de',
    'RTL II': 'RTLZWEI.de',
    'RTL ZWEI': 'RTLZWEI.de',
    'RTLZWEI': 'RTLZWEI.de',
    'SUPERRTL': 'SUPER.RTL.de',
    'SUPER RTL': 'SUPER.RTL.de',
    'RTL PLUS': 'RTLup.de',
    'RTL UP': 'RTLup.de',
    'SAT1': 'SAT.1.de',
    'SAT 1': 'SAT.1.de',
    'SAT 1 GOLD': 'SAT.1.Gold.de',
    'SAT1 GOLD': 'SAT.1.Gold.de',
    'PRO7': 'ProSieben.de',
    'PRO 7': 'ProSieben.de',
    'PROSIEBEN': 'ProSieben.de',
    'PRO7 MAXX': 'ProSieben.MAXX.de',
    'PROSIEBEN MAXX': 'ProSieben.MAXX.de',
    'PRO7 FUN': 'ProSieben.Fun.de',
    'PROSIEBEN FUN': 'ProSieben.Fun.de',
    'KABEL1': 'kabel.eins.de',
    'KABEL 1': 'kabel.eins.de',
    'KABEL EINS': 'kabel.eins.de',
    'KABEL1 DOKU': 'kabel.eins.Doku.de',
    'KABEL 1 DOKU': 'kabel.eins.Doku.de',
    'KABEL EINS DOKU': 'kabel.eins.Doku.de',
    'KABEL1 CLASSICS': 'kabel.eins.classics.de',
    'KABEL 1 CLASSICS': 'kabel.eins.classics.de',
    'N TV': 'ntv.de',
    'N-TV': 'ntv.de',
    'NTV': 'ntv.de',
    'N24': 'WELT.de',
    'N24 DOKU': 'N24.DOKU.de',
    'WELT': 'WELT.de',
    'SPORT1': 'SPORT1.de',
    'SPORT 1': 'SPORT1.de',
    'SPORT1 PLUS': 'SPORT1+.de',
    'SPORT 1 PLUS': 'SPORT1+.de',
    'EUROSPORT': 'Eurosport.1.de',
    'EUROSPORT 1': 'Eurosport.1.de',
    'EUROSPORT 2': 'Eurosport.2.de',
    'DAZN': 'DAZN.de',
    'DAZN 1': 'DAZN.1.de',
    'DAZN1': 'DAZN.1.de',
    'DAZN 2': 'DAZN.2.de',
    'DAZN2': 'DAZN.2.de',
    'COMEDY CENTRAL': 'Comedy.Central.de',
    'NICK': 'nick.de',
    'NICKELODEON': 'nick.de',
    'KIKA': 'KIKA.de',
    'TOGGO PLUS': 'TOGGO.plus.de',
    'MTV LIVE': 'MTV.Live.HD.de',
    'MTV LIVE HD': 'MTV.Live.HD.de',
    'NATIONAL GEOGRAPHIC': 'Nat.Geo.HD.de',
    'NAT GEO': 'Nat.Geo.HD.de',
    'NAT GEO WILD': 'NAT.GEO.WILD.de',
    'HISTORY': 'The.HISTORY.Channel.de',
    'THE HISTORY CHANNEL': 'The.HISTORY.Channel.de',
    'SYFY': 'SyFy.de',
    'SCI FI': 'SyFy.de',
    '13TH STREET': '13th.Street.Universal.de',
    'WARNER TV FILM': 'Warner.TV.Film.de',
    'WARNER TV SERIE': 'Warner.TV.Serie.de',
    'WARNER TV COMEDY': 'Warner.TV.Comedy.de',
}


def _read_text(path):
    for enc in ('utf-8-sig', 'utf-8', 'cp1252'):
        try:
            with open(path, 'r', encoding=enc) as fh:
                return fh.read()
        except UnicodeDecodeError:
            continue
    with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
        return fh.read()


def _write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8', newline='') as fh:
        fh.write(text)
    os.replace(tmp, path)


def _load_source_xml():
    req = Request(SOURCE_URL, headers={'User-Agent': USER_AGENT})
    raw = urlopen(req, timeout=45).read()
    return gzip.decompress(raw)


def _parse_channels(root):
    channels = {}
    for ch in root.findall('channel'):
        cid = ch.get('id', '')
        if not cid:
            continue
        names = [(e.text or '').strip() for e in ch.findall('display-name') if (e.text or '').strip()]
        channels[cid] = names
    return channels


def _build_match_index(channels):
    index = {}
    for cid, names in channels.items():
        keys = [cid, cid.replace('.', ' '), re.sub(r'\.de$', '', cid, flags=re.I)] + names
        for key in keys:
            nk = _norm(key)
            if nk and nk not in index:
                index[nk] = cid
    for alias, cid in ALIASES.items():
        if cid in channels:
            index[_norm(alias)] = cid
    return index


def _attrs(line):
    return {m.group(1): m.group(2) for m in ATTR_RE.finditer(line)}


def _set_attr(line, key, value):
    if re.search(r'%s="[^"]*"' % re.escape(key), line):
        return re.sub(r'%s="[^"]*"' % re.escape(key), '%s="%s"' % (key, value), line, count=1)
    return line.replace('#EXTINF:', '#EXTINF:%s="%s" ' % (key, value), 1)


def _display_name(line):
    return line.rsplit(',', 1)[-1].strip() if ',' in line else ''


def _canonical_id_for(extinf_line, index, channels):
    attrs = _attrs(extinf_line)
    candidates = [
        _display_name(extinf_line),
        attrs.get('tvg-name', ''),
        attrs.get('tvg-id', ''),
    ]
    for candidate in candidates:
        if candidate in channels:
            return candidate
        nk = _norm(candidate)
        if nk in index:
            return index[nk]
        if nk in ALIASES and ALIASES[nk] in channels:
            return ALIASES[nk]
    return ''


def normalize_m3u(path, index, channels):
    if not path or not os.path.exists(path):
        return {'path': path, 'entries': 0, 'changed': 0, 'matched': 0}
    text = _read_text(path)
    lines = text.splitlines()
    changed = 0
    matched = 0
    entries = 0
    out = []
    for line in lines:
        if line.startswith('#EXTINF'):
            entries += 1
            cid = _canonical_id_for(line, index, channels)
            if cid:
                matched += 1
                new_line = _set_attr(line, 'tvg-id', cid)
                if new_line != line:
                    changed += 1
                    line = new_line
        out.append(line)
    if changed:
        _write_text(path, '\n'.join(out) + '\n')
    return {'path': path, 'entries': entries, 'changed': changed, 'matched': matched}


def build_logo_map(paths, channels):
    logo_map = {}
    for path in (paths or []):
        if not path or not os.path.exists(path):
            continue
        for line in _read_text(path).splitlines():
            if not line.startswith('#EXTINF'):
                continue
            attrs = _attrs(line)
            cid = attrs.get('tvg-id', '')
            logo = attrs.get('tvg-logo', '')
            if cid in channels and logo and cid not in logo_map:
                logo_map[cid] = logo
    return logo_map


def apply_logo_map(path, logo_map, channels):
    if not path or not os.path.exists(path) or not logo_map:
        return {'path': path, 'entries': 0, 'changed': 0, 'logos': 0}
    text = _read_text(path)
    lines = text.splitlines()
    out = []
    entries = 0
    changed = 0
    logos = 0
    for line in lines:
        if line.startswith('#EXTINF'):
            entries += 1
            attrs = _attrs(line)
            cid = attrs.get('tvg-id', '')
            logo = logo_map.get(cid, '')
            if cid in channels and logo:
                logos += 1
                new_line = _set_attr(line, 'tvg-logo', logo)
                if new_line != line:
                    changed += 1
                    line = new_line
        out.append(line)
    if changed:
        _write_text(path, '\n'.join(out) + '\n')
    return {'path': path, 'entries': entries, 'changed': changed, 'logos': logos}


def _wanted_ids_from_m3u(path, channels):
    wanted = set()
    if not os.path.exists(path):
        return wanted
    for line in _read_text(path).splitlines():
        if not line.startswith('#EXTINF'):
            continue
        cid = _attrs(line).get('tvg-id', '')
        if cid in channels:
            wanted.add(cid)
    return wanted


def _ensure_channel_icon(channel_node, logo):
    if not logo:
        return
    icon = channel_node.find('icon')
    if icon is None:
        icon = ET.SubElement(channel_node, 'icon')
    icon.set('src', logo)


def write_filtered_epg(root, wanted_ids, out_path, logo_map=None):
    wanted = set(wanted_ids)
    logo_map = logo_map or {}
    today = datetime.now().strftime('%Y%m%d')
    tv = ET.Element('tv', root.attrib)
    channel_count = 0
    programme_count = 0
    for ch in root.findall('channel'):
        if ch.get('id', '') in wanted:
            _ensure_channel_icon(ch, logo_map.get(ch.get('id', ''), ''))
            tv.append(ch)
            channel_count += 1
    for programme in root.findall('programme'):
        if programme.get('channel', '') in wanted:
            stop_date = (programme.get('stop', '') or programme.get('start', ''))[:8]
            if stop_date.isdigit() and stop_date < today:
                continue
            tv.append(programme)
            programme_count += 1
    xml = ET.tostring(tv, encoding='utf-8', xml_declaration=True)
    _write_text(out_path, xml.decode('utf-8'))
    return {'channels': channel_count, 'programmes': programme_count, 'size': os.path.getsize(out_path)}


def _programme_date_bounds(root):
    starts = []
    for programme in root.findall('programme'):
        start = programme.get('start', '')[:8]
        if start.isdigit():
            starts.append(start)
    if not starts:
        return None, None
    return min(starts), max(starts)


def cleanup_epg_caches(cache_dirs, max_age_seconds=7200):
    removed = 0
    now = time.time()
    for cache_dir in cache_dirs or []:
        if not cache_dir or not os.path.isdir(cache_dir):
            continue
        for name in os.listdir(cache_dir):
            path = os.path.join(cache_dir, name)
            try:
                if os.path.isfile(path) and now - os.path.getmtime(path) > max_age_seconds:
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
    return removed


def refresh(shared_epg_path, m3u_paths, meta_path=None, force=False, min_age_hours=12, cache_dirs=None,
            logo_source_paths=None, logo_target_paths=None):
    now = time.time()
    if not force and os.path.exists(shared_epg_path) and meta_path and os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as fh:
                meta = json.load(fh)
            if now - float(meta.get('updated_at', 0)) < min_age_hours * 3600:
                cleanup = cleanup_epg_caches(cache_dirs or [])
                meta['skipped'] = True
                meta['cache_removed'] = cleanup
                return meta
        except Exception:
            pass

    xml = _load_source_xml()
    root = ET.fromstring(xml)
    channels = _parse_channels(root)
    index = _build_match_index(channels)
    playlist_results = [normalize_m3u(path, index, channels) for path in (m3u_paths or [])]
    logo_map = build_logo_map(logo_source_paths or m3u_paths or [], channels)
    logo_results = [apply_logo_map(path, logo_map, channels) for path in (logo_target_paths or [])]
    wanted = set()
    for path in (m3u_paths or []):
        wanted.update(_wanted_ids_from_m3u(path, channels))
    epg_result = write_filtered_epg(root, wanted, shared_epg_path, logo_map=logo_map)
    first_date, last_date = _programme_date_bounds(root)
    cache_removed = cleanup_epg_caches(cache_dirs or [])
    result = {
        'source': SOURCE_URL,
        'updated_at': now,
        'updated_at_iso': datetime.now().isoformat(timespec='seconds'),
        'source_channels': len(channels),
        'source_programmes': len(root.findall('programme')),
        'source_first_date': first_date,
        'source_last_date': last_date,
        'wanted_channels': len(wanted),
        'filtered_epg': epg_result,
        'playlists': playlist_results,
        'logo_sources': len(logo_map),
        'logo_targets': logo_results,
        'cache_removed': cache_removed,
        'skipped': False,
    }
    if meta_path:
        _write_text(meta_path, json.dumps(result, ensure_ascii=False, indent=2))
    return result
