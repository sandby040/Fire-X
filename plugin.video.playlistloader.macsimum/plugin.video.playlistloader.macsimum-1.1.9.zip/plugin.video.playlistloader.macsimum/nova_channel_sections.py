"""Live TV 3 presentation only: country -> general / sport.

No requests, login, player, URL rewriting, playlist writes or MAC state.
Unknown names stay in general. Re-evaluate refreshed lists by name, not IDs.
Country aliases keep START World (drama) separate from Старт (sport).
References: PC report live3_country_sport_split_20261020.
"""
import re
import unicodedata

REVISION = 'country-sections-20261020-6-brand-logos-verified'
GENERAL_MODE, SPORT_MODE = 52, 53
SECTION_MODES = (GENERAL_MODE, SPORT_MODE)
FOLDER_ICONS = {
    GENERAL_MODE: 'special://home/addons/plugin.video.playlistloader.macsimum/resources/images/nova-tv-general.png',
    SPORT_MODE: 'special://home/addons/plugin.video.playlistloader.macsimum/resources/images/nova-tv-sport.png',
}
COUNTRIES = frozenset(('live_tv at ch nl be england us ca fr it es pt pl al rs me '
    'hr si mk ba exyu_allgemein gr ro bg hu cz sk dk se no fi ru ua ge az am au '
    'br co pe arabic_general ma dz sa lb tn kw sd eg ps ae bh iq jo qa sy '
    'kurdish suryoyo ir in pk africa dstv thailand').split())


def folder_icon(mode):
    return FOLDER_ICONS.get(mode, 'DefaultFolder.png')


def country_key(path):
    name = str(path or '').replace('\\', '/').rsplit('/', 1)[-1]
    match = re.fullmatch(r'stalker_macsimum_(.+)\.m3u', name, re.I)
    key = match.group(1).lower() if match else ''
    return key if key in COUNTRIES else ''


def clean_name(value):
    value = unicodedata.normalize('NFKC', str(value or ''))
    value = re.sub(r'\[/?(?:COLOR[^\]]*|B|I|U)\]', '', value, flags=re.I)
    value = ''.join(c for c in unicodedata.normalize('NFKD', value)
                    if not unicodedata.combining(c))
    value = value.upper().replace('_', ' ')
    value = re.sub(r'^(?:(?:DE|AT|CH|NL|BE|UK|US|CA|FR|IT|ES|PT|PL|AL|SRB|HR|SLO|'
                   r'RO|BG|HU|CZ|SK|DK|SE|NO|FI|RU|UA|GE|AZ|AM|AU|AUS|BR|COL|PE|'
                   r'IR|IN|IND|PK|AF|DSTV)\s*[:|\-]\s*)+', '', value)
    return ' '.join(value.split())


SPORT_WORDS = re.compile(
    r'\b(?:SPORT\w*|EUROSPORT\w*|SPOR|ESPORT\w*|DAZN|DYN|ESPN\w*|TSN|RDS|'
    r'SUPERSPORT\w*|GOLF\w*|TENNIS|FOOTBALL|FUTBOL|FUTEBOL|FUSSBALL|FOOT\+?|'
    r'CALCIO|SOCCER|LALIGA|BUNDESLIGA|KONFERENZ|DEPORT\w*|FORMUL[AE]?|F1(?:TV)?|'
    r'HOCKEY|KHL|NHL|NBA|NFL|MLB|NCAA|MLS|MMA|UFC|WWE|WRESTLING|'
    r'FIGHT\w*|BOXING|BOXNATION|BOX NATION|CRICKET|CRICLIFE|RACING|'
    r'MOTORVISION|MOTOWIZJA|MOTOGP|SETANTA|PREMIER LEAGUE|FUEL TV)\b', re.I)
RUSSIAN_SPORT = re.compile(
    r'^(?:МАТЧ[! .]|СПОРТ|ФУТБОЛ|ВОЛЕИ?БОЛ|БАСКЕТБОЛ|МИР БАСКЕТБОЛА|'
    r'ХОККЕИ|КОННЫИ МИР|ТВ СПОРТ|ОККО[.]\s*(?:ФУТБОЛ|СПОРТ|ПРАИМ СПОРТ|ЧЕМПИОНАТ)|'
    r'СУСПИЛЬНЕ СПОРТ|УПЛ ТВ|БОКС ТВ|РУССКИИ ЭКСТРИМ|ТОЧКА ОТРЫВА).*$')

# Explicit country-local brands, not generic ARENA / MAX / START guesses.
COUNTRY_PATTERNS = {
    'live_tv': r'^(?:FC BAYERN TV|CLIP MY HORSE TV|SUDWEST:|WEST:)',
    'nl': r'^(?:VIAPLAY|VERSTAPPEN|FORMULE 1 HERHALING|HORSE AND COUNTRY)',
    'england': r'^(?:LFC(?: TV)?|MUTV|LA LIGA TV)\b',
    'us': r'^(?:BIG TEN NETWORK|NESN|MSG\b|ACC NETWORK|SEC NETWORK|PAC[ -]?12|'
          r'EFL\d|EPL\s*\d|THE COWBOY CHANNEL|SPACE CITY HOME NETWORK|OLYMPIC CHANNEL|'
          r'ATLANTA HAWKS|BOSTON CELTIC|BROOKLYN NETS|CHARLOTTE HORNETS|CHICAGO BULLS|'
          r'CLEVELAND CAVELIERS|DALLAS MAVERICKS|DENVER NUGGETS|DETROIT PISTONS|'
          r'GOLDEN STATE WARRIORS|HOUSTON ROCKETS|INDIANA PACERS|LOS ANGELES CLIPPERS|'
          r'LOS ANGELES LAKERS|MEMPHIS GRIZZLIES|MIAMI HEAT|MILWAUKEE BUCKS|'
          r'MINNESOTA TIMBERWOLVES|NEW ORLEANS PELICANS|NEW YORK KNICKS|'
          r'OKLAHOMA CITY THUNDER|ORLANDO MAGIC|PHILADELPHIA 76ERS|PHONEIX SUNS|'
          r'PORTLAND TRAIL BLAZERS|SACREMENTO KINGS|SAN ANTONIO SPURS|TORONTO RAPTORS|'
          r'UTAH JAZZ|WASHINGTON WIZARDS)',
    'fr': r'^(?:L[ \'’]?EQUIPE|EQUIDIA|AUTOMOTO|INFOSPORT|FOOT\+|'
          r'AMAZON PRIME \d|LIGUE 1\+)',
    'it': r'^(?:INTER TV|MILAN TV|LAZIO STYLE|SUPER TENNIS|HORSE TV|AMAZON PRIME VIDEO EVENT)',
    'es': r'^(?:GOL TV|REAL MADRID TV|MOVISTAR (?:VAMOS|LA LIGA|LIGA DE CAMPEONES))',
    # These masked spellings really occur in the provider's PT catalogue.
    'pt': r'^(?:BENFICA|BTV|PORTO CANAL|SPORTING TV|A BOLA TV|CANAL 11|PFC|'
          r'D\*\*N(?:\s|\d)|S\*\*\*T(?:\s|ING)|E\*\*\*\*N S\*\*\*T|EUROS\*\*\*T)',
    'pl': r'^(?:CANAL\+ (?:EXTRA \d|LIVE(?: EVENT)? \d)|POLSAT GAMES)\b',
    'hr': r'^HAJDUK TV\b',
    'exyu_allgemein': r'^(?:ZVEZDA TV|TV PARTIZAN|SOS KANAL|HAJDUK TV)\b',
    'rs': r'^(?:ZVEZDA TV|TV PARTIZAN|SOS KANAL)\b',
    'ro': r'^(?:PRO-X|PRO ARENA)\b',
    'bg': r'^(?:RING|BNT 3)\b',
    'hu': r'^(?:M4|ARENA 4|MATCH 4)(?:\b|$)',
    'se': r'^(?:C MORE LIVE|ATG LIVE|TV4 MOTOR|V4 HOCKEY)\b',
    'fi': r'^C MORE MAX\b',
    'ru': r'^(?:СТАРТ(?: ТРИУМФ)?|МЯЧ|УДАР|БЕЛАРУСЬ 5 BY|PRIME FIGHT|'
          r'FAST&FUNBOX|RUSSIAN EXTREME ULTRA)(?:\b|$)',
    'az': r'^IDMAN TV\b',
    'br': r'^(?:PREMIERE(?: \d| CLUBES)|COMBATE|OFF)(?:\b|$)',
    'arabic_general': r'^(?:AL AHLY TV|AL KASS|AD YAS)\b',
    'ma': r'^ARRYADIA\b',
    'ir': r'^(?:IRIB VARZESH|VARZISH)\b',
    'pk': r'^GEO SUPER\b',
    'africa': r'^CANAL\+ TOP 14\b',
    'pe': r'^GOL PERU\b',
}
COUNTRY_PATTERNS = {key: re.compile(value) for key, value in COUNTRY_PATTERNS.items()}


def is_sport(country, name, group=''):
    text = clean_name(name)
    if SPORT_WORDS.search(text) or RUSSIAN_SPORT.match(text):
        return True
    pattern = COUNTRY_PATTERNS.get(country)
    if pattern and pattern.search(text):
        return True
    return clean_name(group) in ('SPORT', 'SPORTS', 'SPORTSENDER', 'СПОРТ')


def filter_channels(channels, country, mode):
    if not country or mode not in SECTION_MODES:
        return list(channels)
    want_sport = mode == SPORT_MODE
    return [channel for channel in channels
            if is_sport(country, channel.get('display_name', ''),
                        channel.get('group_title', '')) == want_sport]
