"""Live TV 3: verified local art, then working native/list icon sources.

Art only: do not rewrite URLs, IDs, commands, native sessions or player state.
No downloads or catalogue requests during browsing. Native image parameters
are NOT reachability guarantees; never discard working list art for dead hosts.
"""
from urllib.parse import parse_qs, urlsplit
import hashlib
import json
import os
import re

DEFAULT_CHANNEL_ICON = 'DefaultTVShows.png'
# Confirmed DNS failures / repeated timeouts, not a live per-row probe.
BLOCKED_HOSTS = frozenset(('tvlogolar.xyz', 'logo.eu01.live', 'xc.contact',
                           'logo.sltv.site', 'ottplanet.live'))
_REGISTRY = None


def brand_key(label):
    """Explicit shared-logo families, not fuzzy EPG/channel-name matching.

    Allows a refreshed list/new group ID to keep its verified local logo.
    Magenta Music, DAZN and other Sky channels must never match these rules.
    """
    label = ' '.join(str(label or '').upper().replace('_', ' ').split())
    label = re.sub(r'^DE\s*[:|]\s*', '', label)
    quality = r'(?: (?:FHD|HD|HEVC|RAW|UHD|SD|4K|2K|H265|H264|BKS|NEU))*'
    if re.fullmatch(r'MAGENTA SPORT(?: \d+)?' + quality, label):
        return 'magenta_sport'
    if re.fullmatch(r'SKY(?: SPORT)? BUNDESLIGA(?: \d+| KONFERENZ)?' + quality, label):
        return 'sky_bundesliga'
    if re.fullmatch(r'MDR(?: SACHSEN(?:-ANHALT)?| TH| THÜRINGEN| THURINGEN)?' + quality, label):
        return 'mdr'
    return ''


def art_key(source_url):
    parsed = urlsplit(str(source_url or ''))
    q = parse_qs(parsed.query)
    if (parsed.scheme != 'plugin' or parsed.netloc != 'plugin.video.stalker.macsimum'
            or q.get('action') != ['codex_macsimum_bridge_play']):
        return ''
    country, group = q.get('source_country', [''])[0], q.get('source_group', [''])[0]
    identity = ('group', country, group) if country and group else (
        'channel', q.get('cmd', [''])[0], q.get('label', [''])[0])
    return hashlib.sha256(json.dumps(identity, ensure_ascii=False).encode('utf-8')).hexdigest()


def _registry():
    global _REGISTRY
    if _REGISTRY is None:
        try:
            with open(os.path.join(os.path.dirname(__file__), 'resources', 'channel_art.json'),
                      encoding='utf-8') as handle:
                _REGISTRY = json.load(handle)
        except (OSError, ValueError):
            _REGISTRY = {}
    return _REGISTRY


def _local_asset(filename):
    if not re.fullmatch(r'[0-9a-f]{64}\.(?:png|jpg|webp)', str(filename or '')):
        return ''
    if os.path.isfile(os.path.join(os.path.dirname(__file__), 'resources', 'channel_logos', filename)):
        return 'special://home/addons/plugin.video.playlistloader.macsimum/resources/channel_logos/' + filename
    return ''


def usable(image):
    if not image:
        return False
    try:
        host = (urlsplit(str(image)).hostname or '').lower().removeprefix('www.')
        if host in BLOCKED_HOSTS:
            return False
        digest = hashlib.sha256(str(image).encode('utf-8')).hexdigest()
        return digest not in _registry().get('unavailable_images', [])
    except ValueError:
        return False


def icon_for(source_url, fallback=''):
    try:
        parsed = urlsplit(str(source_url or ''))
        query = parse_qs(parsed.query)
        if (parsed.scheme != 'plugin'
                or parsed.netloc != 'plugin.video.stalker.macsimum'
                or query.get('action') != ['codex_macsimum_bridge_play']):
            return fallback
        local = _local_asset(_registry().get('by_identity', {}).get(art_key(source_url)))
        if local:
            return local
        local = _local_asset(_registry().get('by_brand', {}).get(
            brand_key(query.get('label', [''])[0])))
        if local:
            return local
        native_icon = query.get('icon', [''])[0].strip()
        # An icon PARAMETER is not proof that its image host works. Keep good
        # old list art if the native host is known broken. No HTTP in the GUI.
        for candidate in (native_icon, fallback):
            digest = hashlib.sha256(str(candidate or '').encode('utf-8')).hexdigest()
            cached = _local_asset(_registry().get('by_image', {}).get(digest))
            if cached:
                return cached
            if usable(candidate):
                return candidate
        return DEFAULT_CHANNEL_ICON
    except (TypeError, ValueError):
        return fallback
